"""Rebuild split systems for the 17 earlier rank-eight exclusions and verify coverage."""
import json
import os
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
work = root / "v2/work"
os.chdir(work)
sys.path.insert(0,str(work))
sys.argv = sys.argv[:1]
import combine as C
R = C.R

def require(condition, reason):
    if not condition:
        raise ValueError(reason)

def read(path):
    return json.loads(path.read_text())

def splits(profile):
    budget = 43 - profile[0] - profile[2]
    return [s for s in R.splits(profile+(8,),98)
            if C.permitted(s[:3]) + C.permitted(R.inverse(s[:3],profile)) <= budget]

def anchor(profile):
    key = R.key(profile)
    saved = read(work/f"anchor98_{key}.json")
    require(saved["profile"] == list(profile+(8,)),key)
    # The old anchor used a larger allowed set. Rebuild that superset from the
    # saved leaves and layers, then check it covers every currently allowed split.
    final_rows = list(map(tuple,saved["surviving_splits"]))
    start = set(final_rows)
    for layer in saved["layers"]:
        start.update(R.read_key(name)+(1,) for name in layer)
    require(set(splits(profile)) <= start, ('anchor coverage',key))
    ss = list(start)
    for layer in saved["layers"]:
        both = {s[:3] for s in ss} | {R.inverse(s[:3],profile) for s in ss}
        for name,witness in layer.items():
            require(R.read_key(name) in {s[:3] for s in ss}, name)
            R.verify(R.conditional(profile,R.read_key(name),both),witness)
        ss = [s for s in ss if R.key(s[:3]) not in layer]
    require(set(ss) == set(final_rows),key)
    ss = final_rows
    if saved["final"]:
        R.verify(R.affine_system(profile+(8,),98,ss),saved["final"])
    return ss, bool(saved["final"])

front = {(0,73,17),(15,68,2)}
anchors = {(23,42,8),(2,69,17),(21,46,8),(25,38,8)}
pin = (14,65,5)
centers = {(0,63,23),(1,66,20),(11,66,8),(16,61,5),(18,57,5),(19,50,8),
           (20,53,5),(4,65,17),(5,68,14),(6,71,11)}
from csv import DictReader
start = {tuple(int(row[x]) for x in ('a','b','c'))
         for row in DictReader((work/'remaining_profiles.tsv').open(),delimiter='\t')
         if row['rank']=='8' and row['t']=='98'}
open85 = {R.read_key(row['profile']) for row in DictReader((work/'open98.tsv').open(),delimiter='\t')}
require(len(start)==102 and len(open85)==85 and start-open85==front|anchors|{pin}|centers, 'v2 inventory bridge')
inv = {R.read_key(line) for line in (root/'audit_r6/remaining_rank8.tsv').read_text().splitlines()[1:]}
require(len(inv)==84 and open85-inv=={(0,33,41)} and inv<open85,'quartic inventory bridge')
frontier_certificates = read(root/"v2/t94/frontier_96_98_certs.json")
for profile in sorted(front):
    ss = splits(profile)
    system = R.affine_system(profile+(8,),98,ss)
    certificate = frontier_certificates[R.key((98,)+profile+(8,))]['final']
    R.verify(system,certificate)
    print('frontier',profile,'splits',len(ss),'certificate',json.dumps(certificate),flush=True)
for profile in sorted(anchors|{pin}|centers|{(0,33,41)}):
    ss,done = anchor(profile)
    require(done == (profile in anchors),profile)
    print('anchor',profile,'splits',len(ss),'closed',done,flush=True)
    if profile == pin:
        d = read(work/f'pin_98_{R.key(pin)}.json')
        killed = set(map(tuple,d['killed']))
        ss = [s for s in ss if C.permitted(s[:3])+C.permitted(R.inverse(s[:3],pin))<=43-pin[0]-pin[2]]
        pin_start = list(map(tuple,d['start']))
        require(set(ss) <= set(pin_start), 'pin starting splits')
        ss = pin_start
        for half in killed:
            row=(work/f'out98_{R.key(pin)}_{R.key(half)}.txt').read_text().split()
            budget=43-pin[0]-pin[2]-C.permitted(R.inverse(half,pin))
            require(row[:2]==[R.key(pin),R.key(half)] and row[-2:]==['complete','0']
                    and int(row[2].split('=')[1])>=budget,half)
        rem=[s for s in ss if s[:3] not in killed and R.inverse(s[:3],pin) not in killed]
        require(rem==list(map(tuple,d['rem'])) and not d['layers'],'pin surviving splits')
        R.verify(R.affine_system(pin+(8,),98,rem),d['final'])
        print('pin',pin,'closed after',len(rem),'remaining splits',flush=True)
print('Rank-eight frontier reconciled: 102 = 2 + 4 + 1 + 10 + 1 + 84.')
