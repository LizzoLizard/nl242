"""Build and run the complete shard schedule for the supplied 84 profiles."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess

WEIGHTS = tuple(range(46,83,4))
FOUR_WAY = {(12,30),(12,32),(12,34),(14,32),(14,34)}

def schedule(weights):
    jobs = []
    for n in weights:
        if n != 82:
            jobs.append((n,0,0,0,1))
            continue
        for m in range(8,19,2):
            for side in range(2*m,37,2):
                if side == 18:
                    continue
                parts = 4 if (m,side) in FOUR_WAY else 1
                for index in range(parts):
                    jobs.append((n,m,side,index,parts))
    costs = {(12,34):100,(12,32):70,(12,30):52,(14,34):42,(14,32):35}
    return sorted(jobs,key=lambda j: 65 if j[0]==78 else costs.get((j[1],j[2]),0),reverse=True)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('v3',type=Path)
    parser.add_argument('--cores',type=int,default=8)
    parser.add_argument('--weights',type=int,nargs='+',choices=WEIGHTS,default=WEIGHTS)
    parser.add_argument('--out',type=Path,default=Path('jobs'))
    args = parser.parse_args()
    if args.cores < 1 or len(set(args.weights)) != len(args.weights):
        parser.error('cores must be positive and weights distinct')
    v = args.v3.resolve()
    q = v/'quartic'
    out = args.out.resolve()
    out.mkdir(exist_ok=True,parents=True)
    executable = out/'finish'
    subprocess.run(['c++','-O3','-std=c++17','-march=native',str(Path(__file__).with_name('finish.cpp')),
                    '-o',str(executable)],check=True)
    lines = (v/'audit_r6/remaining_rank8.tsv').read_text().splitlines()
    inventory = [tuple(map(int,line.split(','))) for line in lines[1:]]

    def run_one(job):
        n,m,side,index,parts = job
        directory = out/'_'.join(map(str,job))
        directory.mkdir(exist_ok=True)
        group = [p for p in inventory if p[1]+p[2]==n]
        cases = ''.join(f'{a} {b} {c}\n' for a,b,c in group)
        cmd = [str(executable),str(q/'shapes'),str(n),'0',str(q/'radial_cuts.txt'),
               *map(str,(m,side,index,parts))]
        with (directory/'log').open('w') as log:
            subprocess.run(cmd,cwd=directory,input=cases,text=True,stdout=log,check=True)
        last = (directory/'log').read_text().splitlines()[-1]
        expected = f'finished {n} profiles {len(group)} m {m} size {side} shard {index} of {parts} pairs '
        if not last.startswith(expected):
            raise ValueError(f'incomplete job {job}: {last}')
        print(last,flush=True)

    with ThreadPoolExecutor(args.cores) as pool:
        list(pool.map(run_one,schedule(args.weights)))

if __name__=='__main__':
    main()
