"""Replay each minimum-side slice with the unmodified v3 scalar hinge checker."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse
import subprocess

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("v3", type=Path)
    parser.add_argument("--out", type=Path, default=Path("reference"))
    parser.add_argument("--cores", type=int, default=8)
    args = parser.parse_args()
    q = args.v3.resolve() / "quartic"
    out = args.out.resolve()
    out.mkdir(exist_ok=True, parents=True)
    exe = out / "hinge"
    subprocess.run(["c++", "-std=c++17", "-O3", "-march=native", str(q / "hinge.cpp"), "-o", str(exe)], check=True)
    inventory = (q / "inventory.txt").read_text()
    jobs = [(82, m, s) for m in range(8, 19, 2) for s in range(2*m, 37, 2) if s != 18]
    jobs += [(78, 0, 0)]
    jobs.sort(key=lambda job: (job[1] == 12, job[1] == 14, job[0] == 78, job[2] == 34, job[2] == 32), reverse=True)
    def worker(job):
        n, m, s = job
        directory = out / f"{n}_{m}_{s}"
        directory.mkdir(exist_ok=True)
        with (directory / "log").open("w") as log:
            subprocess.run([str(exe), str(q / "shapes"), str(n), "0", str(q / "radial_cuts.txt"), str(m), str(s)],
                           input=inventory, text=True, cwd=directory, stdout=log, check=True)
        lines = (directory / "log").read_text().splitlines()
        if len([line for line in lines if line.startswith("totals ")]) != 1:
            raise ValueError(f"Incomplete scalar run: {job}")
        print(*job, lines[-1], flush=True)
    with ThreadPoolExecutor(args.cores) as pool:
        list(pool.map(worker, jobs))

if __name__ == "__main__":
    main()
