"""Verify input digests, full per-core and per-shard coverage, and scalar agreement."""
import argparse
from array import array
from collections import Counter, defaultdict
from hashlib import sha256
import re
import sys
from pathlib import Path

D = Path(__file__).resolve().parent
ROW = re.compile(r"(\d+) p ([0-9a-f]+) size (\d+) pairs (\d+) configurations (\d+) total (\d+)")
END = re.compile(r"finished (\d+) profiles (\d+) m (\d+) size (\d+) shard (\d+) of (\d+) pairs (\d+) raw (\d+) viable (\d+) survivors (\d+)")
DIGESTS = {
    8: "0c504784d9dc3cbe386b71dafb9555288ae46999e3bb207ce86723f3699a1e00",
    10: "62e0aee4dfe0dd447f1e6514877c6d406388f0bbaf0f79041f8649557dab714a",
    12: "9ffac4ee5979d0402f23037f016e713723b9b0acea898b8dfadec552cfcddd38",
    14: "0c5f976f58c129b46fd172a4822292ec73658e671731757569918a060daedeb2",
    16: "66d02a405c4f1828c397f298370a47c5641d8f2393dd9af56c2e16ad0d70c786",
    18: "344c2a25ad6d13c17f350073785dd3e2ee9f96d7344d2d9657be33ae50631942",
}
def require(value, message):
    if not value:
        raise ValueError(message)

def verified_masks(directory):
    coordinate = [sum(1 << x for x in range(64) if x>>i & 1) for i in range(6)]
    gram = [(coordinate[i] & coordinate[j], int((i^j)==1)) for i in range(6) for j in range(i)]
    result = {}
    for m,digest in DIGESTS.items():
        bs = (directory/f"shapes{m}.bin").read_bytes()
        require(sha256(bs).hexdigest()==digest,m)
        masks = array('Q')
        masks.frombytes(bs)
        if sys.byteorder != 'little':
            masks.byteswap()
        result[m] = set()
        for mask in masks:
            require(mask.bit_count()==m, ('weight',m))
            if any((mask & col).bit_count()%2 for col in coordinate):
                continue
            if all((mask & entry).bit_count()%2==want for entry,want in gram):
                require(mask not in result[m], ('duplicate',m,mask))
                result[m].add(mask)
    return result

def rows(lines):
    result = {}
    cumulative = 0
    for line in lines:
        match = ROW.fullmatch(line)
        if match:
            weight,mask,size,pairs,configs,total=match.groups()
            key = (int(weight),int(mask,16),int(size))
            require(key not in result,'duplicate core row')
            cumulative += int(configs)
            require(cumulative==int(total),'running total')
            result[key] = (int(pairs), int(configs))
    return result

def stage_counts(lines):
    matches = [l.split()[1:] for l in lines if l.startswith("totals ")]
    require(len(matches)==1 and len(matches[0])==4, 'stage counters')
    require(not any(l.startswith('survivor ') for l in lines), 'surviving profile')
    return tuple(map(int,matches[0]))

def add(target,values):
    for i,x in enumerate(values):
        target[i] += x

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('v3',type=Path)
    ap.add_argument('--jobs',type=Path,default=D/'jobs')
    ap.add_argument('--reference',type=Path,default=D/'reference')
    args=ap.parse_args()
    v=args.v3
    shapes=verified_masks(v/'quartic/shapes')
    inv=(v/'audit_r6/remaining_rank8.tsv').read_bytes()
    require(sha256(inv).hexdigest()=='64d29deda0accac9683b68b3b97e55a079b33ec0482a91093c989347e19bea72','frontier hash')
    profiles=[tuple(map(int,l.split(','))) for l in inv.decode().splitlines()[1:]]
    counts=Counter(b+c for a,b,c in profiles)
    require(len(set(profiles))==len(profiles)==84, '84 distinct profiles')
    expected={}
    partitions={}
    for n in counts:
        maxs=max(s for s in range(0,n//2+1,2) if 255*(n-2*s)**2>=n*(256-n))
        for m,cores in shapes.items():
            for s in range(2*m,maxs+1,2):
                if s==18:
                    continue
                salt= (n,m,s) if n==82 else (n,0,0)
                expected.setdefault(salt,set()).update((n,mask,s) for mask in cores)
                k=4 if n==82 and (m,s) in ((12,30),(12,32),(12,34),(14,32),(14,34)) else 1
                partitions[salt]=k
    per_row=Counter()
    all_pairs={}
    aggregated=defaultdict(lambda:[0]*4)
    raw=Counter()
    expected_jobs={(*key,i,k) for key,k in partitions.items() for i in range(k)}
    actual={tuple(map(int,f.parent.name.split('_'))) for f in args.jobs.glob('*/log')}
    require(actual==expected_jobs,('missing or extra jobs',actual^expected_jobs))
    for n,m,s,i,k in sorted(actual):
        d=args.jobs/'_'.join(map(str,(n,m,s,i,k)))
        lines=(d/'log').read_text().splitlines()
        end=END.fullmatch(lines[-1])
        require(end,('missing completion',d))
        weight,profiles_n,mm,size,ii,kk,pc,rc,vc,survivors=map(int,end.groups())
        require((weight,profiles_n,mm,size,ii,kk,survivors)==(n,counts[n],m,s,i,k,0),('header',d))
        r=rows(lines)
        require(set(r)==expected[n,m,s],('missing core rows',d))
        stages=stage_counts(lines)
        require(vc==stages[1]==sum(v[1] for v in r.values()),('viable count',d))
        require(pc==sum((p+k-1-i)//k for p,c in r.values()),('partition residues',d))
        for key,(p,c) in r.items():
            require(all_pairs.setdefault(key,p)==p,'inconsistent orbit count across shards')
            per_row[key]+=c
        add(aggregated[n,m,s],stages)
        raw[n]+=rc
    reference_jobs={k for k in partitions if k[0] in (78,82)}
    found={tuple(map(int,f.parent.name.split('_'))) for f in args.reference.glob('*/log')}
    require(found==reference_jobs,('reference job coverage',reference_jobs^found))
    for key in sorted(reference_jobs):
        d=args.reference/'_'.join(map(str,key))
        lines=(d/'log').read_text().splitlines()
        r=rows(lines)
        require(set(r)==expected[key],('scalar missing core rows',d))
        require(list(stage_counts(lines))==aggregated[key],('scalar stage counts',key))
        for row,(p,c) in r.items():
            require((p,c)==(all_pairs[row],per_row[row]),('scalar core count',row))
    for n,name in ((78,'speed78_fast.log'),(82,'speed82_fast_partial.log')):
        archived=rows((v/'logs'/name).read_text().splitlines())
        for key,(p,c) in archived.items():
            require((p,c)==(all_pairs[key],per_row[key]),('upstream core count',key))
        print(f'n={n} matched all {len(archived)} rows in {name}')
    print('n profiles  canonical_pairs  raw_after_pair_pruning  minimum_side_pass  three_hinges_pass  moment_pass  survivors')
    for n in sorted(counts):
        total = [0]*4
        for k,stages in aggregated.items():
            if k[0]==n:
                add(total,stages)
        print(n,counts[n],sum(p for k,p in all_pairs.items() if k[0]==n),raw[n],*total[1:],0)
    print(f'{len(actual)} accelerated jobs complete. {len(found)} original scalar jobs agree.')
    print('All 84 quartic profiles excluded.')

if __name__=='__main__':
    main()
