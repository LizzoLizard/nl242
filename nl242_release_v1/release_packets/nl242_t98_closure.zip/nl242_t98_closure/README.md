# Agreement count 98

Under the balanced NL242 reductions in the supplied v3 handoff, there are zero remaining profiles at t = 98. The last four have phase rank eight and b+c = 82. Their profiles (a,b,c), counting magnitudes 1, 5 and 3 respectively, are (1,56,26), (0,53,29), (3,62,20) and (2,59,23). This packet contains the computational evidence and the original v3 input. A Lean proof of this closure remains outstanding.

## What was checked

| Enumeration stage | b+c = 78 | b+c = 82 |
|---|---:|---:|
| Profiles tested together | 10 | 4 |
| Canonical pairs of first cells, summed over minimum-side sizes | 14,827 | 81,818 |
| Four-cell configurations after the initial pair bounds, before the third-cell bound | 945,849,169 | 19,404,895,597 |
| Configurations passing the minimum-side test | 106,366,593 | 2,084,802,654 |
| Configurations passing the three common hinge bounds | 9,245 | 2,006 |
| Configurations passing the sorted first-moment bound for at least one profile | 9,197 | 1,946 |
| Surviving configurations | 0 | 0 |

These are enumeration counts. A geometric support can have more than one representation. The original scalar checker and the accelerated checker share the four-cell enumeration. Their per-core counts and four stage totals are compared by `coverage.py`. The project’s earlier partial run supplied 36 core/side rows at weight 82 and 109 rows at weight 78.

For each support passing the three hinge bounds, `direct.py` rebuilds all 256 entries of the signed Walsh transform directly from the defining matrix. It tests the first moment and then exact integer dual inequalities for each profile. The 8,024 weight-82 support/profile pairs produce 2,334 first-moment exclusions, 4,082 single-sublevel exclusions, 1,522 two-level exclusions and 86 exclusions using a supplied radial table. The test sequence also excludes all 92,450 pairs at weight 78. The four hexadecimal words on each line of `supports/82.txt` or `supports/78.txt` are the four 64-point cells, in increasing order of the two outside-coordinate bits.

## Why the tests exclude a profile

Use the v3 quartic and signed-transform reductions, with F the set of b+c intermediate magnitudes, q the normalized quadratic sign and K the symmetric matrix with entries q(i)(−1)^(i·j)q(j). Write S = K 1_F. The high-block equation is 2KD = 28 − 3S + 32u, where D has a positive entries outside F and c negative entries in F. The ternary vector u has p = 43−a−c positive entries and 158−p negative entries. Taking its inner product with S gives ⟨u,S⟩ = 10n−16c, n = b+c. Thus the sum of the p largest entries of S minus the sum of the 158−p smallest entries must reach 10n−16c. The three hinge tests bound this same sum from above. Their derivation and the four-cell minimum-side reduction are in the input’s README and quartic/NOTES.md.

For any integer vector y, the left side of the following inequality is a lower bound for 2⟨KD,y⟩ and the right side is an upper bound. A strict reversal is an exclusion.

    ⟨28−3S,y⟩ + 32(bottom_p(y) − top_(158−p)(y))
       ≤ 2(top_a(Ky outside F) + top_c(−Ky inside F)).

Here top and bottom denote sums of the indicated number of sorted entries. The direct checker evaluates K using its 256 binary negative-entry row masks and arbitrary-precision integer arithmetic.

For a hinge pair (h,l), set H = Σ[max(Sᵢ−h,0) + max(l−Sᵢ,0)]. Feasibility implies H ≥ 10n−16c − ph + (158−p)l. Summing the two pointwise bounds Sᵢ ≤ h+max(Sᵢ−h,0) on positive sites and −Sᵢ ≤ −l+max(l−Sᵢ,0) on negative sites proves this. The checker takes (14,6), (18,6) and (18,10), and uses the smallest required bound among profiles before rejecting a support for the entire group.

Where AVX-512 VBMI is available, the fast path packs 64 signed entries into bytes. A full phase sum has absolute value at most n ≤ 82; each partial phase sum is bounded by the total selected cell weights included in it. The largest hinge displacement is 18, so the hinge differences stay within signed-byte range. In ordinary spectra the non-DC entries from the two opposite cells have total absolute bound at most their combined weight. The cap comparisons omit the DC lane, whose side constraints are checked by cell weights. The scalar path in v3 performs the corresponding operations with integers. The final radial inequalities use wide sums and comparisons. Two runs of the delivered accelerator reproduced all 59 per-job logs byte for byte.

## Independent coverage of the six-dimensional core orbits

A core P of even size m must have coordinate XOR zero and binary Gram matrix J. The six linear and fifteen off-diagonal quadratic moments specify 21 parity constraints. For each of their 2^21 characters, the verifier evaluates its Boolean polynomial on all 64 sites. If the character is negative on w sites, the sum of its products over the m-subsets is the coefficient of z^m in (1−z)^w(1+z)^(64−w). Multiplication by the character of the target moment vector and averaging over the characters counts all labeled admissible subsets.

Independently, the verifier selects a fixed affine basis in each core. It tries each possible image of the origin in a target core and all images for the six basis differences that preserve their pairwise symplectic products. Their nonsingular Gram matrix ensures the six final images form a basis. The induced affine map is unique. The checker verifies the image of every point. Doing this for every pair of supplied cores of the same size proves pairwise inequivalence and gives their stabilizer orders. The affine symplectic group has order 64 × 2^9 × (4−1)(16−1)(64−1) = 92,897,280. Summing group order divided by stabilizer order agrees exactly with the character count at each size. This checks completeness of the actual admissible cores used by the new enumeration.

| m | Inequivalent cores | Admissible labeled subsets |
|---:|---:|---:|
| 8 | 1 | 2,304 |
| 10 | 1 | 71,680 |
| 12 | 3 | 1,569,792 |
| 14 | 7 | 22,800,384 |
| 16 | 23 | 232,985,088 |
| 18 | 65 | 1,717,438,464 |

## Frontier accounting

The v2 certificate replay leaves 22 rank-six and 102 rank-eight profiles at t = 98. The v3 rank-six verifier excludes all 22, including its positive controls. Among rank eight, the two older frontier exclusions, four anchor exclusions, one pin exclusion, ten centered exclusions and the (0,33,41) obstruction account for 18 profiles. The 84 others split into 70 at b+c ≤ 74, ten at 78 and four at 82. Rank-eight lists are reconciled by membership, so no profile is counted twice.

The earlier section reductions, the supplied flag-search and section logs, and their mathematical justification are inputs to this result. The rank-six row searches were rerun. Earlier flag logs were checked against their stated budgets and certificates. This packet does not certify other agreement counts.

## Reproduce the calculation

Run these commands from the directory containing this README. The v3 setup needs a C++17 compiler. The earlier v2 center and rank-six checks also use its Python environment with NumPy and SciPy. The raw quartic checks, direct matrix verification and orbit counts use C++17 and the Python 3.10+ standard library.

```sh
unzip -q input/nl242_t98_v3_for_codex.zip -d input
V="$PWD/input/nl242_t98_v3"
(cd "$V" && sha256sum -c MANIFEST.sha256 && sh setup.sh)
python3 coverage.py "$V"
python3 direct.py "$V"
python3 orbit_mass.py "$V"
```

The commands above verify the archived comparisons, the late supports and the core inventory. To recompute the two large enumerations into fresh directories, run the following. Use fewer concurrent jobs if memory is limited.

```sh
python3 run.py "$V" --cores 8 --out rerun
python3 reference.py "$V" --cores 8 --out scalar_rerun
python3 coverage.py "$V" --jobs rerun --reference scalar_rerun
python3 capture.py "$V" --cores 8 --out supports_rerun
python3 direct.py "$V" --supports supports_rerun
```

The capture replay requires the archived `jobs/*/log` files. It aborts if any of its per-slice logs differs. Each weight-82 shard takes one residue class of the pair ordinal, separately for each core and minimum-side size. `coverage.py` derives the permitted sizes from Parseval, enumerates the admissible cores and checks the residues and cardinalities for every slice. An omitted slice or core fails the replay.

For the earlier stages, run the following commands.

```sh
(cd "$V/v2/work" && python3 replay.py && python3 ../tools98/budcheck.py 98 .)
python3 earlier.py "$V"
(cd "$V/v2/work" && python3 ../tools98/verify_center.py 98 . 0,63,23 1,66,20 11,66,8 16,61,5 18,57,5 19,50,8 20,53,5 4,65,17 5,68,14 6,71,11)
(cd "$V" && python3 audit_r6/verify.py v2 && python3 quartic/check_frontier.py audit_r6 v2)
(cd "$V" && python3 quartic/check_quartic.py --checker sections --weights 46 50 54 58 62 66 70 74)
```
