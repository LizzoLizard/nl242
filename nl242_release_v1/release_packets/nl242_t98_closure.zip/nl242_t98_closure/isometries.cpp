// Count affine symplectic maps taking one six-dimensional point set to another.
// The search chooses the images of a single fixed affine basis of the source.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <vector>
using Mask = std::uint64_t;

int symplectic(int x, int y) {
    int paired = ((x & 21) << 1) | ((x & 42) >> 1);
    return __builtin_parity(static_cast<unsigned>(paired & y));
}
std::vector<int> points(Mask f) {
    std::vector<int> result;
    for (int i=0; i<64; ++i) if ((f >> i) & 1) result.push_back(i);
    return result;
}

struct Basis {
    std::array<int,6> vectors{};
    std::vector<int> coordinates;
    explicit Basis(Mask f) {
        auto source = points(f);
        const int origin = source.front();
        std::array<int,64> coords;
        coords.fill(-1);
        coords[0]=0;
        int rank=0;
        for (int x : source) {
            int v=x^origin;
            if (coords[v]>=0) continue;
            if (rank==6) throw std::runtime_error("basis overflow");
            vectors[rank]=v;
            auto old=coords;
            for (int j=0;j<64;++j) if (old[j]>=0) coords[j^v]=old[j]|(1<<rank);
            ++rank;
        }
        if (rank!=6) throw std::runtime_error("source is not full-dimensional");
        for (int x:source) coordinates.push_back(coords[x^origin]);
    }
};

struct Count {
    const Basis &src;
    Mask target;
    std::array<int,6> image{};
    std::array<Mask,64> nonorth{};
    int origin=0;
    std::uint64_t maps=0;

    void choose(int depth, Mask candidates) {
        if (depth==6) {
            std::array<int,64> action{};
            action[0]=origin;
            for (int j=1;j<64;++j)
                action[j] = action[j&(j-1)] ^ image[__builtin_ctz(static_cast<unsigned>(j))];
            for (int j:src.coordinates)
                if (!((target>>action[j]) & 1)) return;
            ++maps;
            return;
        }
        Mask allowed=candidates;
        for (int j=0;j<depth;++j) {
            Mask positive=nonorth[image[j]];
            allowed &= symplectic(src.vectors[j],src.vectors[depth]) ? positive : ~positive;
        }
        for (;allowed;allowed &= allowed-1) {
            int v=__builtin_ctzll(allowed);
            image[depth]=v;
            choose(depth+1,candidates & ~(Mask(1)<<v));
        }
    }
    std::uint64_t run() {
        for (int x=0;x<64;++x)
            for (int y=0;y<64;++y) if (symplectic(x,y)) nonorth[x] |= Mask(1)<<y;
        auto sites=points(target);
        for (int point:sites) {
            origin=point;
            Mask differences=0;
            for (int site:sites) if (site!=origin) differences |= Mask(1)<<(site^origin);
            choose(0,differences);
        }
        return maps;
    }
};
int main() {
    std::vector<Mask> cores;
    Mask core;
    while (std::cin >> std::hex >> core) cores.push_back(core);
    if (!std::cin.eof() || cores.empty()) return 2;
    for (std::size_t i=0;i<cores.size();++i) {
        Basis source(cores[i]);
        for (std::size_t j=i;j<cores.size();++j) {
            Count counter{source,cores[j]};
            auto count=counter.run();
            if ((i==j)!=(count!=0)) throw std::runtime_error("equivalent cores or missing identity");
            if (i==j) std::cout << std::hex << cores[i] << ' ' << std::dec << count << '\n';
        }
    }
}
