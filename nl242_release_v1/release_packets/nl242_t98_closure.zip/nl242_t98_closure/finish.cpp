#include <algorithm>
#if defined(__AVX512VBMI__)
#include <immintrin.h>
#endif
#include <sstream>
#include <limits>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
#include <unordered_set>
#include <chrono>
using U=uint64_t;
int pop(U x){return __builtin_popcountll(x);}
int parity(int x){return __builtin_parity((unsigned)x);}
int qbit(int x){return parity(x&(x>>1)&21);}
using P3=std::array<int,3>;
using V64=std::array<int,64>;
using V256=std::array<int,256>;
template<size_t N> void walsh(std::array<int,N>& a){
 for(unsigned s=1;s<N;s*=2) for(unsigned i=0;i<N;i+=2*s) for(unsigned j=i;j<i+s;j++){
  int u=a[j],v=a[j+s];a[j]=u+v;a[j+s]=u-v;
 }
}
std::array<U,32768> quadratic{};
std::array<U,128> affine{};
int jpolar=0;
void setup(){
 std::array<U,15> monos{}; int d=0;
 for(int i=0;i<6;i++)for(int j=0;j<i;j++,d++){
  if((i^j)==1)jpolar|=1<<d;
  for(int x=0;x<64;x++)if((x>>i&1)&&(x>>j&1))monos[d]|=U(1)<<x;
 }
 for(int b=1;b<32768;b++)quadratic[b]=quadratic[b&(b-1)]^monos[__builtin_ctz(b)];
 for(int l=0;l<128;l++)for(int x=0;x<64;x++)if(parity(x&l)^(l>>6))affine[l]|=U(1)<<x;
}
bool gram_ok(U p){
 int gram[6]={},sum=0;
 for(U s=p;s;s&=s-1){int x=__builtin_ctzll(s);sum^=x;for(int i=0;i<6;i++) if(x>>i&1)gram[i]^=x;}
 if(sum)return false;
 for(int i=0;i<6;i++) if(gram[i]!=(1<<(i^1)))return false;
 return true;
}

struct Bins{
 std::array<unsigned char,128> weights;
 std::array<unsigned char,128> indices;
 std::array<unsigned short,66> start{};
};
struct Tables{
 std::vector<Bins> bins;
 Tables(U p):bins(32768){
  for(int b=0;b<32768;b++){
   auto& group=bins[b];
   for(int l=0;l<128;l++){
    int w=pop(p^quadratic[b]^affine[l]);group.weights[l]=w;++group.start[w+1];
   }
   for(int j=1;j<66;j++)group.start[j]+=group.start[j-1];
   auto pos=group.start;
   for(int l=0;l<128;l++)group.indices[pos[group.weights[l]]++]=l;
  }
 }
};
// Point transvections and their affine translates preserve the symplectic
// form. Only retain ones that fix the distinguished six-flat set P.
int recover(U m){
 int coeff=0;
 for(int j=0;j<7;j++){
  int x=j==6?0:1<<j;
  if((m>>x&1)^(j==6?0:m&1)) coeff|=1<<j;
 }
 U pure=m^affine[coeff];int bit=0;
 for(int i=0;i<6;i++)for(int j=0;j<i;j++,bit++)if(pure>>((1<<i)|(1<<j))&1)coeff|=1<<(7+bit);
 return coeff;
}
struct Generator {
 std::array<std::array<int,256>,3> index{};
 int reindex(int c)const{return index[0][c&255]^index[1][(c>>8)&255]^index[2][c>>16];}
 std::array<std::array<U,256>,8> bytes{};
 U map(U x) const {
  U v=0;for(int j=0;j<8;j++){v|=bytes[j][x&255];x>>=8;}return v;
 }
};
std::vector<Generator> generators(U p){
 std::vector<Generator> res;
 for(int w=1;w<64;w++)for(int l=0;l<2;l++){
  int dual=((w&21)<<1)|((w&42)>>1); std::array<int,64> perm{};U dest=0;
  for(int x=0;x<64;x++){perm[x]=x^((parity(x&dual)^l)?w:0);if(p>>x&1)dest|=U(1)<<perm[x];}
  if(dest!=p)continue;
  res.emplace_back();auto& tab=res.back().bytes;
  for(int j=0;j<8;j++)for(int v=1;v<256;v++)
   tab[j][v]=tab[j][v&(v-1)] | U(1)<<perm[8*j+__builtin_ctz(v)];
 }
 for(auto& g:res){
  for(int j=0;j<3;j++)for(int b=0;b<8 && 8*j+b<22;b++){
   int c=1<<(8*j+b);
   g.index[j][1<<b]=recover(g.map(quadratic[c>>7]^affine[c&127]));
  }
  for(auto& tab:g.index)for(int v=1;v<256;v++)if(v&(v-1))tab[v]=tab[v&(v-1)]^tab[v&-v];
 }
 return res;
}
using Cutoffs=std::vector<P3>;
long long tested=0;
std::map<P3,long long> passed;
bool count_only=false;
int minimum_side=0;
std::array<U,64> far{};
using Template=std::array<int,129>;
std::vector<Template> library;
int selected_m=0,selected_s=0, shard=0,shards=1;
long long raw_configs=0,selected_pairs=0;
long long input_shapes=0, viable_shapes=0, passed_moment=0, passed_fast=0;
int hinged_min[3]={};
std::set<std::pair<std::vector<int>,int>> sampled;
std::ofstream sample;
long long skip_min=0;
std::set<std::array<U,4>> survivors;
V256 qq;
void test(const std::array<U,4>& f,const Cutoffs& profiles,const V64& ss0,const V64& ss1,const V64& ss2,const V64& ss3){
 ++tested;if(count_only)return;
 int n=profiles.front()[1]+profiles.front()[2];
 const int bound=n-2*minimum_side;
 V256 v{};
 int hist[129]={};
 for(int x=0;x<64;x++){
  int a=ss0[x]+ss1[x],b=ss0[x]-ss1[x],c=ss2[x]-ss3[x],d=ss2[x]+ss3[x];
  v[x]=qq[x]*(a+c);v[x+64]=qq[x]*(b+d);v[x+128]=qq[x]*(a-c);v[x+192]=-qq[x]*(b-d);
 }
 int over14=0,under6=0,over18=0,under10=0;
 for(int x:v){over14+=std::max(x-14,0);under6+=std::max(6-x,0);}
 if(over14+under6<hinged_min[0])return;
 for(int x:v){over18+=std::max(x-18,0);under10+=std::max(10-x,0);}
 if(over18+under6<hinged_min[1] || over18+under10<hinged_min[2])return;
 ++passed_fast;
 int minv=128,maxv=-128;
 for(int x:v){++hist[(x+256)/4];minv=std::min(minv,x);maxv=std::max(maxv,x);}
 auto tops=[&](int count,bool high){
  int ans=0;
  for(int x=high?maxv:minv;count;x+=high?-4:4){int k=std::min(count,hist[(x+256)/4]);ans+=k*x;count-=k;}
  return ans;
 };
 std::array<bool,100> live{};bool active=false;
 for(unsigned i=0;i<profiles.size();i++){
  auto p=profiles[i];int pos=43-p[0]-p[2];
  if(tops(pos,true)-tops(158-pos,false)<10*n-16*p[2])continue;
  live[i]=true;active=true;
 }
 if(!active)return;
 ++passed_moment;
 // Dual weights are a sum of one or more nested lower-level indicators.
 // The true signed ternary input has exactly p positives and 158-p negatives.
 auto apply=[&](const Template& lut) {
  V256 weights{};long long rhs=0;std::array<int,256> yvals{};
  for(int x=0;x<256;x++){
   int y=lut[(v[x]+256)/4];yvals[x]=y;
   weights[x]=qq[x]*y;rhs+=(28-3*v[x])*y;
  }
  walsh(weights);std::array<int,256> ins{},outs{};int ni=0,no=0;
  for(int i=0;i<256;i++){int score=qq[i]*weights[i];
   if(f[i>>6]>>(i&63)&1)ins[ni++]=-score;else outs[no++]=score;
  }
  int needa=0,needc=0;
  for(unsigned i=0;i<profiles.size();i++)if(live[i]){needa=std::max(needa,profiles[i][0]);needc=std::max(needc,profiles[i][2]);}
  std::partial_sort(ins.begin(),ins.begin()+needc,ins.begin()+ni,std::greater<int>());std::partial_sort(outs.begin(),outs.begin()+needa,outs.begin()+no,std::greater<int>());ni=needc;no=needa;
  std::sort(yvals.begin(),yvals.end());
  std::array<long long,257> si{},so{},uy{};
  for(int j=0;j<ni;j++)si[j+1]=si[j]+ins[j];
  for(int j=0;j<no;j++)so[j+1]=so[j]+outs[j];
  for(int j=0;j<256;j++)uy[j+1]=uy[j]+yvals[j];
  bool any=false;
  for(unsigned i=0;i<profiles.size();i++)if(live[i]){
   auto k=profiles[i];int np=43-k[0]-k[2],nn=158-np;
   long long umin=uy[np]-(uy[256]-uy[256-nn]);
   if(2*(so[k[0]]+si[k[2]])<rhs+32*umin)live[i]=false;else any=true;
  }
  return any;
 };
 auto cut=[&](int a,int b,int c,bool){
  if(b==-1000 && a==minv && hist[(minv+256)/4]==1){
    bool any=false;int na=(n+minv)/2;
    for(unsigned i=0;i<profiles.size();i++)if(live[i]){
     int a0=profiles[i][0],c0=profiles[i][2];
     int maxd=a0-2*std::max(0,a0-(136-na))+c0-2*std::max(0,c0-(n-na));
     if(2*maxd < -4-3*minv) live[i]=false;else any=true;
    }
    return any;
  }
  Template lut{};for(int i=0;i<129;i++){int x=4*i-254;lut[i]=(x<=a)+(x<=b)+(x<=c);}
  return apply(lut);
 };
 int mn=*std::min_element(v.begin(),v.end());
 if(!cut(-6,-1000,-1000,true))return;
 for(int t=mn;t<=-2;t+=4)if(!cut(t,-1000,-1000,true))return;
 for(auto xy:{std::pair<int,int>{-6,-2},{-10,-2},{-6,10},{-10,6},{-6,6},{-6,2},{-14,-6},{-2,10}})
  if(!cut(xy.first,xy.second,-1000,false))return;
 for(const auto& lut:library)if(!apply(lut))return;
 for(int a=mn;a<=2;a+=4)for(int b=a;b<=18;b+=4)if(!cut(a,b,-1000,false))return;
 for(int a=mn;a<=-6;a+=4)for(int b=a;b<=6;b+=4)for(int c=b;c<=18;c+=4)if(!cut(a,b,c,false))return;
 std::vector<int> signature(hist,hist+129);
 for(unsigned i=0;i<profiles.size();i++)if(live[i]){
  passed[profiles[i]]++;
  if(sampled.insert({signature,int(i)}).second && sampled.size()<=4000){
    for(U e:f)sample<<std::hex<<e<<" ";sample<<std::dec<<profiles[i][0]<<" "<<profiles[i][1]<<" "<<profiles[i][2]<<std::endl;
  }
 }
 if(std::find(live.begin(),live.end(),true)!=live.end() && survivors.size()<2000)survivors.insert(f);
}
struct Spectra {
 std::vector<V64> phase, plain;
 Spectra(U p):phase(32768),plain(32768){
  for(int b=0;b<32768;b++){
   for(int x=0;x<64;x++){int v=1-2*int((p^quadratic[b])>>x&1);plain[b][x]=v;phase[b][x]=(1-2*qbit(x))*v;}
   walsh(plain[b]);walsh(phase[b]);
  }
 }
 void get(int b,int l,V64& a,V64& v)const{
  int sg=(l&64)?-1:1;
  for(int x=0;x<64;x++){int row=x^(l&63);a[x]=((x==0?64:0)-sg*plain[b][row])/2;v[x]=(8*(1-2*qbit(x))-sg*phase[b][row])/2;}
 }
};
#if defined(__AVX512VBMI__)
using Z=__m512i;
struct Packed {
 static Z pack(const V64& a){signed char x[64];for(int i=0;i<64;i++)x[i]=a[i];return _mm512_loadu_si512(x);}
 static Z indices(){V64 i{};for(int j=0;j<64;j++)i[j]=j;return pack(i);}
 static Z perm(Z z,int l){return _mm512_permutexvar_epi8(_mm512_xor_si512(indices(),_mm512_set1_epi8(l&63)),z);}
 static Z half(const V64& v){V64 d;for(int i=0;i<64;i++)d[i]=v[i]/2;return pack(d);}
 static Z neg(Z z){return _mm512_sub_epi8(_mm512_setzero_si512(),z);}
 static Z add(Z x,Z y){return _mm512_add_epi8(x,y);}
 static Z sub(Z x,Z y){return _mm512_sub_epi8(x,y);}
 static Z plain(Z base,int l){Z z=perm(base,l);return l&64?z:neg(z);}
 static Z phase(Z base,int l,Z q4){return add(q4,plain(base,l));}
 static bool exceeds(Z v,Z cap){return _mm512_cmpgt_epi8_mask(_mm512_abs_epi8(v),cap)&~uint64_t(1);}
 static Z chi(Z x,Z signbits){return sub(_mm512_xor_si512(x,signbits),signbits);}
 static int hinge(Z a,Z b,Z c,Z d,int h,int l){
  Z hi=_mm512_set1_epi8(h),lo=_mm512_set1_epi8(l),zero=_mm512_setzero_si512();
  auto one=[&](Z x){return _mm512_sad_epu8(_mm512_max_epi8(sub(x,hi),zero),zero);};
  auto two=[&](Z x){return _mm512_sad_epu8(_mm512_max_epi8(sub(lo,x),zero),zero);};
  auto f=[&](Z x){return _mm512_add_epi64(one(x),two(x));};
  return _mm512_reduce_add_epi64(_mm512_add_epi64(_mm512_add_epi64(f(a),f(b)),_mm512_add_epi64(f(c),f(d))));
 }
};
#endif
int main(int argc,char** argv){
 if(argc!=9)return 2;
 std::string dir=argv[1];int n=std::stoi(argv[2]);count_only=std::stoi(argv[3]);
 if (n < 46 || n > 82 || (n - 46) % 4) throw std::runtime_error("unsupported weight");
 Cutoffs profiles;int a,b,c;
 std::string line;
 while(std::getline(std::cin,line)){
  std::istringstream row(line); std::string extra;
  if(!(row>>a>>b>>c) || row>>extra || std::min({a,b,c})<0 || a+b+c>256 || 6*a+3*b+5*c!=304 || 43-a-c<0)
   throw std::runtime_error("bad t=98 inventory");
  if(b+c==n)profiles.push_back({a,b,c});
 }
 if(!std::cin.eof() || profiles.empty() || profiles.size()>100 || std::set<P3>(profiles.begin(),profiles.end()).size()!=profiles.size())throw std::runtime_error("profile coverage");
 shard=std::stoi(argv[7]);shards=std::stoi(argv[8]);
 if(shards<=0 || shard<0 || shard>=shards || count_only)throw std::runtime_error("invalid shard");

 for(int k=0;k<3;k++){
  int h=(k==0?14:18),l=(k==2?10:6);hinged_min[k]=100000;
  for(auto p:profiles){int pos=43-p[0]-p[2];hinged_min[k]=std::min(hinged_min[k],10*n-16*p[2]-pos*h+(158-pos)*l);}
 }
 for(int i=0;i<256;i++)qq[i]=1-2*(qbit(i&63)^((i>>6)==3));
 for(int d=0;d<64;d++)for(int x=0;x<64;x++)if(parity(x&d))far[d]|=U(1)<<x;
 sample.open("sample"+std::to_string(n)+".txt");
 if(argc>4){std::ifstream cuts(argv[4]);if(!cuts)throw std::runtime_error("missing cuts");
  Template v;while(cuts>>v[0]){if(v[0]<-100000 || v[0]>100000)throw std::runtime_error("bad cut start");for(int i=1;i<129;i++)if(!(cuts>>v[i]) || v[i]<-100000 || v[i]>100000)throw std::runtime_error("bad cut");library.push_back(v);}if(!cuts.eof() || library.empty())throw std::runtime_error("cut input");
 }
 if(argc>5)selected_m=std::stoi(argv[5]);if(argc>6)selected_s=std::stoi(argv[6]);setup();
 // Pick a minimum half size using Parseval. Then take a globally minimum
 // nondegenerate six-flat inside the chosen half over its transverse slices.
 int maxs=(n/2)&~1;
 while(255*(n-2*maxs)*(n-2*maxs)<n*(256-n)) maxs-=2;
 if (selected_m && (selected_m < 8 || 2*selected_m > maxs || selected_m % 2)) throw std::runtime_error("invalid core size");
 if (selected_s && (!selected_m || selected_s < 2*selected_m || selected_s > maxs || selected_s % 2 || selected_s == 18)) throw std::runtime_error("invalid minimum side");
 for(int m=8;2*m<=maxs;m+=2){
  if(selected_m && selected_m!=m)continue;std::ifstream in(dir+"/shapes"+std::to_string(m)+".bin",std::ios::binary);
  if(!in)throw std::runtime_error("missing orbit file");
  int cores=0; U p;while(in.read((char*)&p,8)){
   if(pop(p)!=m)throw std::runtime_error("wrong core size");
   if(!gram_ok(p))continue;
   ++cores; Tables tw(p);auto gens=generators(p);Spectra spectra(p);V64 a0,s0;spectra.get(0,0,a0,s0);
   for(int size=2*m;size<=maxs;size+=2){
    if(size==18 || (selected_s && selected_s!=size))continue;minimum_side=size;
    long long pairs=0,before=tested; std::unordered_set<U> covered;
    for(int bt=0;bt<32768;bt++)for(int lt=0;lt<128;lt++){
     U T=quadratic[bt]^affine[lt];if(tw.bins[bt].weights[lt]!=size-m)continue;
     // Normalise by the affine shears of the radical (all transverse slices).
     if(pop(T)>(size-2*m)*(size-2*m))continue;
     bool min=true;for(U l:affine)if(pop(p^(l&T))<m){min=false;break;}
     if(!min)continue;
     if(covered.count(T))continue;
     std::vector<U> orbit{T};covered.insert(T);
     for(size_t k=0;k<orbit.size();k++)for(auto& g:gens){
      U next=g.map(orbit[k]);if(covered.insert(next).second)orbit.push_back(next);
     }
     ++pairs;if((pairs-1)%shards!=shard)continue; ++selected_pairs; V64 a1,s1; spectra.get(bt,lt,a1,s1);
     int B=n-2*size;bool oknear=true;V64 caps{},cp{},cm{};
     for(int x=1;x<64;x++){
       cp[x]=B-std::abs(a0[x]+a1[x]);cm[x]=B-std::abs(a0[x]-a1[x]);
       caps[x]=(cp[x]+cm[x])/2;
       if(std::min(cp[x],cm[x])<0){oknear=false;break;}
     }
     if(!oknear)continue;
     std::vector<const Generator*> stab;for(const auto& g:gens)if(g.map(T)==T)stab.push_back(&g);
     std::vector<bool> already(1<<22,false);

#if defined(__AVX512VBMI__)
     using SIMD=Packed;
     Z vcp=SIMD::pack(cp),vcm=SIMD::pack(cm),vcap=SIMD::pack(caps);
     V64 phase4{},sm{};for(int u=0;u<64;u++){phase4[u]=4*qq[u];sm[u]=qq[u]<0?-1:0;}
     Z q4=SIMD::pack(phase4),sgn=SIMD::pack(sm);
     Z sa=SIMD::add(SIMD::pack(s0),SIMD::pack(s1)),sb=SIMD::sub(SIMD::pack(s0),SIMD::pack(s1));
#endif
     for(int bh=0;bh<32768;bh++){
      int br=bh^bt^jpolar;

      const auto& L=tw.bins[bh];const auto& R=tw.bins[br];
      for(int wl=8;wl<=56;wl+=2){
       int need=n-size-wl;
       if(need<wl || need>56 || L.start[wl]==L.start[wl+1] || R.start[need]==R.start[need+1])continue;
       // By choice of a minimum hyperplane, the other pairings have
       // both side sizes >= size as well.
       if(m+wl<size || m+need<size || size-m+wl<size || size-m+need<size) continue;
       #if defined(__AVX512VBMI__)
       Z lb=SIMD::half(spectra.plain[bh]),rb=SIMD::half(spectra.plain[br]);
       Z lph=SIMD::half(spectra.phase[bh]),rph=SIMD::half(spectra.phase[br]);
#endif
       for(int il=L.start[wl];il<L.start[wl+1];il++){
        int i=L.indices[il];int code=(bh<<7)|i;
        if(!stab.empty()){if(already[code])continue;
        std::vector<int> horbit{code};already[code]=true;
        for(size_t oi=0;oi<horbit.size();oi++)for(const auto* g:stab){
         int h2=g->reindex(horbit[oi]);
         if(!already[h2]){already[h2]=true;horbit.push_back(h2);}
        }
        }
        raw_configs+=R.start[need+1]-R.start[need];
#if defined(__AVX512VBMI__)
        Z left=SIMD::plain(lb,i);
        if(SIMD::exceeds(left,vcap))continue;
        Z sleft=SIMD::phase(lph,i,q4);
#else
        V64 a2,s2;spectra.get(bh,i,a2,s2);
        bool okleft=true;for(int x=1;x<64;x++)if(std::abs(a2[x])>caps[x]){okleft=false;break;}
        if(!okleft)continue;
#endif
        for(int jr=R.start[need];jr<R.start[need+1];jr++){
         int j=R.indices[jr];
        ++input_shapes;
#if defined(__AVX512VBMI__)
         Z right=SIMD::plain(rb,j);
         if(SIMD::exceeds(SIMD::add(left,right),vcp)||SIMD::exceeds(SIMD::sub(left,right),vcm))continue;
         Z sr=SIMD::phase(rph,j,q4),sum=SIMD::add(sleft,sr),dif=SIMD::sub(sleft,sr);
         Z va=SIMD::chi(SIMD::add(sa,dif),sgn),vc=SIMD::chi(SIMD::sub(sa,dif),sgn);
         Z vb=SIMD::chi(SIMD::add(sb,sum),sgn),vd=SIMD::chi(SIMD::sub(sum,sb),sgn);
         ++viable_shapes;
         if(SIMD::hinge(va,vb,vc,vd,14,6)<hinged_min[0]){++tested;continue;}
         V64 a2,s2,a3,s3;spectra.get(bh,i,a2,s2);spectra.get(br,j,a3,s3);
#else
         int sg=(j&64)?-1:1;
         const auto& rw=spectra.plain[br];bool ok=true;
         for(int x=1;x<64;x++){int d=-sg*rw[x^(j&63)]/2;
          if(std::abs(a2[x]+d)>cp[x] || std::abs(a2[x]-d)>cm[x]){ok=false;break;}
         }
         if(!ok)continue;
         V64 a3,s3;spectra.get(br,j,a3,s3);
         ++viable_shapes;
#endif
         test({p,p^T,p^quadratic[bh]^affine[i],p^quadratic[br]^affine[j]},profiles,s0,s1,s2,s3);
        }
       }
      }
     }
    }
    std::cout<<n<<" p "<<std::hex<<p<<std::dec<<" size "<<size<<" pairs "<<pairs<<" configurations "<<tested-before<<" total "<<tested<<std::endl;
   }
  }
  if(!cores || !in.eof() || in.gcount())throw std::runtime_error("incomplete core file");
 }
 std::cout<<"totals "<<input_shapes<<" "<<viable_shapes<<" "<<passed_fast<<" "<<passed_moment<<std::endl;
 for(const auto& [p,z]:passed)std::cout<<"survivor "<<p[0]<<","<<p[1]<<","<<p[2]<<" "<<z<<std::endl;
 if(!count_only){std::ofstream out("dsurv"+std::to_string(n)+".txt");for(auto f:survivors)out<<std::hex<<f[0]<<" "<<f[1]<<" "<<f[2]<<" "<<f[3]<<"\n";}
 std::cout<<"finished "<<n<<" profiles "<<profiles.size()<<" m "<<selected_m<<" size "<<selected_s<<" shard "<<shard<<" of "<<shards<<" pairs "<<selected_pairs<<" raw "<<raw_configs<<" viable "<<tested<<" survivors "<<passed.size()<<std::endl;
}
