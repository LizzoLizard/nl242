"""Check saved four-cell supports using 256-bit row masks for the literal integer matrix K."""
import argparse
from collections import Counter
from pathlib import Path

def quadratic(x):
    return (x & (x >> 1) & 85).bit_count() % 2

# K[i,j] = (-1)^(q(i) + i.j + q(j)). K is symmetric.
negative = [sum(1 << j for j in range(256)
                if (quadratic(i) + (i & j).bit_count() + quadratic(j)) % 2)
            for i in range(256)]

def transform_indicator(mask):
    return [mask.bit_count() - 2 * (mask & row).bit_count() for row in negative]

def prefix(scores):
    result = [0]
    for x in sorted(scores):
        result.append(result[-1] + x)
    return result

def top(sums, count):
    return sums[-1] - sums[len(sums)-1-count]

def cuts(minimum, tables):
    def levels(*thresholds):
        return tuple(sum(v <= t for t in thresholds) for v in range(-254,259,4))
    for t in range(minimum,-1,4):
        yield 'sublevel', levels(t)
    for h,l in ((-6,-2),(-10,-2),(-6,10),(-10,6),(-6,6),(-6,2),(-14,-6),(-2,10)):
        yield 'two levels', levels(h,l)
    for table in tables:
        yield 'radial table', table
    for h in range(minimum,3,4):
        for l in range(h,19,4):
            yield 'two levels', levels(h,l)
    for h in range(minimum,-5,4):
        for l in range(h,7,4):
            for k in range(l,19,4):
                yield 'three levels', levels(h,l,k)

def check(mask, profiles, tables, counts):
    n = mask.bit_count()
    S = transform_indicator(mask)
    if any((s - n) % 4 for s in S) or sum(S) != 16*n or sum(s*s for s in S) != 256*n:
        raise ValueError("wrong signed spectrum")
    sums = prefix(S)
    live = []
    for a,b,c in profiles:
        p = 43-a-c
        if top(sums,p) - sums[158-p] < 10*n - 16*c:
            counts['first moment'] += 1
        else:
            live.append((a,c,p))
    if not live:
        return
    for kind, table in cuts(min(S),tables):
        y = [table[(s + 254)//4] for s in S]
        by_value = {}
        for i,w in enumerate(y):
            if w:
                by_value[w] = by_value.get(w,0) | (1 << i)
        Ky = [0]*256
        for w,group in by_value.items():
            Ky = [prev + w*v for prev,v in zip(Ky,transform_indicator(group))]
        outside = prefix(Ky[i] for i in range(256) if not (mask>>i & 1))
        inside = prefix(-Ky[i] for i in range(256) if mask>>i & 1)
        sy = prefix(y)
        base = sum((28-3*s)*w for s,w in zip(S,y))
        still_live = []
        for a,c,p in live:
            lower = base + 32*(sy[p]-top(sy,158-p))
            upper = 2*(top(outside,a)+top(inside,c))
            if lower > upper:
                counts[kind] += 1
            else:
                still_live.append((a,c,p))
        live = still_live
        if not live:
            return
    raise ValueError(f"unexcluded support {mask:x}: {live}")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("v3",type=Path)
    parser.add_argument("--supports",type=Path,default=Path(__file__).resolve().parent/"supports")
    args = parser.parse_args()
    q = args.v3 / "quartic"
    weights = list(map(int,(q/"radial_cuts.txt").read_text().split()))
    if len(weights)%129:
        raise ValueError("truncated table")
    tables = [tuple(weights[i:i+129]) for i in range(0,len(weights),129)]
    inventory = [tuple(map(int,l.split())) for l in (q/"inventory.txt").read_text().splitlines()]
    for n,expected in ((78,9245),(82,2006)):
        profiles = [profile for profile in inventory if sum(profile[1:]) == n]
        lines = (args.supports/f"{n}.txt").read_text().splitlines()
        if len(lines) != expected or len(set(profiles)) != {78:10,82:4}[n]:
            raise ValueError("incomplete inputs")
        counts = Counter()
        for line in lines:
            words = [int(s,16) for s in line.split()]
            if len(words)!=4 or any(w<0 or w>=2**64 for w in words):
                raise ValueError("invalid four-cell support")
            mask = sum(w << (64*i) for i,w in enumerate(words))
            if mask.bit_count()!=n:
                raise ValueError("wrong support weight")
            check(mask,profiles,tables,counts)
        if sum(counts.values()) != len(profiles)*len(lines):
            raise ValueError("profile coverage")
        print(f"n={n} supports={len(lines)} profiles={len(profiles)} strict exclusions={sum(counts.values())} {dict(counts)}",flush=True)

if __name__ == '__main__':
    main()
