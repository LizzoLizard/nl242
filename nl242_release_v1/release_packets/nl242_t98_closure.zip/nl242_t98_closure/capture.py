"""Instrument a private checker copy to save each support passing the three common hinge bounds."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse
import subprocess
import tempfile

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("v3", type=Path)
    parser.add_argument("--out", type=Path, default=Path("supports"))
    parser.add_argument("--cores", type=int, default=8)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    q = args.v3.resolve() / "quartic"
    args.out.mkdir(parents=True, exist_ok=True)
    out = args.out.resolve()
    src = (here / "finish.cpp").read_text()
    target = "++passed_fast;"
    assert src.count(target) == 1
    src = src.replace(target, target + """
    { static std::ofstream out("supports.txt");
      for (U cell : f) out << std::hex << cell << ' ';
      out << '\\n'; if (!out) throw std::runtime_error("support output");
    }
    """)
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        cpp = work / "capture.cpp"
        cpp.write_text(src)
        exe = work / "capture"
        subprocess.run(["c++", "-O3", "-std=c++17", "-march=native", str(cpp), "-o", str(exe)], check=True)
        jobs = [tuple(map(int,d.name.split('_'))) for d in (here / "jobs").iterdir() if d.is_dir() and d.name.split('_')[0] in ('78','82')]
        jobs.sort(key=lambda j: (j[1:3] in ((12,32),(12,34),(14,34)),j[0]==78), reverse=True)
        def one(job):
            n,m,s,i,k=job
            d = work / "_".join(map(str,job))
            d.mkdir()
            cmd = [str(exe), str(q / "shapes"), str(n), "0", str(q / "radial_cuts.txt"), *map(str,job[1:])]
            res = subprocess.run(cmd, cwd=d, input=(q/"inventory.txt").read_text(), text=True, capture_output=True, check=True)
            if res.stdout != (here/"jobs"/d.name/"log").read_text():
                raise ValueError(f"Replay mismatch: {d.name}")
            f = d / "supports.txt"
            return n, f.read_text() if f.exists() else ""
        with ThreadPoolExecutor(args.cores) as pool:
            results = list(pool.map(one, jobs))
        for n in (78,82):
            (out / f"{n}.txt").write_text("".join(rows for weight,rows in results if n==weight))

if __name__ == "__main__":
    main()
