"""Certify complete affine symplectic orbit coverage using character sums and orbit sizes."""
from collections import Counter
from math import comb
from pathlib import Path
import argparse
import subprocess
import tempfile
from coverage import verified_masks

def kval(m,w):
    return sum((-1)**j*comb(w,j)*comb(64-w,m-j)
               for j in range(max(0,m+w-64),min(m,w)+1))

def characters():
    # The 21 coefficients test six first moments and fifteen off-diagonal Gram entries.
    variables = [sum(1<<x for x in range(64) if x>>i & 1) for i in range(6)]
    masks = variables[:]
    targets = [0]*6
    for i in range(6):
        for j in range(i):
            masks.append(variables[i] & variables[j])
            targets.append(int((i^j)==1))
    signed = Counter()
    truth = 0
    sign = 1
    signed[0] = 1
    for z in range(1,1<<len(masks)):
        # Consecutive reflected Gray words toggle the least set bit in the index.
        bit = (z & -z).bit_length()-1
        truth ^= masks[bit]
        if targets[bit]:
            sign = -sign
        signed[truth.bit_count()] += sign
    return signed

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('v3',type=Path)
    args=parser.parse_args()
    cores=verified_masks(args.v3/'quartic/shapes')
    group_size=64*(2**9)*(4-1)*(16-1)*(64-1)
    signed=characters()
    with tempfile.TemporaryDirectory() as tmp:
        exe=Path(tmp)/'isometries'
        subprocess.run(['c++','-O3','-std=c++17',str(Path(__file__).with_name('isometries.cpp')),'-o',str(exe)],check=True)
        for m,group in sorted(cores.items()):
            rows=subprocess.run([str(exe)],input=''.join(f'{mask:x}\n' for mask in sorted(group)),
                                text=True,capture_output=True,check=True).stdout.splitlines()
            stabs={int(row.split()[0],16):int(row.split()[1]) for row in rows}
            if set(stabs)!=group or any(group_size%s for s in stabs.values()):
                raise ValueError('invalid orbit or stabilizer')
            orbit_sum=sum(group_size//s for s in stabs.values())
            numerator=sum(coef*kval(m,w) for w,coef in signed.items())
            if numerator != (1<<21)*orbit_sum:
                raise ValueError((m,'mass mismatch',numerator,orbit_sum))
            print(f'm={m} inequivalent={len(group)} labeled_sets={orbit_sum} Fourier_mass_matches=True',flush=True)

if __name__=='__main__':
    main()
