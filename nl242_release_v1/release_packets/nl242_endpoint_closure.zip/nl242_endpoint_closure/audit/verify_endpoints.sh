#!/bin/sh
set -eu
audit_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
project_dir=$(dirname -- "$audit_dir")
output_dir=$(mktemp -d "${TMPDIR:-/tmp}/nl242-endpoints.XXXXXX")
printf 'Replay files: %s\n' "$output_dir"
cd "$audit_dir"
"${CXX:-c++}" -O3 -std=c++17 -Wall -Wextra -pedantic endpoint_geometries.cpp -o "$output_dir/geometries"
"$output_dir/geometries" > "$output_dir/geometries.txt"
python3 -B endpoint_signings.py "$output_dir/geometries.txt" --high-file "$output_dir/high.txt"
python3 -B bch_signings.py
"${CXX:-c++}" -O3 -std=c++17 -Wall -Wextra -pedantic bch_complement.cpp -o "$output_dir/low"
"$output_dir/low" --all < "$output_dir/high.txt"
if [ "${1:-}" = "--lean" ]; then
    cd "$project_dir"
    if [ -f lean_sources.txt ]; then
        export LEAN_PATH="$output_dir"
        while IFS= read -r source_file; do
            module_name=$(basename "$source_file" .lean)
            printf 'Checking %s\n' "$module_name"
            lean -o "$output_dir/$module_name.olean" "$source_file"
        done < lean_sources.txt
    else
        export LEAN_PATH="$output_dir:$project_dir/t92/lean/build:$project_dir/build${LEAN_PATH:+:$LEAN_PATH}"
        lean -o "$output_dir/Balanced242Z64Switch.olean" t92/lean/Balanced242Z64Switch.lean
    fi
    lean audit/UpperEndpointProfiles.lean
    lean audit/SmallOddDimensions.lean
fi
