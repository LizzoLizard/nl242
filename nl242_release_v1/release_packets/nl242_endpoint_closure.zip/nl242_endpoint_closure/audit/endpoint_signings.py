"""Check the affine orbit mass and all sign cosets for sixteen exceptional frequencies."""
import argparse
from functools import reduce
from math import comb, prod
from operator import xor
from pathlib import Path

from bch_signings import multiply, plane_count, transform


def popcount(x):
    return bin(x).count("1")


def binomial(n, k):
    return comb(n, k) if 0 <= k <= n else 0


def linear_subspaces(n, d):
    return prod(2**n - 2**i for i in range(d)) // prod(2**d - 2**i for i in range(d))


def spanning_zero_sum_sets():
    full = []
    for n in range(7):
        size = 2**n
        # Extract degree 16 in (1+x)^N and (1-x^2)^(N/2).
        total = (binomial(size, 16) + (size-1)*binomial(size//2, 8)) // size
        lower = sum(2**(n-d) * linear_subspaces(n, d) * full[d] for d in range(n))
        full.append(total-lower)
    return full[-1]


def basis(rows):
    pivots = {}
    for row in rows:
        while row and row.bit_length() in pivots:
            row ^= pivots[row.bit_length()]
        if row:
            pivots[row.bit_length()] = row
    return list(pivots.values())


def words(rows):
    result = [0]
    for row in rows:
        result += [v ^ row for v in result]
    return result


def dual_geometry(points):
    ones = 65535
    rows = basis([ones] + [sum(((x >> j) & 1) << i for i, x in enumerate(points))
                           for j in range(6)])
    assert len(rows) == 7
    dependency_words = words(rows)
    assert all(popcount(w) % 2 == 0 for w in dependency_words)
    if any(popcount(w) == 2 for w in dependency_words):
        return None
    pivots = {r.bit_length()-1 for r in rows}
    # Each nonpivot position gives one word in the nullspace. Solve pivot
    # coordinates from lowest to highest. Include the all-one row first.
    null_rows = []
    for j in range(16):
        if j in pivots:
            continue
        w = 1 << j
        for row in sorted(rows):
            if popcount(w & row) % 2:
                w ^= 1 << (row.bit_length()-1)
        null_rows.append(w)
    code = basis([ones] + null_rows)
    assert len(code) == 9 and code[0] == ones
    assert all(popcount(c & d) % 2 == 0 for c in code for d in rows)
    exceptional = [sum(((r >> i) & 1) << j for j, r in enumerate(code[1:])) for i in range(16)]
    assert len(set(exceptional)) == 16
    return exceptional, rows, words([1 << j for j in sorted(pivots)])


def verify_gold_map(exceptional, signings):
    # Coordinates are bit masks in the ascending-column convention of dual_geometry.
    columns = [53, 106, 98, 191, 14, 97, 36, 99]
    assert len(basis(columns)) == 8
    image = [reduce(xor, (col for j, col in enumerate(columns) if a >> j & 1), 250)
             for a in exceptional]
    graph = [x + 16*multiply(x, multiply(x, x)) for x in range(16)]
    assert set(image) == set(graph) and plane_count(set(image)) == 0
    affine = {sum(((popcount(a & p) % 2) ^ b) << i for i,p in enumerate(graph))
              for a in range(256) for b in (0, 1)}
    transported = [sum(((e >> i) & 1) << (p & 15) for i,p in enumerate(image))
                   for e in signings]
    assert {min(e ^ w for w in affine) for e in transported} == {15, 85, 90}


def main(path, high_file):
    orbit_rows = [s.split() for s in path.read_text().splitlines()]
    group_size = 64 * prod(64 - 2**i for i in range(6))
    mass = sum(group_size // int(aut) for _, aut in orbit_rows)
    assert all(int(aut) > 0 and group_size % int(aut) == 0 for _, aut in orbit_rows)
    assert mass == spanning_zero_sum_sets(), (mass, spanning_zero_sum_sets())
    print(f"{len(orbit_rows)} geometries, orbit mass {mass}", flush=True)
    eligible = zero_matches = hits = hit_geometries = 0
    hit_rows = []
    ternary = [(16-2*popcount(i)+1) % 3 - 1 for i in range(65536)]
    for mask, _ in orbit_rows:
        points = [x for x in range(64) if int(mask, 16) >> x & 1]
        assert len(points) == 16 and reduce(xor, points) == 0
        geom = dual_geometry(points)
        if geom is None:
            continue
        eligible += 1
        exceptional, rows, signs = geom
        syndromes = {tuple(popcount(e & r) % 2 for r in rows) for e in signs}
        assert len(signs) == len(syndromes) == 128
        characters = [sum((popcount(a & x) % 2) << i for i,a in enumerate(exceptional))
                      for x in range(256)]
        found = []
        for e in signs:
            high = [ternary[e ^ c] for c in characters]
            if high.count(0) != 120:
                continue
            zero_matches += 1
            small = [0] * 256
            for i, a in enumerate(exceptional):
                small[a] = 1 - 2*((e >> i) & 1)
            assert high == [(s+1) % 3 - 1 for s in transform(small)]
            if all(w == 4*b if b else abs(w) == 12 for w,b in zip(transform(high), small)):
                found.append(e)
                hit_rows.append(" ".join(str((a+1)*small[a]) for a in exceptional))
                print(f"high hit geometry {mask} signing {e:04x} frequencies {exceptional}", flush=True)
        if len(found) == 3:
            verify_gold_map(exceptional, found)
            print("verified affine map to the Gold cube graph and all three signed cosets")
        elif found:
            assert plane_count(set(exceptional)) == 8
            print("eight affine planes on the other exceptional set")
        hits += len(found)
        hit_geometries += bool(found)
    print(f"{eligible} codes with distinct exceptional points, {eligible*128} sign cosets, "
          f"{zero_matches} zero-count matches, {hits} high hits on {hit_geometries} geometries")
    assert (len(orbit_rows), eligible, zero_matches, hits, hit_geometries) == (89, 64, 33, 5, 2)
    if high_file is not None:
        high_file.write_text("\n".join(hit_rows) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("geometry_file", type=Path)
    parser.add_argument("--high-file", type=Path)
    args = parser.parse_args()
    main(args.geometry_file, args.high_file)
