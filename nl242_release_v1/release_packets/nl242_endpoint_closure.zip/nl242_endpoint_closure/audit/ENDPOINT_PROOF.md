# Direct exclusion of the two upper endpoints

The plane switch excludes both \(t=114\) and \(t=116\) using an eight-variable calculation. The only finite search in this argument concerns the exceptional high frequencies and possible signings of their low complement. It uses standard-library Python and C++17. The reduction from the original halves to the pair described below is checked in Lean. The geometric classification and low-signing exclusions are checked by the programs in this directory.

## What the switch gives

Write \(W_u(a)=\sum_x u(x)(-1)^{a\cdot x}\), without normalization. A putative endpoint gives two ternary tables \(u,v\) on \(\mathbb F_2^8\). At every input exactly one of them is nonzero. Both Walsh transforms have absolute values in \(\{4,12\}\). Write \(E=\{a: |W_u(a)|=4\}\) and \(k=|E|\). At 114 the only possibility is \(k=12\). At 116 the possibilities are 12 and 16.

In the project's notation the switch is \(u=U+S_P,\ v=V+\epsilon 1_P\). The signed plane has transform \(2q_8\), so \(W_u=2(H_8+q_8)\). Evaluation at the eight allowed high values gives \(|W_u|=4\) precisely in classes \(A,C\). The transform of \(1_P\) is a signed four on the radical and zero elsewhere. On the radical the original \(W_V\) belongs to \(\{-8,0,8\}\). Off it, \(W_V\) has magnitude 4 or 12. The plane orientation gives complementarity. The Lean theorem [endpoint_switched_blocks](../t92/lean/Balanced242Z64Switch.lean) establishes these output levels and complementarity, and [reduce_to_endpoint_pair](UpperEndpointProfiles.lean) joins them to the exceptional counts without a covering-radius hypothesis.

## The affine evaluation code

Restrict all eight-variable affine functions to \(E\), forming a binary code \(C\) of length \(k\). Each affine hyperplane contains at least four points of \(E\). Here is a direct derivation for the needed even \(k/2\).

For \(d\ne0\), let \(H=\{a:d\cdot a=1\}\), \(m=|E\cap H|\). Inverting \(W_u^2=144-128\,1_E\) gives
\[
  \sum_x u(x)u(x+d)=m-k/2.
\]
The left side is even by pairing \(x,x+d\), so \(m\) is even. Define \(D(x)=u(x)-u(x+d)\), and let \(T\) be the Walsh transform of the signed indicator \(W_u/4\) restricted to \(E\cap H\) and zero elsewhere. Then \(W_D=2W_u1_H\), and inversion modulo three gives \(D+T\equiv0\bmod3\). Parseval and Walsh duality give
\[
 \sum D^2=288-2m,\qquad \sum T^2=256m,\qquad \sum DT=8m.
\]
If \(m=0\) or \(2\), then \(T\in\{-2,0,2\}\), \(|D|\le2\), and the congruence gives \(2D^2=T^2-DT\) pointwise. Summing would give \(576=252m\). This excludes both values. Multiplying \(u\) by a character translates \(E\), so the same lower bound applies to the other side of the hyperplane. The project's [halfspace_small_counts](../Balanced242Sectors.lean) gives the lower bound as well, by representing any ternary table as the signed agreement table of two Boolean halves.

Thus \(E\) affinely spans eight dimensions, \(C\) has dimension nine, and its minimum distance is at least four. All its words have even weight, and it contains the all-one word. If \(k=12\), the \(2^9\) disjoint radius-one Hamming balls would have \(512\cdot13=6656\) elements in a space of size 4096. This disposes of \(t=114\) and the first branch at \(t=116\).

## All geometries at \(k=16\)

Let \(D_c=C^\perp\), of dimension seven. It is even since \(C\) contains one, and contains one since \(C\) is even. Its minimum distance is at least four because the columns \((1,a)\), \(a\in E\), are distinct. Choose a generator matrix of \(D_c\) with the first row all ones. Its columns have the form \((1,x)\) for sixteen distinct points \(x\in\mathbb F_2^6\). Repeated columns would give a weight-two word in \(C\). The points \(X\) span affinely and have vector sum zero by evenness of \(D_c\). Changing the remaining six basis rows acts on \(X\) by an invertible affine map. Conversely, taking the dual and choosing a basis starting with one recovers \(E\) up to an affine change of coordinates and column order.

[The geometry enumerator](endpoint_geometries.cpp) starts with an affine basis, adjoins every unused point up to size fifteen and at size sixteen adds the uniquely determined XOR. Every spanning zero-sum set is reached by adjoining its points in some order starting with an affine basis. Incidence counts only select possible matches. Every merge requires an actual affine bijection matching membership on all 64 points. The orbit counts for sizes 8 through 15 are **3, 6, 14, 30, 69, 136, 295, 596**. The final zero-sum step gives **89** orbits.

The program separately counts the stabilizer of each final representative. Their orbit sizes sum to **7,630,875,426,048**. For an independent count, the number of zero-sum sixteen-subsets in an affine space of size \(N=2^j\) is
\[
  N^{-1}\left[\binom N{16}+(N-1)\binom{N/2}{8}\right]
\]
for \(j\ge1\), by averaging the coefficient of \(z^{16}\) in \(\prod_x(1+\chi(x)z)\) over characters. Subtract the spanning counts of all proper affine subspaces, in increasing dimension. At \(j=6\) this gives the same total. Removing every case in which \(D_c\) has a word of weight two leaves **64** code classes satisfying the distance conditions on both \(C,D_c\).

## All high signings

For a signed indicator \(s:E\to\{\pm1\}\) extended by zero, inversion modulo three uniquely specifies \(u(x)\) as the ternary representative of \(W_s(x)\). Indeed \(W_u=4s\) on \(E\), all other coefficients vanish modulo three, and \(256\equiv4\equiv1\bmod3\). Parseval forces \(|\operatorname{supp}u|=136\). Translating \(u\) in its input and changing its overall sign multiplies \(s\) by a restricted affine sign, so each code requires \(2^{16-9}=128\) sign cosets. These operations preserve the existence of a complementary low block. Likewise a frequency translation multiplies both tables by a character, and an invertible frequency-coordinate change induces the inverse transpose on their inputs.

[The signing enumerator](endpoint_signings.py) reconstructs \(u\) for **all 8,192** cosets. Exactly 33 have the required support size. Each is transformed and checked at all 256 frequencies, including the prescribed small signs. Five pass, on two geometries. Separately, [the Gold-graph check](bch_signings.py) enumerates all sign cosets on \(\{(x,x^3):x\in\mathbb F_{16}\}\). Three work, and field multipliers relate all three modulo affine signs. The checker explicitly maps the three-signing representative to the graph. In the enumerator's bit coordinates the affine map has offset 250 and the images of the eight standard basis vectors under its linear part are \((53,106,98,191,14,97,36,99)\). It has rank eight, takes the sixteen points onto the graph and transports the three signing cosets to masks 15, 85 and 90 modulo affine signs. The other exceptional set contains eight affine planes. The cube graph contains zero, which distinguishes the two geometries under every affine map. The low test runs on all five.

## Excluding every low complement

Put \(L=\{x:u(x)=0\}\), of size 120. A compatible \(v\) is supported on \(L\) and takes a sign at each of its points. Parseval forces 48 low Walsh magnitudes of four and 208 of twelve.

For \(h=u,v\) let \(p_h(a)=(W_h(a)-4)/8\bmod2\), and \(b_h=(-1)^{p_h}\). The integer-valued polynomial for \(W_h\) follows by expanding \(\prod_i(1-2a_i x_i)\) in its defining sum. The values of \(W_h-4\) are all divisible by eight, hence so are its integer multilinear coefficients by finite differences. After division by eight, coefficients of degree at least four vanish modulo two. At degree three the coefficient at \(I\) is \(\sum_x h(x)\prod_{i\in I}x_i\bmod2\). Complementary supports give identical cubic coefficients for \(u,v\), since \(\sum_x\prod_{i\in I}x_i=32\). Consequently \(p_v=p_u+Q\) for a polynomial \(Q\) of degree at most two.

For any candidate \(b=(-1)^{p_u+Q}\) to be \(b_v\), Walsh duality requires
\[
 \sum_{x\in L}v(x)W_b(x)
 =\sum_a W_v(a)b(a)=4\cdot48-12\cdot208=-2304.
\]
Thus the score \(\sum_{x\in L}|W_b(x)|\) must be at least 2304. At equality every nonzero \(W_b(x)\) on \(L\) forces \(v(x)=-\operatorname{sign}W_b(x)\).

[The low-block enumerator](bch_complement.cpp) covers all \(Q\). A constant flips every sign. A linear term shifts the spectrum. Translating \(b\) in frequency only multiplies \(W_b\) by a character. This preserves the score, and multiplying a possible \(v\) by the same character preserves its Walsh cap. Translation alters the homogeneous quadratic part of \(Q\) by a contraction of the common cubic part, since a translated quadratic differs from itself by an affine function. For each high signing the eight contractions have rank eight. The program also computes all 256 translated differences from their truth-table values and verifies that they represent distinct members of that span. The remaining twenty quadratic coefficients give \(2^{20}\) representatives. For each, integer XOR convolution computes all 256 linear-term scores. Sampled score vectors are compared entry by entry with direct sums. Every forced peak is checked again by a direct character sum.

| High sign cosets | Maximum score | Equalities per coset | Outcome |
|---|---:|---:|---|
| Two on the first geometry | 2272 | 0 | Below 2304 |
| Three on the Gold geometry | 2304 | 320 | Every equality determines all 120 signs and gives peak 28 |

A low block requires peak at most 12. There are zero completions, excluding the final \(t=116,k=16\) branch.

## Replay

From the project root, run `sh audit/verify_endpoints.sh` with Python 3.8+ and Clang or GCC. With Lean 4.15.0, `sh audit/verify_endpoints.sh --lean` also checks the endpoint reduction and [four small-dimension witnesses](SmallOddDimensions.lean). The release packet rebuilds the imported Lean modules from source in a fresh temporary directory. In the development checkout the script uses the existing dependency build and rebuilds the switch module. The eight-variable calculation is independent of the separate nine-variable covering-radius replay. The remaining agreement counts have their own proof packets.
