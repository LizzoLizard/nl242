// Enumerate spanning 16-subsets of AG(6,2) with vector sum zero.
// Each discarded set has an explicit affine bijection to a retained set.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <unordered_map>
#include <vector>

using Mask = std::uint64_t;
using Points = std::array<int, 64>;
using Colors = std::array<Mask, 64>;
static Mask bit(int x) { return Mask(1) << x; }
static int has(Mask set, int x) { return int((set >> x) & 1); }
static int weight(Mask set) { return __builtin_popcountll(set); }

// Hash collisions only cause extra affine-map tests.
static Mask mix(Mask x) {
    x ^= x >> 30;
    x *= UINT64_C(0xbf58476d1ce4e5b9);
    x ^= x >> 27;
    x *= UINT64_C(0x94d049bb133111eb);
    return x ^ (x >> 31);
}

struct Geometry {
    Mask set;
    Colors color{};
    Points order{};
    Mask key = 0;
    Geometry(Mask s, const std::array<Mask,64>& hyperplanes) : set(s) {
        int n = weight(s);
        for (int a = 1; a < 64; ++a) {
            int on = weight(s & hyperplanes[a]);
            for (Mask p = s; p; p &= p-1) {
                int x = __builtin_ctzll(p);
                color[x] += mix(1 + (has(hyperplanes[a], x) ? on : n-on));
            }
        }
        std::vector<int> points;
        for (Mask p = s; p; p &= p-1) {
            int x = __builtin_ctzll(p);
            points.push_back(x);
            key += mix(color[x]);
        }
        Points frequency{};
        for (int x : points) {
            for (int y : points) frequency[x] += (color[x] == color[y]);
        }
        std::stable_sort(points.begin(), points.end(), [&](int x, int y) {
            return frequency[x] < frequency[y];
        });
        order[0] = points.front();
        int size = 1;
        Mask span = bit(order[0]);
        for (int x : points) {
            if (has(span, x)) continue;
            for (int i = 0; i < size; ++i) {
                order[size+i] = x ^ order[0] ^ order[i];
                span |= bit(order[size+i]);
            }
            size *= 2;
        }
        if (size != 64) throw std::runtime_error("set does not span");
    }

    std::uint64_t maps(const Geometry& target, bool first_only) const {
        Points image{};
        auto extend = [&](auto&& self, int size, Mask span) -> std::uint64_t {
            if (size == 64) return 1;
            std::uint64_t count = 0;
            for (Mask p = target.set & ~span; p; p &= p-1) {
                int y = __builtin_ctzll(p);
                if (color[order[size]] != target.color[y]) continue;
                Mask next = span;
                bool matches = true;
                for (int i = 0; i < size; ++i) {
                    int t = y ^ image[0] ^ image[i];
                    int x = order[size+i];
                    if (has(set,x) != has(target.set,t) || color[x] != target.color[t]) {
                        matches = false;
                        break;
                    }
                    image[size+i] = t;
                    next |= bit(t);
                }
                if (matches) count += self(self, 2*size, next);
                if (first_only && count) return count;
            }
            return count;
        };
        std::uint64_t count = 0;
        for (Mask p = target.set; p; p &= p-1) {
            image[0] = __builtin_ctzll(p);
            if (color[order[0]] == target.color[image[0]])
                count += extend(extend, 1, bit(image[0]));
            if (first_only && count) break;
        }
        return count;
    }
};

int main() {
    std::array<Mask,64> hyperplanes{};
    for (int a = 1; a < 64; ++a)
        for (int x = 0; x < 64; ++x)
            if (__builtin_parity(a & x)) hyperplanes[a] |= bit(x);
    Mask basis = bit(0);
    for (int j = 0; j < 6; ++j) basis |= bit(1 << j);
    std::vector<Geometry> sets{Geometry(basis, hyperplanes)};
    for (int size = 8; size <= 16; ++size) {
        std::vector<Geometry> next;
        std::unordered_map<Mask,std::vector<int>> buckets;
        for (const auto& old : sets) {
            Mask choices = ~old.set;
            if (size == 16) {
                int sum = 0;
                for (Mask p = old.set; p; p &= p-1) sum ^= __builtin_ctzll(p);
                choices &= bit(sum);
            }
            for (Mask p = choices; p; p &= p-1) {
                Geometry candidate(old.set | (p & -p), hyperplanes);
                auto& bucket = buckets[candidate.key];
                bool duplicate = std::any_of(bucket.begin(), bucket.end(), [&](int j) {
                    return candidate.maps(next[j], true) != 0;
                });
                if (!duplicate) {
                    bucket.push_back(int(next.size()));
                    next.push_back(candidate);
                }
            }
        }
        sets.swap(next);
        std::cerr << size << " points: " << sets.size() << " orbits\n";
    }
    for (const auto& g : sets)
        std::cout << std::hex << g.set << ' ' << std::dec << g.maps(g, false) << '\n';
}
