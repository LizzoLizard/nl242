// Check every quadratic residue phase for the low complement of a valid high block.
// Build with c++ -O3 -std=c++17 bch_complement.cpp -o /tmp/bch_complement.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

using Table = std::array<int, 256>;

static void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

static void walsh(Table& values) {
    for (int half = 1; half < 256; half *= 2) {
        for (int base = 0; base < 256; base += 2 * half) {
            for (int x = base; x < base + half; ++x) {
                const int left = values[x], right = values[x + half];
                values[x] = left + right;
                values[x + half] = left - right;
            }
        }
    }
}

static int field_product(int x, int y) {
    int result = 0;
    while (y) {
        if (y & 1) result ^= x;
        y >>= 1;
        x <<= 1;
        if (x & 16) x ^= 0x13;
    }
    return result;
}

static std::vector<std::vector<int>> quadratic_representatives(const Table& phase) {
    Table anf = phase;
    for (int bit = 1; bit < 256; bit *= 2) {
        for (int x = 0; x < 256; ++x) if (x & bit) anf[x] ^= anf[x ^ bit];
    }
    std::vector<int> pairs;
    for (unsigned x = 0; x < 256; ++x) {
        const int degree = __builtin_popcount(x);
        require(degree <= 3 || !anf[x], "high residue has degree above three");
        if (degree == 2) pairs.push_back(x);
    }
    // The quadratic part of the derivative along bit j is the contraction
    // of the cubic part along j. For this cubic the eight rows are independent.
    std::array<unsigned, 28> pivots{};
    for (int bit = 1; bit < 256; bit *= 2) {
        unsigned row = 0;
        for (unsigned p = 0; p < pairs.size(); ++p) {
            if (!(pairs[p] & bit) && anf[pairs[p] | bit]) row |= 1u << p;
        }
        while (row) {
            const int p = 31 - __builtin_clz(row);
            if (!pivots[p]) {
                pivots[p] = row;
                break;
            }
            row ^= pivots[p];
        }
    }
    // Independently recover the degree-two coefficients of all 256 translated
    // differences from their four Boolean values. They must give precisely
    // the 256 distinct directions spanned by the eight pivot rows.
    std::vector<unsigned> translations;
    for (int shift = 0; shift < 256; ++shift) {
        auto delta = [&](int a) { return phase[a] ^ phase[a ^ shift]; };
        unsigned row = 0;
        for (unsigned p = 0; p < pairs.size(); ++p) {
            int ij = pairs[p], i = ij & -ij, j = ij ^ i;
            if (delta(0) ^ delta(i) ^ delta(j) ^ delta(ij)) row |= 1u << p;
        }
        translations.push_back(row);
        while (row) {
            int p = 31 - __builtin_clz(row);
            require(pivots[p] != 0, "translated phase outside derivative span");
            row ^= pivots[p];
        }
    }
    std::sort(translations.begin(), translations.end());
    require(std::adjacent_find(translations.begin(), translations.end()) == translations.end(),
            "duplicate translation direction");
    std::vector<std::vector<int>> flips;
    for (unsigned p = 0; p < pairs.size(); ++p) {
        if (pivots[p]) continue;
        flips.emplace_back();
        for (int x = 0; x < 256; ++x) if ((x & pairs[p]) == pairs[p]) flips.back().push_back(x);
    }
    require(flips.size() == 20, "unexpected translation rank");
    return flips;
}

static int direct_score(const Table& spectrum, const Table& support, int shift) {
    int score = 0;
    for (int x = 0; x < 256; ++x) if (support[x]) score += std::abs(spectrum[x ^ shift]);
    return score;
}

static int check_low(const Table& exceptional) {
    Table high = exceptional, low_support{}, phase{}, reference_signs{};
    walsh(high);
    for (int x = 0; x < 256; ++x) {
        high[x] = (high[x] % 3 + 4) % 3 - 1;
        low_support[x] = high[x] == 0;
    }
    Table high_spectrum = high;
    walsh(high_spectrum);
    for (int a = 0; a < 256; ++a) {
        const int w = high_spectrum[a];
        require(exceptional[a] ? w == 4 * exceptional[a] : std::abs(w) == 12, "invalid high signing");
        phase[a] = (w - 4) / 8 % 2 != 0;
        reference_signs[a] = 1 - 2 * phase[a];
    }
    // The high signing must reproduce its own spectral inner product.
    Table control = reference_signs;
    walsh(control);
    int control_score = 0;
    for (int x = 0; x < 256; ++x) {
        if (high[x]) {
            control_score -= high[x] * control[x];
        }
    }
    require(control_score == 2816, "high self-pairing norm");
    Table support_spectrum = low_support;
    walsh(support_spectrum);
    require(support_spectrum[0] == 120, "wrong complement cardinality");
    const auto flips = quadratic_representatives(phase);
    const unsigned count = 1u << flips.size();
    constexpr int target = 2304;
    Table signs = reference_signs;
    int equalities = 0, completions = 0;
    int maximum_score = 0;
    std::array<std::int64_t, 257> peak_counts{};

    for (unsigned i = 0; i < count; ++i) {
        if (i) for (int x : flips[__builtin_ctz(i)]) signs[x] = -signs[x];
        Table spectrum = signs;
        walsh(spectrum);
        // Exact integer XOR convolution gives the 256 linear-term scores.
        Table scores = spectrum;
        for (int& value : scores) value = std::abs(value);
        walsh(scores);
        for (int x = 0; x < 256; ++x) scores[x] *= support_spectrum[x];
        const bool audit_sample = (i % 32749 == 0);
        walsh(scores);
        maximum_score = std::max(maximum_score, *std::max_element(scores.begin(), scores.end()));
        for (int d = 0; d < 256; ++d) {
            if (audit_sample) {
                require(scores[d] == 256 * direct_score(spectrum, low_support, d), "convolution mismatch");
            }
            if (scores[d] < target * 256) continue;
            require(scores[d] == target * 256, "score above threshold requires a separate search");
            require(direct_score(spectrum, low_support, d) == target, "equality replay");
            ++equalities;
            Table low{};
            for (int x = 0; x < 256; ++x) {
                if (!low_support[x]) continue;
                int value = spectrum[x ^ d];
                require(value != 0, "equality leaves an undetermined sign");
                low[x] = value > 0 ? -1 : 1;
            }
            Table forced = low;
            walsh(low);
            int peak = 0;
            for (int value : low) peak = std::max(peak, std::abs(value));
            int peak_at = int(std::find_if(low.begin(), low.end(), [peak](int w) {
                return std::abs(w) == peak;
            }) - low.begin());
            int peak_coefficient = 0;
            for (int x = 0; x < 256; ++x)
                peak_coefficient += (__builtin_parity(peak_at & x) ? -1 : 1) * forced[x];
            require(peak_coefficient == low[peak_at], "forced peak failed direct character sum");
            ++peak_counts[peak];
            if (peak <= 12) ++completions;
        }
    }
    std::cout << "quadratic representatives " << count << ", linear terms 256, threshold "
              << target << ", maximum " << maximum_score/256 << ", equalities " << equalities
              << ", completions " << completions << '\n';
    for (int p = 0; p <= 256; ++p) {
        if (peak_counts[p]) std::cout << "peak " << p << " count " << peak_counts[p] << '\n';
    }
    require(completions == 0, "a signing meets the Walsh cap");
    return equalities;
}

int main(int argc, char** argv) {
    if (argc == 1) {
        Table exceptional{};
        for (int x = 0; x < 16; ++x) {
            int cube = field_product(x, field_product(x, x));
            exceptional[x + 16*cube] = 1 - 2*((15 >> x) & 1);
        }
        require(check_low(exceptional) == 320, "extended-BCH replay failed");
        return 0;
    }
    require(argc == 2 && std::string(argv[1]) == "--all", "expected --all or no argument");
    std::string line;
    int cases = 0;
    while (std::getline(std::cin, line)) {
        std::istringstream input(line);
        Table exceptional{};
        for (int i = 0; i < 16; ++i) {
            int v = 0;
            require(bool(input >> v) && v != 0 && -256 <= v && v <= 256, "invalid signed frequency");
            int a = std::abs(v)-1;
            require(!exceptional[a], "repeated frequency");
            exceptional[a] = v > 0 ? 1 : -1;
        }
        std::string extra;
        require(!(input >> extra), "trailing data");
        std::cout << "case " << ++cases << ": " << std::flush;
        check_low(exceptional);
    }
    require(cases == 5, "incomplete high-block list");
}
