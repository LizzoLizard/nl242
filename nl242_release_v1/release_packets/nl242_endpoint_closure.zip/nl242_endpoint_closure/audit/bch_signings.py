"""Enumerate high signings on the cube graph over F_16, modulo affine functions."""
from itertools import combinations


def parity(n):
    return bin(n).count("1") % 2


def multiply(a, b):
    result = 0
    while b:
        if b & 1:
            result ^= a
        b >>= 1
        a <<= 1
        if a & 16:
            a ^= 0x13
    return result


def transform(values):
    if len(values) == 1:
        return values
    evens = transform(values[::2])
    odds = transform(values[1::2])
    return [v for e, o in zip(evens, odds) for v in (e + o, e - o)]


def plane_count(points):
    # Every affine plane has four triples; each triple determines the fourth point.
    triples = sum(a ^ b ^ c in points for a, b, c in combinations(sorted(points), 3))
    assert triples % 4 == 0
    return triples // 4


def main():
    graph = [x + 16 * multiply(x, multiply(x, x)) for x in range(16)]
    code = {sum((parity(a & point) ^ b) << i for i, point in enumerate(graph))
            for a in range(256) for b in (0, 1)}
    assert len(code) == 512
    remaining = set(range(65536))
    hits = []
    tested = 0
    while remaining:
        mask = min(remaining)
        remaining.difference_update(mask ^ word for word in code)
        small = [0] * 256
        for i, point in enumerate(graph):
            small[point] = 1 - 2 * ((mask >> i) & 1)
        u = [(v + 1) % 3 - 1 for v in transform(small)]
        spectrum = transform(u)
        tested += 1
        if not all((w == 4 * e if e else abs(w) == 12) for w, e in zip(spectrum, small)):
            continue
        zeros = {x for x, v in enumerate(u) if v == 0}
        assert len(zeros) == 120 and plane_count(zeros) == 32850
        hits.append(mask)
    assert tested == 128 and hits == [15, 85, 90]
    # The graph is preserved by (x,y) -> (lambda*x, lambda^3*y).
    for mask in hits:
        witnesses = [c for c in range(1, 16)
                     if sum(((15 >> multiply(c, x)) & 1) << x
                            for x in range(16)) ^ mask in code]
        assert witnesses
        print(f"mask {mask}, multiplier {witnesses[0]}, 32850 planes in zero set")
    print(f"{tested} affine sign cosets, {len(hits)} valid, one equivalence class")


if __name__ == "__main__":
    main()
