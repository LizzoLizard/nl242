import Init

/- Balanced witnesses in dimensions one, three, five and seven. The last
   bit is free and the remaining bits occur in disjoint quadratic pairs.
   The unrestricted upper bound follows mathematically by lifting to seven
   variables and invoking Mykkeltveit's published covering-radius theorem. -/
namespace SmallOddDimensions

def parity (x : Nat) : Nat → Bool
  | 0 => false
  | j+1 => parity x j != x.testBit j

def pairSum (x : Nat) : Nat → Bool
  | 0 => false
  | m+1 => pairSum x m != (x.testBit (2*m) && x.testBit (2*m+1))

def witness (m x : Nat) : Bool := x.testBit (2*m) != pairSum x m

def coefficient (m a : Nat) : Int :=
  (List.range (2^(2*m+1))).foldl (fun s x =>
    if witness m x == parity (a &&& x) (2*m+1) then s+1 else s-1) 0

def weightAndPeak (m : Nat) : Nat × Nat :=
  let xs := List.range (2^(2*m+1))
  (xs.countP (witness m), xs.foldl (fun p a => max p (coefficient m a).natAbs) 0)

set_option maxRecDepth 8000
set_option maxHeartbeats 2000000

theorem four_witnesses :
    [0,1,2,3].map weightAndPeak = [(1,2),(4,4),(16,8),(64,16)] := by decide

#print axioms four_witnesses

end SmallOddDimensions
