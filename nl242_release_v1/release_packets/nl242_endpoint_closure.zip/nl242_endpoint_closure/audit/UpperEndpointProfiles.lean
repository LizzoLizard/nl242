import Balanced242Z64Switch

namespace UpperEndpointProfiles
open FrozenShells CandyKnots CollisionLaw SilentRoom Balanced242Parents Balanced242Support
open Balanced242Reduction Balanced242Global Balanced242Rank Balanced242RankCond
open Balanced242LowBlock Balanced242Z64Switch

/-- k counts the high-block coefficients of magnitude four or twelve
    before the switch. The switch turns them into ternary coefficients
    of magnitude four, and turns all other magnitudes into twelve. -/
theorem endpoint_counts (f g : Half) (res : ∀ a, hi f g a % 8 = 4)
    (cap : ∀ a, (hi f g a).natAbs ≤ 28) (dc : lo f g (zero 8) = 0)
    (lores : ∀ a, lo f g a % 8 = 0) (locap : ∀ a, (lo f g a).natAbs ≤ 24)
    (ht : agreements f g = 114 ∨ agreements f g = 116) :
    let k := cnt (clsA f g) + cnt (clsC f g)
    (agreements f g = 114 ∧ k = 12) ∨ (agreements f g = 116 ∧ (k = 12 ∨ k = 16)) := by
  dsimp only
  obtain ⟨hr, _⟩ := t_ge_114_forces_Z64 f g res dc lores locap (by omega)
  have h9 := z64_small_masks_ge_9 f g res cap hr
  have hp := phase_identity f g res cap
  have hm : many 8 = 256 := by decide
  have hgood := rr_good (β8 f g) (cube8 f g res)
  change rr (β8 f g) * cntGood f g = many 8 at hgood
  rw [hr, hm] at hgood
  obtain ⟨K, hK, hbound, _⟩ := phase_div f g res 128 (by decide) (by rw [hr, hm]; decide)
  have hlow : -4 ≤ K := by omega
  omega

/-- The unswitched high coefficient divided by four is H = w/2 - q,
    where w is the switched ternary Walsh coefficient. For either sign q,
    H has the prescribed phase and q*H has an admissible value. -/
theorem phase_of_inverse_switch (w q : Int)
    (hw : w = -12 ∨ w = -4 ∨ w = 4 ∨ w = 12)
    (hq : q = -1 ∨ q = 1) :
    let H := w / 2 - q
    CandyKnots.sign (Balanced242Plateau.bt H) = q ∧
    (q*H = 1 ∨ q*H = -3 ∨ q*H = 5 ∨ q*H = -7) := by
  rcases hw with h|h|h|h <;> rcases hq with e|e <;> subst w <;> subst q <;> decide

#print axioms endpoint_counts
#print axioms phase_of_inverse_switch

/-- The precise finite statement checked by the direct endpoint audit. -/
def EndpointPair (u v : W 8 → Int) : Prop :=
  (∀ x, Balanced242HighSections.complementary (v x) (u x)) ∧
  (∀ a, (transform v a).natAbs = 4 ∨ (transform v a).natAbs = 12) ∧
  (∀ a, (transform u a).natAbs = 4 ∨ (transform u a).natAbs = 12) ∧
  (let k := cnt fun a => decide ((transform u a).natAbs = 4)
   k = 12 ∨ k = 16)

theorem reduce_to_endpoint_pair (f g : Half) (res : ∀ a, hi f g a % 8 = 4)
    (cap : ∀ a, (hi f g a).natAbs ≤ 28) (dc : lo f g (zero 8) = 0)
    (lores : ∀ a, lo f g a % 8 = 0) (locap : ∀ a, (lo f g a).natAbs ≤ 24)
    (ht : agreements f g = 114 ∨ agreements f g = 116) :
    ∃ u v, EndpointPair u v := by
  obtain ⟨u, v, hc, hv, hu⟩ := endpoint_switched_blocks f g res cap dc lores locap ht
  refine ⟨u,v,hc,hv,?_,?_⟩
  · intro a; rw [hu]; split <;> simp
  · have per (a : W 8) :
        ind (fun b => decide ((transform u b).natAbs = 4)) a =
        ind (clsA f g) a + ind (clsC f g) a := by
      have hd := disjAC f g a
      simp only [ind, hu a]
      cases ha : clsA f g a <;> cases hb : clsC f g a <;> simp_all
    have count_eq : cnt (fun b => decide ((transform u b).natAbs = 4)) =
        cnt (clsA f g) + cnt (clsC f g) := by
      unfold cnt; rw [funext per, total_add]
    dsimp only
    rw [count_eq]
    have h := endpoint_counts f g res cap dc lores locap ht
    dsimp only at h
    omega

#print axioms reduce_to_endpoint_pair
end UpperEndpointProfiles
