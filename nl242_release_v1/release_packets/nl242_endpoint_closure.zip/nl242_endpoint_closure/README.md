# Direct endpoint proof for balanced nine-variable functions

Read [the argument and counts](audit/ENDPOINT_PROOF.md). From this directory run

    shasum -a 256 -c SHA256SUMS
    sh audit/verify_endpoints.sh

The finite replay uses Python 3.8+ and a C++17 compiler. To include a fresh
Lean 4.15.0 build of the switch reduction and smaller-dimension witnesses, run

    sh audit/verify_endpoints.sh --lean

All project imports are included as source. The script writes its intermediate
files to a new temporary directory. The unrestricted covering-radius theorem
is unnecessary for this endpoint calculation.
