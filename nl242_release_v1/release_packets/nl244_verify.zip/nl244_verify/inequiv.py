# GL(9,2)-invariants of the 349 listed cubic classes; if all invariants differ, the classes are pairwise inequivalent.
# T(u,v,w) = third derivative; B_v(x,y) = T(v,x,y) (alternating, v in its radical).
import re, sys
from collections import Counter
def parse(fn):
    reps={}
    for l in open(fn,encoding='latin-1'):
        m=re.match(r'^\s*(\d+) h=\S+\s*(.*)$',l)
        if not m: continue
        P=set()
        for t in [t for t in m.group(2).split('+') if t.strip()]:
            t=t.strip(); assert len(t)==3 and len(set(t))==3, t
            P^={sum(1<<(int(ch)-1) for ch in t)}
        reps[int(m.group(1))]=frozenset(P)
    return reps
def rank(rows):
    basis={}; rk=0
    for r in rows:
        while r:
            h=r.bit_length()-1
            if h in basis: r^=basis[h]
            else: basis[h]=r; rk+=1; break
    return rk
def invariants(P):
    # Be[c] = rows of B_{e_c}: B_{e_c}[a] has bit b iff monomial {a,b,c} in P
    Be=[[0]*9 for _ in range(9)]
    for m in P:
        idx=[i for i in range(9) if m>>i&1]
        for c in idx:
            a,b=[i for i in idx if i!=c]
            Be[c][a]|=1<<b; Be[c][b]|=1<<a
    rows={0:[0]*9}
    for v in range(1,512):
        low=v&-v; c=low.bit_length()-1; prev=rows[v^low]
        rows[v]=[x^y for x,y in zip(prev,Be[c])]
    rk={v:rank(rows[v]) for v in range(1,512)}
    def rad(v):
        R=rows[v]; out=[]
        for w in range(1,512):
            s=0; x=w; i=0
            while x:
                if x&1: s^=R[i]
                x>>=1; i+=1
            if s==0: out.append(w)
        return out
    I1=tuple(sorted(Counter(rk.values()).items()))
    I2=tuple(sorted(Counter((rk[v],tuple(sorted(rk[w] for w in rad(v)))) for v in range(1,512)).items()))
    return I1,I2
reps=parse(sys.argv[1]); assert sorted(reps)==list(range(1,350)), len(reps)
assert len(set(reps.values()))==349
inv={i:invariants(P) for i,P in reps.items()}
for lvl,name in ((0,'rank histogram'),(None,'rank+radical profile')):
    key={i:(v[0] if lvl==0 else v) for i,v in inv.items()}
    groups=Counter(key.values()); coll=[g for g,c in groups.items() if c>1]
    print(f"{name}: {len(groups)} distinct values over 349 classes; colliding groups {len(coll)}")
    if lvl is None and coll:
        for g in coll: print('  collide:',[i for i in key if key[i]==g])
