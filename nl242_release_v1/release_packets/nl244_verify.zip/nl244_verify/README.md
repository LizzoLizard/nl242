# Independent verification: no 9-variable Boolean function has nonlinearity 244

The t = 114/116 plane switch turns a balanced NL-242 function into a function F′ with
W ∈ {±8, ±24} and W(0) = ±8. Closing that case needs "no NL-244 function exists".
Wang–Lou–Wang (arXiv 2610.17871 v1, unrefereed) give an argument for this. These files
re-check every step of that argument independently, so our proof no longer depends on
their claims (we still credit them for the argument).

## The chain and how each link is checked

| Step | Content | Check |
|---|---|---|
| Lemmas 1–3, Prop 1 | W_f ∈ {±8,±24}, 64 of size 8; g = (W_f − 8)/16 mod 2 is cubic; ⟨(−1)^f, W_g⟩ = −10240 | by hand |
| Thm 2 | cubic ℓ1 ≤ 10240; equality only in case A ({±16,±48}) or case B | by hand |
| Lemma 4, Prop 2 | case B impossible | by hand |
| (21)–(22) | case A: h = T(g) is cubic and T(h) = g, where T(g) = ((W_g/16 − 1)/2) mod 2 | by hand |
| Lemma 5 | cubic part P satisfies J(J(P)) = P and C(P) = 0 | by hand |
| **Classification** | RM(3,9)/RM(2,9) has exactly 349 GL(9,2)-orbits, and the Brier–Langevin list is complete | `burnside.py`, `inequiv.py`, `wl.cpp` |
| Prop 3 | only classes 282, 290, 349 satisfy J(J(P)) = P and C(P) = 0 | `prop3.py` |
| Zero class 349 | quadratic ℓ1 ≤ 8192 < 10240 | by hand |
| **Thm 3** | classes 282 and 290: no g has spectrum ⊂ {±16,±48} together with T²(g) = g | `thm3_setup.py`, `thm3_enum2.cpp` |

## Classification (no trust in the 2003 list needed)

- `burnside.py`: Burnside's lemma over all 490 conjugacy classes of GL(9,2) (rational
  canonical forms, Macdonald centralizer orders; the class equation sums to exactly 1).
  The action on cubic parts is the third compound matrix Λ³A.
  Calibration: quadratics give ⌊n/2⌋+1 orbits (n = 4, 5, 6, 9); cubics give 6, 12, 32
  for n = 6, 7, 8. **n = 9 cubics: 349 orbits.** Run: `python3 -I burnside.py 9,3`
- `inequiv.py`: the rank and radical profile of B_v(x,y) = T(v,x,y) separates 321 of the
  349 list entries; 24 groups collide.
- `wl.cpp`: colour refinement (pair relations plus the triple values T(u,v,w)) separates
  all 24 groups (`wl_coll.txt`). The invariant was checked to be unchanged under random
  GL transforms.
- So the 349 entries are pairwise inequivalent, and with 349 orbits the list is complete.

## Theorem 3 (exhaustive)

- WLOG g = P_rep + q + affine. Affine terms permute or negate the spectrum, and
  T²(g + l) = T²(g) + l.
- W ≡ 16 (mod 32) forces Σ_{x_i=1}(−1)^g ≡ 0 (mod 16) for each i. That condition is
  affine-linear in q (mod-8 weight expansion: only the (3,3,2) covers involve q), so
  9 linear equations leave a 27-dimensional affine space of q.
- `thm3_setup.py` builds that space. Checked: base cubic part = representative,
  27 independent kernel vectors, all of degree ≤ 2.
- `thm3_enum2.cpp` enumerates all 2^27 values of q per class (Gray code, FWHT).
  Results (`thm3_results.txt`):

| class | W≡16 (32) | spec ⊂ {±16,±48} | T²(g)=g | both | NL-244 f |
|---|---|---|---|---|---|
| 282 | 65,863,680 | 18,923,520 | 5,996,544 | **0** | 0 |
| 290 | 64,815,104 | 22,118,400 | 4,473,344 | **0** | 0 |

- Among the T² = g cases, max |W| ∈ {80, 112, 176} for class 282 and is always 80 for
  class 290. This matches WLW's Table 1 bound max |W| ≥ 80.

Run: `python3 -I thm3_setup.py classification.txt <folder containing prop3.py> 282 > thm3_282.txt`, then
`g++ -O3 -march=native -pthread thm3_enum2.cpp -o e && ./e thm3_282.txt`
(about 4 min per class on 8 cores).

`classification.txt` is the Brier–Langevin list as published on Langevin's site
(langevin.univ-tln.fr/project/cubics/classification.txt). It is used only as a list of
candidate representatives; its correctness is re-proved above.
