# Independent replay of Wang-Lou-Wang Proposition 3 over the Brier-Langevin list.
# A homogeneous cubic form P on F2^9 = set of 3-subsets of {0..8} (bitmasks).
# J(P): [x^I]J(P) = sum over unordered {A,B}, |A|=|B|=3, A u B = [9]\I, A,B disjoint, of p_A p_B (mod 2).
# C(P): sum over unordered partitions {A,B,D} of [9] into 3-sets of p_A p_B p_D (mod 2).
import re,sys,random,itertools
T3=[sum(1<<i for i in c) for c in itertools.combinations(range(9),3)]
FULL=(1<<9)-1
def J(P):
    out=set()
    for I in T3:
        rest=FULL^I; bits=[i for i in range(9) if rest>>i&1]; s=0
        for A in itertools.combinations(bits,3):
            Am=sum(1<<i for i in A); Bm=rest^Am
            if Am<Bm and Am in P and Bm in P: s^=1
        if s: out.add(I)
    return frozenset(out)
def C(P):
    s=0
    for A in T3:
        if not (A&1): continue          # A contains element 0: canonical first block
        if A not in P: continue
        rest=FULL^A; bits=[i for i in range(9) if rest>>i&1]
        for B in itertools.combinations(bits,3):
            Bm=sum(1<<i for i in B); Dm=rest^Bm
            if Bm<Dm and Bm in P and Dm in P: s^=1
    return s
def parse(fn):
    reps={}
    for l in open(fn,encoding='latin-1'):
        m=re.match(r'^\s*(\d+) h=\S+\s*(.*)$',l)
        if not m: continue
        mons=[t for t in m.group(2).split('+') if t.strip()]
        P=set()
        for t in mons:
            t=t.strip(); assert len(t)==3 and len(set(t))==3, t
            P^={sum(1<<(int(ch)-1) for ch in t)}
        reps[int(m.group(1))]=frozenset(P)
    return reps
# --- linear substitution: P(Ax), homogeneous cubic part (mod RM(2,9)) ---
def subst(P,A):  # A: list of 9 row bitmasks; x_i -> sum_j A[i][j] y_j
    out={}
    for m in P:
        i,j,k=[b for b in range(9) if m>>b&1]
        for a in range(9):
            if not A[i]>>a&1: continue
            for b in range(9):
                if not A[j]>>b&1: continue
                for c in range(9):
                    if not A[k]>>c&1: continue
                    if len({a,b,c})==3:
                        mm=(1<<a)|(1<<b)|(1<<c); out[mm]=out.get(mm,0)^1
    return frozenset(mm for mm,v in out.items() if v)
def rank(rows):
    rows=list(rows); r=0
    for bit in range(9):
        piv=next((i for i in range(r,len(rows)) if rows[i]>>bit&1),None)
        if piv is None: continue
        rows[r],rows[piv]=rows[piv],rows[r]
        for i in range(len(rows)):
            if i!=r and rows[i]>>bit&1: rows[i]^=rows[r]
        r+=1
    return r
def randGL(rng):
    while True:
        A=[rng.randrange(1,512) for _ in range(9)]
        if rank(A)==9: return A
def transpose(A): return [sum(((A[j]>>i)&1)<<j for j in range(9)) for i in range(9)]
def inverse(A):
    M=[(A[i],1<<i) for i in range(9)]
    for col in range(9):
        piv=next(i for i in range(col,9) if M[i][0]>>col&1); M[col],M[piv]=M[piv],M[col]
        for i in range(9):
            if i!=col and M[i][0]>>col&1: M[i]=(M[i][0]^M[col][0],M[i][1]^M[col][1])
    return [M[i][1] for i in range(9)]
if __name__=='__main__':
    reps=parse(sys.argv[1]); assert sorted(reps)==list(range(1,350)), 'indices'
    assert len(reps[349])==0
    fixed=[i for i in sorted(reps) if J(J(reps[i]))==reps[i]]
    surv=[i for i in fixed if C(reps[i])==0]
    print('J(J(P))=P at',fixed); print('and C(P)=0 at',surv)
    print('C values on fixed:',{i:C(reps[i]) for i in fixed})
    # Sanity: GL-equivariance J(P o A) = J(P) o A^{-T}, invariance C(P o A) = C(P), on random A and listed P.
    rng=random.Random(20261122); bad=0; badc=0; N=int(sys.argv[2]) if len(sys.argv)>2 else 300
    for t in range(N):
        P=reps[rng.randrange(1,350)]; A=randGL(rng); AinvT=transpose(inverse(A))
        if J(subst(P,A))!=subst(J(P),AinvT): bad+=1
        if C(subst(P,A))!=C(P): badc+=1
    print('equivariance trials',N,'J failures',bad,'C failures',badc)
