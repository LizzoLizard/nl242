# Build, for class representative P (282 or 290), the affine-linear conditions L_i(q)=0 (i=0..8) on the 36 quadratic
# coefficients q, where L_i(q) = (sum_{x: x_i=1} (-1)^{P(x)+q(x)} / 8) mod 2 (the a_i-coefficient of W_g/16 mod 2).
# Computed numerically on the basis, then checked for affinity on random q. Output: kernel basis + offset as 512-bit
# truth tables (hex) for the C enumerator.
import sys,random,itertools,re
sys.path.insert(0,sys.argv[2]); from prop3 import parse
reps=parse(sys.argv[1]); idx=int(sys.argv[3]); P=reps[idx]
Q2=[(i,j) for i in range(9) for j in range(i+1,9)]
def tt_cubic(P): return [sum(1 for m in P if (x&m)==m)&1 for x in range(512)]
def tt_quad(bits): return [sum(1 for k,(i,j) in enumerate(Q2) if bits>>k&1 and x>>i&1 and x>>j&1)&1 for x in range(512)]
TP=tt_cubic(P); QT=[tt_quad(1<<k) for k in range(36)]
def L(qbits):
    t=[TP[x]^sum(QT[k][x] for k in range(36) if qbits>>k&1)%2 for x in range(512)]
    out=0
    for i in range(9):
        s=sum(1-2*t[x] for x in range(512) if x>>i&1); assert s%8==0,(i,s)
        out|=((s//8)&1)<<i
    return out
L0=L(0); cols=[L(1<<k)^L0 for k in range(36)]
rng=random.Random(1)
for _ in range(200):
    qb=rng.getrandbits(36); exp=L0
    for k in range(36):
        if qb>>k&1: exp^=cols[k]
    assert L(qb)==exp,'not affine'
# solve: sum_k q_k cols[k] = L0  (so L(q)=0); kernel of the 9x36 map + particular solution
rows=[[ (cols[k]>>i)&1 for k in range(36)]+[(L0>>i)&1] for i in range(9)]
piv=[];r=0
for c in range(36):
    p=next((i for i in range(r,9) if rows[i][c]),None)
    if p is None: continue
    rows[r],rows[p]=rows[p],rows[r]
    for i in range(9):
        if i!=r and rows[i][c]: rows[i]=[a^b for a,b in zip(rows[i],rows[r])]
    piv.append(c); r+=1
assert all(not row[-1] for row in rows[r:]),'inconsistent'
free=[c for c in range(36) if c not in piv]
part=0
for i,c in enumerate(piv):
    if rows[i][-1]: part|=1<<c
kern=[]
for f in free:
    v=1<<f
    for i,c in enumerate(piv):
        if rows[i][f]: v|=1<<c
    kern.append(v)
assert L(part)==0 and all(L(part^v)==0 for v in kern)
print('class',idx,'rank',r,'kernel dim',len(kern),file=sys.stderr)
def hex512(t): return ''.join('%016x'%sum(t[64*w+b]<<b for b in range(64)) for w in range(8))
base=[TP[x]^tt_quad(part)[x] for x in range(512)]
print(len(kern)); print(hex512(base))
for v in kern: print(hex512(tt_quad(v)))
