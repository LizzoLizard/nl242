// Color refinement invariant for alternating trilinear forms on F2^9 (cubic classes).
// Deterministic function of GL-invariant data => different outputs prove inequivalence.
#include <cstdio>
#include <cstdint>
#include <vector>
#include <sstream>
#include <iostream>
#include <string>
using namespace std; typedef uint64_t U;
static inline U mix(U x){x+=0x9e3779b97f4a7c15ULL;x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL;x=(x^(x>>27))*0x94d049bb133111ebULL;return x^(x>>31);}
static inline U H(U a,U b){return mix(a*0x100000001b3ULL ^ mix(b));}
int rk(vector<int> r){int n=0;for(int b=8;b>=0;b--){int p=-1;for(size_t i=0;i<r.size();i++) if(r[i]>>b&1){p=i;break;} if(p<0)continue; int pv=r[p]; r.erase(r.begin()+p); for(auto&x:r) if(x>>b&1) x^=pv; n++;} return n;}
int main(){
  string line; int rounds_pair=3, rounds_tri=2;
  while(getline(cin,line)){
    istringstream ss(line); int idx; ss>>idx; vector<int> mons; int m; while(ss>>m) mons.push_back(m);
    int Be[9][9]={{0}};
    for(int mm:mons){int id[3],k=0;for(int i=0;i<9;i++) if(mm>>i&1) id[k++]=i;
      for(int c=0;c<3;c++){int a=id[(c+1)%3],b=id[(c+2)%3]; Be[id[c]][a]|=1<<b; Be[id[c]][b]|=1<<a;}}
    static int B[512][9]; for(int j=0;j<9;j++) B[0][j]=0;
    for(int v=1;v<512;v++){int c=__builtin_ctz(v); for(int j=0;j<9;j++) B[v][j]=B[v&(v-1)][j]^Be[c][j];}
    static int Bw[512][512]; // Bw[v][w] = mask of y with T(v,w,y)=1
    for(int v=0;v<512;v++){Bw[v][0]=0; for(int w=1;w<512;w++){int c=__builtin_ctz(w); Bw[v][w]=Bw[v][w&(w-1)]^B[v][c];}}
    static int R[512]; for(int v=1;v<512;v++){vector<int> r(B[v],B[v]+9); R[v]=rk(r);}
    static U col[512],nc[512];
    for(int v=1;v<512;v++) col[v]=mix(R[v]);
    // pair rounds: relation = (Bw[v][w]==0, rank of stacked B_v,B_w)
    static int S[512][512];
    for(int v=1;v<512;v++) for(int w=v+1;w<512;w++){vector<int> r(B[v],B[v]+9); r.insert(r.end(),B[w],B[w]+9); S[v][w]=S[w][v]=rk(r);}
    for(int it=0;it<rounds_pair;it++){
      for(int v=1;v<512;v++){U acc=0; for(int w=1;w<512;w++){ if(w==v) continue; U a=col[w],b=col[v^w]; if(a>b){U t=a;a=b;b=t;} acc+=mix(H(H(a,b), (U)(Bw[v][w]==0)*16+S[v][w]));} nc[v]=H(col[v],acc);}
      for(int v=1;v<512;v++) col[v]=nc[v];
    }
    for(int it=0;it<rounds_tri;it++){
      for(int v=1;v<512;v++){U acc=0; for(int w=1;w<512;w++){ if(w==v) continue; int t=Bw[v][w]; for(int u=w+1;u<512;u++){ if(!((__builtin_popcount(t&u))&1)) continue; // T(v,w,u)=1
            U a=col[w],b=col[u]; if(a>b){U x=a;a=b;b=x;} acc+=mix(H(H(a,b),col[w^u]));}} nc[v]=H(col[v],acc);}
      for(int v=1;v<512;v++) col[v]=nc[v];
    }
    U inv=0; for(int v=1;v<512;v++) inv+=mix(col[v]);
    printf("%d %016llx\n",idx,(unsigned long long)inv); fflush(stdout);
  }
}
