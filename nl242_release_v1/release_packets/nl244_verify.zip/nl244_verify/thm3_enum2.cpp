// Theorem 3 check (WLW case A, classes 282/290), all hypotheses:
//   g = base + span(kernel)  [kernel = all quadratic q meeting the linear necessary conditions of W_g == 16 mod 32]
//   (i)  W_g(a) == 16 (mod 32) for all a
//   (ii) h = T(g) := ((W_g/16 - 1)/2) mod 2 ; W_h == 16 mod 32 and T(h) == g
//   (iii) spectrum of g in {+-16,+-48}
//   (iv) f from W_f = -(W_h + 32(-1)^g)/2 is a Boolean function with W_f in {+-8,+-24}
// Affine terms are irrelevant: T^2(g+l) = T^2(g)+l and spectra only shift/negate.
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <array>
#include <thread>
#include <atomic>
#include <string>
#include <fstream>
#include <cstdlib>
using namespace std;
typedef uint64_t U;
int dim; U base[8]; vector<array<U,8>> K;
atomic<long long> c_mod32{0}, c_spec{0}, c_t2{0}, c_t2spec{0}, c_f{0};
long long hist_mod32[8][520], hist_t2[8][520];
static inline void fwht(int32_t*w){for(int h=1;h<512;h<<=1)for(int i=0;i<512;i+=h<<1)for(int j=i;j<i+h;j++){int32_t a=w[j],b=w[j+h];w[j]=a+b;w[j+h]=a-b;}}
static inline int bit(const U*t,int x){return (t[x>>6]>>(x&63))&1;}
static inline bool mod32ok(const int32_t*W){for(int x=0;x<512;x++) if((((W[x]%32)+32)%32)!=16) return false; return true;}
static inline void Tmap(const int32_t*W,U*o){memset(o,0,64);for(int x=0;x<512;x++){int k=W[x]/16; int r=((k-1)/2)&1; if(r) o[x>>6]|=1ULL<<(x&63);}}
void work(int tid,int tb){
  int low=dim-tb; U t[8]; memcpy(t,base,sizeof t);
  for(int b=0;b<tb;b++) if(tid>>b&1) for(int w=0;w<8;w++) t[w]^=K[low+b][w];
  int32_t W[512],Wh[512],Wh2[512]; U h[8],gg[8];
  long long m32=0,spec=0,t2=0,t2s=0,ff=0;
  for(long long i=0;i<(1LL<<low);i++){
    if(i){int k=__builtin_ctzll(i); for(int w=0;w<8;w++) t[w]^=K[k][w];}
    for(int x=0;x<512;x++) W[x]=1-2*bit(t,x);
    fwht(W);
    if(!mod32ok(W)) continue;
    m32++; int mx=0; bool sp=true;
    for(int x=0;x<512;x++){int a=abs(W[x]); if(a>mx)mx=a; if(a!=16&&a!=48) sp=false;}
    hist_mod32[tid][mx]++; if(sp) spec++;
    Tmap(W,h);
    for(int x=0;x<512;x++) Wh[x]=1-2*bit(h,x);
    fwht(Wh);
    if(!mod32ok(Wh)) continue;
    Tmap(Wh,gg);
    if(memcmp(gg,t,64)!=0) continue;
    t2++; hist_t2[tid][mx]++;
    if(!sp) continue;
    t2s++;
    printf("T2SPEC tid %d i %lld\n",tid,i); fflush(stdout);
    bool okf=true;
    for(int x=0;x<512;x++){int v=-(Wh[x]+32*(1-2*bit(t,x))); if(v%2){okf=false;break;} Wh2[x]=v/2; int a=abs(Wh2[x]); if(a!=8&&a!=24) okf=false;}
    if(okf){fwht(Wh2); for(int x=0;x<512;x++){ if(Wh2[x]!=512&&Wh2[x]!=-512) okf=false; }}
    if(okf){ff++; printf("NL244_FOUND tid %d i %lld\n",tid,i); fflush(stdout);}
  }
  c_mod32+=m32; c_spec+=spec; c_t2+=t2; c_t2spec+=t2s; c_f+=ff;
}
int main(int argc,char**argv){
  ifstream in(argv[1]); string s; in>>dim;
  auto rd=[&](U*o){in>>s; for(int w=0;w<8;w++) o[w]=strtoull(s.substr(16*w,16).c_str(),0,16);};
  rd(base); K.resize(dim); for(int k=0;k<dim;k++) rd(K[k].data());
  memset(hist_mod32,0,sizeof hist_mod32); memset(hist_t2,0,sizeof hist_t2);
  int tb=3; vector<thread> th; for(int t=0;t<(1<<tb);t++) th.emplace_back(work,t,tb); for(auto&x:th) x.join();
  printf("dim %d total %lld | W==16mod32 %lld | spec{16,48} %lld | T2(g)=g %lld | T2 & spec %lld | NL244 f %lld\n",
    dim,1LL<<dim,(long long)c_mod32,(long long)c_spec,(long long)c_t2,(long long)c_t2spec,(long long)c_f);
  auto ph=[&](const char*nm,long long H[8][520]){printf("%s max|W| hist:",nm);for(int m=0;m<520;m++){long long c=0;for(int t=0;t<8;t++)c+=H[t][m];if(c)printf(" %d:%lld",m,c);}printf("\n");};
  ph("mod32",hist_mod32); ph("T2",hist_t2);
}
