# Count orbits of GL(n,2) on degree-r homogeneous parts RM(r,n)/RM(r-1,n) (= alternating r-linear forms)
# via Burnside over conjugacy classes (rational canonical form by elementary divisors; Macdonald centralizer formula).
import sys, itertools
from fractions import Fraction
from math import prod
def pmul(a,b):
    r=0
    while b:
        if b&1: r^=a
        a<<=1; b>>=1
    return r
def deg(p): return p.bit_length()-1
def irreducibles(maxd):
    out=[]; 
    for d in range(1,maxd+1):
        for p in range(1<<d,1<<(d+1)):
            if p&1==0 and p!=2: continue   # constant term 0 => divisible by x (keep x itself only)
            ok=True
            for q in out:
                if 2*deg(q)>d: break
                # trial division
                r=p; dq=deg(q)
                while r and deg(r)>=dq: r^=q<<(deg(r)-dq)
                if r==0: ok=False; break
            if ok: out.append(p)
    return out
def partitions(n,maxp=None):
    if maxp is None: maxp=n
    if n==0: yield (); return
    for k in range(min(n,maxp),0,-1):
        for rest in partitions(n-k,k): yield (k,)+rest
def companion(p):
    d=deg(p); M=[[0]*d for _ in range(d)]
    for i in range(1,d): M[i][i-1]=1
    for i in range(d): M[i][d-1]=(p>>i)&1
    return M
def blockdiag(blocks):
    n=sum(len(b) for b in blocks); M=[[0]*n for _ in range(n)]; o=0
    for b in blocks:
        for i in range(len(b)):
            for j in range(len(b)): M[o+i][o+j]=b[i][j]
        o+=len(b)
    return M
def ppow(p,k):
    r=1
    for _ in range(k): r=pmul(r,p)
    return r
def det2(M):
    M=[row[:] for row in M]; n=len(M)
    for c in range(n):
        piv=next((r for r in range(c,n) if M[r][c]),None)
        if piv is None: return 0
        M[c],M[piv]=M[piv],M[c]
        for r in range(c+1,n):
            if M[r][c]: M[r]=[x^y for x,y in zip(M[r],M[c])]
    return 1
def rank_rows(rows):
    rows=[r for r in rows if r]; rk=0; basis={}
    for r in rows:
        while r:
            h=r.bit_length()-1
            if h in basis: r^=basis[h]
            else: basis[h]=r; rk+=1; break
    return rk
def fixdim(A,n,r):
    S=list(itertools.combinations(range(n),r)); idx={s:i for i,s in enumerate(S)}
    rows=[]
    for I in S:   # image of monomial x^I under x->Ax : sum_J det A[I,J] x^J  (cubic part); minus identity
        v=0
        for J in S:
            if det2([[A[i][j] for j in J] for i in I]): v|=1<<idx[J]
        v^=1<<idx[I]; rows.append(v)
    return len(S)-rank_rows(rows)
def cent(lam,Q):
    conj=[sum(1 for x in lam if x>i) for i in range(lam[0])] if lam else []
    e=sum(c*c for c in conj); out=Fraction(Q)**e
    from collections import Counter
    for i,m in Counter(lam).items():
        for k in range(1,m+1): out*=(1-Fraction(1,Q**k))
    return out
def classes(n,polys):
    polys=[p for p in polys if p!=2 and deg(p)<=n]
    def rec(i,left):
        if left==0: yield []; return
        if i==len(polys): return
        p=polys[i]; d=deg(p)
        yield from rec(i+1,left)
        for size in range(1,left//d+1):
            for lam in partitions(size):
                for rest in rec(i+1,left-size*d): yield [(p,lam)]+rest
    yield from rec(0,n)
def run(n,r):
    polys=irreducibles(n); tot=Fraction(0); N=Fraction(0); nc=0
    G=prod((1<<n)-(1<<i) for i in range(n))
    for cl in classes(n,polys):
        blocks=[companion(ppow(p,k)) for p,lam in cl for k in lam]
        A=blockdiag(blocks); c=prod(cent(lam,1<<deg(p)) for p,lam in cl)
        tot+=1/c; N+=Fraction(2**fixdim(A,n,r))/c; nc+=1
    return nc,tot,N
for n,r in [(int(a.split(',')[0]),int(a.split(',')[1])) for a in sys.argv[1:]]:
    nc,tot,N=run(n,r); print(f"n={n} r={r}: {nc} conjugacy classes, sum 1/|C| = {tot}, orbits = {N}",flush=True)
