import sys; sys.path.insert(0,'')
exec(open(sys.argv[2]).read().split('def rank(')[0])   # reuse parse() from inequiv.py
reps=parse(sys.argv[1])
for i in sorted(reps): print(i,*sorted(reps[i]))
