#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
TMPBIN="$(mktemp -d)"
trap 'rm -rf "$TMPBIN"' EXIT
export PYTHONDONTWRITEBYTECODE=1

echo "=== [1/10] t=100 r=8: Exact rational proof of H_64 w >= 6 ==="
(cd "$ROOT/t100/r8" && python3 verify_h64_w_ge_6_exact.py)

echo "=== [2/10] t=100 r=8: Exact Fraction Signed Delsarte Farkas certificates (11/11 + QR17 PC) ==="
(cd "$ROOT/t100/r8" && python3 verify_delsarte_farkas_exact.py)

echo "=== [3/10] t=100 r=8: Standalone QR(17) (n_0=18, v=0) + t=102 pos ctrl ==="
g++ -O3 -std=c++17 "$ROOT/t100/r8/verify_qr17_t100_standalone.cpp" -o "$TMPBIN/verify_qr17_t100"
"$TMPBIN/verify_qr17_t100"

echo "=== [4/10] t=100 r=8: Non-empty symmetry positive control (all 5 nonzero v reps) ==="
g++ -O3 -std=c++17 "$ROOT/t100/r8/test_sym_nonempty.cpp" -o "$TMPBIN/test_sym_nonempty"
"$TMPBIN/test_sym_nonempty"

echo "=== [5/10] t=100 r=8: Individual exact integer dual audit of n_0=14 (32/32) & n_0=16 (4,124/4,124) ==="
g++ -O3 -std=c++17 "$ROOT/t100/r8/audit_n14_n16_exact.cpp" -o "$TMPBIN/audit_n14_n16"
"$TMPBIN/audit_n14_n16"

echo "=== [6/10] t=100 r=8: Exact O^-(8,2) orbit audit + exact rational L1 certification of n_0=18 & n_0=20 ==="
g++ -O3 -std=c++17 -pthread "$ROOT/t100/r8/audit_n18_n20_exact_orbits.cpp" -o "$TMPBIN/audit_n18_n20"
(cd "$ROOT/t100/r8" && "$TMPBIN/audit_n18_n20" && python3 certify_exact_o8_orbs_L1.py)

echo "=== [7/10] t=100 r=6: |Z|=128 reductions & orbit tables + small-mask range k in [9..15] ==="
g++ -O3 -std=c++17 "$ROOT/t100/z128/verify_z128_reductions.cpp" -o "$TMPBIN/verify_z128_reductions"
"$TMPBIN/verify_z128_reductions"
g++ -O3 -std=c++17 "$ROOT/t100/z112/check_small_masks.cpp" -o "$TMPBIN/check_small_masks"
"$TMPBIN/check_small_masks"

echo "=== [8/10] t=100 r=6: |Z|=112 master all-45 (h,p) exact verifier (7 positive controls + 111/111 killed) ==="
g++ -O3 -std=c++17 -pthread "$ROOT/t100/z112/verify_z112_all45_exact.cpp" -o "$TMPBIN/verify_z112_all45_exact"
(cd "$ROOT/t100/z112" && "$TMPBIN/verify_z112_all45_exact")

echo "=== [9/10] t=102: z128 exact check + r=8 standalone verifier ==="
python3 "$ROOT/t102/verify_t102_z128_closed.py"
g++ -O3 -std=c++20 "$ROOT/t102/verify_t102_r8_closed.cpp" -o "$TMPBIN/verify_t102_r8"
"$TMPBIN/verify_t102_r8"

echo "=== [10/10] t=84, 110, 112 pure-integer Farkas verifiers ==="
python3 "$ROOT/t104_plus/verify_t84_closed.py"
python3 "$ROOT/t104_plus/verify_t110_closed.py"
python3 "$ROOT/t104_plus/verify_t112_closed.py"

echo ""
echo "ALL QUICK EXACT VERIFIERS PASSED 100%!"
