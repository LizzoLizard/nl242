#!/usr/bin/env python3
"""
Standalone, zero-dependency, 100%-exact integer verifier for the QR(17) theorem at
(t = 102, rank = 8, |Z| = 120, n_0 = 18, n_8 = 0):

1. CONSTRUCTS an exact, real, Z_17-symmetric t = 102, |Z| = 120, n_0 = 18, n_8 = 0 low block
   V : F_2^8 -> {-1, 0, +1} with V_hat(0) = 0, mass(V) = 102, and |2*V_hat(u)| <= 24 everywhere
   (spectrum of 2*V_hat: {-24: 60, -16: 47, 0: 18, +16: 55, +24: 76}).
   => PROVES NO LOW-BLOCK-ONLY ARGUMENT CAN CLOSE (t = 102, r = 8, |Z| = 120)!

2. PROVES UNIQUENESS of V (up to shifting/negating V) for the QR(17) zero set Z_0:
   From Parseval,
     128 * sum_x V(x) w_base(x) = 4096*102 + 256*(136*9) - 256*(102*4) = 626,688
     => sum_x V(x) w_base(x) = 4,896 = 102 * 48.
   Since |w_base(x)| <= 48 everywhere and |w_base(x)| == 48 on EXACTLY 102 points,
   V(x) = sgn(w_base(x)) * 1_{|w_base(x)| == 48} is UNIQUELY FORCED!

3. PROVES IMPOSSIBILITY OF ANY COMPLEMENTARY HIGH BLOCK U ON S_U = F_2^8 \\ supp(V) (154 pts):
   By Balanced242HighSections.coupled_phase, the high-block phase q(u) = (-1)^{(U_hat(u)/2 - 1)/2}
   satisfies q(u) = s * (-1)^{<b, u> + Q(u)} for some b in F_2^8, s in {-1, +1}.
   For EVERY ONE of all 512 pairs (b, s), there exists a character u* in F_2^8 and sign eps in {-1,+1}
   such that sigma_{b,s}(x) = q_hat(x)/16 agrees with eps * (-1)^{<u*, x>} on 136 of the 154 points of S_U
   and disagrees on ONLY 18 points (the 18 points where w_base(x) = 0).
   Since |U_hat(u*)| <= 14 (high cap |2*U_hat| <= 28) and |U(x)| = 1 on S_U:
     sum_u q(u) U_hat(u) = 16 * sum_{x in S_U} sigma_{b,s}(x) U(x)
                         = 16 * eps * U_hat(u*) + 16 * sum_{x in S_U} (sigma_{b,s}(x) - eps*chi_{u*}(x)) U(x)
                        >= 16 * (-14) - 32 * 18 = -224 - 576 = -800.
   Yet the high-energy phase identity requires:
     sum_u q(u) U_hat(u) = 32 * (2*102 - 232 - B) = -896 - 32*B <= -928  (since B = N_4 + N_{12} >= 1 is odd).
   Contradiction: -800 > -928!
"""

from collections import Counter

def pop(x):
    return bin(x).count("1")

def fwht256(a):
    a = list(a)
    st = 1
    while st < 256:
        for i in range(0, 256, 2 * st):
            for j in range(i, i + st):
                x, y = a[j], a[j + st]
                a[j], a[j + st] = x + y, x - y
        st *= 2
    return a

def inv_gf2(M):
    n = len(M)
    A = [M[i][:] + [1 if i == j else 0 for j in range(n)] for i in range(n)]
    for col in range(n):
        piv = next(i for i in range(col, n) if A[i][col])
        A[col], A[piv] = A[piv], A[col]
        for i in range(n):
            if i != col and A[i][col]:
                A[i] = [A[i][k] ^ A[col][k] for k in range(2 * n)]
    return [row[n:] for row in A]

def poly_mul(a, b):
    res = 0
    for i in range(b.bit_length()):
        if (b >> i) & 1:
            res ^= a << i
    return res

def poly_mod(a, m):
    dm = m.bit_length() - 1
    while a.bit_length() - 1 >= dm:
        a ^= m << (a.bit_length() - 1 - dm)
    return a

def main():
    # 1. Construct even [17, 8, 6] quadratic residue code QR(17)
    x17_1 = (1 << 17) | 1
    facs = [f for f in range(257, 512, 2) if poly_mod(x17_1, f) == 0]
    assert len(facs) == 2
    g = poly_mul(3, facs[0])  # (x + 1) * f(x), degree 9
    Umat = [[((g << r) >> j) & 1 for j in range(17)] for r in range(8)]
    us = [sum((Umat[r][j] << r) for r in range(8)) for j in range(17)]

    # Verify weight distribution {0:1, 6:68, 8:85, 10:68, 12:34}
    span = [0]
    for r in range(8):
        rm = sum(Umat[r][j] << j for j in range(17))
        span += [x ^ rm for x in span]
    assert dict(Counter(pop(x) for x in span)) == {0: 1, 6: 68, 8: 85, 10: 68, 12: 34}

    # 2. Construct unique quadratic form Q with B_Q = (U U^T)^{-1} vanishing on Z_0 = {0} u us
    G = [[sum(Umat[i][k] & Umat[j][k] for k in range(17)) & 1 for j in range(8)] for i in range(8)]
    B = inv_gf2(G)
    assert all(B[i][i] == 0 for i in range(8))

    def Q0(x):
        s = 0
        for i in range(8):
            if (x >> i) & 1:
                for j in range(i + 1, 8):
                    if B[i][j] and ((x >> j) & 1):
                        s ^= 1
        return s

    valid_a = [a for a in range(256) if all((pop(a & u) & 1) == Q0(u) for u in us)]
    assert len(valid_a) == 1
    a = valid_a[0]
    Qtab = [Q0(x) ^ (pop(a & x) & 1) for x in range(256)]
    Z = [x for x in range(256) if Qtab[x] == 0]
    F = [x for x in range(256) if Qtab[x] == 1]
    assert len(Z) == 120 and len(F) == 136

    # 3. Solve unique p_F in Q_2 + RM(3, 8) matching 1 - 1_{Z_0} on Z_120
    mons_Q = [(i, j) for i in range(8) for j in range(i + 1, 8) if B[i][j]]
    lin_Q = [i for i in range(8) if (a >> i) & 1]
    Q2 = []
    for x in range(256):
        S = sum(((x >> i) & 1) & ((x >> j) & 1) for i, j in mons_Q) + sum((x >> i) & 1 for i in lin_Q)
        Q2.append((S * (S - 1) // 2) & 1)
    mons3 = [m for m in range(256) if pop(m) <= 3]
    Z0_set = set([0] + us)
    pivs, basis = [], {}
    for x in Z:
        v = sum((1 << k) for k, m in enumerate(mons3) if (x & m) == m)
        r = (1 ^ Q2[x] ^ (1 if x in Z0_set else 0)) & 1
        for p in pivs:
            if (v >> p) & 1:
                v ^= basis[p][0]
                r ^= basis[p][1]
        if v == 0:
            assert r == 0
        else:
            p = (v & -v).bit_length() - 1
            for q in list(basis.keys()):
                if (basis[q][0] >> p) & 1:
                    basis[q] = (basis[q][0] ^ v, basis[q][1] ^ r)
            basis[p] = (v, r)
            pivs.append(p)
            pivs.sort()
    assert len(pivs) == 84  # kernel = Q * RM(1, 8) (dim 9) -> unique up to shift/sign of V!
    c_sol = [0] * 93
    for p in pivs:
        c_sol[p] = basis[p][1]
    p_all = [Q2[u] ^ (sum(c_sol[k] for k, m in enumerate(mons3) if (u & m) == m) & 1) for u in range(256)]
    h_F = [(3 if p_all[u] else -3) if Qtab[u] == 1 else 0 for u in range(256)]
    wb = fwht256(h_F)

    # Verify exact distribution of w_base and uniqueness of V!
    wb_dist = dict(sorted(Counter(wb).items()))
    assert wb_dist == {-48: 51, -24: 68, 0: 18, 24: 68, 48: 51}
    assert sum(x * x for x in wb) == 256 * 136 * 9
    assert (4096 * 102 + 256 * 136 * 9 - 256 * 102 * 4) == 128 * (102 * 48)
    print(f"[PASS 1] QR(17) w_base dist = {wb_dist}; Parseval UNIQUELY forces V = sgn(w_base)*1_{{|w_base|=48}}!")

    # 4. Construct V and verify ALL low-block properties!
    V = [1 if wb[x] == 48 else (-1 if wb[x] == -48 else 0) for x in range(256)]
    Vhat = fwht256(V)
    assert sum(abs(x) for x in V) == 102
    assert Vhat[0] == 0
    assert max(abs(2 * x) for x in Vhat) == 24
    assert all((Vhat[u] == 0) == (u in Z0_set) for u in range(256))
    assert all((abs(2 * Vhat[u]) == 24) == (Qtab[u] == 1) for u in range(256))
    print(f"[PASS 2] EXACT REAL t=102, |Z|=120 low block V constructed! 2*V_hat dist = {dict(sorted(Counter(2*x for x in Vhat).items()))}")

    # 5. Prove 0 complementary high blocks U on S_U = {x : V[x] == 0} across ALL 512 coupled phases (b, s)!
    S_U = [x for x in range(256) if V[x] == 0]
    assert len(S_U) == 154
    q0 = [-1 if Qtab[u] else 1 for u in range(256)]
    q0h = fwht256(q0)
    assert all(abs(x) == 16 for x in q0h)
    sigma0 = [x // 16 for x in q0h]

    # Check ALL 512 (b, s) explicitly!
    for b in range(256):
        for s in (-1, 1):
            # sigma_{b, s}(x) = s * sigma0(x ^ b)
            sig = [s * sigma0[x ^ b] for x in range(256)]
            # Find u* maximizing |sum_{x in S_U} sig[x] * (-1)^{<u*, x>}| via FWHT!
            vec = [sig[x] if V[x] == 0 else 0 for x in range(256)]
            wh = fwht256(vec)
            best_abs = max(abs(val) for val in wh)
            # Disagreement count E = (154 - best_abs) // 2
            assert (154 - best_abs) % 2 == 0
            E = (154 - best_abs) // 2
            assert E == 18, f"Expected E=18, got {E} at b={b}, s={s}"
            lb = 16 * (-14) - 32 * E
            assert lb == -800 and lb > -896  # required <= -896 - 32*B <= -928!
    print("[PASS 3] ALL 512 coupled phases (b, s): E = 18 => sum q*U_hat >= -800 > -928 => 0 high-block completions!")
    print("\n=== ALL CHECKS PASSED: QR(17) LOW BLOCK CONSTRUCTED, PROVED UNIQUE, AND KILLED ON COUPLED HIGH BLOCK! ===")

if __name__ == "__main__":
    main()
