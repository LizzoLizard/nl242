#!/usr/bin/env python3
"""
100% EXHAUSTIVE CHECK OF THE SZ\{0} TRIPLE-XOR AFFINE-MOD-4 THEOREM!
Verifies:
  1. Every c in SZc is the XOR of a unique triple {s1, s2, s3} subset SZ\{0}!
  2. For EVERY n_0(s) = 0 coset (ALL 65,536 4-bit Boolean functions, both EVEN and ODD):
       b_s(x) = (z_s(x) - pf)/2 (mod 2) is ALWAYS AFFINE (deg <= 1)!
  3. Exhaustively checks EVERY k_c in {0, 1, 2, 3, 4, 5, 6, 7} (pf = 0 and pf = 1) to find
     ALL possible |z_c| / z_c*J_c configurations where b_c(x) = (z_c(x) - pf)/2 (mod 2) IS AFFINE!
  4. Checks whether ANY cell with J_c = +2, z_c = -10 (even) exists in the 729 mod-3 cells!
"""
import itertools
import numpy as np

H4 = np.array([[1 if (bin(a & x).count("1") % 2 == 0) else -1 for x in range(16)] for a in range(16)], dtype=int)
SZ = [0, 4, 8, 13, 14, 15]
SZc = [1, 2, 3, 5, 6, 7, 9, 10, 11, 12]

# 1. Verify bijection between triples of SZ\{0} and SZc!
triples_map = {}
for s1, s2, s3 in itertools.combinations(SZ[1:], 3):
    c = s1 ^ s2 ^ s3
    assert c in SZc and c not in triples_map
    triples_map[c] = (s1, s2, s3)
assert len(triples_map) == 10
print("[PASS 1] Exact bijection: all 10 c in SZc = s1 ^ s2 ^ s3 with s1,s2,s3 in SZ\\{0}:")
for c in SZc:
    print(f"   c={c:2d} = {triples_map[c][0]} ^ {triples_map[c][1]} ^ {triples_map[c][2]}")

# Build exact set of all 32 affine functions on F_2^4 (as 16-bit ints):
AFF32 = set()
for a in range(16):
    for b in (0, 1):
        m = sum((1 << x) for x in range(16) if ((bin(a & x).count("1") & 1) ^ b) == 1)
        AFF32.add(m)
assert len(AFF32) == 32
pows = (1 << np.arange(16))

# 2. Verify ALL 65,536 4-bit Boolean functions give AFFINE b_s!
bits16 = ((np.arange(65536)[:, None] >> np.arange(16)) & 1)
S16 = 1 - 2 * bits16
for pf in (0, 1):
    sub = S16[(bits16.sum(axis=1) & 1) == pf]
    Zs = (sub @ H4.T) // 2
    assert np.all((Zs & 1) == pf)
    Bs = ((Zs - pf) // 2) & 1
    masks = set(int(x) for x in (Bs @ pows))
    assert masks.issubset(AFF32), f"NON-AFFINE b_s found for pf={pf}!"
print(f"\n[PASS 2] ALL 65,536/65,536 zero-free functions (EVEN & ODD) have AFFINE b_s in AFF32!")

# 3. Check ALL k_c in {0, 1, 2, 3, 4, 5, 6, 7}, pf in {0, 1}!
#    For a coset c with k_c entries of +-4 and (16-k_c) entries of +-12:
#    W_c(w) in {+-4, +-12} (exactly k_c entries of +-4), z_c = (1/16) H_4 @ W_c!
#    Wait: z_c is an integer with same parity pf on all 16 x, |z_c(x)| <= 16!
#    Check EVERY (k_c, pf): can b_c = (z_c - pf)/2 (mod 2) EVER be in AFF32?!
#    Wait: for k_c <= 3, we can fix the k_c positions up to AGL(4,2) (only 1 orbit for k=0,1,2,3!) and test ALL 2^16 signings!
#    For k_c = 4: only 2 orbits (2-plane, non-2-plane)!
#    For k_c = 5, 6, 7: test ALL orbits (or check by enumerating all S_c containing 0 up to GL(4,2))!
print("\n=== CHECKING WHICH (k_c, pf) CAN EVER HAVE AFFINE b_c = (z_c - pf)/2 (mod 2) ===")
# Even simpler: remember z_c(x) = (3*y_c(x) - J_c(x)) / 2 where y_c = W_4(s)/2!
# Wait: FOR ANY k_c and ANY subset S_c of size k_c, testing ALL 2^16 signings s in {-1,+1}^16
# (setting W_c(w) = 4*s(w) for w in S_c, 12*s(w) for w not in S_c) checks EVERY possible W_c for that S_c!
# Let's check:
#   k=0: S = []
#   k=1: S = [0]
#   k=2: S = [0, 1]
#   k=3: S = [0, 1, 2]
#   k=4: S = [0, 1, 2, 3] (2-plane), [0, 1, 2, 4] (non-plane)
#   k=5: all orbits of 5-subsets of F_2^4 containing 0:
#        (a) 2-plane + 1: [0,1,2,3,4]
#        (b) cap (XOR=0): [0,1,2,4,8] -> wait 1^2^4^8=15 != 0 -> [0,1,2,4,7]? No, 1^2^4=7 -> 2-plane!
#            Actually cap of size 5 in F_2^4: 0 + 4 independent {1,2,4,8} (rank 4, no 2-plane)!
#            Wait: 0,1,2,4,8 has 0^1^2^4^8 = 15. Any 5-set in F_2^4 either contains a 2-plane (1 orbit) or doesn't (1 orbit: {0,1,2,4,8})!
#   k=6: enumerate ALL distinct (rank, #2-planes) orbits of 6-subsets containing 0!
def get_k_orbits(k):
    if k == 0: return [()]
    if k == 1: return [(0,)]
    if k == 2: return [(0, 1)]
    if k == 3: return [(0, 1, 2)]
    if k == 4: return [(0, 1, 2, 3), (0, 1, 2, 4)]
    # For k=5,6,7: classify ALL C(15, k-1) subsets by (span_size, #2-planes, #3-planes, sorted degs of 2-planes)
    reps = {}
    for comb in itertools.combinations(range(1, 16), k - 1):
        S = (0,) + comb
        span = {0}
        for v in S: span |= {u ^ v for u in span}
        p4 = [q for q in itertools.combinations(S, 4) if (q[0]^q[1]^q[2]^q[3]) == 0]
        degs = tuple(sorted(sum(1 for q in p4 if v in q) for v in S))
        # Also count # of 6-subsets with XOR=0 etc.
        key = (len(span), len(p4), degs)
        if key not in reps:
            reps[key] = S
    return list(reps.values())

for kc in range(0, 8):
    orbs = get_k_orbits(kc)
    for pf in (0, 1):
        aff_hits = 0
        z_pats = set()
        for S in orbs:
            mag = np.full(16, 12, dtype=int)
            for w in S: mag[w] = 4
            W = S16 * mag[None, :]
            Znum = W @ H4.T
            ok = np.all((Znum % 16) == 0, axis=1)
            Z = Znum[ok] // 16
            if len(Z) == 0: continue
            # Filter by constant parity == pf AND |Z| <= 16!
            m_pf = np.all((Z & 1) == pf, axis=1) & np.all(np.abs(Z) <= 16, axis=1)
            Z = Z[m_pf]
            if len(Z) == 0: continue
            B = ((Z - pf) // 2) & 1
            bmasks = B @ pows
            for idx_r, bm in enumerate(bmasks):
                if int(bm) in AFF32:
                    aff_hits += 1
                    row = Z[idx_r]
                    z_pats.add(tuple(sorted(np.abs(row).tolist())))
        print(f"  k_c={kc} pf={pf} ({'EVEN' if pf==0 else 'ODD '}) [{len(orbs):2d} orbs] | AFFINE b_c hits={aff_hits:6d} | |z_c| pats={sorted(z_pats)[:6]}")
