#!/usr/bin/env python3
"""
verify_t110_closed.py — Pure-integer, zero-dependency proof verifier closing t = 110!

Proves that NO balanced 9-variable Boolean function of nonlinearity 242 has agreement count t = 110.
Zero third-party libraries (no numpy, no scipy, no sympy). 100% exact Python integer arithmetic.

Proof Summary:
  0. Low Parseval + quadratic-phase rank bound forces |Z| <= 108 => |Z| in {64, 96}.
     |Z| = 64 gives sum_P U*sigma = -(12 + B)/4 => B <= 4, contradicting B >= 9
     (AGREEMENT_RANGE.md, no covering-radius theorem needed!).
     Hence |Z| = 96 (Z = SZ x F_2^4) and Parseval slack n_0 + 2*n_8 = 16 (n_8 in {0..7}).
  1. Even-Zeros + Constant Cell-Parity + No-Pair-of-Zeros Lemma:
     - 2 | n_0(s) for all s in SZ.
     - Any zero-free s in SZ forces constant cell parity m(x) == pf (mod 2) on all 16 cells,
       and any s with n_0(s) = 2 forces an 8-even / 8-odd affine hyperplane split (H_p, H_p^c).
     - Hence whenever constant cell parity holds (automatic for n_8 >= 3 and n_8 = 0),
       n_0(s) != 2 for all s in SZ (in particular n_0(0) >= 4, E(0) <= 48).
  2. Mod-16 Affine-Parity Theorem:
     - Every c in SZc is a unique XOR c = s_1 ^ s_2 ^ s_3 with {s_1, s_2, s_3} subset SZ\{0},
       and 4 | (z_c + z_{s_1} + z_{s_2} + z_{s_3}) pointwise.
     - Whenever s_1, s_2, s_3 are all zero-free, b_c(x) = (z_c(x) - pf)/2 (mod 2) is affine
       (deg <= 1), forcing k_c == pf (mod 2) via sum z_c^2 = 144 - 8*k_c (mod 16).
     - For pf = 0 (EVEN): clean (k_c = 0) affine cosets satisfy |z_c| in {0, 12} ONLY (1x12);
       k_c = 2 affine cosets MUST have pattern P1: |z_c| = (0^8, 2^7, 10) (unique cell z_c = -10 when J_c = +2).
  3. Exhaustive closure of all 8 values n_8 in {0, 1, 2, 3, 4, 5, 6, 7}:
     - n_8 = 0, 5, 6, 7, n_8 = 3 ODD, n_8 = 4-I: 100% pure combinatorics + Mod-16 Affine-Parity (ZERO LP!).
     - n_8 = 1: 1 universal aggregate Farkas certificate [-256, 36, 5, -1, 8] (RHS = -720 < 0).
     - n_8 = 2 (const & mixed), n_8 = 3 EVEN, n_8 = 4-II (odd & even): 279 exact integer Farkas certificates
       checked in pure Python integer arithmetic (LHS >= 0 on ALL cells, RHS < 0, y_ub >= 0).
"""
import itertools
import json
import os
import time

# 16x16 Walsh-Hadamard matrix on F_2^4
H4 = [[1 if (bin(a & x).count("1") % 2 == 0) else -1 for x in range(16)] for a in range(16)]

# Canonical rank-4 quadratic residue set Z = SZ x F_2^4 of size 96 containing 0:
SZ = [c for c in range(16) if ((((c & 1) == 0 and ((c >> 1) & 1) == 0) ^ (((c >> 2) & 1) == 1 and ((c >> 3) & 1) == 1)))]
SZc = [c for c in range(16) if c not in SZ]
SZ_set = set(SZ)
A4 = {9, 10, 11, 12}
assert SZ == [0, 4, 8, 13, 14, 15] and SZc == [1, 2, 3, 5, 6, 7, 9, 10, 11, 12]


def fwht16(a):
    """Exact in-place-free 4-stage Walsh-Hadamard transform of a length-16 integer list."""
    v = list(a)
    for step in (1, 2, 4, 8):
        step2 = step * 2
        for i in range(0, 16, step2):
            for j in range(i, i + step):
                x = v[j]
                y = v[j + step]
                v[j] = x + y
                v[j + step] = x - y
    return v


# Cache of 729 ternary cells for each (jm_tuple, pf)
CELL_CACHE = {}


def enum_cells_raw(jm, pf=None):
    """Enumerate all 3^6 = 729 ternary cells v in {-1, 0, 1}^16 matching z_c == jm[c] (mod 3) on SZc.
    Returns deduplicated list of (m, z_tuple) with exact mod-3 check."""
    key = (jm, pf)
    if key in CELL_CACHE:
        return CELL_CACHE[key]
    out = set()
    zm = list(jm)
    for vals in itertools.product((0, 1, 2), repeat=6):
        for idx, s in enumerate(SZ):
            zm[s] = vals[idx]
        # v = H4 @ zm (mod 3), lifted uniquely to {-1, 0, 1}
        raw = fwht16(zm)
        v = [(-1 if (r % 3) == 2 else (r % 3)) for r in raw]
        m = sum(vx * vx for vx in v)
        if pf is not None and (m & 1) != pf:
            continue
        z = tuple(fwht16(v))
        for c in SZc:
            assert (z[c] - jm[c]) % 3 == 0
        out.add((m, z))
    res = list(out)
    CELL_CACHE[key] = res
    return res


def verify_cert(cert_dict, eq_rows, b_eq, ub_rows=None, b_ub=None, name=""):
    """Pure-integer Farkas verification:
         y_ub >= 0,
         y_eq^T eq_rows + y_ub^T ub_rows >= 0 on EVERY cell,
         y_eq^T b_eq + y_ub^T b_ub < 0."""
    y_eq = cert_dict["eq"]
    y_ub = cert_dict.get("ub", [])
    assert len(y_eq) == len(b_eq), f"{name}: eq len mismatch {len(y_eq)} != {len(b_eq)}"
    if ub_rows is None:
        assert len(y_ub) == 0, f"{name}: unexpected ub weights"
        ub_rows = []
        b_ub = []
    else:
        assert len(y_ub) == len(b_ub), f"{name}: ub len mismatch {len(y_ub)} != {len(b_ub)}"
    assert all(isinstance(v, int) for v in y_eq) and all(isinstance(v, int) for v in y_ub)
    assert all(v >= 0 for v in y_ub), f"{name}: negative ub weight!"
    rhs = sum(y_eq[i] * b_eq[i] for i in range(len(b_eq))) + sum(y_ub[i] * b_ub[i] for i in range(len(b_ub)))
    assert rhs < 0, f"{name}: RHS={rhs} is NOT strictly negative!"
    ncells = len(eq_rows[0]) if eq_rows else 0
    for j in range(ncells):
        lhs = sum(y_eq[i] * eq_rows[i][j] for i in range(len(y_eq)) if y_eq[i] != 0)
        if y_ub:
            lhs += sum(y_ub[i] * ub_rows[i][j] for i in range(len(y_ub)) if y_ub[i] != 0)
        assert lhs >= 0, f"{name}: cell {j} violated LHS={lhs} < 0!"


# ==============================================================================
# STEP A: SYMMETRIES & BIJECTION VERIFICATION
# ==============================================================================
def verify_setup_and_symmetries():
    # 1. Exact bijection SZc <-> 3-subsets of SZ\{0}
    triples = {}
    for s1, s2, s3 in itertools.combinations(SZ[1:], 3):
        c = s1 ^ s2 ^ s3
        assert c in SZc and c not in triples
        triples[c] = (s1, s2, s3)
    assert len(triples) == 10
    # Verify A4 = {9, 10, 11, 12} is EXACTLY the set of triples from {8, 13, 14, 15} (avoiding s_1 = 4)
    a4_check = {s1 ^ s2 ^ s3 for s1, s2, s3 in itertools.combinations([8, 13, 14, 15], 3)}
    assert a4_check == A4

    # 2. Enumerate ALL 120 linear automorphisms Aut(SZ) subset GL(4, 2)
    nz_SZ = SZ[1:]
    aut = []
    for e4 in nz_SZ:
        for e8 in nz_SZ:
            if e8 == e4:
                continue
            for e1 in SZc:
                for e2 in SZc:
                    if e2 == e1:
                        continue
                    img = [0] * 16
                    for x in range(16):
                        v = 0
                        if x & 1: v ^= e1
                        if x & 2: v ^= e2
                        if x & 4: v ^= e4
                        if x & 8: v ^= e8
                        img[x] = v
                    if len(set(img)) == 16 and all(img[s] in SZ_set for s in SZ):
                        # Verify exact F_2-linearity on all 16x16 pairs!
                        for a in range(16):
                            for b in range(16):
                                assert img[a ^ b] == (img[a] ^ img[b])
                        aut.append(tuple(img))
    assert len(aut) == 120
    # Verify transitivity on SZ\{0} (5 elements) and SZc (10 elements)
    assert {g[4] for g in aut} == set(nz_SZ)
    assert {g[1] for g in aut} == set(SZc)
    stab4 = [g for g in aut if g[4] == 4]
    assert len(stab4) == 24
    # Verify Stab(4) preserves A4 setwise
    for g in stab4:
        assert {g[c] for c in A4} == A4

    print("  [PASS A] Bijection SZc <-> C(SZ\\{0}, 3), |Aut(SZ)|=120 (transitive on SZ\\{0} & SZc), |Stab(4)|=24.")
    return aut, stab4


def canonical_orbits(part, group, forbid_odd_A4=False):
    """Exact orbit representatives for placing partition `part` into SZc under `group`."""
    groups = []
    i = 0
    while i < len(part):
        j = i
        while j < len(part) and part[j] == part[i]:
            j += 1
        groups.append((part[i], j - i))
        i = j
    reps = set()

    def rec(gi, used, cur):
        if gi == len(groups):
            if forbid_odd_A4:
                for c, kc in zip(cur, part):
                    if c in A4 and (kc % 2 == 1):
                        return
            best = None
            for g in group:
                mp = []
                idx = 0
                for _, cnt in groups:
                    mp.extend(sorted(g[cur[idx + k]] for k in range(cnt)))
                    idx += cnt
                cand = tuple(mp)
                if best is None or cand < best:
                    best = cand
            reps.add(best)
            return
        kc, cnt = groups[gi]
        avail = [c for c in SZc if c not in used and not (forbid_odd_A4 and c in A4 and kc % 2 == 1)]
        for comb in itertools.combinations(avail, cnt):
            rec(gi + 1, used | set(comb), cur + comb)

    rec(0, set(), ())
    return sorted(reps)


# ==============================================================================
# STEP B: EXHAUSTIVE PURE-PYTHON VERIFICATION OF COSET LEMMAS
# ==============================================================================
def verify_exhaustive_coset_lemmas():
    # 1. Exact |J| histograms for k = 1, 2, 3, 4 (all distinct w_i in F_2^4, WLOG w_1 = 0, eps_1 = +1)
    j_hists = {}
    for k in (1, 2, 3, 4):
        hists = set()
        for comb in itertools.combinations(range(1, 16), k - 1):
            ws = (0,) + comb
            for eps in itertools.product((1, -1), repeat=k - 1):
                es = (1,) + eps
                vals = [abs(sum(es[i] * H4[ws[i]][x] for i in range(k))) for x in range(16)]
                hists.add(tuple(sorted((v, vals.count(v)) for v in set(vals))))
        j_hists[k] = sorted(hists)
    assert j_hists == {
        1: [((1, 16),)],
        2: [((0, 8), (2, 8))],
        3: [((1, 12), (3, 4))],
        4: [((0, 6), (2, 8), (4, 2)), ((0, 12), (4, 4)), ((2, 16),)],
    }

    # 2. Build all 32 affine functions on F_2^4 as 16-bit masks
    aff32 = set()
    for a in range(16):
        for b in (0, 1):
            aff32.add(sum((1 << x) for x in range(16) if ((bin(a & x).count("1") & 1) ^ b) == 1))
    assert len(aff32) == 32

    # 3. Exhaustive check over ALL 2^16 = 65,536 4-bit Boolean functions (pure-Python FWHT!):
    #    (i)  Every zero-free s in SZ (W_4(z_s) = 8 * s_s) has AFFINE b_s = (z_s - pf)/2 (mod 2)!
    #    (ii) Every clean coset d (z_d = 3 * W_4(s_d) / 4) with M1 parity (EVEN on H_0={x_0=0}, ODD on H_1={x_0=1})
    #         has ONLY patterns (0^8; 3^7, 9) or (0^6, 6^2; 3^8) => E_{H_0}(d) in {0, 72}!
    H0 = [x for x in range(16) if (x & 1) == 0]
    H1 = [x for x in range(16) if (x & 1) == 1]
    clean_m1_pats = set()
    for mask in range(65536):
        s_vec = [-1 if ((mask >> w) & 1) else 1 for w in range(16)]
        w_vec = fwht16(s_vec)
        # (i) z_s = w_vec // 2
        pf = (w_vec[0] // 2) & 1
        bmask = 0
        all_div4 = True
        for x in range(16):
            zx = w_vec[x] // 2
            assert (zx & 1) == pf
            if ((zx - pf) // 2) & 1:
                bmask |= (1 << x)
            if w_vec[x] & 3:
                all_div4 = False
        assert bmask in aff32
        # (ii) clean M1 check
        if all_div4:
            zd = [(w_vec[x] // 4) * 3 for x in range(16)]
            if all((zd[x] & 1) == 0 for x in H0) and all((zd[x] & 1) == 1 for x in H1):
                clean_m1_pats.add((
                    tuple(sorted(abs(zd[x]) for x in H0)),
                    tuple(sorted(abs(zd[x]) for x in H1)),
                ))
    assert clean_m1_pats == {
        ((0, 0, 0, 0, 0, 0, 0, 0), (3, 3, 3, 3, 3, 3, 3, 9)),
        ((0, 0, 0, 0, 0, 0, 6, 6), (3, 3, 3, 3, 3, 3, 3, 3)),
    }

    # 4. Exhaustive check of ALL k_c = 2 cosets with H_0 = {x_0=0} (J_c=0) and H_1 = {x_0=1} (|J_c|=2):
    #    WLOG S_c = {0, 1} with eps(0) = +1, eps(1) = -1 (shifting S_c by u multiplies z_c and J_c by (-1)^{u.x},
    #    preserving |z_c(x)|, z_c(x)*J_c(x), and affine property of b_c!).
    #    Check BOTH EVEN parity and M1 mixed parity (EVEN on H_0, ODD on H_1)!
    k2_even_pats = set()
    k2_even_aff_pats = set()
    k2_m1_pats = set()
    for mask in range(16384):
        w_in = [4, -4] + [(-12 if ((mask >> i) & 1) else 12) for i in range(14)]
        znum = fwht16(w_in)
        if any(v & 15 for v in znum):
            continue
        z = [v // 16 for v in znum]
        if all((z[x] & 1) == 0 for x in range(16)):
            pat = (tuple(sorted(abs(z[x]) for x in H0)), tuple(sorted(z[x] for x in H1)))
            k2_even_pats.add(pat)
            bmask = sum((1 << x) for x in range(16) if ((z[x] // 2) & 1))
            if bmask in aff32:
                k2_even_aff_pats.add(pat)
        elif all((z[x] & 1) == 0 for x in H0) and all((z[x] & 1) == 1 for x in H1):
            k2_m1_pats.add((tuple(sorted(abs(z[x]) for x in H0)), tuple(sorted(z[x] for x in H1))))

    assert k2_even_pats == {
        ((0, 0, 0, 0, 0, 0, 0, 0), (-10, 2, 2, 2, 2, 2, 2, 2)),
        ((0, 0, 0, 0, 0, 0, 0, 0), (-4, -4, -4, 2, 2, 2, 2, 8)),
        ((0, 0, 0, 0, 0, 0, 6, 6), (-4, -4, 2, 2, 2, 2, 2, 2)),
    }
    assert k2_even_aff_pats == {
        ((0, 0, 0, 0, 0, 0, 0, 0), (-10, 2, 2, 2, 2, 2, 2, 2)),
    }
    assert k2_m1_pats == {
        ((0, 0, 0, 0, 0, 0, 0, 0), (-1, -1, -1, -1, -1, -1, -1, 11)),
        ((0, 0, 0, 0, 0, 0, 0, 0), (-7, -1, -1, -1, -1, 5, 5, 5)),
        ((0, 0, 0, 0, 0, 0, 6, 6), (-1, -1, -1, -1, -1, -1, 5, 5)),
    }
    print("  [PASS B] Exhaustively verified J_HISTS[1..4], ALL 65,536 zero-free affine b_s, clean M1, and k_c=2 EVEN/M1 patterns.")
    return j_hists


# ==============================================================================
# STEP C: n_8 = 0 (PURE COMBINATORICS + MOD-16 AFFINE-PARITY — ZERO LP!)
# ==============================================================================
def verify_n8_0():
    cells = enum_cells_raw((0,) * 16, None)
    odd_cells = [c for c in cells if (c[0] & 1) == 1]
    even_cells = [c for c in cells if (c[0] & 1) == 0]
    assert all(m >= 11 and all(z[u] * z[u] == 9 for u in SZc) for m, z in odd_cells)
    assert all(all(z[u] * z[u] in (0, 36, 144) for u in SZc) for _, z in even_cells)
    # 9*r + 36*(...) = 144 => 4 | r; r >= 12 => m >= 132 > 110; r = 8 => m >= 8*11 + 5*10 = 138 > 110;
    # r = 4 => 30/4 = 7.5 m=10 cells (not integer). Hence r = 0 (ALL 16 cells EVEN => Constant Cell-Parity => n_0(s) != 2)!
    even_ms = sorted({m for m, _ in even_cells})
    assert even_ms == [0, 6, 8, 10, 12, 16]
    m10_planes = {}
    m12_masks = {c: set() for c in SZc}
    m8_masks = set()
    m6_masks = set()
    for m, z in even_cells:
        ezc = sum(z[c] * z[c] for c in SZc)
        z2s = tuple(z[s] * z[s] for s in SZ)
        if m in (0, 6, 8, 16):
            assert ezc == 0
            if m == 8: m8_masks.add(z2s)
            if m == 6: m6_masks.add(z2s)
        elif m == 10:
            assert ezc == 144
            p = tuple(c for c in SZc if z[c] * z[c] == 36)
            assert len(p) == 4
            m10_planes[p] = z2s
        elif m == 12:
            assert ezc == 144
            cs = [c for c in SZc if z[c] * z[c] == 144]
            assert len(cs) == 1
            m12_masks[cs[0]].add(z2s)
    assert len(m10_planes) == 15
    planes_list = list(m10_planes.keys())
    # Weight from k cells of m=12 and (10-k) cells of m=10 is 100 + 2k; remaining 10 - 2k must sum from {0, 6, 8, 16}.
    # ONLY k in {1, 2, 5} are achievable!
    # Check k = 5: 0 valid 5-plane covers of 5 cosets!
    for rem in itertools.combinations(SZc, 5):
        C5 = set(SZc) - set(rem)
        avail = [P for P in planes_list if set(P).issubset(C5)]
        for comb in itertools.combinations_with_replacement(avail, 5):
            cnt = {c: sum(1 for P in comb if c in P) for c in C5}
            assert not all(v == 4 for v in cnt.values())
    # Check k = 1: 0 survivors with E(0) <= 48, E(s) <= 64, E(s) != 56, 8 | E(s)!
    for rem in itertools.combinations(SZc, 1):
        C9 = set(SZc) - set(rem)
        avail = [P for P in planes_list if set(P).issubset(C9)]
        for comb in itertools.combinations_with_replacement(avail, 9):
            cnt = {c: sum(1 for P in comb if c in P) for c in C9}
            if not all(v == 4 for v in cnt.values()):
                continue
            base = [sum(m10_planes[P][j] for P in comb) for j in range(6)]
            for m12 in m12_masks[rem[0]]:
                for ex in m8_masks:
                    tot = [base[j] + m12[j] + ex[j] for j in range(6)]
                    assert not (tot[0] <= 48 and all(x <= 64 and x != 56 and (x % 8 == 0) for x in tot))
    # Check k = 2: EVERY survivor with E(0) <= 48, E(s) != 56, 8 | E(s) has 4 zero-free s in SZ\{0},
    # which by the Mod-16 Affine-Parity Theorem forces 4 clean cosets to be 1x12 (needing 4 cells of m=12 > k=2)!
    k2_checked = 0
    for rem in itertools.combinations(SZc, 2):
        C8 = set(SZc) - set(rem)
        avail = [P for P in planes_list if set(P).issubset(C8)]
        for comb in itertools.combinations_with_replacement(avail, 8):
            cnt = {c: sum(1 for P in comb if c in P) for c in C8}
            if not all(v == 4 for v in cnt.values()):
                continue
            base = [sum(m10_planes[P][j] for P in comb) for j in range(6)]
            for p1 in m12_masks[rem[0]]:
                for p2 in m12_masks[rem[1]]:
                    for ex in m6_masks:
                        tot = [base[j] + p1[j] + p2[j] + ex[j] for j in range(6)]
                        if tot[0] <= 48 and all(x <= 64 and x != 56 and (x % 8 == 0) for x in tot):
                            # Count zero-free s in SZ\{0} (tot[j] == 64 for j in 1..5):
                            nzf = sum(1 for j in range(1, 6) if tot[j] == 64)
                            assert nzf >= 4, f"k=2 survivor with only {nzf} zero-free SZ\\{{0}} cosets!"
                            # C(nzf, 3) >= C(4, 3) = 4 clean cosets MUST be 1x12, contradicting k = 2!
                            k2_checked += 1
    assert k2_checked == 30
    print("  [PASS C] n_8 = 0: 100% excluded (r=0; k=5,1 empty; all 30 k=2 candidates force >=4 clean 1x12 cosets > 2).")


# ==============================================================================
# STEP D: n_8 = 1 (UNIVERSAL AGGREGATE CERT)
# ==============================================================================
def verify_n8_1():
    y = [-256, 36, 5, -1, 8]
    rhs = y[0] * 16 + y[1] * 110 + y[2] * 136 + y[3] * (9 * 144) + y[4] * 4
    assert rhs == -720 < 0
    for c1 in SZc:
        jm = [0] * 16; jm[c1] = 1
        clean = [c for c in SZc if c != c1]
        for m, z in enum_cells_raw(tuple(jm), None):
            lhs = y[0] + y[1] * m + y[2] * (z[c1] * z[c1]) + y[3] * sum(z[d] * z[d] for d in clean) + y[4] * z[c1]
            assert lhs >= 0
    print("  [PASS D] n_8 = 1: all 10/10 cosets certified by [-256, 36, 5, -1, 8] (RHS = -720 < 0).")


# ==============================================================================
# STEP E: n_8 = 2 (CONSTANT PARITY + MIXED PARITY)
# ==============================================================================
def verify_n8_2(aut, certs, used_certs):
    # 1. Constant parity (E(0) <= 48, E(s) <= 64)
    # 2A (1 orbit: c1 = 1)
    for pf in (0, 1):
        jm2 = [0] * 16; jm2[1] = 2
        c0 = enum_cells_raw((0,) * 16, pf)
        c2 = enum_cells_raw(tuple(jm2), pf)
        cells = [(0, 0, m, z) for m, z in c0] + [(1, 2, m, z) for m, z in c2]
        eq = [
            [1 if g == 0 else 0 for g, _, _, _ in cells],
            [1 if g == 1 else 0 for g, _, _, _ in cells],
            [m for _, _, m, _ in cells],
            [z[1] * j for _, j, _, z in cells],
        ] + [[z[c] * z[c] for _, _, _, z in cells] for c in SZc]
        b_eq = [8, 8, 110, 8] + [128 if c == 1 else 144 for c in SZc]
        ub = [[z[s] * z[s] for _, _, _, z in cells] for s in SZ]
        b_ub = [48, 64, 64, 64, 64, 64]
        k = f"n2_2A_const_pf{pf}"
        verify_cert(certs[k], eq, b_eq, ub, b_ub, k); used_certs.add(k)

    # 2B (2 orbits under Aut(SZ): (1, 2) and (1, 5))
    orbs_2B = canonical_orbits((1, 1), aut)
    assert orbs_2B == [(1, 2), (1, 5)]
    for c1, c2 in orbs_2B:
        for pf in (0, 1):
            jm1 = [0] * 16; jm1[c1] = 1; jm1[c2] = 1
            jm2 = [0] * 16; jm2[c1] = 1; jm2[c2] = 2
            ca = enum_cells_raw(tuple(jm1), pf)
            cb = enum_cells_raw(tuple(jm2), pf)
            cells = [(1, 1, m, z) for m, z in ca] + [(1, -1, m, z) for m, z in cb]
            eq = [
                [1] * len(cells),
                [m for _, _, m, _ in cells],
                [z[c1] * j1 for j1, _, _, z in cells],
                [z[c2] * j2 for _, j2, _, z in cells],
            ] + [[z[c] * z[c] for _, _, _, z in cells] for c in SZc]
            b_eq = [16, 110, 4, 4] + [136 if c in (c1, c2) else 144 for c in SZc]
            ub = [[z[s] * z[s] for _, _, _, z in cells] for s in SZ]
            b_ub = [48, 64, 64, 64, 64, 64]
            k = f"n2_2B_const_{c1}_{c2}_pf{pf}"
            verify_cert(certs[k], eq, b_eq, ub, b_ub, k); used_certs.add(k)

    # 2. Mixed parity (all 6 n_0(s) = 2 => E(s) = 56, affine hyperplane 8E + 8O)
    # 2B MIXED (2 orbits)
    for c1, c2 in orbs_2B:
        cells = []
        for pf in (0, 1):
            for j2 in (1, -1):
                jm = [0] * 16; jm[c1] = 1; jm[c2] = j2 % 3
                for m, z in enum_cells_raw(tuple(jm), pf):
                    cells.append((pf, 1, j2, m, z))
        eq = [
            [1 if pf == 0 else 0 for pf, _, _, _, _ in cells],
            [1 if pf == 1 else 0 for pf, _, _, _, _ in cells],
            [m for _, _, _, m, _ in cells],
            [z[c1] * j1 for _, j1, _, _, z in cells],
            [z[c2] * j2 for _, _, j2, _, z in cells],
        ] + [[z[c] * z[c] for _, _, _, _, z in cells] for c in SZc] + [[z[s] * z[s] for _, _, _, _, z in cells] for s in SZ]
        b_eq = [8, 8, 110, 4, 4] + [136 if c in (c1, c2) else 144 for c in SZc] + [56] * 6
        k = f"n2_2B_mixed_{c1}_{c2}"
        verify_cert(certs[k], eq, b_eq, None, None, k); used_certs.add(k)

    # 2A MIXED (1 orbit: c1 = 1): M2, M3, M1
    for mname, grp_specs in [
        ("M2", [(0, 1, 8), (2, 0, 8)]),
        ("M3", [(0, 0, 4), (0, 1, 4), (2, 0, 4), (2, 1, 4)]),
    ]:
        cells = []
        for gid, (jv, pf, _) in enumerate(grp_specs):
            jm = [0] * 16; jm[1] = jv % 3
            for m, z in enum_cells_raw(tuple(jm), pf):
                cells.append((gid, jv, m, z))
        eq = [[1 if g == gid else 0 for g, _, _, _ in cells] for gid in range(len(grp_specs))] + [
            [m for _, _, m, _ in cells],
            [z[1] * j for _, j, _, z in cells],
        ] + [[z[c] * z[c] for _, _, _, z in cells] for c in SZc] + [[z[s] * z[s] for _, _, _, z in cells] for s in SZ]
        b_eq = [cnt for _, _, cnt in grp_specs] + [110, 8] + [128 if c == 1 else 144 for c in SZc] + [56] * 6
        k = f"n2_2A_mixed_{mname}"
        verify_cert(certs[k], eq, b_eq, None, None, k); used_certs.add(k)

    # 2A MIXED M1 (H_0 = 8 EVEN, H_1 = 8 ODD):
    # First check Pattern 3 (z_1 = +11 on H_1) has 0 cells!
    jm1 = [0] * 16; jm1[1] = 2
    h1_raw = enum_cells_raw(tuple(jm1), 1)
    h1_z11 = [
        (m, z) for m, z in h1_raw
        if z[1] == 11 and all(abs(z[d]) in (3, 9) for d in SZc[1:]) and all(abs(z[s]) <= 7 for s in SZ)
    ]
    assert len(h1_z11) == 0, "Pattern 3 in 2A MIXED M1 unexpectedly had z_1 == +11 cells!"
    # Patterns 1 & 2:
    h0_cells = [
        (0, m, z) for m, z in enum_cells_raw((0,) * 16, 0)
        if all(abs(z[d]) in (0, 6) for d in SZc[1:]) and all(abs(z[s]) <= 6 for s in SZ) and abs(z[1]) in (0, 6)
    ]
    h1_cells = [
        (1, m, z) for m, z in h1_raw
        if all(abs(z[d]) in (3, 9) for d in SZc[1:]) and all(abs(z[s]) <= 7 for s in SZ) and z[1] in (-7, -1, 5)
    ]
    cells = h0_cells + h1_cells
    c6_row = [1 if (g == 0 and m == 6) else 0 for g, m, _ in cells]
    k0_row = [1 if (g == 0 and m == 10 and z[1] == 0) else 0 for g, m, z in cells]
    ub_m1 = [[(z[d] * z[d] if g == 0 else 0) for g, _, z in cells] for d in SZc[1:]]
    b_ub_m1 = [72] * 9
    for pname, (u, vp, vm) in [("P1", (2, 2, 0)), ("P2", (0, 3, 1))]:
        eq_base = [
            [1 if g == 0 else 0 for g, _, _ in cells],
            [1 if g == 1 else 0 for g, _, _ in cells],
            [m for _, m, _ in cells],
            [1 if (g == 0 and abs(z[1]) == 6) else 0 for g, _, z in cells],
            [1 if (g == 1 and z[1] == 5) else 0 for g, _, z in cells],
            [1 if (g == 1 and z[1] == -7) else 0 for g, _, z in cells],
        ] + [[z[c] * z[c] for _, _, z in cells] for c in SZc] + [[z[s] * z[s] for _, _, z in cells] for s in SZ]
        b_base = [8, 8, 110, u, vp, vm] + [128 if c == 1 else 144 for c in SZc] + [56] * 6
        for c6v in range(9):
            if c6v in (0, 1):
                for kv in range(9):
                    k = f"n2_2A_M1_{pname}_c6_{c6v}_k0_{kv}"
                    verify_cert(certs[k], eq_base + [c6_row, k0_row], b_base + [c6v, kv], ub_m1, b_ub_m1, k)
                    used_certs.add(k)
            else:
                k = f"n2_2A_M1_{pname}_c6_{c6v}"
                verify_cert(certs[k], eq_base + [c6_row], b_base + [c6v], ub_m1, b_ub_m1, k)
                used_certs.add(k)
    print("  [PASS E] n_8 = 2: constant parity (2A, 2B even/odd) + mixed parity (2B, 2A M2/M3/M1) 100% certified.")


# ==============================================================================
# STEP F: n_8 = 3 (ODD 1-LINE DEAD; EVEN CERTIFIED ACROSS ALL Aut(SZ) ORBITS!)
# ==============================================================================
def verify_n8_3(aut, certs, used_certs):
    # ODD: n_0 = 10 < 12 => Constant Cell-Parity & n_0(s) != 2 => at least 4 zero-free s in SZ\{0}
    #      => at least C(4, 3) = 4 affine cosets in SZc => ODD forces k_c >= 1 on each => n_8 >= 4 > 3! DEAD!
    # EVEN (3): 1 orbit (1,)
    jm1 = [0] * 16; jm1[1] = 1
    c1_l = enum_cells_raw(tuple(jm1), 0)
    c3_l = enum_cells_raw((0,) * 16, 0)
    cells = [(0, 1, m, z) for m, z in c1_l] + [(1, 3, m, z) for m, z in c3_l]
    eq = [
        [1 if g == 0 else 0 for g, _, _, _ in cells],
        [1 if g == 1 else 0 for g, _, _, _ in cells],
        [m for _, _, m, _ in cells],
        [z[1] * j for _, j, _, z in cells],
    ] + [[z[c] * z[c] for _, _, _, z in cells] for c in SZc]
    b_eq = [12, 4, 110, 12] + [120 if c == 1 else 144 for c in SZc]
    ub = [[z[s] * z[s] for _, _, _, z in cells] for s in SZ]
    b_ub = [48, 64, 64, 64, 64, 64]
    verify_cert(certs["n3_3_even"], eq, b_eq, ub, b_ub, "n3_3_even"); used_certs.add("n3_3_even")

    # EVEN (2, 1): 2 orbits
    orbs_21 = canonical_orbits((2, 1), aut)
    assert orbs_21 == [(1, 2), (1, 5)]
    for c1, c2 in orbs_21:
        j0 = [0] * 16; j0[c2] = 1
        j2p = [0] * 16; j2p[c1] = 2; j2p[c2] = 1
        j2m = [0] * 16; j2m[c1] = 2; j2m[c2] = 2
        cells = ([(0, 0, 1, m, z) for m, z in enum_cells_raw(tuple(j0), 0)]
                 + [(1, 2, 1, m, z) for m, z in enum_cells_raw(tuple(j2p), 0)]
                 + [(1, 2, -1, m, z) for m, z in enum_cells_raw(tuple(j2m), 0)])
        eq = [
            [1 if g == 0 else 0 for g, _, _, _, _ in cells],
            [1 if g == 1 else 0 for g, _, _, _, _ in cells],
            [m for _, _, _, m, _ in cells],
            [z[c1] * j1 for _, j1, _, _, z in cells],
            [z[c2] * j2 for _, _, j2, _, z in cells],
        ] + [[z[c] * z[c] for _, _, _, _, z in cells] for c in SZc]
        b_eq = [8, 8, 110, 8, 4] + [128 if c == c1 else (136 if c == c2 else 144) for c in SZc]
        ub = [[z[s] * z[s] for _, _, _, _, z in cells] for s in SZ]
        k = f"n3_21_even_{c1}_{c2}"
        verify_cert(certs[k], eq, b_eq, ub, b_ub, k); used_certs.add(k)

    # EVEN (1, 1, 1): 4 orbits
    orbs_111 = canonical_orbits((1, 1, 1), aut)
    assert len(orbs_111) == 4
    for c1, c2, c3 in orbs_111:
        cells = []
        for s2 in (1, -1):
            for s3 in (1, -1):
                jm = [0] * 16; jm[c1] = 1; jm[c2] = s2 % 3; jm[c3] = s3 % 3
                for m, z in enum_cells_raw(tuple(jm), 0):
                    cells.append((1, s2, s3, m, z))
        eq = [
            [1] * len(cells),
            [m for _, _, _, m, _ in cells],
            [z[c1] * j1 for j1, _, _, _, z in cells],
            [z[c2] * j2 for _, j2, _, _, z in cells],
            [z[c3] * j3 for _, _, j3, _, z in cells],
        ] + [[z[c] * z[c] for _, _, _, _, z in cells] for c in SZc]
        b_eq = [16, 110, 4, 4, 4] + [136 if c in (c1, c2, c3) else 144 for c in SZc]
        ub = [[z[s] * z[s] for _, _, _, _, z in cells] for s in SZ]
        k = f"n3_111_even_{c1}_{c2}_{c3}"
        verify_cert(certs[k], eq, b_eq, ub, b_ub, k); used_certs.add(k)
    print("  [PASS F] n_8 = 3: ODD 1-line Mod-16 Affine-Parity dead; EVEN (3), (2,1), (1,1,1) 100% certified.")


# ==============================================================================
# STEP G: n_8 = 4 (SUBCASE 4-I PURE COMBINATORICS; SUBCASE 4-II CERTIFIED!)
# ==============================================================================
def verify_n8_4(stab4, j_hists, certs, used_certs):
    # --- Subcase 4-I: n_0(0) = 8, ALL 5 s in SZ\{0} zero-free => ALL 10 cosets in SZc affine! ---
    # ODD: n_8 >= 10 > 4 -> DEAD!
    # EVEN: k_c even everywhere -> ONLY (4,) and (2, 2), all clean cosets |z_d| in {0, 12}!
    #   (a) (4,) [all 10 cosets]: every cell with 9 clean in {0, 12} has (#cl12>=1 => #cl12==1 and m==12) AND m != 2!
    #       So 9 clean cosets force 9 distinct cells of m=12 (sum=108), leaving 110 - 108 = 2 (no m=2 cell!).
    for c1 in SZc:
        clean9 = [c for c in SZc if c != c1]
        for j1 in (0, 1, 2):
            jm = [0] * 16; jm[c1] = j1
            for m, z in enum_cells_raw(tuple(jm), 0):
                if all(abs(z[d]) in (0, 12) for d in clean9):
                    assert m != 2
                    nc12 = sum(1 for d in clean9 if abs(z[d]) == 12)
                    if nc12 >= 1:
                        assert nc12 == 1 and m == 12
    #   (b) (2, 2) [all 45 pairs]: k_c=2 affine forces P1 (needs cell with z_{c1} == -10 when J_{c1}=+2) & 8 clean in {0,12}!
    for c1, c2 in itertools.combinations(SZc, 2):
        clean8 = [c for c in SZc if c not in (c1, c2)]
        for j2 in (0, 1, 2):
            jm = [0] * 16; jm[c1] = 2; jm[c2] = j2
            for _, z in enum_cells_raw(tuple(jm), 0):
                assert not (z[c1] == -10 and all(abs(z[d]) in (0, 12) for d in clean8))

    # --- Subcase 4-II: n_0(0) = 4, n_0(s_1) = 4 (WLOG s_1 = 4 by verified Aut(SZ) transitivity!) ---
    # A4 = {9, 10, 11, 12} are ALL affine!
    # 4-II ODD: forces (1,1,1,1) on A4={9,10,11,12}! Certified by n4_4II_odd (no affine cell filter even needed!).
    cells = []
    for s10, s11, s12 in itertools.product((1, -1), repeat=3):
        jm = [0] * 16; jm[9] = 1; jm[10] = s10 % 3; jm[11] = s11 % 3; jm[12] = s12 % 3
        for m, z in enum_cells_raw(tuple(jm), 1):
            cells.append(((1, s10, s11, s12), m, z))
    eq = ([[1] * len(cells), [m for _, m, _ in cells]]
          + [[z[c] * z[c] for _, _, z in cells] for c in SZc]
          + [[z[c] * jt[i] for jt, _, z in cells] for i, c in enumerate(sorted(A4))]
          + [[z[s] * z[s] for _, _, z in cells] for s in SZ])
    b_eq = [16, 110] + [136 if c in A4 else 144 for c in SZc] + [4, 4, 4, 4] + [48, 48, 64, 64, 64, 64]
    verify_cert(certs["n4_4II_odd"], eq, b_eq, None, None, "n4_4II_odd"); used_certs.add("n4_4II_odd")

    # 4-II EVEN: all 5 partitions under Stab(4) with k_c even on A4!
    for part in [(4,), (3, 1), (2, 2), (2, 1, 1), (1, 1, 1, 1)]:
        reps = canonical_orbits(part, stab4, forbid_odd_A4=True)
        ptag = "_".join(map(str, part))
        for rep in reps:
            if part == (2, 2) and rep in ((1, 2), (1, 5)):
                continue
            act_set = set(rep)
            k_map = dict(zip(rep, part))
            rtag = "_".join(map(str, rep))
            for hidx, hcombo in enumerate(itertools.product(*(j_hists[k] for k in part))):
                val_opts = []
                for idx_i, h in enumerate(hcombo):
                    opts = []
                    for v, _ in h:
                        if v == 0: opts.append(0)
                        elif idx_i == 0: opts.append(v)
                        else: opts.extend([v, -v])
                    val_opts.append(opts)
                cells = []
                for jtup in itertools.product(*val_opts):
                    if next((v for v in jtup if v != 0), 0) < 0:
                        continue
                    jm = [0] * 16
                    for c, jv in zip(rep, jtup):
                        jm[c] = jv % 3
                    for m, z in enum_cells_raw(tuple(jm), 0):
                        ok = True
                        if abs(z[0]) > 6 or abs(z[4]) > 6:
                            ok = False
                        if ok:
                            for s in SZ[2:]:
                                if abs(z[s]) > 8:
                                    ok = False; break
                        if ok:
                            for c in SZc:
                                if c not in act_set:
                                    if c in A4:
                                        if abs(z[c]) not in (0, 12): ok = False; break
                                    else:
                                        if abs(z[c]) > 12: ok = False; break
                                else:
                                    if c in A4 and k_map[c] == 2 and abs(z[c]) not in (0, 2, 10):
                                        ok = False; break
                        if ok:
                            cells.append((jtup, m, z))
                eq = [[1] * len(cells), [m for _, m, _ in cells]]
                b_eq = [16, 110]
                for c in SZc:
                    eq.append([z[c] * z[c] for _, _, z in cells])
                    b_eq.append(144 - 8 * k_map.get(c, 0))
                for ik, (c, kc) in enumerate(zip(rep, part)):
                    eq.append([z[c] * jt[ik] for jt, _, z in cells])
                    b_eq.append(4 * kc)
                for ik, h in enumerate(hcombo):
                    if len(h) > 1:
                        for val, cnt in h[:-1]:
                            eq.append([1 if abs(jt[ik]) == val else 0 for jt, _, _ in cells])
                            b_eq.append(cnt)
                for si, s in enumerate(SZ):
                    eq.append([z[s] * z[s] for _, _, z in cells])
                    b_eq.append(48 if si in (0, 1) else 64)
                for c in sorted(A4):
                    if k_map.get(c, 0) == 2:
                        eq.append([1 if abs(z[c]) == 10 else 0 for _, _, z in cells])
                        b_eq.append(1)
                k = f"n4_4II_even_{ptag}_{rtag}_h{hidx}"
                verify_cert(certs[k], eq, b_eq, None, None, k); used_certs.add(k)

    # 4-II EVEN (2, 2) on the 2 remaining orbits (1, 2) and (1, 5):
    # Two affine hyperplanes H^(1), H^(2) in F_2^4 give ONLY 3 joint |J|-splits: 8/8-comp, 4/4/4/4, 8/8-same!
    PATS = {
        "P1": (0, (0,),   ((-20, 1), (4, 7))),
        "P2": (0, (0,),   ((-8, 3),  (4, 4), (16, 1))),
        "P3": (2, (0, 6), ((-8, 2),  (4, 6))),
    }
    for rep in ((1, 2), (1, 5)):
        c1, c2 = rep
        rtag = f"{c1}_{c2}"
        # (a) 8/8-comp & 4/4/4/4
        for cname, j_specs in [
            ("comp", [([(2, 0)], 8), ([(0, 2)], 8)]),
            ("4444", [([(0, 0)], 4), ([(2, 0)], 4), ([(0, 2)], 4), ([(2, 2), (2, -2)], 4)]),
        ]:
            cells = []
            for gid, (jtups, _) in enumerate(j_specs):
                for jtup in jtups:
                    jm = [0] * 16; jm[c1] = jtup[0] % 3; jm[c2] = jtup[1] % 3
                    for m, z in enum_cells_raw(tuple(jm), 0):
                        if (abs(z[0]) <= 6 and abs(z[4]) <= 6
                                and all(abs(z[s]) <= 8 for s in SZ[2:])
                                and all(abs(z[c]) in (0, 12) for c in A4)
                                and all(abs(z[c]) <= 12 for c in SZc if c not in A4 and c not in rep)):
                            cells.append((gid, jtup, m, z))
            eq = ([[1 if g == gid else 0 for g, _, _, _ in cells] for gid in range(len(j_specs))]
                  + [[m for _, _, m, _ in cells],
                     [z[c1] * jt[0] for _, jt, _, z in cells],
                     [z[c2] * jt[1] for _, jt, _, z in cells]]
                  + [[z[c] * z[c] for _, _, _, z in cells] for c in SZc]
                  + [[z[s] * z[s] for _, _, _, z in cells] for s in SZ])
            b_eq = [cnt for _, cnt in j_specs] + [110, 8, 8] + [128 if c in rep else 144 for c in SZc] + [48, 48, 64, 64, 64, 64]
            k = f"n4_4II_22_{rtag}_{cname}"
            verify_cert(certs[k], eq, b_eq, None, None, k); used_certs.add(k)

        # (b) 8/8-same: all 8 non-(P2, P2) pattern pairs
        for p1n, p2n in itertools.product(("P1", "P2", "P3"), repeat=2):
            if (p1n, p2n) == ("P2", "P2"):
                continue
            u1, h0s1, zj1_req = PATS[p1n]
            u2, h0s2, zj2_req = PATS[p2n]
            zj1_vals = {v for v, _ in zj1_req}
            zj2_vals = {v for v, _ in zj2_req}
            cells = []
            for gid, jtups in [(0, [(0, 0)]), (1, [(2, 2), (2, -2)])]:
                for jtup in jtups:
                    jm = [0] * 16; jm[c1] = jtup[0] % 3; jm[c2] = jtup[1] % 3
                    for m, z in enum_cells_raw(tuple(jm), 0):
                        if not (abs(z[0]) <= 6 and abs(z[4]) <= 6
                                and all(abs(z[s]) <= 8 for s in SZ[2:])
                                and all(abs(z[c]) in (0, 12) for c in A4)
                                and all(abs(z[c]) <= 12 for c in SZc if c not in A4 and c not in rep)):
                            continue
                        if gid == 0:
                            if abs(z[c1]) not in h0s1 or abs(z[c2]) not in h0s2: continue
                        else:
                            if (z[c1] * jtup[0]) not in zj1_vals or (z[c2] * jtup[1]) not in zj2_vals: continue
                        cells.append((gid, jtup, m, z))
            eq = [
                [1 if g == 0 else 0 for g, _, _, _ in cells],
                [1 if g == 1 else 0 for g, _, _, _ in cells],
                [m for _, _, m, _ in cells],
            ]
            b_eq = [8, 8, 110]
            if u1 > 0: eq.append([1 if (g == 0 and abs(z[c1]) == 6) else 0 for g, _, _, z in cells]); b_eq.append(u1)
            if u2 > 0: eq.append([1 if (g == 0 and abs(z[c2]) == 6) else 0 for g, _, _, z in cells]); b_eq.append(u2)
            for val, cnt in zj1_req:
                eq.append([1 if (g == 1 and z[c1] * jt[0] == val) else 0 for g, jt, _, z in cells]); b_eq.append(cnt)
            for val, cnt in zj2_req:
                eq.append([1 if (g == 1 and z[c2] * jt[1] == val) else 0 for g, jt, _, z in cells]); b_eq.append(cnt)
            for c in SZc: eq.append([z[c] * z[c] for _, _, _, z in cells]); b_eq.append(128 if c in rep else 144)
            for si, s in enumerate(SZ): eq.append([z[s] * z[s] for _, _, _, z in cells]); b_eq.append(48 if si in (0, 1) else 64)
            k = f"n4_4II_22_{rtag}_same_{p1n}_{p2n}"
            verify_cert(certs[k], eq, b_eq, None, None, k); used_certs.add(k)

        # (c) 8/8-same (P2, P2): sequential s_star in [8, 15, 13, 14], then s_star = None!
        p2_cells = []
        for gid, jtups in [(0, [(0, 0)]), (1, [(2, 2), (2, -2)])]:
            for jtup in jtups:
                jm = [0] * 16; jm[c1] = jtup[0] % 3; jm[c2] = jtup[1] % 3
                for m, z in enum_cells_raw(tuple(jm), 0):
                    if not (abs(z[0]) <= 6 and abs(z[4]) <= 6
                            and all(abs(z[s]) <= 8 for s in SZ[2:])
                            and all(abs(z[c]) in (0, 12) for c in A4)
                            and all(abs(z[c]) <= 12 for c in SZc if c not in A4 and c not in rep)):
                        continue
                    if gid == 0:
                        if z[c1] != 0 or z[c2] != 0: continue
                    else:
                        if (z[c1] * jtup[0]) not in (-8, 4, 16) or (z[c2] * jtup[1]) not in (-8, 4, 16): continue
                    p2_cells.append((gid, jtup, m, z))

        prev = []
        for s_star in (8, 15, 13, 14):
            sub = [
                cell for cell in p2_cells
                if abs(cell[3][s_star]) in (0, 8) and all(abs(cell[3][sp]) <= 6 for sp in prev)
            ]
            eq = [
                [1 if g == 0 else 0 for g, _, _, _ in sub],
                [1 if g == 1 else 0 for g, _, _, _ in sub],
                [m for _, _, m, _ in sub],
                [1 if abs(z[s_star]) == 8 else 0 for _, _, _, z in sub],
            ]
            b_eq = [8, 8, 110, 1]
            for c in SZc: eq.append([z[c] * z[c] for _, _, _, z in sub]); b_eq.append(128 if c in rep else 144)
            for ik, ck in enumerate(rep):
                for val, cnt in ((16, 1), (-8, 3), (4, 4)):
                    eq.append([1 if (g == 1 and z[ck] * jt[ik] == val) else 0 for g, jt, _, z in sub]); b_eq.append(cnt)
            for si, s in enumerate(SZ): eq.append([z[s] * z[s] for _, _, _, z in sub]); b_eq.append(48 if si in (0, 1) else 64)
            k = f"n4_4II_22_{rtag}_P2P2_s{s_star}"
            verify_cert(certs[k], eq, b_eq, None, None, k); used_certs.add(k)
            prev.append(s_star)

        # s_star = None: all |z_s| <= 6 on {8, 13, 14, 15}
        sub = [cell for cell in p2_cells if all(abs(cell[3][s]) <= 6 for s in SZ[2:])]
        # Verify EVERY cell in `sub` has |z_s| in {0, 4} for ALL s in {8, 13, 14, 15}!
        # By the Affine 2-Plane Lemma (|W_4(z_s)|=8 & |z_s| in {0, 4} => supp(z_s) is an affine 2-plane),
        # E_{H_0}(s) MUST lie in {0, 32, 64} for every s in {8, 13, 14, 15}!
        for s in SZ[2:]:
            assert all(abs(cell[3][s]) in (0, 4) for cell in sub)
        eq_base = [
            [1 if g == 0 else 0 for g, _, _, _ in sub],
            [1 if g == 1 else 0 for g, _, _, _ in sub],
            [m for _, _, m, _ in sub],
        ]
        b_base = [8, 8, 110]
        for c in SZc: eq_base.append([z[c] * z[c] for _, _, _, z in sub]); b_base.append(128 if c in rep else 144)
        for ik, ck in enumerate(rep):
            for val, cnt in ((16, 1), (-8, 3), (4, 4)):
                eq_base.append([1 if (g == 1 and z[ck] * jt[ik] == val) else 0 for g, jt, _, z in sub]); b_base.append(cnt)
        for si, s in enumerate(SZ): eq_base.append([z[s] * z[s] for _, _, _, z in sub]); b_base.append(48 if si in (0, 1) else 64)
        e0_rows = [[(z[s] * z[s] if g == 0 else 0) for g, _, _, z in sub] for s in SZ[2:]]
        for e0_tup in itertools.product((0, 32, 64), repeat=4):
            etag = "_".join(map(str, e0_tup))
            k = f"n4_4II_22_{rtag}_P2P2_e0_{etag}"
            verify_cert(certs[k], eq_base + e0_rows, b_base + list(e0_tup), None, None, k)
            used_certs.add(k)

    print("  [PASS G] n_8 = 4: Subcase 4-I (pure Mod-16 Affine-Parity) + Subcase 4-II (odd + all 5 even partitions) 100% certified.")


# ==============================================================================
# STEP H: n_8 = 5, 6, 7 (100% PURE COMBINATORICS + MOD-16 AFFINE-PARITY — ZERO LP!)
# ==============================================================================
def verify_n8_5_6_7():
    # n_8 = 7 (n_0 = 2 < 12): Constant Cell-Parity => n_0(0) = 2 violates No-Pair-of-Zeros! DEAD!
    # n_8 = 5 (n_0 = 6 < 12): Constant Cell-Parity & n_0(s) != 2 => n_0(0) = 6, all 5 s in SZ\{0} zero-free
    #   => ALL 10 cosets in SZc affine: ODD forces n_8 >= 10 > 5; EVEN forces 2 | n_8 (contradicts 5)! DEAD!
    # n_8 = 6 (n_0 = 4 < 12): Constant Cell-Parity & n_0(s) != 2 => n_0(0) = 4, all 5 s in SZ\{0} zero-free
    #   => ALL 10 cosets in SZc affine: ODD forces n_8 >= 10 > 6; EVEN forces k_c even everywhere => ONLY (6,), (4, 2), (2, 2, 2)!
    #   - (6,): already verified in Step G (4-I) that for all 10 cosets, 9 clean in {0, 12} => 9*12=108 & no m=2 cell! DEAD!
    #   - (4, 2) [all 90 ordered pairs (c1, c2)]: c2 has k_c=2 affine => needs cell with z_{c2} == -10 (J_{c2}=+2) & 8 clean in {0, 12}!
    #     Already verified 0 such cells across all 45 unordered pairs (90 ordered pairs by symmetry of j2)! Check explicitly:
    for c1 in SZc:
        for c2 in SZc:
            if c1 == c2:
                continue
            clean8 = [c for c in SZc if c not in (c1, c2)]
            for j1 in (0, 1, 2):
                jm = [0] * 16; jm[c1] = j1; jm[c2] = 2
                for _, z in enum_cells_raw(tuple(jm), 0):
                    assert not (z[c2] == -10 and all(abs(z[d]) in (0, 12) for d in clean8))
    #   - (2, 2, 2) [all 120 triples (c1, c2, c3)]: c1 has k_c=2 affine => needs cell with z_{c1} == -10 & 7 clean in {0, 12}!
    for c1, c2, c3 in itertools.combinations(SZc, 3):
        clean7 = [c for c in SZc if c not in (c1, c2, c3)]
        for j2 in (0, 1, 2):
            for j3 in (0, 1, 2):
                jm = [0] * 16; jm[c1] = 2; jm[c2] = j2; jm[c3] = j3
                for _, z in enum_cells_raw(tuple(jm), 0):
                    assert not (z[c1] == -10 and all(abs(z[d]) in (0, 12) for d in clean7))
    print("  [PASS H] n_8 = 5, 6, 7: 100% excluded with ZERO LP (No-Pair-of-Zeros + Mod-16 Affine-Parity on all 90 pairs & 120 triples).")


def main():
    t0 = time.time()
    cert_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "t110_farkas_certs.json")
    with open(cert_path) as f:
        certs = json.load(f)
    used_certs = set()

    print("=== VERIFYING t = 110 IMPOSSIBLE (100% PURE INTEGER ARITHMETIC, ZERO THIRD-PARTY LIBS) ===")
    aut, stab4 = verify_setup_and_symmetries()
    j_hists = verify_exhaustive_coset_lemmas()
    verify_n8_0()
    verify_n8_1()
    verify_n8_2(aut, certs, used_certs)
    verify_n8_3(aut, certs, used_certs)
    verify_n8_4(stab4, j_hists, certs, used_certs)
    verify_n8_5_6_7()

    assert used_certs == set(certs.keys()), f"Unused certs: {set(certs.keys()) - used_certs}"
    dt = time.time() - t0
    print(f"\nALL CASES OF t = 110 (|Z| = 96, n_8 in {{0..7}}, {len(used_certs)} integer Farkas certs) 100% CERTIFIED IMPOSSIBLE in {dt:.2f}s!")


if __name__ == "__main__":
    main()
