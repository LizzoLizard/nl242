// Test the remaining e <= 21 profiles of deficit = 80 (after exact symplectic phase elimination!)
// Exact same SectionSearch engine as nl242-lab/check_high_sections.cpp, parallelized across profiles.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <vector>

namespace {
constexpr int dimension = 8;
constexpr int samples = 128;
constexpr std::array<int, 3> weight_order{2, 3, 1};
constexpr std::array<int, 4> mass{0, 6, 3, 5};
using Counts = std::array<int, 4>;
using Word = std::uint64_t;

int parity(int x) { return __builtin_parity(static_cast<unsigned>(x)); }
int order(int w) { return (w + 1) % 3; }

void hadamard(std::array<int, samples>& values) {
    for (int width = 1; width < samples; width *= 2) {
        for (int block = 0; block < samples; block += 2 * width) {
            for (int i = block; i < block + width; ++i) {
                int a = values[i], b = values[i + width];
                values[i] = a + b;
                values[i + width] = a - b;
            }
        }
    }
}

Word xor_indices(Word v, int mask) {
    constexpr std::array<Word, 6> low{
        0x5555555555555555ULL, 0x3333333333333333ULL, 0x0f0f0f0f0f0f0f0fULL,
        0x00ff00ff00ff00ffULL, 0x0000ffff0000ffffULL, 0x00000000ffffffffULL};
    for (int k = 0; k < 6; ++k) {
        if (mask & (1 << k)) {
            int step = 1 << k;
            v = ((v & low[k]) << step) | ((v >> step) & low[k]);
        }
    }
    return v;
}

struct SectionSearch {
    int deficit;
    std::array<int, dimension> basis{}, row{};
    std::vector<int> extras, columns;
    int odd_columns = 0, words = 0;
    std::array<int, dimension + 1> tail_residues{};
    std::array<std::array<std::vector<Word>, 7>, dimension + 1> feasible;
    std::array<std::vector<int>, dimension> row_options;
    std::uint64_t lifted = 0;
    std::uint64_t survivors = 0;

    explicit SectionSearch(int value) : deficit(value) {}

    void check_lift(int signs) {
        std::array<int, 256> residual{};
        for (int i = 0; i < dimension; ++i) residual[1 << i] = basis[i];
        for (unsigned j = 0; j < extras.size(); ++j) {
            residual[columns[j]] = (signs & (1 << j)) ? -extras[j] : extras[j];
        }
        std::array<int, samples> values{};
        for (int a = 0; a < samples; ++a) values[a] = residual[2*a + (1 ^ parity(a))];
        hadamard(values);
        int energy = 0;
        for (int& v : values) {
            v = (v % 7 + 10) % 7 - 3;
            if (v < -2 || v > 2) throw std::logic_error("invalid retained lift");
            energy += v*v;
        }
        ++lifted;
        if (4*energy != 784 - deficit) return;
        hadamard(values);
        for (int a = 0; a < samples; ++a) {
            int h = values[a]/2;
            if (2*h != values[a] || h % 2 == 0 || std::abs(h) > 7 ||
                (h - residual[2*a + (1 ^ parity(a))]) % 7 != 0) return;
        }
        ++survivors;
    }

    void prepare() {
        int p = static_cast<int>(extras.size());
        int assignments = 1 << p;
        words = std::max(1, assignments/64);
        for (auto& level : feasible) for (auto& residues : level) residues.assign(words, 0);
        for (int y = 0; y < words*64; ++y) {
            int sum = 0;
            for (int j = 0; j < p; ++j) sum += (y & (1 << j)) ? 7-extras[j] : extras[j];
            for (int b = 0; b < 7; ++b) {
                int r = (b + sum) % 7;
                if (r != 3 && r != 4) feasible[0][b][y/64] |= Word(1) << (y%64);
            }
        }
        tail_residues[dimension] = 1;
        for (int i = dimension-1; i >= 0; --i) {
            int w = basis[i], next = 0;
            for (int z = 0; z < 7; ++z) {
                if (tail_residues[i+1] & (1 << z)) {
                    next |= (1 << ((z+w)%7)) | (1 << ((z+7-w)%7));
                }
            }
            tail_residues[i] = next;
            row_options[i].clear();
            for (int bits = 0; bits < assignments; ++bits) {
                int cost = mass[w];
                bool allowed = true;
                for (int j = 0; j < p; ++j) {
                    if (bits & (1 << j)) {
                        if (order(w) > order(extras[j])) allowed = false;
                        cost += mass[extras[j]];
                    }
                }
                if (allowed && cost % 4 == 0) row_options[i].push_back(bits);
            }
        }
    }

    bool refine(int i, int bits) {
        int w = basis[i];
        for (int b = 0; b < 7; ++b) {
            bool live = false;
            for (int k = 0; k < words; ++k) {
                Word plus = feasible[i][(b+w)%7][k];
                Word minus = feasible[i][(b+7-w)%7][k ^ (bits >> 6)];
                Word valid = plus & xor_indices(minus, bits & 63);
                feasible[i+1][b][k] = valid;
                live |= valid != 0;
            }
            if (!live && (tail_residues[i+1] & (1 << b))) return false;
        }
        return true;
    }

    void rows(int i) {
        if (survivors > 0) return;
        int p = static_cast<int>(extras.size());
        if (i == dimension) {
            for (int j = 0; j < p; ++j) {
                if (!parity(columns[j]) || __builtin_popcount(static_cast<unsigned>(columns[j])) < 3 ||
                    std::find(columns.begin(), columns.begin()+j, columns[j]) != columns.begin()+j) return;
            }
            for (int block = 0; block < words; ++block) {
                Word live = feasible[i][0][block];
                while (live) {
                    int signs = 64*block + __builtin_ctzll(live);
                    live &= live-1;
                    if (signs < (1 << p)) {
                        check_lift(signs);
                        if (survivors > 0) return;
                    }
                }
            }
            return;
        }
        std::vector<int> earlier(p);
        int required_last = 0;
        for (int j = 0; j < p; ++j) {
            if (!parity(columns[j])) required_last |= 1 << j;
            for (int k = 0; k < j; ++k) {
                if (extras[k] == extras[j] && columns[k] == columns[j]) earlier[j] |= 1 << k;
            }
        }
        for (int bits : row_options[i]) {
            if (survivors > 0) return;
            if (i == dimension-1 && bits != required_last) continue;
            if (i && basis[i] == basis[i-1] && bits < row[i-1]) continue;
            bool valid = true;
            for (int j = 0; j < p; ++j) {
                if ((bits & (1 << j)) && (earlier[j] & ~bits)) valid = false;
            }
            for (int r = 0; r < i; ++r) {
                if (parity(bits & row[r] & odd_columns)) valid = false;
            }
            if (!valid || !refine(i, bits)) continue;
            row[i] = bits;
            for (int j = 0; j < p; ++j) columns[j] |= ((bits >> j) & 1) << i;
            rows(i+1);
            for (int& col : columns) col &= ~(1 << i);
        }
    }

    void bases(int i, int first, Counts remaining) {
        if (survivors > 0) return;
        if (i == dimension) {
            extras.clear();
            odd_columns = 0;
            for (int w : weight_order) {
                for (int j = 0; j < remaining[w]; ++j) {
                    if (mass[w] % 2) odd_columns |= 1 << extras.size();
                    extras.push_back(w);
                }
            }
            columns.assign(extras.size(), 0);
            prepare();
            rows(0);
            return;
        }
        for (int k = first; k < 3; ++k) {
            int w = weight_order[k];
            if (!remaining[w]) continue;
            --remaining[w];
            basis[i] = w;
            bases(i+1, k, remaining);
            ++remaining[w];
        }
    }
};
} // namespace

int main() {
    struct Prof { int a, b, c; };
    // All 9 non-boundary surviving profiles at deficit = 80 (e <= 21) + boundary (6,13,1)
    std::vector<Prof> profs = {
        {1, 8, 10}, {3, 9, 7}, {5, 10, 4}, {7, 11, 1},   // e = 19 (p = 11)
        {0, 10, 10}, {2, 11, 7}, {4, 12, 4}, {6, 13, 1}, // e = 20 (p = 12)
        {1, 13, 7}, {3, 14, 4}                           // e = 21 (p = 13)
    };
    std::mutex mtx;
    std::vector<std::thread> threads;
    for (auto pr : profs) {
        threads.emplace_back([pr, &mtx]() {
            SectionSearch s(80);
            s.bases(0, 0, {0, pr.a, pr.b, pr.c});
            std::lock_guard<std::mutex> lk(mtx);
            std::cout << "DONE deficit=80 e=" << (pr.a+pr.b+pr.c)
                      << " (" << pr.a << "," << pr.b << "," << pr.c << ")"
                      << " | lifted=" << s.lifted
                      << " | SURVIVORS=" << s.survivors << "\n" << std::flush;
        });
    }
    for (auto& t : threads) t.join();
    return 0;
}
