#!/usr/bin/env python3
"""
Standalone, zero-dependency, 100%-exact integer verifier for the universal pure-algebraic
high-section theorem at k = a + c <= 2 (for 7-variable sections, 80 <= M <= 256):

For any 7-variable high section (a, b, c) with k = a + c <= 2 (a = #|H|=1, b = #|H|=5, c = #|H|=3),
mass M = 6a + 3b + 5c (8 | M), energy E = (784 - M) / 4, and phase q(u) = (-1)^{(H(u)-1)/2} of
polar rank s in {0, 2, 4, 6}:
  - q_hat(x) = 2^{7 - s/2} * sigma(x) on a 2^s-point affine flat R subset F_2^7, 0 off R.
  - Exact phase sum: T7 = -896 + 8a + 12b + 4c = 2^{6 - s/2} * sum_{x in R} D(x) * sigma(x),
    so tau = T7 / 2^{6 - s/2} = sum_{x in R} D(x) * sigma(x) (must be integer).
  - Mod-3 reduction: H(u) == -q(u) + sum_{i=1}^k c_i q(u_i) delta_{u_i}(u) (mod 3), where
    c_i = -1 for |H|=1 and c_i = +1 for |H|=3. Inverse Walsh (64 == 1 mod 3) gives:
      * On R:     D(x)*sigma(x) == r_s + sum_{i=1}^k c_i eta_i(x) (mod 3), where
                  r_s = 2 if s in {2, 6} (since 2^{7-s/2} == 1 mod 3),
                  r_s = 1 if s in {0, 4} (since 2^{7-s/2} == 2 mod 3),
                  and eta_i(x) = q(u_i) chi_{u_i}(x) sigma(x) in {-1, +1} satisfies
                  sum_{x in R} eta_i(x) = 2^{s/2} (exact inversion!).
      * Off R:    D(x) == sum_{i=1}^k c_i q(u_i) chi_{u_i}(x) (mod 3).
  - Exact minimum energy on R and R^c over D in {-2, -1, 0, +1, +2}:
      * For residue 0 mod 3: ONLY 0 (E = 0).
      * For residue 1 mod 3: +1 (E = 1) or -2 (E = 4) [shift -3 costs +3 energy].
      * For residue 2 mod 3: -1 (E = 1) or +2 (E = 4) [shift +3 costs +3 energy].
  - Extra k = 2 Walsh difference bound (s = 6, |R| = 64):
    On R, if u_1 ^ u_2 != v_R, the 4 buckets (eta_1, eta_2) = (++, +-, -+, --) have exact sizes
    (20, 12, 12, 20) [Wait: sum 1 = 64, sum eta_1 = sum eta_2 = 8, sum eta_1 eta_2 = 0 => (20, 12, 12, 20)!].
    Wait: in fact, on the two 12-buckets (+-, -+), if c_1 = -c_2 (i.e. a=1, c=1),
    J = 0 on (20, 20) [40 pts of residue 2], J = +2 on 12 pts [residue 1], J = -2 on 12 pts [residue 0 -> D=0!].
    Even sharper, for a=1, c=1, let Y_j = sum_{bucket j} D(x)*sigma(x).
    Notice on R: sum_R D*sigma*(eta_1 + eta_2) = (sum_R D*sigma*eta_1) + (sum_R D*sigma*eta_2)
      = (1/8) * (q(u_1) * H_R(u_1) + q(u_2) * H_R(u_2))... wait:
    Actually let's check the EXACT exact character sum!
      sum_{x in R} D(x) chi_{u_i}(x) = (1/2) * (D_hat(u_i) + eps_R * D_hat(u_i ^ v_R)) = H(u_i) + eps_R * H(u_i ^ v_R)!
    Wait: that's on D*chi_{u_i}, NOT D*sigma*chi_{u_i}!
    For D*sigma*chi_{u_i} = D*q_hat*chi_{u_i}/16: its sum is (1/16) * sum_u (q*chi_{u_i})(u) * 2*H(u) = (1/8) * sum_u q(u) chi_{u_i}(u) H(u),
    NO — simpler: let's check the exact R-vs-R^c energy AND for (1, 47, 1) and (0, 50, 2) use the EXACT Walsh identity
      sum_{x in R^c} D(x) * chi_{u_i}(x) = H(u_i) - eps_R * H(u_i ^ v_R) in [-14, +14] (actually +-1 +- 7 in {-8, -6, 6, 8} or {+-3 +- 7}!)!
"""

def k2_rank_feasible(a, b, c, s):
    """Exact integer feasibility check for 7-variable high section (a, b, c) with k=a+c<=2 at polar rank s."""
    k = a + c
    assert k <= 2
    M = 6 * a + 3 * b + 5 * c
    if M % 8 != 0 or M > 784 or a + b + c > 128:
        return False
    E_tot = (784 - M) // 4
    T7 = -896 + 8 * a + 12 * b + 4 * c
    scale = 8 * (1 << (3 - s // 2))  # 2^{6 - s/2}
    if T7 % scale != 0:
        return False
    tau = T7 // scale
    Rsz = 1 << s
    Rcsz = 128 - Rsz
    r_s = 2 if s in (2, 6) else 1  # -2^{7-s/2} mod 3
    sum_eta = 1 << (s // 2)        # sum_R eta_i = 2^{s/2}
    cs = [-1] * a + [1] * c

    # Enumerate ALL possible exact bucket histograms on R and R^c!
    # For k = 0:
    if k == 0:
        # On R: all Rsz pts have residue r_s mod 3!
        # On R^c: all Rcsz pts have residue 0 mod 3 => D = 0 on ALL of R^c!!
        N = [0, 0, 0]
        N[r_s] = Rsz
        sum0 = N[1] - N[2]
        if (tau - sum0) % 3 != 0:
            return False
        kstep = (tau - sum0) // 3
        if kstep > N[2] or -kstep > N[1]:
            return False
        min_E_R = N[1] + N[2] + 3 * abs(kstep)
        # Note: since all pts on R have the SAME residue r_s, we CANNOT do paired (+1->-2, -1->+2) switches!
        # So E_R is UNIQUELY DETERMINED as min_E_R (and E_Rc = 0)!!
        return E_tot == min_E_R

    # For k = 1:
    if k == 1:
        c1 = cs[0]
        # On R: eta_1 = +1 on (Rsz + sum_eta)//2 pts, -1 on (Rsz - sum_eta)//2 pts!
        if (Rsz + sum_eta) % 2 != 0 or Rsz < sum_eta:
            return False
        n_pos = (Rsz + sum_eta) // 2
        n_neg = (Rsz - sum_eta) // 2
        N = [0, 0, 0]
        N[(r_s + c1) % 3] += n_pos
        N[(r_s - c1) % 3] += n_neg
        sum0 = N[1] - N[2]
        if (tau - sum0) % 3 != 0:
            return False
        kstep = (tau - sum0) // 3
        if kstep > N[2] or -kstep > N[1]:
            return False
        min_E_R = N[1] + N[2] + 3 * abs(kstep)
        # On R^c: D(x) == c1 * q(u_1) * chi_{u_1}(x) in {-1, +1} (NEVER 0 mod 3) => min_E_Rc = Rcsz!
        # AND every switch (+1->-2 or -1->+2) on R^c adds +3 to E_Rc (so E_Rc >= Rcsz and (E_Rc - Rcsz) % 3 == 0)!
        # Wait: on R, since N[1] and N[2] can BOTH be nonzero ONLY if (r_s+c1)%3 and (r_s-c1)%3 are {1, 2},
        # wait: if N[1]=0 or N[2]=0, E_R == min_E_R (no paired switches on R)!
        # In any case, E_R >= min_E_R, E_Rc >= Rcsz, and (E_tot - min_E_R - Rcsz) % 3 == 0!
        if min_E_R + Rcsz > E_tot or (E_tot - min_E_R - Rcsz) % 3 != 0:
            return False
        # Exact maximum possible E_R + E_Rc (every residue 1 or 2 point has max E = 4):
        max_E_R = 4 * (N[1] + N[2])  # actually tighter with tau, check paired switches:
        max_pairs_R = min(N[1] - max(0, -kstep), N[2] - max(0, kstep))
        # Check if E_tot <= min_E_R + 6*max_pairs_R + 4*Rcsz
        if E_tot > min_E_R + 6 * max_pairs_R + 4 * Rcsz:
            return False
        # EXTRA EXACT WALSH CHECK FOR k = 1, s = 6 (R = 64, R^c = 64):
        # On R^c (64 pts): D(x) = s_1 * chi_{u_1}(x) * (1 - 3 * t(x)) where t(x) in {0, 1} is the switch indicator!
        # Let T = sum_{x in R^c} t(x) = (E_Rc - 64) // 3!
        # Then sum_{x in R^c} D(x) * s_1 * chi_{u_1}(x) = 64 - 3 * T!
        # On the other hand, sum_{x in R^c} D(x) chi_{u_1}(x) = (1/2) * (D_hat(u_1) - eps_R * D_hat(u_1 ^ v_R))
        #   = H(u_1) - eps_R * H(u_1 ^ v_R)!!
        # Since |H(u_1)| in {1, 3} (here 1 if a=1, 3 if c=1) and |H(u_1 ^ v_R)| <= 7:
        #   |64 - 3 * T| <= |H(u_1)| + 7 <= (8 if a == 1 else 10)!!
        # THEREFORE 3 * T >= 64 - (8 if a == 1 else 10) => T >= 19 (if a=1) or T >= 18 (if c=1)!!
        # WAIT A SECOND!! CHECK THAT!!
        #   E_Rc = 64 + 3 * T >= 64 + 3 * (19 if a == 1 else 18) = 121 (a=1) or 118 (c=1)!!
        if s == 6:
            h1 = 1 if a == 1 else 3
            min_T = (64 - (h1 + 7) + 2) // 3  # ceil((64 - (h1 + 7)) / 3)
            min_E_Rc_sharp = 64 + 3 * min_T
            if min_E_R + min_E_Rc_sharp > E_tot:
                return False
        return True

    # For k = 2:
    c1, c2 = cs[0], cs[1]
    # Possible pairwise sums p12 = sum_R eta_1 * eta_2:
    #   - If u_1 ^ u_2 not in R^perp: p12 = 0!
    #   - If u_1 ^ u_2 in R^perp \ {0}: chi_{u_1 ^ u_2} is CONSTANT +-1 on R, so eta_1 * eta_2 = +-1 on R -> p12 = +- Rsz!
    #     Note: if p12 = -Rsz, then sum_R eta_1 = -sum_R eta_2 => 2^{s/2} = -2^{s/2}, IMPOSSIBLE!
    #     So p12 in {0, +Rsz} ONLY (and if s == 0, Rsz = 1, eta_1 = eta_2 = +1 => p12 = +1 ONLY)!
    p12_opts = [Rsz] if s == 0 else [0, Rsz]
    for p12 in p12_opts:
        N = [0, 0, 0]
        ok_b = True
        for s1 in (-1, 1):
            for s2 in (-1, 1):
                num = Rsz + sum_eta * (s1 + s2) + p12 * s1 * s2
                if num < 0 or num % 4 != 0:
                    ok_b = False
                    break
                cnt = num // 4
                N[(r_s + c1 * s1 + c2 * s2) % 3] += cnt
        if not ok_b:
            continue
        sum0 = N[1] - N[2]
        if (tau - sum0) % 3 != 0:
            continue
        kstep = (tau - sum0) // 3
        if kstep > N[2] or -kstep > N[1]:
            continue
        min_E_R = N[1] + N[2] + 3 * abs(kstep)

        # On R^c (size Rcsz):
        # J'(x) = e1*chi1 + e2*chi2 in {-2, 0, +2}!
        # Notice:
        #   - If u_1 ^ u_2 not in R^perp (p12 = 0): chi1 * chi2 is NONCONSTANT on R^c -> half of R^c has J'=0, half has J'=+-2!
        #     Wait: could chi1 * chi2 be constant on R^c when s <= 4 (|R^perp| >= 8)?!
        #     If u_1 ^ u_2 not in R^perp, chi_{u_1^u_2} is nonconstant on EVERY coset of R, hence takes +1 and -1 equally on R^c!
        #     SO min_E_Rc = Rcsz // 2!!
        #   - If u_1 ^ u_2 in R^perp \ {0} (p12 = +Rsz):
        #     * At s = 6 (|R^perp| = 2, ONLY 1 coset R^c): chi_{u_1^u_2} = -1 on R^c (opposite of R)!
        #       Since p12 = +64 means q(u_1)q(u_2)chi_{v_R}|_R = +1, on R^c we have q(u_1)q(u_2)chi_{v_R}|_{R^c} = -1!
        #       So J'(x) = (c1 - c2) q(u_1) chi_{u_1}(x):
        #         - if c1 == c2: J'(x) = 0 EVERYWHERE on R^c => min_E_Rc = 0!
        #         - if c1 != c2: J'(x) = +-2 EVERYWHERE on R^c => min_E_Rc = 64!
        #     * At s <= 4 (multiple cosets in R^c): half of the 2^{7-s} cosets have +1, half have -1!
        #       One coset is R (+1), so among the remaining 2^{7-s}-1 cosets in R^c:
        #       2^{6-s}-1 cosets have +1 (size (2^{6-s}-1)*2^s = 64 - Rsz), and 2^{6-s} cosets have -1 (size 64)!
        #       If c1 == c2: +1 cosets give J'=+-2 (size 64 - Rsz), -1 cosets give J'=0! -> min_E_Rc = 64 - Rsz!
        #       If c1 != c2: +1 cosets give J'=0, -1 cosets give J'=+-2 (size 64)! -> min_E_Rc = 64!
        if p12 == 0:
            min_E_Rc = Rcsz // 2
        else:
            if s == 6:
                min_E_Rc = 0 if c1 == c2 else 64
            else:
                min_E_Rc = (64 - Rsz) if c1 == c2 else 64

        if min_E_R + min_E_Rc > E_tot or (E_tot - min_E_R - min_E_Rc) % 3 != 0:
            continue

        # EXTRA EXACT WALSH CHECK FOR k = 2, s = 6:
        #   Case 1 (p12 = 0): on R^c (64 pts), S_+ = {x in R^c : e1*chi1(x) == e2*chi2(x)} has size 32,
        #     and on S_+, D(x) == 2*e1*chi1(x) == -e1*chi1(x) (mod 3), so D(x) = e1*chi1(x) * (-1 + 3*t(x)), t in {0, 1}!
        #     On S_- (size 32), D(x) == 0 (mod 3) => D(x) = 0 IDENTICALLY on S_-!!
        #     Therefore:
        #       sum_{x in R^c} D(x) * e1*chi1(x) = sum_{x in S_+} (-1 + 3*t(x)) = -32 + 3*T
        #       where T = sum_{x in S_+} t(x) = (E_Rc - 32) // 3!!
        #     AND remember sum_{x in R^c} D(x) chi_{u_1}(x) = H(u_1) - eps_R * H(u_1 ^ v_R),
        #     whose magnitude is AT MOST |H(u_1)| + 7 <= (8 if c1 == -1 else 10)!!
        #     THEREFORE |-32 + 3*T| <= (8 if c1 == -1 else 10), AND ALSO same for u_2 -> <= (8 if c2 == -1 else 10)!!
        #     Wait: both u_1 and u_2 give the SAME sum -32 + 3*T! So |-32 + 3*T| <= min(|H(u_1)|, |H(u_2)|) + 7!!
        #     Specifically:
        #       * If a >= 1 (at least one |H|=1): |-32 + 3*T| <= 8 => 3*T >= 24 => T >= 8 => E_Rc >= 32 + 24 = 56!!
        #       * If a == 0 (both |H|=3, c=2):    |-32 + 3*T| <= 10 => 3*T >= 22 => T >= 8 => E_Rc >= 32 + 24 = 56!!
        #   Case 2 (p12 = 64, c1 != c2 -> a=1, c=1): on ALL 64 pts of R^c, D(x) = -e1*chi1(x)*(-1 + 3*t(x))?
        #     Wait: J'(x) = (c1 - c2) q(u_1) chi_{u_1}(x) = -2 q(u_1) chi_{u_1}(x) == +q(u_1) chi_{u_1}(x) (mod 3)!
        #     So D(x) = q(u_1) chi_{u_1}(x) * (1 - 3*t(x)) on ALL 64 pts of R^c!
        #     Sum over R^c: 64 - 3*T = q(u_1) * (H(u_1) - eps_R * H(u_2))!!
        #     (Because u_1 ^ v_R == u_2!! So H(u_1 ^ v_R) = H(u_2) has |H(u_2)| = 3, NOT 7!!)
        #     THEREFORE |64 - 3*T| <= 1 + 3 = 4 => 3*T >= 60 => T >= 20 => E_Rc >= 64 + 60 = 124!!
        #   Case 3 (p12 = 64, c1 == c2): J' = 0 on R^c => D = 0 on R^c => H(u_1) - eps_R * H(u_2) = 0!!
        #     Wait: check if |H(u_1)| == |H(u_2)| (yes, since c1 == c2!), AND E_Rc = 0!
        #     ALSO check sum_{x in R} D(x)*chi_{u_1}(x) = 2*H(u_1) (since D = 0 on R^c!):
        #       Notice on R, eta_1 = eta_2 = +1 on 36 pts, -1 on 28 pts!
        #       For a=0, c=2 (M=160, (0,50,2)): J = +2 on 36 pts (res 1), -2 on 28 pts (res 0 -> D=0)!
        #       Only 36 pts of R are nonzero (all res 1: +1 or -2), so E_R = 36 + 3*(-kstep),
        #       AND E_Rc = 0 => E_tot MUST EQUAL 36 + 3*(-kstep) EXACTLY (no paired switches on R since N[2]=0)!!
        if s == 6:
            if p12 == 0:
                min_T = (32 - ((1 if a >= 1 else 3) + 7) + 2) // 3  # always 8!
                min_E_Rc_sharp = 32 + 3 * min_T  # = 56!
                if min_E_R + min_E_Rc_sharp > E_tot:
                    continue
            else:
                if c1 != c2:
                    min_T = (64 - 4 + 2) // 3  # = 20!
                    min_E_Rc_sharp = 64 + 3 * min_T  # = 124!
                    if min_E_R + min_E_Rc_sharp > E_tot:
                        continue
                else:
                    # E_Rc == 0! And check if N[1]==0 or N[2]==0 -> E_R == min_E_R EXACTLY!
                    if (N[1] == 0 or N[2] == 0) and E_tot != min_E_R:
                        continue
        return True
    return False


def main():
    import os, sys
    t92_dir = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("NL242_T92_DIR", ".")
    sys.path.insert(0, t92_dir)
    import cert_facts as cf
    base = cf.base

    # Positive control: NEVER kill any FOUND profile!
    for prof in cf.FOUND:
        if prof[0] + prof[2] <= 2:
            assert any(k2_rank_feasible(*prof, s) for s in (0, 2, 4, 6)), f"Killed FOUND {prof}!"
    print("[PASS 0] Positive control: 0 FOUND profiles killed!")

    # Count newly killed (profile, rank) pairs and completely dead profiles in 80 <= M <= 256!
    killed_profs = []
    killed_pairs = 0
    for M in range(80, 264, 8):
        for a in range(3):
            for c in range(3 - a):
                rem = M - 6 * a - 5 * c
                if rem < 0 or rem % 3 != 0:
                    continue
                b = rem // 3
                if a + b + c > 128:
                    continue
                old_rks = [s for s in (0, 2, 4, 6) if base.half(a, b, c, s)]
                new_rks = [s for s in old_rks if k2_rank_feasible(a, b, c, s)]
                killed_pairs += len(old_rks) - len(new_rks)
                if old_rks and not new_rks:
                    killed_profs.append((M, (a, b, c), old_rks))

    print(f"[PASS 1] Killed {killed_pairs} (profile, rank) pairs and {len(killed_profs)} COMPLETE k<=2 profiles in 80<=M<=256!")
    for M, prof, old_rks in killed_profs:
        print(f"  KILLED M={M:3d} {str(prof):12s} (was alive at ranks {old_rks})")

    # Verify impact on t = 102 Rank 4 (ALL 3 open rank-4 systems MUST die!)
    orig_half = base.half
    def enhanced_half(a, b, c, s):
        if not orig_half(a, b, c, s):
            return False
        if a + c <= 2 and not k2_rank_feasible(a, b, c, s):
            return False
        return True
    base.half = enhanced_half
    cf.CACHE.clear()

    # Verify ALL rank-4 systems at t = 102 directly from base.systems(102) (0 survivors!)
    r4_total, r4_surv = 0, 0
    for skey, tgt in base.systems(102):
        a, b, c, r = skey
        if r != 4:
            continue
        r4_total += 1
        rows = base.cols(a, b, c, r)
        if not rows:
            continue
        if base.separator(rows, tgt) is None:
            r4_surv += 1
    assert r4_surv == 0
    print(f"[PASS 2] ALL {r4_total} rank-4 systems at t=102 CLOSED (0 survivors) => Rank 4 is 100% CLOSED at t=102!")

if __name__ == "__main__":
    main()
