// Standalone, zero-dependency, exact-integer C++20 proof verifier that NO Rank-6 (|Z|=112, |D|=20)
// low block V : F_2^8 -> {-1, 0, +1} exists at agreement count t = 104!
// Covers EVERY SINGLE CASE from scratch:
//   - Positive controls for BOTH beta = 1_H and beta = 0 engines (including PhaseReducer!)
//   - Pass 1: Aut(Q) transvections, 126 affine hyperplanes -> 2 orbits of 63, D_hat mod 8 laws
//   - Pass 2: beta = 1_H, Case II (|H cap Z|=16): II-D (n8=0), II-B (n8=1), II-C (n8=2, all 102 tuples)
//   - Pass 3: beta = 1_H, Case III (|H cap Z|=12): III-0 (n8=0), III-A, III-B, III-C, III-D, III-E2, III-E0
//   - Pass 4: beta = 0, ALL n0 in {2,4,6,8,10,12,14,16,18,20}:
//       * n0 in {2,6,10}: m2 odd <= 5 impossible
//       * m2 = 0 (including (4,8)): 36*144 - 80*n8 > 4096
//       * (8,6) (m2=4): all odd_F=6 (336 words) and odd_F=0 ((4,2) & (2,2,2)) orbits
//       * n0 >= 12, dim(U)=1: all 12/6/3 orbits for (20,0), (16,2), (12,4) (p0=0 & p0=Z) + 4-cell joins
//       * n0 >= 12, dim(U)=2: all 27 Stab(a)-orbits (322 cases) + exact 4-cell (E8, phase64) joins
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace {

int Q64[64];
uint64_t Zmask = 0, Fmask = 0;
int perm64[63][64];

void init_Q() {
    Zmask = Fmask = 0;
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
        if (Q64[x] == 0) Zmask |= (1ULL << x);
        else Fmask |= (1ULL << x);
    }
    if (__builtin_popcountll(Zmask) != 28 || __builtin_popcountll(Fmask) != 36)
        throw std::logic_error("Q64 sizes mismatch");
    for (int v = 1; v < 64; ++v) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        for (int x = 0; x < 64; ++x)
            perm64[v - 1][x] = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
        for (int x = 0; x < 64; ++x)
            if (Q64[perm64[v - 1][x]] != Q64[x])
                throw std::logic_error("Transvection failed to preserve Q");
    }
}

inline uint64_t apply_p64(uint64_t w, const int* p) {
    uint64_t out = 0;
    while (w) { int i = __builtin_ctzll(w); out |= (1ULL << p[i]); w &= w - 1; }
    return out;
}

inline void fwht16(std::array<int, 16>& a) {
    for (int step = 1; step < 16; step *= 2)
        for (int i = 0; i < 16; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}

inline void fwht64(std::array<int, 64>& a) {
    for (int step = 1; step < 64; step *= 2)
        for (int i = 0; i < 64; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}

struct PhaseReducer {
    uint64_t pivs[64]{};
    uint64_t mask = 0;
    void init(uint64_t m) {
        mask = m;
        for (int b = 0; b < 64; ++b) pivs[b] = 0;
        for (int k = 0; k < 7; ++k) {
            uint64_t w = 0;
            for (int c = 0; c < 64; ++c)
                if (k == 6 || ((c >> k) & 1)) w |= (1ULL << c);
            w &= mask;
            while (w) {
                int b = 63 - __builtin_clzll(w);
                if (!pivs[b]) { pivs[b] = w; break; }
                w ^= pivs[b];
            }
        }
    }
    uint64_t reduce(uint64_t w) const {
        w &= mask;
        for (int b = 63; b >= 0; --b)
            if (pivs[b] && ((w >> b) & 1)) w ^= pivs[b];
        return w;
    }
};

// ==================== BETA = 1_H ENGINE (32+32 HALF-JOIN) ====================
using Opts32 = std::array<std::vector<int>, 32>;
using HalfMap = std::unordered_map<uint32_t, std::map<uint32_t, int>>;

void enum_slice16_H(int start, int j, std::array<int, 16>& z, const Opts32& opts,
                    std::map<uint16_t, std::vector<std::array<int, 16>>>& out) {
    if (j < 16) {
        for (int v : opts[start + j]) { z[j] = v; enum_slice16_H(start, j + 1, z, opts, out); }
        return;
    }
    auto u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 15) return;
        int q = u[y] >> 4;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back(u);
}

void collect_half_minE(const Opts32& opts, HalfMap& by_par, long long& count) {
    by_par.clear(); count = 0;
    std::map<uint16_t, std::vector<std::array<int, 16>>> g0, g1;
    std::array<int, 16> tmp{};
    enum_slice16_H(0, 0, tmp, opts, g0);
    enum_slice16_H(16, 0, tmp, opts, g1);
    for (auto& [par, v0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a[y]) + std::abs(b[y]) > 4) { ok = false; break; }
                int x0 = (a[y] + b[y]) / 2, x1 = (a[y] - b[y]) / 2;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (uint32_t(1) << y);
                if (x1 & 1) p32 |= (uint32_t(1) << (16 + y));
                if (std::abs(x0) == 2) tw |= (uint32_t(1) << y);
                if (std::abs(x1) == 2) tw |= (uint32_t(1) << (16 + y));
            }
            if (ok) {
                auto& mp = by_par[p32];
                auto it2 = mp.find(tw);
                if (it2 == mp.end() || e2 < it2->second) mp[tw] = e2;
                count++;
            }
        }
    }
}

int min_join_m(const HalfMap& mt, const HalfMap& ms) {
    int best_m = 999;
    for (const auto& [p32, tm] : mt) {
        auto it = ms.find(p32); if (it == ms.end()) continue;
        for (const auto& [tw_t, et] : tm)
            for (const auto& [tw_s, es] : it->second)
                if ((tw_t & tw_s) == 0) {
                    int m = (et + es) / 2;
                    if (m < best_m) best_m = m;
                }
    }
    return best_m;
}

int solve_H_min_m(const Opts32& opt_t, const Opts32& opt_s) {
    HalfMap mt, ms; long long ct = 0, cs = 0;
    collect_half_minE(opt_t, mt, ct);
    if (ct == 0) return 999;
    collect_half_minE(opt_s, ms, cs);
    if (cs == 0) return 999;
    return min_join_m(mt, ms);
}

struct Slice16S { std::array<int, 16> u; uint16_t mask68, sgn; };
void enum_slice16_S(int start, int j, std::array<int, 16>& z, uint16_t m68, uint16_t sg,
                    const Opts32& opts, uint32_t track_mask,
                    std::map<uint16_t, std::vector<Slice16S>>& out) {
    if (j < 16) {
        int idx = start + j; bool tr = (track_mask >> idx) & 1;
        for (int v : opts[idx]) {
            z[j] = v;
            uint16_t nm = m68 | ((tr && (std::abs(v) == 6 || std::abs(v) == 8)) ? (uint16_t(1) << j) : 0);
            uint16_t ns = sg | ((v < 0) ? (uint16_t(1) << j) : 0);
            enum_slice16_S(start, j + 1, z, nm, ns, opts, track_mask, out);
        }
        return;
    }
    auto u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 15) return;
        int q = u[y] >> 4;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back({u, m68, sg});
}

struct HalfEntryS { uint32_t tw, mask68, sgn; int e2; };
void collect_half_S(const Opts32& opts, uint32_t track_mask,
                    std::unordered_map<uint32_t, std::vector<HalfEntryS>>& out) {
    out.clear();
    std::map<uint16_t, std::vector<Slice16S>> g0, g1;
    std::array<int, 16> tmp{};
    enum_slice16_S(0, 0, tmp, 0, 0, opts, track_mask, g0);
    enum_slice16_S(16, 0, tmp, 0, 0, opts, track_mask, g1);
    for (auto& [par, v0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                int x0 = (a.u[y] + b.u[y]) / 2, x1 = (a.u[y] - b.u[y]) / 2;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (uint32_t(1) << y);
                if (x1 & 1) p32 |= (uint32_t(1) << (16 + y));
                if (std::abs(x0) == 2) tw |= (uint32_t(1) << y);
                if (std::abs(x1) == 2) tw |= (uint32_t(1) << (16 + y));
            }
            if (ok) {
                uint32_t m68 = uint32_t(a.mask68) | (uint32_t(b.mask68) << 16);
                uint32_t sg = uint32_t(a.sgn) | (uint32_t(b.sgn) << 16);
                out[p32].push_back({tw, m68, sg, e2});
            }
        }
    }
}

inline uint64_t interleave(uint32_t even_bits, uint32_t odd_bits) {
    uint64_t out = 0;
    for (int i = 0; i < 32; ++i) {
        if ((even_bits >> i) & 1) out |= (1ULL << (2 * i));
        if ((odd_bits >> i) & 1) out |= (1ULL << (2 * i + 1));
    }
    return out;
}

// ==================== BETA = 0 ENGINE (4-WAY MEET-IN-THE-MIDDLE) ====================
using Slice = std::array<int, 16>;
using Opts64 = std::array<std::vector<int>, 64>;
using Groups = std::map<uint16_t, std::vector<Slice>>;

void enum_slice_b0(const int idx[16], int j, Slice& z, const Opts64& opts, Groups& out) {
    if (j < 16) {
        for (int v : opts[idx[j]]) { z[j] = v; enum_slice_b0(idx, j + 1, z, opts, out); }
        return;
    }
    Slice u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 3) return;
        int q = u[y] >> 2;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back(u);
}

struct Pair { uint16_t par = 0, s2 = 0, d2 = 0; const Slice *a = nullptr, *b = nullptr; };
inline bool make_pair(const Slice& a, const Slice& b, Pair& p) {
    p.par = p.s2 = p.d2 = 0; p.a = &a; p.b = &b;
    for (int y = 0; y < 16; ++y) {
        int s = (a[y] + b[y]) >> 1, d = (a[y] - b[y]) >> 1;
        if (std::abs(s) > 2 || std::abs(d) > 2) return false;
        if (s & 1) p.par |= (uint16_t(1) << y);
        if (std::abs(s) == 2) p.s2 |= (uint16_t(1) << y);
        if (std::abs(d) == 2) p.d2 |= (uint16_t(1) << y);
    }
    return true;
}

int min_row_energy(const Opts64& o) {
    int s = 0;
    for (int c = 0; c < 64; ++c) { int m = 99; for (int v : o[c]) m = std::min(m, v * v); s += m; }
    return s;
}

bool row_exists_b0(Opts64 opts) {
    if (min_row_energy(opts) > 256) return false;
    std::array<int, 7> pivots{};
    for (int c = 0; c < 64; ++c) {
        auto& ent = opts[c];
        if (std::find(ent.begin(), ent.end(), 0) != ent.end() || ent.size() <= 1) continue;
        int col = 64 | c;
        for (int i = 6; i >= 0; --i) if ((col >> i) & 1) {
            if (pivots[i]) col ^= pivots[i];
            else {
                pivots[i] = col;
                ent.erase(std::remove_if(ent.begin(), ent.end(), [](int v){ return v < 0; }), ent.end());
                break;
            }
        }
    }
    long long best_cost = (1LL << 60); int b0 = 5, b1 = 4;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        long long prod[4] = {1, 1, 1, 1};
        for (int c = 0; c < 64; ++c) prod[(((c>>i)&1)<<1)|((c>>j)&1)] *= (long long)opts[c].size();
        if (prod[0]+prod[1]+prod[2]+prod[3] < best_cost) { best_cost = prod[0]+prod[1]+prod[2]+prod[3]; b0 = i; b1 = j; }
    }
    int rem[4], rk = 0;
    for (int b = 0; b < 6; ++b) if (b != b0 && b != b1) rem[rk++] = b;
    int sl[4][16];
    for (int q = 0; q < 4; ++q)
        for (int r = 0; r < 16; ++r) {
            int c = (((q >> 1) & 1) << b0) | ((q & 1) << b1);
            for (int j = 0; j < 4; ++j) if ((r >> j) & 1) c |= (1 << rem[j]);
            sl[q][r] = c;
        }
    std::array<Groups, 4> grp;
    for (int q = 0; q < 4; ++q) {
        Slice f{}; enum_slice_b0(sl[q], 0, f, opts, grp[q]);
        if (grp[q].empty()) return false;
    }
    int min_q = 0;
    for (int q = 1; q < 4; ++q) if (grp[q].size() < grp[min_q].size()) min_q = q;
    for (const auto& [k, _] : grp[min_q]) {
        std::array<const std::vector<Slice>*, 4> g{};
        bool ok = true;
        for (int q = 0; q < 4; ++q) {
            auto it = grp[q].find(k);
            if (it == grp[q].end()) { ok = false; break; }
            g[q] = &it->second;
        }
        if (!ok) continue;
        std::array<int, 4> ord{0, 1, 2, 3};
        std::sort(ord.begin(), ord.end(), [&](int a, int b){ return g[a]->size() < g[b]->size(); });
        std::unordered_map<uint16_t, std::vector<Pair>> idx;
        for (const auto& a : *g[ord[0]]) for (const auto& b : *g[ord[3]]) {
            Pair p; if (make_pair(a, b, p)) idx[p.par].push_back(p);
        }
        if (idx.empty()) continue;
        for (const auto& c : *g[ord[1]]) for (const auto& d : *g[ord[2]]) {
            Pair q; if (!make_pair(c, d, q)) continue;
            auto it = idx.find(q.par); if (it == idx.end()) continue;
            for (const auto& p : it->second)
                if (!(p.s2 & q.s2) && !(p.d2 & q.d2)) return true;
        }
    }
    return false;
}

std::vector<std::pair<uint64_t, uint64_t>> collect_sigs_b0(Opts64 opts, uint64_t pool, const PhaseReducer& red) {
    std::set<std::pair<uint64_t, uint64_t>> res;
    if (min_row_energy(opts) > 256) return {};
    std::array<int, 7> pivots{};
    for (int c = 0; c < 64; ++c) {
        auto& ent = opts[c];
        if (std::find(ent.begin(), ent.end(), 0) != ent.end() || ent.size() <= 1) continue;
        int col = 64 | c;
        for (int i = 6; i >= 0; --i) if ((col >> i) & 1) {
            if (pivots[i]) col ^= pivots[i];
            else {
                pivots[i] = col;
                ent.erase(std::remove_if(ent.begin(), ent.end(), [](int v){ return v < 0; }), ent.end());
                break;
            }
        }
    }
    long long best_cost = (1LL << 60); int b0 = 5, b1 = 4;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        long long prod[4] = {1, 1, 1, 1};
        for (int c = 0; c < 64; ++c) prod[(((c>>i)&1)<<1)|((c>>j)&1)] *= (long long)opts[c].size();
        if (prod[0]+prod[1]+prod[2]+prod[3] < best_cost) { best_cost = prod[0]+prod[1]+prod[2]+prod[3]; b0 = i; b1 = j; }
    }
    int rem[4], rk = 0;
    for (int b = 0; b < 6; ++b) if (b != b0 && b != b1) rem[rk++] = b;
    int sl[4][16];
    for (int q = 0; q < 4; ++q)
        for (int r = 0; r < 16; ++r) {
            int c = (((q >> 1) & 1) << b0) | ((q & 1) << b1);
            for (int j = 0; j < 4; ++j) if ((r >> j) & 1) c |= (1 << rem[j]);
            sl[q][r] = c;
        }
    std::array<Groups, 4> grp;
    for (int q = 0; q < 4; ++q) {
        Slice f{}; enum_slice_b0(sl[q], 0, f, opts, grp[q]);
        if (grp[q].empty()) return {};
    }
    int min_q = 0;
    for (int q = 1; q < 4; ++q) if (grp[q].size() < grp[min_q].size()) min_q = q;
    for (const auto& [k, _] : grp[min_q]) {
        std::array<const std::vector<Slice>*, 4> g{};
        bool ok = true;
        for (int q = 0; q < 4; ++q) {
            auto it = grp[q].find(k);
            if (it == grp[q].end()) { ok = false; break; }
            g[q] = &it->second;
        }
        if (!ok) continue;
        std::array<int, 4> ord{0, 1, 2, 3};
        std::sort(ord.begin(), ord.end(), [&](int a, int b){ return g[a]->size() < g[b]->size(); });
        std::unordered_map<uint16_t, std::vector<Pair>> idx;
        for (const auto& a : *g[ord[0]]) for (const auto& b : *g[ord[3]]) {
            Pair p; if (make_pair(a, b, p)) idx[p.par].push_back(p);
        }
        if (idx.empty()) continue;
        for (const auto& c : *g[ord[1]]) for (const auto& d : *g[ord[2]]) {
            Pair q; if (!make_pair(c, d, q)) continue;
            auto it = idx.find(q.par); if (it == idx.end()) continue;
            for (const auto& p : it->second) {
                if ((p.s2 & q.s2) || (p.d2 & q.d2)) continue;
                std::array<const Slice*, 4> orig{};
                orig[ord[0]] = p.a; orig[ord[3]] = p.b; orig[ord[1]] = &c; orig[ord[2]] = &d;
                uint64_t e8 = 0, sgn = 0;
                for (int sq = 0; sq < 4; ++sq) {
                    Slice row = *orig[sq]; fwht16(row);
                    for (int r = 0; r < 16; ++r) {
                        int h = row[r] / 4;
                        uint64_t bit = 1ULL << sl[sq][r];
                        if (std::abs(h) == 2) e8 |= bit;
                        if (h < 0) sgn |= bit;
                    }
                }
                res.insert({e8 & pool, red.reduce(sgn)});
            }
        }
    }
    return {res.begin(), res.end()};
}

Opts64 make_row_b0(uint64_t p, uint64_t d2_mask, uint64_t k1_mask, uint64_t k2_mask, uint64_t k3_mask, uint64_t k4_mask = 0) {
    Opts64 o;
    for (int c = 0; c < 64; ++c) {
        int pc = (p >> c) & 1;
        if (Q64[c] == 0) {
            if ((d2_mask >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
            else                    o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 0, 2};
        } else {
            if ((k1_mask >> c) & 1)      o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 2};
            else if ((k2_mask >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 0, 2};
            else if ((k3_mask >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
            else if ((k4_mask >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
            else                         o[c] = pc ? std::vector<int>{-3, 3} : std::vector<int>{0};
        }
    }
    return o;
}

bool join_4rows_b0(std::array<uint64_t, 4> ps, uint64_t d2_mask, uint64_t k1, uint64_t k2, uint64_t k3, int m4) {
    std::array<Opts64, 4> rows;
    std::array<int, 4> ord{0, 1, 2, 3}, en;
    for (int i = 0; i < 4; ++i) {
        rows[i] = make_row_b0(ps[i], d2_mask, k1, k2, k3);
        en[i] = min_row_energy(rows[i]);
        if (en[i] > 256) return false;
    }
    std::sort(ord.begin(), ord.end(), [&](int a, int b){ return en[a] > en[b]; });
    for (int idx : ord) if (!row_exists_b0(rows[idx])) return false;

    uint64_t Z0 = Zmask & ~(ps[0] | ps[1] | ps[2] | ps[3]);
    uint64_t Z1 = Zmask & (ps[0] & ps[1] & ps[2] & ps[3]);
    uint64_t pool = Z0 | k2;
    uint64_t phase64 = Z1 | k1;
    PhaseReducer red;
    red.init(phase64);
    uint64_t target_sgn = red.reduce(phase64);

    std::array<std::vector<std::pair<uint64_t, uint64_t>>, 4> sigs;
    for (int i = 0; i < 4; ++i) {
        sigs[i] = collect_sigs_b0(rows[i], pool, red);
        if (sigs[i].empty()) return false;
    }
    std::array<int, 4> so{0, 1, 2, 3};
    std::sort(so.begin(), so.end(), [&](int a, int b){ return sigs[a].size() < sigs[b].size(); });

    std::vector<uint64_t> targets;
    if (m4 == 0) targets.push_back(pool);
    else if (m4 == 1) {
        uint64_t t = Z0;
        while (t) { int c = __builtin_ctzll(t); targets.push_back(pool ^ (1ULL << c)); t &= t - 1; }
    } else {
        throw std::logic_error("Unexpected m4 >= 2 in join_4rows_b0");
    }

    std::set<std::pair<uint64_t, uint64_t>> left;
    for (auto [e0, s0] : sigs[so[0]])
        for (auto [e3, s3] : sigs[so[3]])
            if (!(e0 & e3)) left.insert({e0 | e3, s0 ^ s3});

    for (auto [e1, s1] : sigs[so[1]])
        for (auto [e2, s2] : sigs[so[2]]) {
            if (e1 & e2) continue;
            uint64_t eu = e1 | e2;
            uint64_t su = target_sgn ^ (s1 ^ s2);
            for (uint64_t tgt : targets) {
                if ((eu & tgt) != eu) continue;
                if (left.count({tgt ^ eu, su})) return true;
            }
        }
    return false;
}

// ==================== POSITIVE CONTROLS ====================
void run_positive_controls() {
    // Control 1: beta = 1_H engine + PhaseReducer!
    // Construct a REAL ternary 6-bit function v(y) in {-1, 0, +1}^64 whose Walsh transform has beta = 1_{H_0}:
    // Take v(y) = 1 on an affine 1-flat {0, 1} shifted? Better: take v = 1 on 10 points so v_hat(2*i) == 2 (mod 4)
    // and v_hat(2*i+1) == 0 (mod 4)!
    // Simply set v(0, y') = 1 on 3 points of F_2^5 and v(1, y') = 1 on 3 points?
    // Check: v_hat(0, c') = sum_{y'} (v(0,y')+v(1,y')) (-1)^{c'.y'} == 2 (mod 4) iff v(0,y')+v(1,y') has ODD count of ±2's?
    // Wait: v(0, 0)=1, v(1, 0)=1 gives t(0)=2, s(0)=0 -> v_hat(0, c') = 2, v_hat(1, c') = 0 for ALL c'!!
    // Check! If v(0)=1, v(1)=1, and all other v(y)=0 (mass m=2):
    //   v_hat(2*i) = 2 for all i (≡ 2 mod 4, p=0!), v_hat(2*i+1) = 0 for all i (≡ 0 mod 4, p=0!)!
    // Now add a non-trivial shift + sign on 4 synthetic cells (v0,v1,v2,v3) and check collect_half_S + PhaseReducer!
    {
        Opts32 opt_t, opt_s;
        for (int i = 0; i < 32; ++i) {
            opt_t[i] = {2, -2};
            opt_s[i] = {0};
        }
        int m = solve_H_min_m(opt_t, opt_s);
        if (m != 2) throw std::logic_error("Positive control 1a (beta=1_H min_m) failed");

        // Test PhaseReducer invariance under arbitrary affine shifts s ^ (a . c):
        uint64_t mask = 0x5555555555555555ULL | 0x00000000000000AAULL;
        PhaseReducer red; red.init(mask);
        uint64_t base_sgn = 0x123456789ABCDEF0ULL;
        uint64_t r0 = red.reduce(base_sgn);
        for (int s = 0; s < 2; ++s)
            for (int a = 0; a < 64; ++a) {
                uint64_t aff = 0;
                for (int c = 0; c < 64; ++c)
                    if (s ^ (__builtin_parity(a & c) & 1)) aff |= (1ULL << c);
                if (red.reduce(base_sgn ^ aff) != r0)
                    throw std::logic_error("Positive control 1b (PhaseReducer affine invariance) failed");
            }
    }
    // Control 2: beta = 0 engine (4-way meet-in-the-middle + collect_sigs_b0)!
    // Take v = indicator of the 3-flat {0..7} (mass m = 8): v_hat(c) = 8 for c & 7 == 0, else 0 -> h(c) = 2 for c & 7 == 0!
    {
        Opts64 opts;
        for (int c = 0; c < 64; ++c)
            opts[c] = ((c & 7) == 0) ? std::vector<int>{-2, 2} : std::vector<int>{0};
        if (!row_exists_b0(opts))
            throw std::logic_error("Positive control 2a (beta=0 row_exists) failed");
        PhaseReducer red; red.init(0x0101010101010101ULL);
        auto sigs = collect_sigs_b0(opts, 0x0101010101010101ULL, red);
        if (sigs.empty() || sigs[0].first != 0x0101010101010101ULL)
            throw std::logic_error("Positive control 2b (beta=0 collect_sigs) failed");
    }
    std::cout << "[PASS 0] Positive controls (beta=1_H, beta=0, PhaseReducer) PASSED!\n" << std::flush;
}

// ==================== PASS 1: HYPERPLANE ORBITS & D_hat MOD 8 ====================
void run_pass1_algebra() {
    // 1a. Verify 126 affine hyperplanes form exactly 2 Aut(Q) orbits of 63 each!
    std::set<uint64_t> seen;
    std::vector<std::tuple<int, int, int>> hyp_orbs;
    for (int a = 1; a < 64; ++a) {
        for (int b = 0; b < 2; ++b) {
            uint64_t H = 0;
            for (int c = 0; c < 64; ++c)
                if ((__builtin_parity(a & c) & 1) == b) H |= (1ULL << c);
            if (seen.count(H)) continue;
            std::vector<uint64_t> bfs{H}; seen.insert(H);
            for (size_t qi = 0; qi < bfs.size(); ++qi)
                for (int g = 0; g < 63; ++g) {
                    uint64_t n = apply_p64(bfs[qi], perm64[g]);
                    if (!seen.count(n)) { seen.insert(n); bfs.push_back(n); }
                }
            hyp_orbs.push_back({__builtin_popcountll(H & Zmask), __builtin_popcountll(H & Fmask), (int)bfs.size()});
        }
    }
    std::sort(hyp_orbs.begin(), hyp_orbs.end());
    if (hyp_orbs.size() != 2 ||
        hyp_orbs[0] != std::make_tuple(12, 20, 63) ||
        hyp_orbs[1] != std::make_tuple(16, 16, 63))
        throw std::logic_error("Hyperplane orbit decomposition mismatch");

    // 1b. Verify D_hat(y) === 4 (mod 8) for all y != 0 forces:
    //     - Case II (H_0={bit0=0}, sum R = 2): a ^ b = 2!
    //     - Case III (H_1={bit0=1}, sum R = 4): a1 ^ a2 ^ a3 ^ a4 = 2!
    std::array<int, 64> b2{}, b3{};
    for (int c = 0; c < 64; ++c) {
        if ((c & 1) == 0 && Q64[c] == 0) b2[c] = 1;
        if ((c & 1) == 1 && Q64[c] == 0) b3[c] = 1;
    }
    fwht64(b2); fwht64(b3);
    int d2_match = -1, d3_match = -1;
    for (int d = 0; d < 64; ++d) {
        bool ok2 = true, ok3 = true;
        for (int y = 1; y < 64; ++y) {
            int need2 = ((4 - b2[y]) % 8 + 8) % 8;
            int need3 = ((4 - b3[y]) % 8 + 8) % 8;
            int got2 = (2 * (1 + ((__builtin_parity(d & y) & 1) ? -1 : 1))) % 8;
            int got3 = 4 * (__builtin_parity(d & y) & 1);
            if (got2 != need2) ok2 = false;
            if (got3 != need3) ok3 = false;
        }
        if (ok2) { if (d2_match != -1) throw std::logic_error("Multiple d2"); d2_match = d; }
        if (ok3) { if (d3_match != -1) throw std::logic_error("Multiple d3"); d3_match = d; }
    }
    if (d2_match != 2 || d3_match != 2)
        throw std::logic_error("D_hat mod 8 defect XOR law failed");

    std::cout << "[PASS 1] Hyperplane orbits (2x63: (16,16) & (12,20)), beta=1 dead (28>20), D_hat mod 8 -> XOR=2 VERIFIED!\n" << std::flush;
}

// ==================== PASS 2: BETA = 1_H, CASE II (|H cap Z| = 16) ====================
void run_pass2_caseII() {
    int H_pts[32], Hc_pts[32];
    for (int i = 0; i < 32; ++i) { H_pts[i] = 2 * i; Hc_pts[i] = 2 * i + 1; }

    std::vector<std::array<int, 32>> gens;
    for (int v = 2; v < 64; v += 2) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        std::array<int, 32> g{};
        for (int i = 0; i < 32; ++i) {
            int x = 2 * i + 1;
            int y = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
            if ((y & 1) != 1) throw std::logic_error("Stab(H0) failed");
            g[i] = (y - 1) / 2;
        }
        gens.push_back(g);
    }

    uint32_t mons[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0;
        for (int i = 0; i < 32; ++i) if ((i & m) == m) mask |= (1u << i);
        mons[mk++] = mask;
    }
    uint32_t mHZ = 0, mHcZ = 0, mHcF = 0;
    for (int i = 0; i < 32; ++i) {
        if (Q64[H_pts[i]] == 0) mHZ |= (1u << i);
        if (Q64[Hc_pts[i]] == 0) mHcZ |= (1u << i);
        else mHcF |= (1u << i);
    }
    std::vector<uint32_t> all_q(65536, 0);
    for (int s = 1; s < 65536; ++s) all_q[s] = all_q[s - 1] ^ mons[__builtin_ctz(s)];

    // Build all 74 Stab(H_0) orbits of 5-var quadratics on H_0^c
    std::unordered_map<uint32_t, int> vis; vis.reserve(100000);
    struct Orb { int w36; uint32_t rep; };
    std::vector<Orb> orbs;
    for (uint32_t q : all_q) {
        if (vis.count(q)) continue;
        int oid = (int)orbs.size();
        std::vector<uint32_t> bfs{q}; vis[q] = oid;
        for (size_t qi = 0; qi < bfs.size(); ++qi)
            for (const auto& g : gens) {
                uint32_t nxt = 0, tmp = bfs[qi];
                while (tmp) { int i = __builtin_ctz(tmp); nxt |= (1u << g[i]); tmp &= tmp - 1; }
                if (!vis.count(nxt)) { vis[nxt] = oid; bfs.push_back(nxt); }
            }
        orbs.push_back({__builtin_popcount(q & mHcF), q});
    }
    if (orbs.size() != 74) throw std::logic_error("Expected 74 Stab(H_0) orbits");

    // 2a. II-D (n_8 = 0) & 2b. II-B (n_8 = 1) in ONE pass over the 74 orbits!
    std::vector<int> H_F_idx;
    for (int i = 0; i < 32; ++i) if (Q64[H_pts[i]] == 1) H_F_idx.push_back(i);
    int min_D[21], min_B2[21], min_B10[21];
    for (int w = 0; w <= 20; ++w) min_D[w] = min_B2[w] = min_B10[w] = 999;

    for (const auto& o : orbs) {
        Opts32 opt_s;
        for (int i = 0; i < 32; ++i) {
            int pi = (o.rep >> i) & 1;
            if (Q64[Hc_pts[i]] == 1) opt_s[i] = pi ? std::vector<int>{-12, 12} : std::vector<int>{0};
            else opt_s[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 0, 8};
        }
        HalfMap ms; long long cs = 0;
        collect_half_minE(opt_s, ms, cs);
        if (cs == 0) continue;

        // II-D (clean H_0)
        Opts32 opt_t_clean;
        for (int i = 0; i < 32; ++i) {
            int pi = (o.rep >> i) & 1;
            if (Q64[H_pts[i]] == 1) opt_t_clean[i] = pi ? std::vector<int>{6} : std::vector<int>{-6};
            else opt_t_clean[i] = pi ? std::vector<int>{-2, 6} : std::vector<int>{-6, 2};
        }
        HalfMap mt; long long ct = 0;
        collect_half_minE(opt_t_clean, mt, ct);
        if (ct > 0) min_D[o.w36] = std::min(min_D[o.w36], min_join_m(mt, ms));

        // II-B (1 dirty k=1 at b in H_0 cap F, d=3 at a=b^2 in H_0 cap Z)
        for (int ib : H_F_idx) {
            int ia = ib ^ 1;
            Opts32 opt_t = opt_t_clean;
            opt_t[ia] = ((o.rep >> ia) & 1) ? std::vector<int>{-2} : std::vector<int>{2};
            int pb = (o.rep >> ib) & 1;
            opt_t[ib] = pb ? std::vector<int>{-2} : std::vector<int>{2};
            collect_half_minE(opt_t, mt, ct);
            if (ct > 0) min_B2[o.w36] = std::min(min_B2[o.w36], min_join_m(mt, ms));
            opt_t[ib] = pb ? std::vector<int>{-10} : std::vector<int>{10};
            collect_half_minE(opt_t, mt, ct);
            if (ct > 0) min_B10[o.w36] = std::min(min_B10[o.w36], min_join_m(mt, ms));
        }
    }
    int best_D = 999, best_B = 999;
    for (int w0 = 0; w0 <= 20; ++w0)
      for (int w1 = w0; w1 <= 20; ++w1)
        for (int w2 = w1; w2 <= 20; ++w2) {
            int w3 = 20 - w0 - w1 - w2;
            if (w3 < 0 || w3 > 20) continue;
            if (w3 >= w2) best_D = std::min(best_D, min_D[w0] + min_D[w1] + min_D[w2] + min_D[w3]);
            best_B = std::min(best_B, min_B2[w0] + min_B2[w1] + min_B2[w2] + min_B10[w3]);
        }
    if (best_D <= 104 || best_B <= 104)
        throw std::logic_error("Case II-D or II-B survived!");

    // 2c. II-C (n_8 = 2, {a, a^2} subset H_0^c cap F): verify transitivity on 10 pairs, test ALL 102 4-tuples!
    std::set<int> pair_orb{0}; std::vector<int> pbfs{0};
    for (size_t q = 0; q < pbfs.size(); ++q)
        for (const auto& g : gens) {
            int b = g[pbfs[q]] & ~1;
            if (!pair_orb.count(b)) { pair_orb.insert(b); pbfs.push_back(b); }
        }
    if (pair_orb.size() != 10) throw std::logic_error("II-C pair transitivity failed");

    std::unordered_map<uint32_t, std::vector<uint32_t>> q_on_F;
    std::vector<uint32_t> ker;
    for (uint32_t q : all_q) {
        q_on_F[q & mHcF].push_back(q);
        if ((q & mHcZ) == 0) ker.push_back(q);
    }
    std::set<std::array<uint32_t, 4>> tuples;
    for (uint32_t k1 : ker)
        for (uint32_t k2 : ker) {
            auto it = q_on_F.find(((k1 & k2) ^ 3u) & mHcF);
            if (it == q_on_F.end()) continue;
            for (uint32_t p0 : it->second) {
                std::array<uint32_t, 4> t{p0, p0 ^ k1, p0 ^ k2, p0 ^ k1 ^ k2 ^ mHcF};
                std::sort(t.begin(), t.end());
                tuples.insert(t);
            }
        }
    if (tuples.size() != 102) throw std::logic_error("Expected 102 Case II-C 4-tuples");

    // Pre-cache raw (e6, e8, m, sgn64) per unique p in tuples!
    struct RawRow { uint32_t e6, e8; int m; uint64_t sgn64; };
    std::unordered_map<uint32_t, std::vector<RawRow>> raw_cache;
    for (const auto& t : tuples) for (uint32_t p : t) {
        if (raw_cache.count(p)) continue;
        Opts32 opt_t, opt_s;
        for (int i = 0; i < 32; ++i) {
            int pi = (p >> i) & 1;
            if (Q64[H_pts[i]] == 1) opt_t[i] = pi ? std::vector<int>{6} : std::vector<int>{-6};
            else opt_t[i] = pi ? std::vector<int>{-2, 6} : std::vector<int>{-6, 2};
            if (Q64[Hc_pts[i]] == 1) {
                if (i == 0 || i == 1) opt_s[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 8};
                else opt_s[i] = pi ? std::vector<int>{-12, 12} : std::vector<int>{0};
            } else opt_s[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 0, 8};
        }
        std::unordered_map<uint32_t, std::vector<HalfEntryS>> mt, ms;
        collect_half_S(opt_t, mHZ, mt);
        collect_half_S(opt_s, mHcZ, ms);
        std::vector<RawRow> v;
        for (const auto& [p32, vt] : mt) {
            auto its = ms.find(p32); if (its == ms.end()) continue;
            for (const auto& et : vt) for (const auto& es : its->second)
                if ((et.tw & es.tw) == 0) {
                    int m = (et.e2 + es.e2) / 2;
                    if (m <= 64) v.push_back({et.mask68, es.mask68, m, interleave(et.sgn, es.sgn)});
                }
        }
        raw_cache[p] = std::move(v);
    }

    long long iic_joins = 0;
    for (const auto& t : tuples) {
        if (raw_cache[t[0]].empty() || raw_cache[t[1]].empty() ||
            raw_cache[t[2]].empty() || raw_cache[t[3]].empty()) continue;
        uint64_t phase64 = interleave(0xFFFFFFFFu, (t[0] & mHcZ) | 3u);
        PhaseReducer red; red.init(phase64);
        uint64_t tgt_sgn = red.reduce(phase64);
        uint32_t need8 = mHcZ & ~t[0];

        struct Sig {
            uint32_t e6, e8; int m; uint64_t sgn;
            bool operator<(const Sig& o) const {
                if (e6 != o.e6) return e6 < o.e6;
                if (e8 != o.e8) return e8 < o.e8;
                if (m != o.m) return m < o.m;
                return sgn < o.sgn;
            }
            bool operator==(const Sig& o) const {
                return e6 == o.e6 && e8 == o.e8 && m == o.m && sgn == o.sgn;
            }
        };
        std::array<std::vector<Sig>, 4> s;
        for (int k = 0; k < 4; ++k) {
            for (const auto& r : raw_cache[t[k]])
                s[k].push_back({r.e6, r.e8, r.m, red.reduce(r.sgn64)});
            std::sort(s[k].begin(), s[k].end());
            s[k].erase(std::unique(s[k].begin(), s[k].end()), s[k].end());
        }
        struct Key {
            uint32_t e6, e8; uint64_t sgn;
            bool operator<(const Key& o) const {
                if (e6 != o.e6) return e6 < o.e6;
                if (e8 != o.e8) return e8 < o.e8;
                return sgn < o.sgn;
            }
        };
        std::map<Key, std::array<uint64_t, 2>> lmap;
        for (const auto& a : s[0]) for (const auto& b : s[1]) {
            if ((a.e6 & b.e6) || (a.e8 & b.e8)) continue;
            int m = a.m + b.m; if (m > 104) continue;
            auto& bm = lmap[{a.e6 | b.e6, a.e8 | b.e8, a.sgn ^ b.sgn}];
            bm[m >> 6] |= (1ULL << (m & 63));
        }
        for (const auto& c : s[2]) for (const auto& d : s[3]) {
            if ((c.e6 & d.e6) || (c.e8 & d.e8)) continue;
            int m = c.m + d.m; if (m > 104) continue;
            auto it = lmap.find({mHZ ^ (c.e6 | d.e6), need8 ^ (c.e8 | d.e8), tgt_sgn ^ (c.sgn ^ d.sgn)});
            if (it != lmap.end()) {
                int rem = 104 - m;
                if (it->second[rem >> 6] & (1ULL << (rem & 63))) iic_joins++;
            }
        }
    }
    if (iic_joins != 0) throw std::logic_error("Case II-C join survivor found!");
    std::cout << "[PASS 2] beta=1_H Case II CLOSED: II-D min=" << best_D << ">104, II-B min=" << best_B
              << ">104, II-C=0/102 joins!\n" << std::flush;
}

// ==================== PASS 3: BETA = 1_H, CASE III (|H cap Z| = 12) ====================
void run_pass3_caseIII() {
    uint32_t mZ = 0, mF = 0;
    for (int i = 0; i < 32; ++i) {
        if (Q64[2 * i] == 0) mZ |= (1u << i); else mF |= (1u << i);
    }
    std::vector<std::array<int, 32>> gens_Hc, gens_H1;
    for (int v = 2; v < 64; v += 2) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        std::array<int, 32> g0{}, g1{};
        for (int i = 0; i < 32; ++i) {
            int x0 = 2 * i, x1 = 2 * i + 1;
            int y0 = x0 ^ ((1 ^ Q64[v] ^ (__builtin_parity(x0 & dual) & 1)) ? v : 0);
            int y1 = x1 ^ ((1 ^ Q64[v] ^ (__builtin_parity(x1 & dual) & 1)) ? v : 0);
            g0[i] = y0 / 2; g1[i] = (y1 - 1) / 2;
        }
        gens_Hc.push_back(g0); gens_H1.push_back(g1);
    }

    uint32_t mons[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0;
        for (int i = 0; i < 32; ++i) if ((i & m) == m) mask |= (1u << i);
        mons[mk++] = mask;
    }
    std::vector<uint32_t> all_q(65536, 0);
    for (int s = 1; s < 65536; ++s) all_q[s] = all_q[s - 1] ^ mons[__builtin_ctz(s)];

    // Verify RM(2,5)|_{H_1^c cap Z} has kernel {0, mF} and ALL even weights!
    int ker_cnt = 0;
    std::unordered_map<uint32_t, std::vector<uint32_t>> q_by_F, q_by_Z;
    for (uint32_t q : all_q) {
        int wz = __builtin_popcount(q & mZ);
        if (wz & 1) throw std::logic_error("Odd wtZ in RM(2,5)|_{H_1^c cap Z}");
        if (wz == 0) ker_cnt++;
        q_by_F[q & mF].push_back(q);
        q_by_Z[q & mZ].push_back(q);
    }
    if (ker_cnt != 2) throw std::logic_error("Expected dim-1 kernel on H_1^c cap Z");

    // Verify single-orbit transitivity on all 120 pairs in H_1^c cap Z and all 120 pairs in H_1^c cap F!
    auto check_pair_trans = [&](uint32_t init_pair) {
        std::set<uint32_t> vis{init_pair}; std::vector<uint32_t> bfs{init_pair};
        for (size_t q = 0; q < bfs.size(); ++q)
            for (const auto& g : gens_Hc) {
                uint32_t nxt = 0, tmp = bfs[q];
                while (tmp) { int i = __builtin_ctz(tmp); nxt |= (1u << g[i]); tmp &= tmp - 1; }
                if (!vis.count(nxt)) { vis.insert(nxt); bfs.push_back(nxt); }
            }
        return (int)vis.size();
    };
    if (check_pair_trans((1u << 0) | (1u << 2)) != 120 || check_pair_trans((1u << 1) | (1u << 3)) != 120)
        throw std::logic_error("Case III pair transitivity failed");

    auto make_H1_clean = [&](uint32_t p) {
        Opts32 o;
        for (int i = 0; i < 32; ++i) {
            int pi = (p >> i) & 1;
            if (Q64[2*i + 1] == 1) o[i] = pi ? std::vector<int>{6} : std::vector<int>{-6};
            else o[i] = pi ? std::vector<int>{-2, 6} : std::vector<int>{-6, 2};
        }
        return o;
    };
    auto make_Hc = [&](uint32_t p, uint32_t k1m, int k2_idx = -1) {
        Opts32 o;
        for (int i = 0; i < 32; ++i) {
            int pi = (p >> i) & 1;
            if (Q64[2*i] == 1) {
                if ((k1m >> i) & 1) o[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 8};
                else if (i == k2_idx) o[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 8};
                else o[i] = pi ? std::vector<int>{-12, 12} : std::vector<int>{0};
            } else o[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 0, 8};
        }
        return o;
    };

    // 3a. III-0 (n_8 = 0, all 74 Stab(H_1) orbits)
    std::unordered_map<uint32_t, int> vis; vis.reserve(100000);
    struct Orb { int w36; uint32_t rep; };
    std::vector<Orb> orbs;
    for (uint32_t q : all_q) {
        if (vis.count(q)) continue;
        int oid = (int)orbs.size();
        std::vector<uint32_t> bfs{q}; vis[q] = oid;
        for (size_t qi = 0; qi < bfs.size(); ++qi)
            for (const auto& g : gens_Hc) {
                uint32_t nxt = 0, tmp = bfs[qi];
                while (tmp) { int i = __builtin_ctz(tmp); nxt |= (1u << g[i]); tmp &= tmp - 1; }
                if (!vis.count(nxt)) { vis[nxt] = oid; bfs.push_back(nxt); }
            }
        orbs.push_back({__builtin_popcount(q & mF), q});
    }
    if (orbs.size() != 74) throw std::logic_error("Expected 74 Stab(H_1) orbits");

    int min3_0[17]; for (int w = 0; w <= 16; ++w) min3_0[w] = 999;
    for (const auto& o : orbs)
        min3_0[o.w36] = std::min(min3_0[o.w36], solve_H_min_m(make_H1_clean(o.rep), make_Hc(o.rep, 0)));
    int best3_0 = 999;
    for (int w0 = 0; w0 <= 16; ++w0) for (int w1 = w0; w1 <= 16; ++w1) for (int w2 = w1; w2 <= 16; ++w2) {
        int w3 = 16 - w0 - w1 - w2;
        if (w3 >= w2 && w3 <= 16)
            best3_0 = std::min(best3_0, min3_0[w0] + min3_0[w1] + min3_0[w2] + min3_0[w3]);
    }
    if (best3_0 <= 104) throw std::logic_error("Case III n_8=0 survived!");

    // 3b. III-A (m2_Z = 3, odd_F = 1, n_8 = 1): also verify min odd_F >= 1 across all 56 lifts!
    {
        auto& d1s = q_by_Z[(1u << 0) | (1u << 2)];
        std::set<std::pair<int, std::array<uint32_t, 4>>> cases;
        for (int i3 = 0; i3 < 32; ++i3) {
            if (!((mZ >> i3) & 1) || i3 == 0 || i3 == 2) continue;
            auto& d2s = q_by_Z[(1u << 0) | (1u << i3)];
            for (uint32_t d1 : d1s) for (uint32_t d2 : d2s) {
                uint32_t prod = (d1 & d2) & mF;
                if (q_by_F.count(prod)) throw std::logic_error("Unexpected odd_F=0 for m2_Z=3");
            }
            int b = (2 * i3) ^ 4 ^ 2;
            if ((b & 1) != 0 || Q64[b] != 1) continue;
            int ib = b / 2;
            for (uint32_t d1 : d1s) for (uint32_t d2 : d2s) {
                auto it = q_by_F.find(((d1 & d2) ^ (1u << ib)) & mF);
                if (it == q_by_F.end()) continue;
                for (uint32_t p0 : it->second) {
                    std::array<uint32_t, 4> t{p0, p0 ^ d1, p0 ^ d2, p0 ^ d1 ^ d2 ^ mF};
                    std::sort(t.begin(), t.end());
                    cases.insert({ib, t});
                }
            }
        }
        for (const auto& [ib, t] : cases) {
            int s = 0;
            for (int k = 0; k < 4; ++k) s += solve_H_min_m(make_H1_clean(t[k]), make_Hc(t[k], 1u << ib));
            if (s <= 104) throw std::logic_error("Case III-A survived!");
        }
    }

    // 3c. III-B (m2_Z = 0, odd_F = 4, n_8 = 4, XOR = 2): enumerate ALL 160 -> 2 orbits!
    {
        std::vector<uint32_t> w4x2;
        for (uint32_t q : all_q) {
            if (__builtin_popcount(q & mF) != 4) continue;
            int xr = 0;
            for (int i = 0; i < 32; ++i) if ((q & mF) & (1u << i)) xr ^= (2 * i);
            if (xr == 2) w4x2.push_back(q);
        }
        std::set<uint32_t> vB;
        int orbB = 0;
        for (uint32_t q : w4x2) {
            if (vB.count(q)) continue;
            orbB++;
            std::vector<uint32_t> bfs{q}; vB.insert(q);
            for (size_t qi = 0; qi < bfs.size(); ++qi)
                for (const auto& g : gens_Hc) {
                    uint32_t nxt = 0, tmp = bfs[qi];
                    while (tmp) { int i = __builtin_ctz(tmp); nxt |= (1u << g[i]); tmp &= tmp - 1; }
                    if (!vB.count(nxt)) { vB.insert(nxt); bfs.push_back(nxt); }
                }
            uint32_t k1m = q & mF;
            int m0 = solve_H_min_m(make_H1_clean(q), make_Hc(q, k1m));
            int m3 = solve_H_min_m(make_H1_clean(q ^ mF), make_Hc(q ^ mF, k1m));
            if (3 * m0 + m3 <= 104) throw std::logic_error("Case III-B survived!");
        }
        if (orbB != 2) throw std::logic_error("Expected 2 III-B orbits");
    }

    // 3d. III-C (m2_Z = 2, odd_F = 2, n_8 = 2)
    {
        auto& d1s = q_by_Z[(1u << 0) | (1u << 2)];
        for (int i1 = 0; i1 < 32; ++i1) {
            if (!((mF >> i1) & 1)) continue;
            int b1 = 2 * i1, b2 = b1 ^ 6;
            if (b2 <= b1 || Q64[b2] != 1) continue;
            uint32_t k1m = (1u << i1) | (1u << (b2 / 2));
            for (uint32_t p0 : q_by_F[k1m]) for (uint32_t d1 : d1s) {
                int m0 = solve_H_min_m(make_H1_clean(p0), make_Hc(p0, k1m));
                int m2 = solve_H_min_m(make_H1_clean(p0 ^ d1), make_Hc(p0 ^ d1, k1m));
                int m3 = solve_H_min_m(make_H1_clean(p0 ^ d1 ^ mF), make_Hc(p0 ^ d1 ^ mF, k1m));
                if (2 * m0 + m2 + m3 <= 104) throw std::logic_error("Case III-C survived!");
            }
        }
    }

    // 3e. III-D (m2_Z = 2, odd_F = 0): verify min_m(p0) >= 30 (so 2*30 + 58 = 118 > 104)!
    {
        for (uint32_t p0 : std::vector<uint32_t>{0u, mZ}) {
            HalfMap ms; long long cs = 0;
            collect_half_minE(make_Hc(p0, 0), ms, cs);
            for (int c1 = 1; c1 < 64; c1 += 2) {
                int c2 = c1 ^ 6; if (c2 < c1) continue;
                if (Q64[c1] == 0 && Q64[c2] == 0) continue;
                auto opt_t = make_H1_clean(p0);
                for (int c : {c1, c2}) if (Q64[c] == 1) {
                    int idx = c / 2;
                    opt_t[idx] = ((p0 >> idx) & 1) ? std::vector<int>{-10, -2} : std::vector<int>{2, 10};
                }
                HalfMap mt; long long ct = 0;
                collect_half_minE(opt_t, mt, ct);
                int m = (ct > 0) ? min_join_m(mt, ms) : 999;
                if (2 * m + 58 <= 104) throw std::logic_error("Case III-D survived!");
            }
        }
    }

    // 3f. III-E2 (m2_Z = 0, odd_F = 2)
    {
        uint32_t k1m = (1u << 1) | (1u << 3);
        for (uint32_t p0 : q_by_F[k1m]) {
            uint32_t p3 = p0 ^ mF;
            HalfMap ms0, ms3; long long cs0 = 0, cs3 = 0;
            collect_half_minE(make_Hc(p0, k1m), ms0, cs0);
            collect_half_minE(make_Hc(p3, k1m), ms3, cs3);
            for (int c1 = 1; c1 < 64; c1 += 2) {
                int c2 = c1 ^ 6; if (c2 < c1) continue;
                auto ot0 = make_H1_clean(p0), ot3 = make_H1_clean(p3);
                for (int c : {c1, c2}) if (Q64[c] == 1) {
                    int idx = c / 2;
                    ot0[idx] = ((p0 >> idx) & 1) ? std::vector<int>{-10, -2} : std::vector<int>{2, 10};
                    ot3[idx] = ((p3 >> idx) & 1) ? std::vector<int>{-10, -2} : std::vector<int>{2, 10};
                }
                HalfMap mt0, mt3; long long ct0 = 0, ct3 = 0;
                collect_half_minE(ot0, mt0, ct0); collect_half_minE(ot3, mt3, ct3);
                int m0 = (ct0 > 0) ? min_join_m(mt0, ms0) : 999;
                int m3 = (ct3 > 0) ? min_join_m(mt3, ms3) : 999;
                if (3 * m0 + m3 <= 104) throw std::logic_error("Case III-E2 survived!");
            }
        }
    }

    // 3g. III-E0 (m2_Z = 0, odd_F = 0, p0 in {0, mZ}, p3 in {mF, ALL})
    {
        std::vector<int> h1F;
        for (int i = 0; i < 32; ++i) if (Q64[2 * i + 1] == 1) h1F.push_back(i);
        auto reduce_H1 = [&](const std::vector<uint32_t>& masks) {
            std::set<uint32_t> v; std::vector<uint32_t> reps;
            for (uint32_t m : masks) {
                if (v.count(m)) continue;
                reps.push_back(m);
                std::vector<uint32_t> bfs{m}; v.insert(m);
                for (size_t q = 0; q < bfs.size(); ++q)
                    for (const auto& g : gens_H1) {
                        uint32_t nxt = 0, tmp = bfs[q];
                        while (tmp) { int i = __builtin_ctz(tmp); nxt |= (1u << g[i]); tmp &= tmp - 1; }
                        if (!v.count(nxt)) { v.insert(nxt); bfs.push_back(nxt); }
                    }
            }
            return reps;
        };
        std::vector<uint32_t> m1, m2, m3, m4x2;
        int nF = (int)h1F.size();
        for (int a = 0; a < nF; ++a) {
            m1.push_back(1u << h1F[a]);
            for (int b = a + 1; b < nF; ++b) {
                m2.push_back((1u << h1F[a]) | (1u << h1F[b]));
                for (int c = b + 1; c < nF; ++c) {
                    m3.push_back((1u << h1F[a]) | (1u << h1F[b]) | (1u << h1F[c]));
                    for (int d = c + 1; d < nF; ++d)
                        if (((2*h1F[a]+1) ^ (2*h1F[b]+1) ^ (2*h1F[c]+1) ^ (2*h1F[d]+1)) == 2)
                            m4x2.push_back((1u<<h1F[a])|(1u<<h1F[b])|(1u<<h1F[c])|(1u<<h1F[d]));
                }
            }
        }
        auto r1 = reduce_H1(m1), r2 = reduce_H1(m2), r3 = reduce_H1(m3), r4 = reduce_H1(m4x2);
        std::vector<uint32_t> need_p3_masks;
        for (uint32_t p0 : std::vector<uint32_t>{0u, mZ}) {
            HalfMap ms_clean, ms_k2; long long cs = 0, csk2 = 0;
            collect_half_minE(make_Hc(p0, 0), ms_clean, cs);
            collect_half_minE(make_Hc(p0, 0, 1), ms_k2, csk2);
            auto check_grp = [&](const std::vector<uint32_t>& reps, bool allow6) {
                for (uint32_t mask : reps) {
                    Opts32 ot = make_H1_clean(p0);
                    for (int i = 0; i < 32; ++i) if ((mask >> i) & 1) {
                        int pi = (p0 >> i) & 1;
                        if (allow6) ot[i] = pi ? std::vector<int>{-10, -2, 6} : std::vector<int>{-6, 2, 10};
                        else        ot[i] = pi ? std::vector<int>{-10, -2}    : std::vector<int>{2, 10};
                    }
                    HalfMap mt; long long ct = 0;
                    collect_half_minE(ot, mt, ct);
                    int m = (ct > 0) ? min_join_m(mt, ms_clean) : 999;
                    if (3 * m + 46 <= 104) {
                        if (p0 != 0u) throw std::logic_error("III-E0a p0=mZ survived!");
                        need_p3_masks.push_back(mask);
                    }
                }
            };
            check_grp(r1, true); check_grp(r2, true); check_grp(r3, true); check_grp(r4, false);
            // III-E0b (k_Hc = 2 at c*=2, k_H=0 or pair {b, b^2})
            {
                HalfMap mt0; long long ct0 = 0;
                collect_half_minE(make_H1_clean(p0), mt0, ct0);
                int mc0 = (ct0 > 0) ? min_join_m(mt0, ms_clean) : 999;
                int mk20 = (ct0 > 0) ? min_join_m(mt0, ms_k2) : 999;
                if (2 * mc0 + mk20 + 45 <= 104) throw std::logic_error("III-E0b k_H=0 survived!");
            }
            for (int b = 1; b < 64; b += 2) {
                int b2 = b ^ 2; if (b2 < b || Q64[b] != 1) continue;
                Opts32 ot = make_H1_clean(p0);
                for (int c : {b, b2}) {
                    int idx = c / 2;
                    ot[idx] = ((p0 >> idx) & 1) ? std::vector<int>{-10, -2} : std::vector<int>{2, 10};
                }
                HalfMap mt; long long ct = 0;
                collect_half_minE(ot, mt, ct);
                int mc = (ct > 0) ? min_join_m(mt, ms_clean) : 999;
                int mk2 = (ct > 0) ? min_join_m(mt, ms_k2) : 999;
                if (2 * mc + mk2 + 45 <= 104) throw std::logic_error("III-E0b pair survived!");
            }
        }
        // Check p3 = mF on all need_p3_masks (should be ONLY {0x3, 0x7})!
        if (!need_p3_masks.empty()) {
            HalfMap ms3; long long cs3 = 0;
            collect_half_minE(make_Hc(mF, 0), ms3, cs3);
            for (uint32_t mask : need_p3_masks) {
                Opts32 ot3 = make_H1_clean(mF);
                for (int i = 0; i < 32; ++i) if ((mask >> i) & 1) {
                    int pi = (mF >> i) & 1;
                    ot3[i] = pi ? std::vector<int>{-10, -2, 6} : std::vector<int>{-6, 2, 10};
                }
                HalfMap mt3; long long ct3 = 0;
                collect_half_minE(ot3, mt3, ct3);
                int m3 = (ct3 > 0) ? min_join_m(mt3, ms3) : 999;
                if (m3 < 999) throw std::logic_error("III-E0a p3=mF survived!");
            }
        }
    }
    std::cout << "[PASS 3] beta=1_H Case III CLOSED: III-0 min=" << best3_0
              << ">104, III-A/B/C/D/E2/E0 ALL 0 survivors!\n" << std::flush;
}

// ==================== PASS 4: BETA = 0, ALL n_0 in {2..20} ====================
void run_pass4_beta0() {
    // Build RM(2,6) basis, decoders liftF & liftZ, and [36, 21, 6] syndrome table on F!
    uint64_t pivF[64]{}, pivZ[64]{};
    std::vector<uint64_t> basisZ, basisF;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) <= 2) {
        uint64_t w = 0;
        for (int x = 0; x < 64; ++x) if ((x & m) == m) w |= (1ULL << x);
        {
            uint64_t t = w;
            while (t & Fmask) {
                int b = 63 - __builtin_clzll(t & Fmask);
                if (!pivF[b]) { pivF[b] = t; basisF.push_back(w); break; }
                t ^= pivF[b];
            }
        }
        {
            uint64_t t = w;
            while (t & Zmask) {
                int b = 63 - __builtin_clzll(t & Zmask);
                if (!pivZ[b]) { pivZ[b] = t; basisZ.push_back(w); break; }
                t ^= pivZ[b];
            }
        }
    }
    if (basisZ.size() != 21 || basisF.size() != 21)
        throw std::logic_error("RM(2,6) rank on Z or F != 21");

    auto liftF = [&](uint64_t wf, uint64_t& out) -> bool {
        out = 0; uint64_t t = wf & Fmask;
        while (t) {
            int b = 63 - __builtin_clzll(t);
            if (!pivF[b]) return false;
            out ^= pivF[b]; t ^= (pivF[b] & Fmask);
        }
        return true;
    };

    // Scan ALL 2^21 words of RM(2,6)|_Z and RM(2,6)|_F!
    // Verify min nonzero wt_Z = 4 (315 words), min nonzero wt_F = 6 (336 words)!
    std::vector<uint64_t> w4Z, w6Z, w8Z, w10Z;
    int min_nz_Z = 99;
    {
        uint64_t cur = 0;
        for (uint32_t s = 0; s < (1u << 21); ++s) {
            if (s) cur ^= basisZ[__builtin_ctz(s)];
            int wz = __builtin_popcountll(cur & Zmask);
            if (wz > 0 && wz < min_nz_Z) min_nz_Z = wz;
            if (wz == 4) w4Z.push_back(cur);
            else if (wz == 6) w6Z.push_back(cur);
            else if (wz == 8) w8Z.push_back(cur);
            else if (wz == 10) w10Z.push_back(cur);
        }
    }
    if (min_nz_Z != 4 || w4Z.size() != 315 || w6Z.size() != 6048)
        throw std::logic_error("RM(2,6)|_Z weight check failed");

    std::vector<uint64_t> w6F;
    int min_nz_F = 99;
    {
        uint64_t cur = 0;
        for (uint32_t s = 0; s < (1u << 21); ++s) {
            if (s) cur ^= basisF[__builtin_ctz(s)];
            int wf = __builtin_popcountll(cur & Fmask);
            if (wf > 0 && wf < min_nz_F) min_nz_F = wf;
            if (wf == 6) w6F.push_back(cur & Fmask);
        }
    }
    if (min_nz_F != 6 || w6F.size() != 336)
        throw std::logic_error("RM(2,6)|_F weight check failed");

    // 4a. Energy bound for m_2 = 0 (n_8 <= 13 => 36*144 - 80*n_8 > 4096) & odd m_2 <= 5 impossible!
    for (int n8 = 0; n8 <= 10; ++n8)
        if (36 * 144 - 80 * n8 <= 4096) throw std::logic_error("m_2=0 energy bound failed");

    // Helper: orbit-reduce a list of Z-words under Aut(Q)
    auto get_Z_orbs = [&](const std::vector<uint64_t>& list) {
        std::unordered_set<uint64_t> vis; vis.reserve(list.size() * 2);
        std::vector<uint64_t> reps;
        for (uint64_t w : list) {
            uint64_t wz = w & Zmask;
            if (vis.count(wz)) continue;
            // Canonical lift with smaller wt_F
            uint64_t w0 = w, w1 = w ^ Fmask;
            int f0 = __builtin_popcountll(w0 & Fmask);
            reps.push_back((f0 <= 18) ? w0 : w1);
            std::vector<uint64_t> bfs{wz}; vis.insert(wz);
            for (size_t qi = 0; qi < bfs.size(); ++qi)
                for (int g = 0; g < 63; ++g) {
                    uint64_t n = apply_p64(bfs[qi], perm64[g]);
                    if (!vis.count(n)) { vis.insert(n); bfs.push_back(n); }
                }
        }
        return reps;
    };
    auto o4 = get_Z_orbs(w4Z), o6 = get_Z_orbs(w6Z), o8 = get_Z_orbs(w8Z), o10 = get_Z_orbs(w10Z);
    if (o4.size() != 1 || o6.size() != 2 || o8.size() != 3 || o10.size() != 6)
        throw std::logic_error("Aut(Q) orbit counts on Z mismatch");

    // 4b. (n_0 = 8, n_8 = 6) with m_2 = 4, m_4 = 0, dim(U) = 1 (u = o4[0])!
    //     Since odd_F = wt(p_0 & F) <= 6 and min nonzero wt_F = 6, odd_F in {0, 6}!
    //     - odd_F = 6: k = (1,1,1,1,1,1) at e in w6F (336 words -> orbit-reduce under Stab(u))
    //     - odd_F = 0: p0 in {0, Z}, k_F partitions of 6 into {2, 4}: (4, 2) or (2, 2, 2)!
    {
        uint64_t u = o4[0];
        uint64_t d2m = u & Zmask;
        // Full stabilizer of u in Aut(Q) via BFS on orbit of u&Z (315 elements) — or direct transvections fixing u!
        // Note: using ONLY verified elements perm in Aut(Q) that fix u&Z AND u (preserving lift) is strictly sound!
        std::vector<int> stab_u;
        for (int g = 0; g < 63; ++g) if (apply_p64(u, perm64[g]) == u) stab_u.push_back(g);
        // Generate closure of stab_u? Wait: even faster, BFS the 315-orbit of d2m to get full Schreier stabilizer fixing u!
        std::unordered_map<uint64_t, std::array<int, 64>> to_w;
        std::array<int, 64> id64; for (int x = 0; x < 64; ++x) id64[x] = x;
        auto comp = [](const std::array<int, 64>& g, const std::array<int, 64>& h) {
            std::array<int, 64> r; for (int x = 0; x < 64; ++x) r[x] = g[h[x]]; return r;
        };
        to_w[d2m] = id64; std::vector<uint64_t> qbfs{d2m};
        for (size_t qi = 0; qi < qbfs.size(); ++qi) {
            uint64_t cur = qbfs[qi]; auto h = to_w[cur];
            for (int g = 0; g < 63; ++g) {
                uint64_t n = apply_p64(cur, perm64[g]);
                if (!to_w.count(n)) {
                    std::array<int, 64> gp; for (int x = 0; x < 64; ++x) gp[x] = perm64[g][x];
                    to_w[n] = comp(gp, h); qbfs.push_back(n);
                }
            }
        }
        if (to_w.size() != 315) throw std::logic_error("315-orbit check failed");
        std::unordered_map<uint64_t, std::array<int, 64>> inv_w;
        for (const auto& [w, h] : to_w) {
            std::array<int, 64> inv; for (int x = 0; x < 64; ++x) inv[h[x]] = x;
            inv_w[w] = inv;
        }
        std::set<std::array<int, 64>> stab_full;
        for (const auto& [w, h] : to_w)
            for (int g = 0; g < 63; ++g) {
                std::array<int, 64> gp; for (int x = 0; x < 64; ++x) gp[x] = perm64[g][x];
                auto pr = comp(inv_w[apply_p64(w, perm64[g])], comp(gp, h));
                if (apply_p64(u, pr.data()) == u) stab_full.insert(pr);
            }
        std::vector<std::array<int, 64>> perms_u(stab_full.begin(), stab_full.end());

        auto test_86 = [&](uint64_t e6, uint64_t k2, uint64_t k4) {
            uint64_t p0_base = 0;
            if (!liftF(e6, p0_base)) throw std::logic_error("liftF failed on w6F");
            for (uint64_t p0 : {p0_base, p0_base ^ Zmask}) {
                std::array<uint64_t, 4> ps{p0, p0 ^ u, p0, p0 ^ u ^ Fmask};
                // Quick energy + single row check on all 4 rows, then exact 4-cell join!
                std::array<Opts64, 4> rows;
                bool ok = true;
                for (int i = 0; i < 4; ++i) {
                    rows[i] = make_row_b0(ps[i], d2m, e6, k2, 0, k4);
                    if (min_row_energy(rows[i]) > 256) { ok = false; break; }
                }
                if (!ok) continue;
                // Test distinct rows first
                std::array<int, 4> ord{0, 1, 2, 3};
                std::sort(ord.begin(), ord.end(), [&](int a, int b){ return min_row_energy(rows[a]) > min_row_energy(rows[b]); });
                for (int idx : ord) if (!row_exists_b0(rows[idx])) { ok = false; break; }
                if (!ok) continue;
                // Full 4-cell join!
                uint64_t Z0 = Zmask & ~(ps[0] | ps[1] | ps[2] | ps[3]);
                uint64_t Z1 = Zmask & (ps[0] & ps[1] & ps[2] & ps[3]);
                uint64_t pool = Z0 | k2;
                uint64_t phase64 = Z1 | e6;
                PhaseReducer red; red.init(phase64);
                uint64_t tgt_sgn = red.reduce(phase64);
                std::array<std::vector<std::pair<uint64_t, uint64_t>>, 4> sigs;
                for (int i = 0; i < 4; ++i) {
                    sigs[i] = collect_sigs_b0(rows[i], pool, red);
                    if (sigs[i].empty()) { ok = false; break; }
                }
                if (!ok) continue;
                std::array<int, 4> so{0, 1, 2, 3};
                std::sort(so.begin(), so.end(), [&](int a, int b){ return sigs[a].size() < sigs[b].size(); });
                std::set<std::pair<uint64_t, uint64_t>> left;
                for (auto [e0, s0] : sigs[so[0]]) for (auto [e3, s3] : sigs[so[3]])
                    if (!(e0 & e3)) left.insert({e0 | e3, s0 ^ s3});
                for (auto [e1, s1] : sigs[so[1]]) for (auto [e2, s2] : sigs[so[2]])
                    if (!(e1 & e2) && left.count({pool ^ (e1 | e2), tgt_sgn ^ (s1 ^ s2)}))
                        throw std::logic_error("(8,6) join survivor found!");
            }
        };

        // odd_F = 6: reduce w6F under perms_u
        {
            std::set<uint64_t> todo(w6F.begin(), w6F.end());
            while (!todo.empty()) {
                uint64_t e6 = *todo.begin();
                for (const auto& pr : perms_u) todo.erase(apply_p64(e6, pr.data()));
                test_86(e6, 0, 0);
            }
        }
        // odd_F = 0: k = (2, 2, 2) (C(36,3) triples reduced under perms_u) AND k = (4, 2) (36*35 ordered pairs)!
        std::vector<int> fpts;
        for (int c = 0; c < 64; ++c) if (Q64[c] == 1) fpts.push_back(c);
        {
            std::set<uint64_t> todo;
            for (size_t i = 0; i < fpts.size(); ++i)
              for (size_t j = i + 1; j < fpts.size(); ++j)
                for (size_t k = j + 1; k < fpts.size(); ++k)
                    todo.insert((1ULL << fpts[i]) | (1ULL << fpts[j]) | (1ULL << fpts[k]));
            while (!todo.empty()) {
                uint64_t k2 = *todo.begin();
                for (const auto& pr : perms_u) todo.erase(apply_p64(k2, pr.data()));
                test_86(0, k2, 0);
            }
        }
        {
            std::set<std::pair<int, int>> todo;
            for (int a : fpts) for (int b : fpts) if (a != b) todo.insert({a, b});
            while (!todo.empty()) {
                auto [a, b] = *todo.begin();
                for (const auto& pr : perms_u) todo.erase({pr[a], pr[b]});
                test_86(0, 1ULL << b, 1ULL << a);
            }
        }
    }

    // 4c. n_0 >= 12, dim(U) = 1: (20,0), (16,2), (12,4) (p0=0 & p0=Z)!
    //     Helper to verify 4-cell join for p0 = 0 (v0, v2 pure-8):
    auto valid_pure8 = [&](uint64_t T) {
        int sz = __builtin_popcountll(T);
        if (sz == 0) return true;
        if (sz < 8) return false;
        Opts64 o;
        for (int c = 0; c < 64; ++c) o[c] = ((T >> c) & 1) ? std::vector<int>{-2, 2} : std::vector<int>{0};
        return row_exists_b0(o);
    };
    auto check_dim1_p0_zero = [&](uint64_t u, uint64_t k2, uint64_t k4, int m4) {
        uint64_t p1 = u, p3 = u ^ Fmask, d2m = u & Zmask;
        auto r3 = make_row_b0(p3, d2m, 0, k2, 0, k4);
        auto r1 = make_row_b0(p1, d2m, 0, k2, 0, k4);
        if (!row_exists_b0(r3) || !row_exists_b0(r1)) return;
        uint64_t pool = (Zmask & ~u) | k2;
        PhaseReducer red; red.init(0ULL);
        auto s3 = collect_sigs_b0(r3, pool, red);
        auto s1 = collect_sigs_b0(r1, pool, red);
        for (auto [e3, _3] : s3) for (auto [e1, _1] : s1) {
            if (e3 & e1) continue;
            uint64_t rem = pool ^ (e3 | e1);
            int rsz = __builtin_popcountll(rem) - m4;
            if (rsz < 0) continue;
            if (rsz >= 16) throw std::logic_error("Unexpected rsz>=16 in dim1_p0_zero");
            if (m4 == 0) {
                if (valid_pure8(rem)) throw std::logic_error("dim(U)=1 join survivor!");
            } else if (m4 == 1) {
                uint64_t cand = rem & (Zmask & ~u);
                while (cand) {
                    int c = __builtin_ctzll(cand); cand &= cand - 1;
                    if (valid_pure8(rem ^ (1ULL << c))) throw std::logic_error("dim(U)=1 m4=1 survivor!");
                }
            } else throw std::logic_error("Unexpected m4>=2 in dim1_p0_zero");
        }
    };

    std::vector<uint64_t> all_dim1;
    for (uint64_t u : o4) all_dim1.push_back(u);
    for (uint64_t u : o6) all_dim1.push_back(u);
    for (uint64_t u : o8) all_dim1.push_back(u);
    for (uint64_t u : o10) all_dim1.push_back(u);

    std::vector<int> fpts;
    for (int c = 0; c < 64; ++c) if (Q64[c] == 1) fpts.push_back(c);

    for (uint64_t u : all_dim1) {
        int wz = __builtin_popcountll(u & Zmask);
        // (20, 0): m4 = (10 - wz)/2
        check_dim1_p0_zero(u, 0, 0, (10 - wz) / 2);
        // (16, 2): wz <= 8, one k=2 on F
        if (wz <= 8) {
            std::vector<int> stab;
            for (int g = 0; g < 63; ++g) if (apply_p64(u, perm64[g]) == u) stab.push_back(g);
            uint64_t remF = Fmask;
            while (remF) {
                int c0 = __builtin_ctzll(remF);
                uint64_t orb = (1ULL << c0); std::vector<int> bfs{c0};
                for (size_t qi = 0; qi < bfs.size(); ++qi)
                    for (int g : stab) { int y = perm64[g][bfs[qi]]; if (!((orb >> y) & 1)) { orb |= (1ULL << y); bfs.push_back(y); } }
                remF &= ~orb;
                check_dim1_p0_zero(u, 1ULL << c0, 0, (8 - wz) / 2);
            }
        }
        // (12, 4): wz <= 6, one k=4 OR two k=2 on F (plus p0=Z for wz=6!)
        if (wz <= 6) {
            std::vector<int> stab;
            for (int g = 0; g < 63; ++g) if (apply_p64(u, perm64[g]) == u) stab.push_back(g);
            uint64_t remF = Fmask;
            while (remF) {
                int c0 = __builtin_ctzll(remF);
                uint64_t orb = (1ULL << c0); std::vector<int> bfs{c0};
                for (size_t qi = 0; qi < bfs.size(); ++qi)
                    for (int g : stab) { int y = perm64[g][bfs[qi]]; if (!((orb >> y) & 1)) { orb |= (1ULL << y); bfs.push_back(y); } }
                remF &= ~orb;
                check_dim1_p0_zero(u, 0, 1ULL << c0, (6 - wz) / 2);
            }
            std::set<uint64_t> visp;
            for (size_t i = 0; i < fpts.size(); ++i)
              for (size_t j = i + 1; j < fpts.size(); ++j) {
                  uint64_t pm = (1ULL << fpts[i]) | (1ULL << fpts[j]);
                  if (visp.count(pm)) continue;
                  std::vector<uint64_t> bfs{pm}; visp.insert(pm);
                  for (size_t qi = 0; qi < bfs.size(); ++qi)
                      for (int g : stab) { uint64_t n = apply_p64(bfs[qi], perm64[g]); if (!visp.count(n)) { visp.insert(n); bfs.push_back(n); } }
                  check_dim1_p0_zero(u, pm, 0, (6 - wz) / 2);
                  if (wz == 6) {
                      if (row_exists_b0(make_row_b0(u ^ Zmask ^ Fmask, u & Zmask, 0, 0, 0, pm)) &&
                          row_exists_b0(make_row_b0(u ^ Zmask, u & Zmask, 0, 0, 0, pm)))
                          throw std::logic_error("(12,4) p0=Z survivor!");
                  }
              }
        }
    }

    // 4d. n_0 >= 12, dim(U) = 2: ALL 27 Stab(a)-orbits via [36, 21, 6] syndrome table + exact 4-cell joins!
    int f_idx[64]; std::fill(f_idx, f_idx + 64, -1);
    for (int j = 0; j < 36; ++j) f_idx[fpts[j]] = j;
    uint64_t rref[21]{}; int piv_col[21]{}; int rank = 0; bool is_piv[36]{};
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) <= 2) {
        uint64_t row = 0;
        for (int j = 0; j < 36; ++j) if ((fpts[j] & m) == m) row |= (1ULL << j);
        for (int r = 0; r < rank; ++r) if ((row >> piv_col[r]) & 1) row ^= rref[r];
        if (row) {
            int pc = __builtin_ctzll(row);
            for (int r = 0; r < rank; ++r) if ((rref[r] >> pc) & 1) rref[r] ^= row;
            rref[rank] = row; piv_col[rank] = pc; is_piv[pc] = true; rank++;
        }
    }
    int free_cols[15], frk = 0;
    for (int j = 0; j < 36; ++j) if (!is_piv[j]) free_cols[frk++] = j;
    uint16_t Hcol[36]{};
    for (int k = 0; k < 15; ++k) Hcol[free_cols[k]] = (uint16_t(1) << k);
    for (int r = 0; r < 21; ++r) {
        uint16_t col = 0;
        for (int k = 0; k < 15; ++k) if ((rref[r] >> free_cols[k]) & 1) col |= (uint16_t(1) << k);
        Hcol[piv_col[r]] = col;
    }
    auto synF = [&](uint64_t w) {
        uint16_t s = 0; uint64_t t = w & Fmask;
        while (t) { int c = __builtin_ctzll(t); s ^= Hcol[f_idx[c]]; t &= t - 1; }
        return s;
    };
    std::vector<std::vector<uint64_t>> err_by_syn[5];
    for (int d = 0; d <= 4; ++d) err_by_syn[d].resize(32768);
    err_by_syn[0][0].push_back(0ULL);
    for (int i = 0; i < 36; ++i) err_by_syn[1][Hcol[i]].push_back(1ULL << fpts[i]);
    for (int i = 0; i < 36; ++i) for (int j = i + 1; j < 36; ++j)
        err_by_syn[2][Hcol[i] ^ Hcol[j]].push_back((1ULL << fpts[i]) | (1ULL << fpts[j]));
    for (int i = 0; i < 36; ++i) for (int j = i + 1; j < 36; ++j) for (int k = j + 1; k < 36; ++k)
        err_by_syn[3][Hcol[i] ^ Hcol[j] ^ Hcol[k]].push_back((1ULL << fpts[i]) | (1ULL << fpts[j]) | (1ULL << fpts[k]));
    for (int i = 0; i < 36; ++i) for (int j = i + 1; j < 36; ++j) for (int k = j + 1; k < 36; ++k) for (int l = k + 1; l < 36; ++l)
        err_by_syn[4][Hcol[i] ^ Hcol[j] ^ Hcol[k] ^ Hcol[l]].push_back((1ULL << fpts[i]) | (1ULL << fpts[j]) | (1ULL << fpts[k]) | (1ULL << fpts[l]));

    std::vector<std::pair<int, uint64_t>> repsA{{4, o4[0]}, {6, o6[0]}, {6, o6[1]}};
    int dim2_orbs = 0, dim2_cases = 0;
    for (auto [wa, u] : repsA) {
        uint64_t a = u & Zmask;
        std::vector<int> stab;
        for (int g = 0; g < 63; ++g) if (apply_p64(a, perm64[g]) == a) stab.push_back(g);
        std::vector<std::tuple<int, int, int, uint64_t>> orb_reps;
        std::set<uint64_t> vis;
        auto scan_list = [&](const std::vector<uint64_t>& list, int wb) {
            for (uint64_t v : list) {
                uint64_t b = v & Zmask;
                if (b == a) continue;
                int m2 = __builtin_popcountll(a | b); if (m2 > 10) continue;
                int wab = __builtin_popcountll(a ^ b); if (wab < wb) continue;
                uint16_t syn = synF(u & v);
                bool has_any = false;
                for (int d = 0; d <= 10 - m2; ++d) if (!err_by_syn[d][syn].empty()) { has_any = true; break; }
                if (!has_any) continue;
                uint64_t can = std::min(b, a ^ b);
                if (vis.count(can)) continue;
                orb_reps.push_back({m2, wb, wab, v});
                std::vector<uint64_t> bfs{can}; vis.insert(can);
                for (size_t qi = 0; qi < bfs.size(); ++qi)
                    for (int g : stab) {
                        uint64_t n = apply_p64(bfs[qi], perm64[g]);
                        uint64_t nc = std::min(n, a ^ n);
                        if (!vis.count(nc)) { vis.insert(nc); bfs.push_back(nc); }
                    }
            }
        };
        if (wa == 4) { scan_list(w4Z, 4); scan_list(w6Z, 6); scan_list(w8Z, 8); }
        else scan_list(w6Z, 6);

        dim2_orbs += (int)orb_reps.size();
        for (auto [m2, wb, wab, v] : orb_reps) {
            uint64_t d2m = (u | v) & Zmask;
            uint16_t syn = synF(u & v);
            for (int d = 0; d <= 10 - m2; ++d) {
                if ((d % 2) != ((10 - m2) % 2)) continue;
                for (uint64_t e : err_by_syn[d][syn]) {
                    uint64_t p0_base = 0;
                    if (!liftF(((u & v) ^ e) & Fmask, p0_base)) continue;
                    for (uint64_t p0 : {p0_base, p0_base ^ Zmask}) {
                        std::array<uint64_t, 4> ps{p0, p0 ^ u, p0 ^ v, p0 ^ u ^ v ^ Fmask};
                        int m4_0 = (10 - m2 - d) / 2;
                        if (__builtin_popcountll(Zmask & ~(ps[0] | ps[1] | ps[2] | ps[3])) >= m4_0) {
                            dim2_cases++;
                            if (join_4rows_b0(ps, d2m, e, 0, 0, m4_0))
                                throw std::logic_error("dim(U)=2 r=0 join survivor!");
                        }
                        if (10 - m2 - d >= 2) {
                            int m4_1 = (10 - m2 - d - 2) / 2;
                            uint64_t tmp = e;
                            while (tmp) {
                                int c = __builtin_ctzll(tmp); tmp &= tmp - 1;
                                dim2_cases++;
                                if (join_4rows_b0(ps, d2m, e ^ (1ULL << c), 0, 1ULL << c, m4_1))
                                    throw std::logic_error("dim(U)=2 k=(3,1) join survivor!");
                            }
                            for (int c : fpts) {
                                if ((e >> c) & 1) continue;
                                dim2_cases++;
                                if (join_4rows_b0(ps, d2m, e, 1ULL << c, 0, m4_1))
                                    throw std::logic_error("dim(U)=2 k=(1,1,2) join survivor!");
                            }
                        }
                    }
                }
            }
        }
    }
    std::cout << "[PASS 4] beta=0 CLOSED: ALL n0 in {2..20} ((8,6), dim1, " << dim2_orbs
              << " dim2 orbits / " << dim2_cases << " cases) -> 0 survivors!\n" << std::flush;
}

} // namespace

int main() {
    init_Q();
    run_positive_controls();
    run_pass1_algebra();
    // Run Passes 2, 3, 4 in parallel (completely independent, read-only globals)!
    std::exception_ptr ep2, ep3, ep4;
    std::thread t2([&]() { try { run_pass2_caseII(); } catch (...) { ep2 = std::current_exception(); } });
    std::thread t3([&]() { try { run_pass3_caseIII(); } catch (...) { ep3 = std::current_exception(); } });
    std::thread t4([&]() { try { run_pass4_beta0(); } catch (...) { ep4 = std::current_exception(); } });
    t2.join(); t3.join(); t4.join();
    if (ep2) std::rethrow_exception(ep2);
    if (ep3) std::rethrow_exception(ep3);
    if (ep4) std::rethrow_exception(ep4);
    std::cout << "\n===================================================================\n";
    std::cout << "Q.E.D. ALL RANK-6 (|Z|=112, |D|=20) CASES AT t = 104 EXCLUDED (0 SURVIVORS)!\n";
    std::cout << "===================================================================\n";
    return 0;
}
