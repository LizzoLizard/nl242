// TURBO 8-thread exact v = 0 H_56 DFS for n_0 = 26 (m = 25, n_8 = 0, v = 0):
//   - Exact r = 5 GF(2) linear solver (solves 6 parity checks directly -> ~64x faster!)
//   - Exact reach_dots + rem_lo/rem_hi pruning at r = 0..4!
//   - Cross-check #1: POSCTRL QR(17) (m=17, w=6) -> must find 12 copies in orb 7!
//   - Cross-check #2: n26_H56_w6_orb3 -> must match EXACTLY 116,256 valid / 84 hists from non-turbo run!
//   - Exact code-by-code verification: for EVERY valid n_0=26 code with top100(|wF|) >= 4896,
//     we ALSO check exact 2^{10} = 1,024 RM(3,8) mod-8 y_Z candidates directly (0 real V => 100% exact kill, no LP needed!)
//     PLUS dump distinct hists for independent min_L1 confirmation!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <mutex>
#include <set>
#include <sstream>
#include <thread>
#include <vector>

inline int pop8(int x) { return __builtin_popcount(static_cast<unsigned>(x)); }
inline int pop32(uint32_t x) { return __builtin_popcount(x); }
inline int q6p(int w) {
    return ((((w >> 0) & 1) & ((w >> 1) & 1)) ^
            (((w >> 2) & 1) & ((w >> 3) & 1)) ^
            (((w >> 4) & 1) & ((w >> 5) & 1)));
}
inline int Q8_s(int u) {
    return (((u>>0)&1) + ((u>>1)&1) + (((u>>0)&1)&((u>>1)&1)) +
            (((u>>2)&1)&((u>>3)&1)) + (((u>>4)&1)&((u>>5)&1)) + (((u>>6)&1)&((u>>7)&1)));
}
inline int Q8(int u) { return Q8_s(u) & 1; }
inline int Q8_carry(int u) { int s = Q8_s(u); return (s * (s - 1) / 2) & 1; }
void fwht256(int a[256]) {
    for (int st = 1; st < 256; st *= 2)
        for (int i = 0; i < 256; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}

struct Block { int start, len, prefix; };
int mons3[93];
uint8_t Qtab[256], Qcarry[256];
std::vector<int> Z_all, F_all;
// Precomputed M3[k][u] = ((u & mons3[k]) == mons3[k])
uint64_t M3_Z_col[120][2]; // for each Z_idx j in 0..119, 93-bit vector of mons3 evaluated at Z_all[j]
// Precomputed GF_map[136][120] for O(n_0) instant g_F computation from Z_0!
uint64_t GF_col[120][3]; // 136 bits for each Z_idx j!
uint64_t GF_const[3];

void init_tables() {
    int k = 0;
    for (int m = 0; m < 256; ++m) if (pop8(m) <= 3) mons3[k++] = m;
    for (int u = 0; u < 256; ++u) {
        Qtab[u] = (uint8_t)Q8(u);
        Qcarry[u] = (uint8_t)Q8_carry(u);
        if (!Qtab[u]) Z_all.push_back(u);
        else F_all.push_back(u);
    }
    // Precompute exact linear map z0 (120 bits) -> g_F (136 bits) via RREF of MZ (120 x 93)!
    struct Row { uint64_t m[2]{}; uint64_t id[2]{}; };
    Row A[120];
    for (int i = 0; i < 120; ++i) {
        int u = Z_all[i];
        for (int b = 0; b < 93; ++b)
            if ((u & mons3[b]) == mons3[b]) A[i].m[b >> 6] |= (1ULL << (b & 63));
        M3_Z_col[i][0] = A[i].m[0]; M3_Z_col[i][1] = A[i].m[1];
        A[i].id[i >> 6] |= (1ULL << (i & 63));
    }
    int piv_cols[93], rk = 0;
    for (int col = 0; col < 93; ++col) {
        int p = -1;
        for (int i = rk; i < 120; ++i) if ((A[i].m[col >> 6] >> (col & 63)) & 1ULL) { p = i; break; }
        if (p == -1) continue;
        std::swap(A[rk], A[p]);
        for (int i = 0; i < 120; ++i)
            if (i != rk && ((A[i].m[col >> 6] >> (col & 63)) & 1ULL)) {
                A[i].m[0] ^= A[rk].m[0]; A[i].m[1] ^= A[rk].m[1];
                A[i].id[0] ^= A[rk].id[0]; A[i].id[1] ^= A[rk].id[1];
            }
        piv_cols[rk++] = col;
    }
    if (rk != 84) throw std::logic_error("Expected rank 84");
    // For each F_idx fi in 0..135: compute row (M[F_all[fi]][piv_cols] @ A[:84].id) (120 bits)
    for (int fi = 0; fi < 136; ++fi) {
        int u = F_all[fi];
        uint64_t row[2]{};
        for (int r = 0; r < 84; ++r) {
            int col = piv_cols[r];
            if ((u & mons3[col]) == mons3[col]) { row[0] ^= A[r].id[0]; row[1] ^= A[r].id[1]; }
        }
        int cbit = Qcarry[u];
        for (int j = 0; j < 120; ++j) {
            if ((row[j >> 6] >> (j & 63)) & 1ULL) {
                GF_col[j][fi >> 6] |= (1ULL << (fi & 63));
                if (1 ^ Qcarry[Z_all[j]]) cbit ^= 1;
            }
        }
        if (cbit) GF_const[fi >> 6] |= (1ULL << (fi & 63));
    }
}

int u_to_zidx[256];
void init_zmap() {
    std::fill(u_to_zidx, u_to_zidx + 256, -1);
    for (int i = 0; i < 120; ++i) u_to_zidx[Z_all[i]] = i;
}

// Fast exact verification of a single n_0=26 (n_8=0) code:
//   1. Compute wF in 1 microsecond via precomputed GF_col!
//   2. Check exact top100(|wF|) < 4896 -> instant kill! (Wait: also check M=48 bound: 6528 - (4/3)*ex48 > 6400 -> ex48 < 96!)
//   3. If top100 >= 4896, check ALL 2^{10} = 1,024 RM(3,8) mod-8 solutions for y_Z -> exact check if ANY real V in {-1,0,1} exists!
// Returns: 0 if killed by top100<4896, 1 if killed by exact 1024 y_Z check, 2 if REAL V FOUND!
int verify_n26_exact(const std::vector<int>& us, int t_target, std::string& hs_out, bool compute_hist) {
    uint64_t gF[3] = {GF_const[0], GF_const[1], GF_const[2]};
    bool inZ0[256]{}; inZ0[0] = true;
    int z0_0 = u_to_zidx[0];
    gF[0] ^= GF_col[z0_0][0]; gF[1] ^= GF_col[z0_0][1]; gF[2] ^= GF_col[z0_0][2];
    for (int u : us) {
        inZ0[u] = true;
        int zi = u_to_zidx[u];
        gF[0] ^= GF_col[zi][0]; gF[1] ^= GF_col[zi][1]; gF[2] ^= GF_col[zi][2];
    }
    int fF[256]{};
    for (int fi = 0; fi < 136; ++fi) {
        int b = (int)((gF[fi >> 6] >> (fi & 63)) & 1ULL);
        fF[F_all[fi]] = b ? 3 : -3;
    }
    int wF[256]; for (int i = 0; i < 256; ++i) wF[i] = fF[i];
    fwht256(wF);

    if (compute_hist) {
        std::map<int,int> h;
        for (int x = 0; x < 256; ++x) h[std::abs(wF[x])]++;
        hs_out = "v0|";
        for (auto [val, c] : h) hs_out += std::to_string(val) + ":" + std::to_string(c) + " ";
    }

    int aw[256];
    for (int x = 0; x < 256; ++x) aw[x] = std::abs(wF[x]);
    std::nth_element(aw, aw + t_target, aw + 256, std::greater<int>());
    int top_sum = 0; for (int i = 0; i < t_target; ++i) top_sum += aw[i];
    if (top_sum < 4896) return 0; // Exact orthogonality kill!

    // Check exact 2^{mZ - 84} RM(3,8) mod-8 y_Z candidates!
    // Build Z_nz (size 94 for n_0=26, 102 for n_0=18)
    std::vector<int> Z_nz; Z_nz.reserve(104);
    int f_base[256]; for (int i = 0; i < 256; ++i) f_base[i] = fF[i];
    for (int zi = 0; zi < 120; ++zi) {
        int u = Z_all[zi];
        if (!inZ0[u]) { Z_nz.push_back(u); f_base[u] = 2; }
    }
    int mZ = (int)Z_nz.size();
    // Solve M3[:, Z_nz] * y_Z == ((M3 @ f_base) / 4) mod 2 (93 eqs in mZ vars)!
    // Compute M3 @ f_base via Mobius / direct loop (93*256 = 23k ops, or fast SOS!)
    // Actually SOS transform computes sum_{u >= m} f_base[u] for ALL 256 masks m in 8*256 = 2048 ops!!
    int sos[256]; for (int i = 0; i < 256; ++i) sos[i] = f_base[i];
    for (int bit = 0; bit < 8; ++bit)
        for (int m = 0; m < 256; ++m)
            if ((m & (1 << bit)) == 0) sos[m] += sos[m | (1 << bit)];
    // Now sos[m] = sum_{(u & m) == m} f_base[u]!!
    struct Eq { uint64_t lo = 0, hi = 0; int rhs = 0; };
    Eq pivs[104]; bool has_piv[104]{};
    auto setb = [](Eq& e, int c) { if (c < 64) e.lo |= (1ULL << c); else e.hi |= (1ULL << (c - 64)); };
    auto firstb = [](const Eq& e) -> int {
        if (e.lo) return __builtin_ctzll(e.lo);
        if (e.hi) return 64 + __builtin_ctzll(e.hi);
        return -1;
    };
    for (int k = 0; k < 93; ++k) {
        int m = mons3[k];
        if (sos[m] & 3) return 1; // Impossible mod 4
        Eq e;
        e.rhs = (sos[m] >> 2) & 1;
        for (int c = 0; c < mZ; ++c) if ((Z_nz[c] & m) == m) setb(e, c);
        while (true) {
            int b = firstb(e);
            if (b == -1) { if (e.rhs != 0) return 1; break; }
            if (has_piv[b]) { e.lo ^= pivs[b].lo; e.hi ^= pivs[b].hi; e.rhs ^= pivs[b].rhs; }
            else { pivs[b] = e; has_piv[b] = true; break; }
        }
    }
    // Back-substitute pivots to get RREF!
    for (int b = mZ - 1; b >= 0; --b) {
        if (!has_piv[b]) continue;
        for (int p = 0; p < b; ++p) {
            if (!has_piv[p]) continue;
            bool bit_on = (b < 64) ? ((pivs[p].lo >> b) & 1ULL) : ((pivs[p].hi >> (b - 64)) & 1ULL);
            if (bit_on) { pivs[p].lo ^= pivs[b].lo; pivs[p].hi ^= pivs[b].hi; pivs[p].rhs ^= pivs[b].rhs; }
        }
    }
    uint64_t base_lo = 0, base_hi = 0;
    std::vector<std::pair<uint64_t, uint64_t>> dirs;
    for (int c = 0; c < mZ; ++c) {
        if (has_piv[c]) {
            if (pivs[c].rhs) { if (c < 64) base_lo |= (1ULL << c); else base_hi |= (1ULL << (c - 64)); }
        } else {
            uint64_t dlo = 0, dhi = 0;
            if (c < 64) dlo |= (1ULL << c); else dhi |= (1ULL << (c - 64));
            for (int p = 0; p < mZ; ++p) if (has_piv[p]) {
                bool on = (c < 64) ? ((pivs[p].lo >> c) & 1ULL) : ((pivs[p].hi >> (c - 64)) & 1ULL);
                if (on) { if (p < 64) dlo |= (1ULL << p); else dhi |= (1ULL << (p - 64)); }
            }
            dirs.push_back({dlo, dhi});
        }
    }
    if (dirs.size() > 18) throw std::logic_error("Too many free bits in y_Z!");
    // Precompute WHT of f_base and of each dir vector!
    int w_cur[256];
    for (int i = 0; i < 256; ++i) w_cur[i] = f_base[i];
    for (int c = 0; c < mZ; ++c) {
        bool on = (c < 64) ? ((base_lo >> c) & 1ULL) : ((base_hi >> (c - 64)) & 1ULL);
        if (on) w_cur[Z_nz[c]] = -2;
    }
    // Wait: Gray code over dirs doesn't linearly update f because XOR flips +2 <-> -2!
    // Just build f[256] and call fwht256: 1024 * 2000 ops = 2M ops = 0.2ms!!
    // Even faster: check 1st 16 pts of mod-16 SOS BEFORE fwht256? Actually 1024 fwht256 takes only 0.4ms, and we only do it for top_sum>=4896!
    uint64_t cur_lo = base_lo, cur_hi = base_hi;
    uint32_t total = 1u << dirs.size();
    for (uint32_t s = 0; s < total; ++s) {
        if (s) {
            int b = __builtin_ctz(s);
            cur_lo ^= dirs[b].first; cur_hi ^= dirs[b].second;
        }
        // Quick DC check: sum f[u] == 0 (mod 64) -> sum fF + 2*mZ - 4*pop(cur) == 0 mod 64!
        int f_try[256];
        for (int i = 0; i < 256; ++i) f_try[i] = fF[i];
        int dc = 0;
        for (int fi = 0; fi < 136; ++fi) dc += fF[F_all[fi]];
        int pop_y = __builtin_popcountll(cur_lo) + __builtin_popcountll(cur_hi);
        dc += 2 * mZ - 4 * pop_y;
        if (dc != 0 && dc != 64 && dc != -64) continue;
        for (int c = 0; c < mZ; ++c) {
            bool on = (c < 64) ? ((cur_lo >> c) & 1ULL) : ((cur_hi >> (c - 64)) & 1ULL);
            f_try[Z_nz[c]] = on ? -2 : 2;
        }
        fwht256(f_try);
        bool ok = true;
        int nz = 0;
        for (int x = 0; x < 256; ++x) {
            int v = f_try[x];
            if (v != 0 && v != 64 && v != -64) { ok = false; break; }
            if (v != 0) nz++;
        }
        if (ok && nz == t_target) return 2; // REAL V FOUND!
    }
    return 1;
}

// TURBO v = 0 H_56 DFS with r=5 GF(2) solver + reach_dots + rem_lo/rem_hi!
void run_h56_v0_turbo(int m, const std::vector<int>& u_tail, int min_d_56, int min_d_64,
                      bool is_w2_sym, bool do_exact_yZ, int t_target,
                      const std::string& label, const std::string& out_file, int nthreads = 8) {
    auto t0 = std::chrono::steady_clock::now();
    int K = (int)u_tail.size();
    int H = m - K;
    int bmap[6] = {2, 3, 4, 5, 6, 7};
    if (is_w2_sym) { bmap[0]=4; bmap[1]=5; bmap[2]=6; bmap[3]=7; bmap[4]=2; bmap[5]=3; }

    uint32_t tail_W[6]{}, tail_r1 = 0;
    for (int j = 0; j < K; ++j) {
        if ((u_tail[j] >> 1) & 1) tail_r1 |= (1u << j);
        for (int r = 0; r < 6; ++r)
            if ((u_tail[j] >> bmap[r]) & 1) tail_W[r] |= (1u << j);
    }
    if ((pop32(tail_r1) & 1) == 0) return;

    int wt_mod4[6], req_dots[6], r1_dot_req[6], tail_wt[6];
    for (int r = 0; r < 6; ++r) {
        tail_wt[r] = pop32(tail_W[r]);
        wt_mod4[r] = ((0 - tail_wt[r]) % 4 + 4) % 4;
        r1_dot_req[r] = pop32(tail_r1 & tail_W[r]) & 1;
        int rd = 0;
        for (int p = 0; p < r; ++p) {
            int full_dot = ((r == 1 && p == 0) || (r == 3 && p == 2) || (r == 5 && p == 4)) ? 1 : 0;
            if (full_dot ^ (pop32(tail_W[r] & tail_W[p]) & 1)) rd |= (1 << p);
        }
        req_dots[r] = rd;
    }
    int r1_wt_mod4 = ((2 - pop32(tail_r1)) % 4 + 4) % 4;
    // Allowed head wt bounds for row r (full row y = e_{bmap[r]} has Q*(y) = 0 -> H_64, complement H_56!)
    // Also cw ^ tail_mask has Q*(y1) = 1 -> H_56, complement H_64!
    // full_row wt = used_wt + tail_wt[r] in [min_d_64, m + 1 - min_d_56]
    // cw ^ tail_mask wt = used_wt + (K - tail_wt[r]) in [min_d_56, m + 1 - min_d_64]
    int min_head_wt[6], max_head_wt[6];
    for (int r = 0; r < 6; ++r) {
        min_head_wt[r] = std::max(min_d_64 - tail_wt[r], min_d_56 - (K - tail_wt[r]));
        max_head_wt[r] = std::min((m + 1 - min_d_56) - tail_wt[r], (m + 1 - min_d_64) - (K - tail_wt[r]));
    }

    static const int sing4[9] = {1, 2, 4, 5, 6, 8, 9, 10, 15};
    static const int stab_e0[8][3] = {
        {2, 4, 8}, {2, 8, 4}, {6, 4, 9}, {6, 9, 4},
        {10, 5, 8}, {10, 8, 5}, {15, 5, 9}, {15, 9, 5}
    };
    uint32_t tail_mask = ((1u << K) - 1u) << H;

    struct T2 { uint32_t W0, W1, span[4]; std::vector<Block> blocks; };
    std::vector<T2> tasks;
    {
        uint32_t cur_W[2]{}, span[4]{};
        auto gen2 = [&](auto& self, int r, const std::vector<Block>& blocks) -> void {
            if (r == 2) { tasks.push_back({cur_W[0], cur_W[1], {span[0], span[1], span[2], span[3]}, blocks}); return; }
            int nb = (int)blocks.size();
            int max_blk = 1 << (5 - r);
            int ks[28], k_lo[28], k_hi[28];
            for (int bi = 0; bi < nb; ++bi) {
                int len = blocks[bi].len;
                int mz = (blocks[bi].prefix == 0) ? (max_blk - 1) : max_blk;
                k_lo[bi] = std::max(0, len - mz);
                k_hi[bi] = std::min(len, max_blk);
                if (k_lo[bi] > k_hi[bi]) return;
            }
            int prev_sz = 1 << r;
            auto rec = [&](auto& rself, int bi, int used_wt, int cur_dots, uint32_t mask) -> void {
                if (bi == nb) {
                    if ((used_wt & 3) != wt_mod4[r] || cur_dots != req_dots[r]) return;
                    if (used_wt < min_head_wt[r] || used_wt > max_head_wt[r]) return;
                    if (is_w2_sym && r == 1 && used_wt < pop32(cur_W[0])) return;
                    uint32_t full_row = mask | (tail_W[r] << H);
                    for (int i = 0; i < prev_sz; ++i) {
                        int y6 = i | (1 << r);
                        uint32_t cw = full_row ^ span[i];
                        int w = pop32(cw);
                        int qy = q6p(y6);
                        if ((w & 3) != (qy ? 2 : 0)) return;
                        int mind = qy ? min_d_56 : min_d_64;
                        int mind_c = qy ? min_d_64 : min_d_56;
                        if (w < mind || (m + 1 - w) < mind_c) return;
                        int w1 = pop32(cw ^ tail_mask);
                        int qy1 = 1 ^ qy;
                        if ((w1 & 3) != (qy1 ? 2 : 0)) return;
                        int mind1 = qy1 ? min_d_56 : min_d_64;
                        int mind1_c = qy1 ? min_d_64 : min_d_56;
                        if (w1 < mind1 || (m + 1 - w1) < mind1_c) return;
                        span[prev_sz + i] = cw;
                    }
                    cur_W[r] = mask;
                    std::vector<Block> nblocks;
                    for (int j = 0; j < nb; ++j) {
                        int s = blocks[j].start, len = blocks[j].len, pref = blocks[j].prefix, k = ks[j];
                        if (len - k > 0) nblocks.push_back({s, len - k, pref});
                        if (k > 0) nblocks.push_back({s + len - k, k, pref | (1 << r)});
                    }
                    self(self, r + 1, nblocks);
                    return;
                }
                int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                for (int k = k_lo[bi]; k <= k_hi[bi]; ++k) {
                    ks[bi] = k;
                    int nd = (k & 1) ? (cur_dots ^ pref) : cur_dots;
                    uint32_t bm = k ? (((1u << k) - 1u) << (s + len - k)) : 0u;
                    rself(rself, bi + 1, used_wt + k, nd, mask | bm);
                }
            };
            rec(rec, 0, 0, 0, 0);
        };
        gen2(gen2, 0, {{0, H, 0}});
    }

    std::atomic<size_t> next_idx{0};
    std::mutex mtx;
    std::map<std::string, std::pair<int, std::vector<int>>> hists;
    int total_valid = 0, killed_top = 0, killed_yZ = 0, real_V = 0;

    auto worker = [&]() {
        std::map<std::string, std::pair<int, std::vector<int>>> loc_hists;
        int loc_valid = 0, loc_ktop = 0, loc_kyZ = 0, loc_real = 0;
        while (true) {
            size_t ti = next_idx.fetch_add(1);
            if (ti >= tasks.size()) break;
            const auto& tk = tasks[ti];
            uint32_t cur_W[6]{tk.W0, tk.W1, 0, 0, 0, 0};
            uint32_t span_W[64]{};
            for (int i = 0; i < 4; ++i) span_W[i] = tk.span[i];

            auto check_leaf = [&](uint32_t mask5) {
                cur_W[5] = mask5;
                if (is_w2_sym && pop32(mask5) < pop32(cur_W[4])) return;
                uint32_t full_row = mask5 | (tail_W[5] << H);
                for (int i = 0; i < 32; ++i) {
                    int y6 = i | 32;
                    uint32_t cw = full_row ^ span_W[i];
                    int w = pop32(cw);
                    int qy = q6p(y6);
                    if ((w & 3) != (qy ? 2 : 0)) return;
                    int mind = qy ? min_d_56 : min_d_64;
                    int mind_c = qy ? min_d_64 : min_d_56;
                    if (w < mind || (m + 1 - w) < mind_c) return;
                    int w1 = pop32(cw ^ tail_mask);
                    int qy1 = 1 ^ qy;
                    if ((w1 & 3) != (qy1 ? 2 : 0)) return;
                    int mind1 = qy1 ? min_d_56 : min_d_64;
                    int mind1_c = qy1 ? min_d_64 : min_d_56;
                    if (w1 < mind1 || (m + 1 - w1) < mind1_c) return;
                }
                uint32_t head_r1 = 0;
                int ws[28]; uint64_t seen = 0;
                for (int j = 0; j < H; ++j) {
                    int w = 0;
                    if (is_w2_sym) {
                        w = (((cur_W[4]>>j)&1u)<<0) | (((cur_W[5]>>j)&1u)<<1) |
                            (((cur_W[0]>>j)&1u)<<2) | (((cur_W[1]>>j)&1u)<<3) |
                            (((cur_W[2]>>j)&1u)<<4) | (((cur_W[3]>>j)&1u)<<5);
                    } else {
                        for (int b = 0; b < 6; ++b) if ((cur_W[b] >> j) & 1u) w |= (1 << b);
                    }
                    if (w == 0 || ((seen >> w) & 1ULL)) return;
                    seen |= (1ULL << w);
                    ws[j] = w;
                    if (q6p(w)) head_r1 |= (1u << j);
                }
                if ((pop32(head_r1) & 3) != r1_wt_mod4) return;
                for (int b = 0; b < 6; ++b)
                    if ((pop32(head_r1 & cur_W[b]) & 1) != r1_dot_req[b]) return;

                uint32_t U8[8]{};
                U8[0] = tail_mask;
                U8[1] = head_r1 | (tail_r1 << H);
                for (int b = 0; b < 6; ++b) U8[bmap[b]] = cur_W[b] | (tail_W[b] << H);

                uint32_t cw = 0;
                for (int step = 1; step < 256; ++step) {
                    int y = step ^ (step >> 1);
                    cw ^= U8[__builtin_ctz(step)];
                    int w = pop32(cw);
                    int qy = Q8(y);
                    if ((w & 3) != (qy ? 2 : 0)) return;
                    int mind = qy ? min_d_56 : min_d_64;
                    int mind_c = qy ? min_d_64 : min_d_56;
                    if (w < mind || (m + 1 - w) < mind_c) return;
                }
                std::vector<int> us(m);
                for (int j = 0; j < H; ++j) us[j] = (((head_r1 >> j) & 1u) << 1) | (ws[j] << 2);
                for (int j = 0; j < K; ++j) us[H + j] = u_tail[j];
                std::sort(us.begin(), us.end());
                loc_valid++;
                std::string hs;
                if (do_exact_yZ) {
                    int st = verify_n26_exact(us, t_target, hs, true);
                    if (st == 0) loc_ktop++;
                    else if (st == 1) loc_kyZ++;
                    else { loc_real++; std::cerr << "!!! REAL V FOUND in " << label << " !!!\n"; }
                } else {
                    // Just compute hist via GF_col
                    uint64_t gF[3] = {GF_const[0], GF_const[1], GF_const[2]};
                    int z0_0 = u_to_zidx[0];
                    gF[0] ^= GF_col[z0_0][0]; gF[1] ^= GF_col[z0_0][1]; gF[2] ^= GF_col[z0_0][2];
                    for (int u : us) {
                        int zi = u_to_zidx[u];
                        gF[0] ^= GF_col[zi][0]; gF[1] ^= GF_col[zi][1]; gF[2] ^= GF_col[zi][2];
                    }
                    int fF[256]{};
                    for (int fi = 0; fi < 136; ++fi) fF[F_all[fi]] = ((gF[fi>>6]>>(fi&63))&1ULL) ? 3 : -3;
                    fwht256(fF);
                    std::map<int,int> h;
                    for (int x = 0; x < 256; ++x) h[std::abs(fF[x])]++;
                    hs = "v0|";
                    for (auto [val, c] : h) hs += std::to_string(val) + ":" + std::to_string(c) + " ";
                }
                if (loc_hists.find(hs) == loc_hists.end()) loc_hists[hs] = {1, us};
                else loc_hists[hs].first++;
            };

            auto dfs = [&](auto& self, int r, const std::vector<Block>& blocks) -> void {
                int nb = (int)blocks.size();
                if (r == 5) {
                    // EXACT r=5 GF(2) LINEAR SOLVER!
                    // Every block has max_blk = 1: len==2 -> k=1 forced; len==1 & pref==0 -> k=1 forced; len==1 & pref!=0 -> free bit!
                    uint32_t forced_mask = 0;
                    int forced_wt = 0, forced_dots = 0;
                    int free_pos[28], free_pref[28], nf = 0;
                    for (int bi = 0; bi < nb; ++bi) {
                        int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                        if (len > 2 || (len == 2 && pref == 0)) return;
                        if (len == 2 || pref == 0) {
                            forced_mask |= (1u << (s + len - 1));
                            forced_wt++;
                            forced_dots ^= pref;
                        } else {
                            free_pos[nf] = s;
                            free_pref[nf] = pref;
                            nf++;
                        }
                    }
                    // Solve 6 GF(2) equations on nf free bits:
                    //   eq 0..4: bit b of dots == bit b of (req_dots[5] ^ forced_dots)
                    //   eq 5:    sum(bits) mod 2 == (wt_mod4[5] ^ forced_wt) & 1
                    int need_dots = req_dots[5] ^ forced_dots;
                    int need_par = (wt_mod4[5] ^ forced_wt) & 1;
                    uint32_t eq[6]{}; int erhs[6]{};
                    for (int b = 0; b < 5; ++b) {
                        erhs[b] = (need_dots >> b) & 1;
                        for (int i = 0; i < nf; ++i) if ((free_pref[i] >> b) & 1) eq[b] |= (1u << i);
                    }
                    erhs[5] = need_par;
                    eq[5] = (nf == 32) ? ~0u : ((1u << nf) - 1u);

                    uint32_t pm[28]{}; int pr[28]{}; bool hp[28]{};
                    for (int e = 0; e < 6; ++e) {
                        uint32_t m_e = eq[e]; int r_e = erhs[e];
                        for (int c = 0; c < nf; ++c) if (((m_e >> c) & 1u) && hp[c]) { m_e ^= pm[c]; r_e ^= pr[c]; }
                        if (m_e == 0) { if (r_e != 0) return; }
                        else {
                            int p = __builtin_ctz(m_e);
                            for (int c = 0; c < nf; ++c) if (hp[c] && ((pm[c] >> p) & 1u)) { pm[c] ^= m_e; pr[c] ^= r_e; }
                            pm[p] = m_e; pr[p] = r_e; hp[p] = true;
                        }
                    }
                    uint32_t base_x = 0;
                    uint32_t d_x[28]; int nd = 0;
                    for (int c = 0; c < nf; ++c) {
                        if (hp[c]) { if (pr[c]) base_x |= (1u << c); }
                        else {
                            uint32_t d = 1u << c;
                            for (int p = 0; p < nf; ++p) if (hp[p] && ((pm[p] >> c) & 1u)) d |= (1u << p);
                            d_x[nd++] = d;
                        }
                    }
                    // Map base_x and d_x directly to H-bit masks!
                    auto to_Hmask = [&](uint32_t xv) -> uint32_t {
                        uint32_t hm = 0;
                        while (xv) { int c = __builtin_ctz(xv); hm |= (1u << free_pos[c]); xv &= xv - 1; }
                        return hm;
                    };
                    uint32_t cur_hm = forced_mask | to_Hmask(base_x);
                    uint32_t d_hm[28];
                    for (int i = 0; i < nd; ++i) d_hm[i] = to_Hmask(d_x[i]);
                    int lo_w = min_head_wt[5], hi_w = max_head_wt[5], wm4 = wt_mod4[5];
                    uint32_t tot = 1u << nd;
                    for (uint32_t s = 0; s < tot; ++s) {
                        if (s) cur_hm ^= d_hm[__builtin_ctz(s)];
                        int w = pop32(cur_hm);
                        if ((w & 3) != wm4 || w < lo_w || w > hi_w) continue;
                        check_leaf(cur_hm);
                    }
                    return;
                }

                int max_blk = 1 << (5 - r);
                int ks[28], k_lo[28], k_hi[28];
                int rem_lo[29], rem_hi[29];
                int reach_dots[29];
                for (int bi = 0; bi < nb; ++bi) {
                    int len = blocks[bi].len;
                    int mz = (blocks[bi].prefix == 0) ? (max_blk - 1) : max_blk;
                    k_lo[bi] = std::max(0, len - mz);
                    k_hi[bi] = std::min(len, max_blk);
                    if (k_lo[bi] > k_hi[bi]) return;
                }
                rem_lo[nb] = 0; rem_hi[nb] = 0; reach_dots[nb] = 0;
                for (int bi = nb - 1; bi >= 0; --bi) {
                    rem_lo[bi] = rem_lo[bi + 1] + k_lo[bi];
                    rem_hi[bi] = rem_hi[bi + 1] + k_hi[bi];
                    // Can block bi toggle cur_dots by blocks[bi].prefix?
                    // If k_lo < k_hi, both parities of k are possible -> can toggle!
                    // If k_lo == k_hi, parity is fixed to k_lo&1 -> NOT toggleable (wait: better compute fixed_dots_rem!)
                    reach_dots[bi] = reach_dots[bi + 1] | ((k_lo[bi] < k_hi[bi]) ? blocks[bi].prefix : 0);
                }
                // Also track fixed_dots from forced blocks bi..nb-1!
                int fixed_rem[29]; fixed_rem[nb] = 0;
                for (int bi = nb - 1; bi >= 0; --bi)
                    fixed_rem[bi] = fixed_rem[bi + 1] ^ ((k_lo[bi] == k_hi[bi] && (k_lo[bi] & 1)) ? blocks[bi].prefix : 0);

                int lo_w = min_head_wt[r], hi_w = max_head_wt[r];
                int prev_sz = 1 << r;
                auto rec = [&](auto& rself, int bi, int used_wt, int cur_dots, uint32_t mask) -> void {
                    if (used_wt + rem_hi[bi] < lo_w || used_wt + rem_lo[bi] > hi_w) return;
                    if (((cur_dots ^ fixed_rem[bi] ^ req_dots[r]) & ~reach_dots[bi]) != 0) return;
                    if (bi == nb) {
                        if ((used_wt & 3) != wt_mod4[r] || cur_dots != req_dots[r]) return;
                        if (is_w2_sym) {
                            if (r == 2) {
                                int w0 = pop32(cur_W[0]), w1 = pop32(cur_W[1]), w2 = used_wt;
                                int w02 = pop32(cur_W[0] ^ mask), w12 = pop32(cur_W[1] ^ mask);
                                if (w2 < w0 || w02 < w0 || w12 < w0 || w12 < w1) return;
                            } else if (r == 3) {
                                int wts[16];
                                for (int i = 0; i < 8; ++i) {
                                    wts[i] = pop32(span_W[i]);
                                    wts[8 + i] = pop32(span_W[i] ^ mask);
                                }
                                int w0 = wts[1];
                                for (int s : sing4) if (wts[s] < w0) return;
                                std::array<int, 3> cur_t = {wts[2], wts[4], wts[8]};
                                for (int si = 1; si < 8; ++si) {
                                    std::array<int, 3> tt = {wts[stab_e0[si][0]], wts[stab_e0[si][1]], wts[stab_e0[si][2]]};
                                    if (tt < cur_t) return;
                                }
                            }
                        }
                        uint32_t full_row = mask | (tail_W[r] << H);
                        for (int i = 0; i < prev_sz; ++i) {
                            int y6 = i | (1 << r);
                            uint32_t cw = full_row ^ span_W[i];
                            int w = pop32(cw);
                            int qy = q6p(y6);
                            if ((w & 3) != (qy ? 2 : 0)) return;
                            int mind = qy ? min_d_56 : min_d_64;
                            int mind_c = qy ? min_d_64 : min_d_56;
                            if (w < mind || (m + 1 - w) < mind_c) return;
                            int w1 = pop32(cw ^ tail_mask);
                            int qy1 = 1 ^ qy;
                            if ((w1 & 3) != (qy1 ? 2 : 0)) return;
                            int mind1 = qy1 ? min_d_56 : min_d_64;
                            int mind1_c = qy1 ? min_d_64 : min_d_56;
                            if (w1 < mind1 || (m + 1 - w1) < mind1_c) return;
                            span_W[prev_sz + i] = cw;
                        }
                        cur_W[r] = mask;
                        std::vector<Block> nblocks;
                        for (int j = 0; j < nb; ++j) {
                            int s = blocks[j].start, len = blocks[j].len, pref = blocks[j].prefix, k = ks[j];
                            if (len - k > 0) nblocks.push_back({s, len - k, pref});
                            if (k > 0) nblocks.push_back({s + len - k, k, pref | (1 << r)});
                        }
                        self(self, r + 1, nblocks);
                        return;
                    }
                    int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                    for (int k = k_lo[bi]; k <= k_hi[bi]; ++k) {
                        ks[bi] = k;
                        int nd = (k & 1) ? (cur_dots ^ pref) : cur_dots;
                        uint32_t bm = k ? (((1u << k) - 1u) << (s + len - k)) : 0u;
                        rself(rself, bi + 1, used_wt + k, nd, mask | bm);
                    }
                };
                rec(rec, 0, 0, 0, 0);
            };
            dfs(dfs, 2, tk.blocks);
        }
        std::lock_guard<std::mutex> lk(mtx);
        total_valid += loc_valid; killed_top += loc_ktop; killed_yZ += loc_kyZ; real_V += loc_real;
        for (auto& [hs, p] : loc_hists) {
            if (hists.find(hs) == hists.end()) hists[hs] = p;
            else hists[hs].first += p.first;
        }
    };
    std::vector<std::thread> ths;
    for (int t = 0; t < nthreads; ++t) ths.emplace_back(worker);
    for (auto& th : ths) th.join();
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "[" << label << "] valid=" << total_valid << " hists=" << hists.size();
    if (do_exact_yZ) std::cout << " [EXACT: top_kill=" << killed_top << " yZ_kill=" << killed_yZ << " REAL_V=" << real_V << "]";
    std::cout << " (" << dt << "s)\n" << std::flush;
    if (!out_file.empty()) {
        std::ofstream fout(out_file, std::ios::app);
        for (auto& [hs, p] : hists) {
            fout << label << " | " << hs << " | ";
            for (int u : p.second) fout << u << " ";
            fout << "\n";
        }
    }
}

int main() {
    init_tables();
    init_zmap();
    std::ofstream("n26_v0_turbo_reps.txt", std::ios::trunc);

    std::vector<std::vector<int>> w6_orbs;
    {
        std::ifstream fin("exact_orbs_H56_w6.txt");
        std::string ln;
        while (std::getline(fin, ln)) {
            if (ln.empty()) continue;
            std::istringstream iss(ln.substr(0, ln.find('|')));
            std::vector<int> us; int u; while (iss >> u) us.push_back(u);
            w6_orbs.push_back(us);
        }
    }
    // POS CTRL #1: QR(17) at t=102 -> verify_n26_exact MUST FIND REAL_V == 12 on orb 7!
    run_h56_v0_turbo(17, w6_orbs[6], 6, 8, false, true, 102, "POSCTRL_QR17_EXACT_yZ", "", 8);

    // ALL 10 exact H_56 w=6 orbits for n_0=26 (m=25, v=0, t=100, H=19)!
    for (size_t i = 0; i < w6_orbs.size(); ++i)
        run_h56_v0_turbo(25, w6_orbs[i], 6, 8, false, true, 100,
                         "n26_H56_w6_orb" + std::to_string(i+1), "n26_v0_turbo_reps.txt", 8);

    // Unique exact H_56 w=2 orbit {13, 15} for n_0=26 (m=25, v=0, t=100, H=23, 144x sym)!
    run_h56_v0_turbo(25, {13, 15}, 2, 8, true, true, 100,
                     "n26_H56_w2", "n26_v0_turbo_reps.txt", 8);
    return 0;
}
