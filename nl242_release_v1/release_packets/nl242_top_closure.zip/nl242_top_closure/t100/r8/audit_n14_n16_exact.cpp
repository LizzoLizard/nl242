// Exact individual integer dual-witness verifier for ALL n_0 = 14 (n_8 = 6) and n_0 = 16 (n_8 = 5) codes
// at (t = 100, r = 8, |Z| = 120)!
// Every single valid RREF rep is verified INDIVIDUALLY (ZERO histogram grouping!) with an exact integer
// Linf witness c in Z^256 (M = 0) and conservative unsigned F-penalty 4*|C(u)|:
//   base - 2*sum_{Z\Z0} |C(u)| - sum_{top n_8 u in F} 4*|C(u)| > 64 * sum |c(x)|
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <set>
#include <stdexcept>
#include <vector>

inline int pop8(int x) { return __builtin_popcount(static_cast<unsigned>(x)); }
inline int pop16(uint16_t x) { return __builtin_popcount(x); }
void fwht256(int a[256]) {
    for (int step = 1; step < 256; step *= 2)
        for (int i = 0; i < 256; i += 2 * step)
            for (int j = i; j < i + step; ++j) { int x = a[j], y = a[j + step]; a[j] = x + y; a[j + step] = x - y; }
}
bool invert8(const uint8_t M[8], uint8_t inv[8]) {
    uint16_t A[8];
    for (int i = 0; i < 8; ++i) A[i] = static_cast<uint16_t>(M[i] | (1u << (8 + i)));
    for (int col = 0; col < 8; ++col) {
        int piv = -1;
        for (int i = col; i < 8; ++i) if ((A[i] >> col) & 1u) { piv = i; break; }
        if (piv == -1) return false;
        std::swap(A[col], A[piv]);
        for (int i = 0; i < 8; ++i) if (i != col && ((A[i] >> col) & 1u)) A[i] ^= A[col];
    }
    for (int i = 0; i < 8; ++i) inv[i] = static_cast<uint8_t>(A[i] >> 8);
    return true;
}
int rank_gf2_u8(const uint8_t G[7], int r) {
    uint8_t A[7]; for (int i = 0; i < r; ++i) A[i] = G[i];
    int rk = 0;
    for (int col = 0; col < r; ++col) {
        int piv = -1;
        for (int i = rk; i < r; ++i) if ((A[i] >> col) & 1u) { piv = i; break; }
        if (piv == -1) continue;
        std::swap(A[rk], A[piv]);
        for (int i = 0; i < r; ++i) if (i != rk && ((A[i] >> col) & 1u)) A[i] ^= A[rk];
        rk++;
    }
    return rk;
}
int mons3[93];
void init_mons3() { int k = 0; for (int m = 0; m < 256; ++m) if (pop8(m) <= 3) mons3[k++] = m; }

void solve_rm3_phase(const uint8_t Qtab[256], const uint8_t Qcarry[256],
                     const bool inZ0[256], uint8_t g_out[256]) {
    struct Row93 { uint64_t lo = 0, hi = 0; int rhs = 0; };
    Row93 pivs[93]; bool has_piv[93]{};
    auto set_bit = [](Row93& r, int b) { if (b < 64) r.lo |= (1ULL << b); else r.hi |= (1ULL << (b - 64)); };
    auto first_bit = [](const Row93& r) -> int {
        if (r.lo) return __builtin_ctzll(r.lo);
        if (r.hi) return 64 + __builtin_ctzll(r.hi);
        return -1;
    };
    for (int u = 0; u < 256; ++u) {
        if (Qtab[u] != 0) continue;
        Row93 r;
        for (int k = 0; k < 93; ++k) if ((u & mons3[k]) == mons3[k]) set_bit(r, k);
        r.rhs = (inZ0[u] ? 0 : 1) ^ Qcarry[u];
        while (true) {
            int b = first_bit(r); if (b == -1) break;
            if (has_piv[b]) { r.lo ^= pivs[b].lo; r.hi ^= pivs[b].hi; r.rhs ^= pivs[b].rhs; }
            else { pivs[b] = r; has_piv[b] = true; break; }
        }
        if (first_bit(r) == -1 && r.rhs != 0) throw std::logic_error("RM(3,8) inconsistent");
    }
    uint64_t sol_lo = 0, sol_hi = 0;
    for (int b = 92; b >= 0; --b) {
        if (!has_piv[b]) continue;
        int par = (__builtin_popcountll(pivs[b].lo & sol_lo) + __builtin_popcountll(pivs[b].hi & sol_hi)) & 1;
        if (pivs[b].rhs ^ par) { if (b < 64) sol_lo |= (1ULL << b); else sol_hi |= (1ULL << (b - 64)); }
    }
    for (int u = 0; u < 256; ++u) {
        int s = 0;
        for (int k = 0; k < 93; ++k) {
            bool on = (k < 64) ? ((sol_lo >> k) & 1ULL) : ((sol_hi >> (k - 64)) & 1ULL);
            if (on && ((u & mons3[k]) == mons3[k])) s ^= 1;
        }
        g_out[u] = static_cast<uint8_t>(s ^ Qcarry[u]);
    }
}

bool dual_kill_exact(const uint8_t Qtab[256], const uint8_t g[256],
                     const bool inZ0[256], int n8_free, int& best_margin) {
    int fF[256]{};
    for (int u = 0; u < 256; ++u) if (Qtab[u] == 1) fF[u] = g[u] ? 3 : -3;
    int wF[256]; for (int i = 0; i < 256; ++i) wF[i] = fF[i];
    fwht256(wF);

    auto eval_c = [&](const int c[256]) -> int {
        int norm1 = 0; for (int x = 0; x < 256; ++x) norm1 += std::abs(c[x]);
        if (!norm1) return -1000000;
        int C[256]; for (int i = 0; i < 256; ++i) C[i] = c[i];
        fwht256(C);
        int base = 0, zpen = 0;
        int fabs_arr[136], nf = 0;
        for (int u = 0; u < 256; ++u) {
            base += fF[u] * C[u];
            if (Qtab[u] == 0 && !inZ0[u]) zpen += 2 * std::abs(C[u]);
            else if (Qtab[u] == 1) fabs_arr[nf++] = std::abs(C[u]);
        }
        std::nth_element(fabs_arr, fabs_arr + n8_free, fabs_arr + nf, std::greater<int>());
        int fpen = 0; for (int i = 0; i < n8_free; ++i) fpen += 4 * fabs_arr[i];
        return (base - zpen - fpen) - 64 * norm1;
    };

    best_margin = -1000000;
    std::set<int> thrs;
    for (int x = 0; x < 256; ++x) if (std::abs(wF[x]) >= 60) thrs.insert(std::abs(wF[x]));
    for (int thr : thrs) {
        int c[256]{};
        for (int x = 0; x < 256; ++x) {
            if (wF[x] >= thr) c[x] = 1;
            else if (wF[x] <= -thr) c[x] = -1;
        }
        int m = eval_c(c);
        if (m > best_margin) best_margin = m;
        if (m > 0) return true;
    }
    // 2-level integer witness: 2*sgn(wF)*1_{|wF|>=108} + sgn(wF)*1_{|wF|==84}
    {
        int c[256]{};
        for (int x = 0; x < 256; ++x) {
            int aw = std::abs(wF[x]);
            if (aw >= 108) c[x] = (wF[x] > 0) ? 2 : -2;
            else if (aw == 84) c[x] = (wF[x] > 0) ? 1 : -1;
        }
        int m = eval_c(c);
        if (m > best_margin) best_margin = m;
        if (m > 0) return true;
    }
    return false;
}

void run_n14() {
    const int m = 13, d = 5, max_w = 6;
    const uint16_t all_ones = (1u << m) - 1u;
    int lcd_cnt = 0, s_v0 = 0, s_vnz = 0, k_v0 = 0, k_vnz = 0;
    int min_m_v0 = 1e9, min_m_vnz = 1e9;
    for (int dmin = 6; dmin >= 3; --dmin) {
        uint16_t rows[5]{all_ones, static_cast<uint16_t>(((1u << dmin) - 1u) << (m - dmin)), 0, 0, 0};
        std::vector<uint16_t> span = {0, all_ones, rows[1], static_cast<uint16_t>(all_ones ^ rows[1])};
        auto dfs = [&](auto& self, int r, const std::vector<std::pair<int,int>>& blocks) -> void {
            if (r >= 3) {
                uint8_t GH[7]{};
                for (int i = 0; i < r; ++i) for (int j = 0; j < r; ++j)
                    if (pop16(rows[i] & rows[j]) & 1) GH[i] |= (1u << j);
                if (r - rank_gf2_u8(GH, r) > d - r) return;
            }
            if (r == d) {
                lcd_cnt++;
                uint16_t Hr[5]; for (int i = 0; i < d; ++i) Hr[i] = rows[i];
                int pivs[5], npiv = 0; bool is_piv[13]{};
                for (int col = 0; col < m && npiv < d; ++col) {
                    int p = -1; for (int i = npiv; i < d; ++i) if ((Hr[i] >> col) & 1u) { p = i; break; }
                    if (p == -1) continue;
                    std::swap(Hr[npiv], Hr[p]);
                    for (int i = 0; i < d; ++i) if (i != npiv && ((Hr[i] >> col) & 1u)) Hr[i] ^= Hr[npiv];
                    pivs[npiv++] = col; is_piv[col] = true;
                }
                uint16_t U[8]{}; int rr = 0;
                for (int col = 0; col < m; ++col) {
                    if (is_piv[col]) continue;
                    uint16_t v = (1u << col);
                    for (int i = 0; i < d; ++i) if ((Hr[i] >> col) & 1u) v |= (1u << pivs[i]);
                    U[rr++] = v;
                }
                uint8_t G[8]{}, B[8]{};
                for (int i = 0; i < 8; ++i) for (int j = 0; j < 8; ++j)
                    if (pop16(U[i] & U[j]) & 1) G[i] |= (1u << j);
                if (!invert8(G, B)) return;
                int us[13];
                for (int j = 0; j < m; ++j) { int u = 0; for (int i = 0; i < 8; ++i) if ((U[i] >> j) & 1u) u |= (1 << i); us[j] = u; }
                uint8_t Qtab[256], Qcarry[256]; int zcnt = 0;
                for (int x = 0; x < 256; ++x) {
                    int s = 0; for (int i = 0; i < 8; ++i) if ((x >> i) & 1) s += pop8((B[i] >> (i + 1)) & (x >> (i + 1)));
                    Qtab[x] = s & 1; Qcarry[x] = (s >> 1) & 1; if (!Qtab[x]) zcnt++;
                }
                for (int k = 0; k < d; ++k) if (Qtab[us[pivs[k]]] != 0) return;
                if (zcnt != 120) return;
                int qh[256], z0h[256]{};
                for (int x = 0; x < 256; ++x) qh[x] = Qtab[x];
                z0h[0] = 1; for (int j = 0; j < m; ++j) z0h[us[j]] = 1;
                fwht256(qh); fwht256(z0h);
                int v = 0;
                for (int i = 0; i < 8; ++i) {
                    int y = 1 << i;
                    int rhs = (((80 * qh[y]) / 64) % 8 + 8) % 8;
                    int diff = ((z0h[y] + 4 - rhs) % 8 + 8) % 8;
                    if (diff == 4) v |= (1 << i);
                    else if (diff != 0) return;
                }
                for (int y = 1; y < 256; ++y) {
                    int rhs = (((80 * qh[y]) / 64) % 8 + 8) % 8;
                    int lhs = ((z0h[y] + 4 - 4 * (pop8(y & v) & 1)) % 8 + 8) % 8;
                    if (lhs != rhs) return;
                }
                bool inZ0[256]{}; inZ0[0] = true; for (int j = 0; j < m; ++j) inZ0[us[j]] = true;
                uint8_t g[256]; solve_rm3_phase(Qtab, Qcarry, inZ0, g);
                int bm = 0;
                bool dead = dual_kill_exact(Qtab, g, inZ0, 6, bm);
                if (v == 0) { s_v0++; if (dead) k_v0++; if (bm < min_m_v0) min_m_v0 = bm; }
                else { s_vnz++; if (dead) k_vnz++; if (bm < min_m_vnz) min_m_vnz = bm; }
                return;
            }
            int nb = (int)blocks.size(); std::vector<int> ks(nb, 0);
            size_t prev_sz = span.size(); int prev_wt = pop16(rows[r - 1]);
            auto rec = [&](auto& rself, int bi, int used_wt, uint16_t mask) -> void {
                if (bi == nb) {
                    if (used_wt < prev_wt || used_wt > max_w) return;
                    for (size_t i = 0; i < prev_sz; ++i) { int w = pop16(mask ^ span[i]); if (std::min(w, m - w) < used_wt) return; }
                    rows[r] = mask;
                    for (size_t i = 0; i < prev_sz; ++i) span.push_back(mask ^ span[i]);
                    std::vector<std::pair<int,int>> nblocks;
                    for (int j = 0; j < nb; ++j) {
                        auto [st, len] = blocks[j]; int k = ks[j];
                        if (len - k > 0) nblocks.push_back({st, len - k});
                        if (k > 0) nblocks.push_back({st + len - k, k});
                    }
                    self(self, r + 1, nblocks);
                    span.resize(prev_sz); return;
                }
                auto [st, len] = blocks[bi]; int lim = std::min(len, max_w - used_wt);
                for (int k = 0; k <= lim; ++k) {
                    ks[bi] = k; uint16_t bm = k ? (((1u << k) - 1u) << (st + len - k)) : 0u;
                    rself(rself, bi + 1, used_wt + k, mask | bm);
                }
            };
            rec(rec, 0, 0, 0);
        };
        dfs(dfs, 2, {{0, m - dmin}, {m - dmin, dmin}});
    }
    std::cout << "[n_0=14, n_8=6 EXACT INDIVIDUAL AUDIT] lcd=" << lcd_cnt
              << " | v=0: " << k_v0 << "/" << s_v0 << " (min_margin=+" << min_m_v0 << ")"
              << " | v!=0: " << k_vnz << "/" << s_vnz << " (min_margin=+" << min_m_vnz << ")\n";
    if (k_v0 != s_v0 || k_vnz != s_vnz) throw std::logic_error("n_0=14 audit failed!");
}

void run_n16() {
    const int m = 15, d = 7, max_w = 7;
    const uint16_t all_ones = (1u << m) - 1u;
    long long lcd_cnt = 0;
    std::set<std::array<uint16_t, 7>> uniq_rref;
    int cnt[3]{}, killed[3]{}, min_m[3]{999999, 999999, 999999};
    for (int dmin = 6; dmin >= 3; --dmin) {
        uint16_t rows[7]{}; rows[0] = all_ones; rows[1] = static_cast<uint16_t>(((1u << dmin) - 1u) << (m - dmin));
        std::vector<uint16_t> span = {0, all_ones, rows[1], static_cast<uint16_t>(all_ones ^ rows[1])};
        auto dfs = [&](auto& self, int r, const std::vector<std::pair<int,int>>& blocks) -> void {
            if (r >= 4) {
                uint8_t GH[7]{};
                for (int i = 0; i < r; ++i) for (int j = 0; j < r; ++j)
                    if (pop16(rows[i] & rows[j]) & 1) GH[i] |= (1u << j);
                if (r - rank_gf2_u8(GH, r) > d - r) return;
            }
            if (r == d) {
                lcd_cnt++;
                uint16_t Hr[7]; for (int i = 0; i < d; ++i) Hr[i] = rows[i];
                int pivs[7], npiv = 0; bool is_piv[15]{};
                for (int col = 0; col < m && npiv < d; ++col) {
                    int p = -1; for (int i = npiv; i < d; ++i) if ((Hr[i] >> col) & 1u) { p = i; break; }
                    if (p == -1) continue;
                    std::swap(Hr[npiv], Hr[p]);
                    for (int i = 0; i < d; ++i) if (i != npiv && ((Hr[i] >> col) & 1u)) Hr[i] ^= Hr[npiv];
                    pivs[npiv++] = col; is_piv[col] = true;
                }
                if (npiv != d) return;
                uint16_t U[8]{}; int rr = 0;
                for (int col = 0; col < m; ++col) {
                    if (is_piv[col]) continue;
                    uint16_t v = (1u << col);
                    for (int i = 0; i < d; ++i) if ((Hr[i] >> col) & 1u) v |= (1u << pivs[i]);
                    U[rr++] = v;
                }
                uint8_t G[8]{}, B[8]{};
                for (int i = 0; i < 8; ++i) for (int j = 0; j < 8; ++j)
                    if (pop16(U[i] & U[j]) & 1) G[i] |= (1u << j);
                if (!invert8(G, B)) return;
                int us[15];
                for (int j = 0; j < m; ++j) { int u = 0; for (int i = 0; i < 8; ++i) if ((U[i] >> j) & 1u) u |= (1 << i); us[j] = u; }
                auto Q0 = [&](int x) -> int {
                    int s = 0; for (int i = 0; i < 8; ++i) if ((x >> i) & 1) s ^= pop8((B[i] >> (i + 1)) & (x >> (i + 1))) & 1; return s;
                };
                for (int k = 0; k < d; ++k) if (Q0(us[pivs[k]]) != 0) return;
                uint8_t Qtab[256], Qcarry[256]; int zcnt = 0;
                for (int x = 0; x < 256; ++x) {
                    int s = 0; for (int i = 0; i < 8; ++i) if ((x >> i) & 1) s += pop8((B[i] >> (i + 1)) & (x >> (i + 1)));
                    Qtab[x] = s & 1; Qcarry[x] = (s >> 1) & 1; if (!Qtab[x]) zcnt++;
                }
                if (zcnt != 120) return;
                int qh[256], z0h[256]{};
                for (int x = 0; x < 256; ++x) qh[x] = Qtab[x];
                z0h[0] = 1; for (int j = 0; j < m; ++j) z0h[us[j]] = 1;
                fwht256(qh); fwht256(z0h);
                int v = 0;
                for (int i = 0; i < 8; ++i) {
                    int y = 1 << i;
                    int rhs = (((80 * qh[y]) / 64) % 8 + 8) % 8;
                    int diff = ((z0h[y] + 2 - rhs) % 8 + 8) % 8;
                    if (diff == 4) v |= (1 << i);
                    else if (diff != 0) return;
                }
                for (int y = 1; y < 256; ++y) {
                    int rhs = (((80 * qh[y]) / 64) % 8 + 8) % 8;
                    int lhs = ((z0h[y] + 2 - 4 * (pop8(y & v) & 1)) % 8 + 8) % 8;
                    if (lhs != rhs) return;
                }
                std::array<uint16_t, 7> key; for (int i = 0; i < 7; ++i) key[i] = Hr[i];
                if (!uniq_rref.insert(key).second) return;
                int cat = (v == 0) ? 0 : (Qtab[v] ? 2 : 1);
                cnt[cat]++;
                bool inZ0[256]{}; inZ0[0] = true; for (int j = 0; j < m; ++j) inZ0[us[j]] = true;
                uint8_t g[256]; solve_rm3_phase(Qtab, Qcarry, inZ0, g);
                int bm = 0;
                bool dead = dual_kill_exact(Qtab, g, inZ0, 5, bm);
                if (dead) killed[cat]++;
                if (bm < min_m[cat]) min_m[cat] = bm;
                return;
            }
            int nb = (int)blocks.size(); std::vector<int> ks(nb, 0);
            size_t prev_sz = span.size(); int prev_wt = pop16(rows[r - 1]);
            auto rec = [&](auto& rself, int bi, int used_wt, uint16_t mask) -> void {
                if (bi == nb) {
                    if (used_wt < prev_wt || used_wt > max_w) return;
                    for (size_t i = 0; i < prev_sz; ++i) { int w = pop16(mask ^ span[i]); if (std::min(w, m - w) < used_wt) return; }
                    rows[r] = mask;
                    for (size_t i = 0; i < prev_sz; ++i) span.push_back(mask ^ span[i]);
                    std::vector<std::pair<int,int>> nblocks;
                    for (int j = 0; j < nb; ++j) {
                        auto [st, len] = blocks[j]; int k = ks[j];
                        if (len - k > 0) nblocks.push_back({st, len - k});
                        if (k > 0) nblocks.push_back({st + len - k, k});
                    }
                    self(self, r + 1, nblocks);
                    span.resize(prev_sz); return;
                }
                auto [st, len] = blocks[bi]; int lim = std::min(len, max_w - used_wt);
                for (int k = 0; k <= lim; ++k) {
                    ks[bi] = k; uint16_t bm = k ? (((1u << k) - 1u) << (st + len - k)) : 0u;
                    rself(rself, bi + 1, used_wt + k, mask | bm);
                }
            };
            rec(rec, 0, 0, 0);
        };
        dfs(dfs, 2, {{0, m - dmin}, {m - dmin, dmin}});
    }
    std::cout << "[n_0=16, n_8=5 EXACT INDIVIDUAL AUDIT] lcd=" << lcd_cnt << " uniq_rref=" << uniq_rref.size()
              << " | v=0: " << killed[0] << "/" << cnt[0] << " (min_margin=+" << min_m[0] << ")"
              << " | Q(v)=0: " << killed[1] << "/" << cnt[1] << " (min_margin=+" << min_m[1] << ")"
              << " | Q(v)=1: " << killed[2] << "/" << cnt[2] << " (min_margin=+" << min_m[2] << ")\n";
    if (killed[0] != cnt[0] || killed[1] != cnt[1] || killed[2] != cnt[2]) throw std::logic_error("n_0=16 audit failed!");
}

int main() {
    init_mons3();
    run_n14();
    run_n16();
    std::cout << "ALL n_0 = 14 AND n_0 = 16 RREF REPS 100% INDIVIDUALLY KILLED BY EXACT INTEGER DUAL WITNESSES!\n";
    return 0;
}
