#!/usr/bin/env python3
"""
100% EXACT RATIONAL (fractions.Fraction) L_1 + L_inf LP DUAL CERTIFICATE VERIFIER
for EVERY SINGLE exact O^-(8,2) orbit rep in exact_n18_n20_o8_orbs.txt!

For each exact O^-(8,2) orbit rep (Z_0, n_8):
  Primal variables (all >= 0):
    x_F[0..135]   in [0, 1]     (S_8 indicators on F; sum x_F <= n_8)
    y_Z[0..nZ-1]  in [0, 4]     (f_Z = y_Z - 2 in [-2, +2] on Z \ Z_0)
    a[0..255]     in [0, 64]    (|w_tot(x)| <= a[x] <= 64)
  Linear inequalities:
    w_tot(x) - a[x] <= 0        (x = 0..255)
   -w_tot(x) - a[x] <= 0        (x = 0..255)
    sum x_F <= n_8
    x_F[j] <= 1, y_Z[k] <= 4, a[x] <= 64.
  Objective:
    minimize  sum_{x=0}^{255} a[x]   (lower bound on L_1 norm of w_tot = 64 V!)
  Since wt(V) = 100 and V in {-1, 0, +1}^256, ANY real solution MUST have sum a[x] <= 6,400!

  EXACT RATIONAL PROOF (ZERO floating-point trust!):
    For any dual vector u >= 0 (exact Fractions) satisfying A_ub^T u + c_obj >= 0 componentwise:
      c_obj^T x >= (c_obj + A_ub^T u)^T x - b_ub^T u >= -b_ub^T u.
    If -b_ub^T u > 6400 (as an EXACT Fraction!), then NO real V exists!
    (Note: when the primal LP is plain infeasible even without L_1, we certify plain infeasibility
     with exact Fraction Farkas certificate u >= 0, A_ub^T u >= 0, b_ub^T u < 0!)

MANDATORY POSITIVE CONTROL:
  QR(17) (n_0=18, n_8=0, t=102): verifies min L_1 == 6528 == 64*102 (NOT > 6528!),
  AND QR(17) at t=100 (n_8=4): verifies min L_1 <= 6400 (cannot be falsely killed by L_1 LP!).
"""
from fractions import Fraction
import numpy as np
from scipy.optimize import linprog

def Q8_s(u):
    return (((u>>0)&1) + ((u>>1)&1) + (((u>>0)&1)&((u>>1)&1)) +
            (((u>>2)&1)&((u>>3)&1)) + (((u>>4)&1)&((u>>5)&1)) + (((u>>6)&1)&((u>>7)&1)))
def Q8(u): return Q8_s(u) & 1
def Q8_carry(u): s = Q8_s(u); return (s * (s - 1) // 2) & 1
def pop(x): return bin(x).count("1")

H8 = np.zeros((256, 256), dtype=int)
for x in range(256):
    for u in range(256):
        H8[x, u] = -1 if (pop(x & u) & 1) else 1

Z_all = [u for u in range(256) if Q8(u) == 0]
F_all = [u for u in range(256) if Q8(u) == 1]
mons3 = [m for m in range(256) if pop(m) <= 3]

# Precompute RREF of M3[Z_all]
A = []
for i, u in enumerate(Z_all):
    mb = 0
    for k, m in enumerate(mons3):
        if (u & m) == m: mb |= (1 << k)
    A.append([mb, 1 << i])
rk = 0; pivs = []
for col in range(93):
    p = -1
    for i in range(rk, 120):
        if (A[i][0] >> col) & 1: p = i; break
    if p == -1: continue
    A[rk], A[p] = A[p], A[rk]
    for i in range(120):
        if i != rk and ((A[i][0] >> col) & 1):
            A[i][0] ^= A[rk][0]; A[i][1] ^= A[rk][1]
    pivs.append(col); rk += 1
assert rk == 84

# Fast GF_map matrix (136 x 120) over GF(2)
GF_mat = np.zeros((136, 120), dtype=np.uint8)
GF_c = np.zeros(136, dtype=np.uint8)
z_base = np.array([1 ^ Q8_carry(u) for u in Z_all], dtype=np.uint8)
for fi, u in enumerate(F_all):
    row = np.zeros(120, dtype=np.uint8)
    for r in range(84):
        m = mons3[pivs[r]]
        if (u & m) == m:
            h = A[r][1]
            for i in range(120):
                if (h >> i) & 1: row[i] ^= 1
    GF_mat[fi] = row
    GF_c[fi] = (Q8_carry(u) ^ int(np.dot(row, z_base) & 1)) & 1
u_to_zi = {u: i for i, u in enumerate(Z_all)}

def certify_rep_exact_L1(us, n8, t_target=100, expect_kill=True):
    inZ0 = set([0] + list(us))
    z_ind = np.zeros(120, dtype=np.uint8)
    for u in inZ0: z_ind[u_to_zi[u]] = 1
    gF_vec = (GF_c ^ ((GF_mat @ z_ind) & 1)) & 1

    fF0 = np.zeros(256, dtype=int)
    for fi, u in enumerate(F_all):
        fF0[u] = 3 if gF_vec[fi] else -3
    wF0 = H8 @ fF0

    Z_nz = [u for u in Z_all if u not in inZ0]
    nF = 136
    nZ = len(Z_nz)
    # Variables: [xF (136), yZ (nZ), a (256)]
    nvar = nF + nZ + 256
    M_w = np.zeros((256, nF + nZ), dtype=int)
    base_w = wF0.copy()
    for j, u in enumerate(F_all):
        sgn = 4 * (1 - 2 * int(gF_vec[j]))
        M_w[:, j] = H8[:, u] * sgn
    for k, u in enumerate(Z_nz):
        M_w[:, nF + k] = H8[:, u]
        base_w -= 2 * H8[:, u]

    # Build A_ub @ vars <= b_ub (rows: 256 pos, 256 neg, 1 sum_xF, nvar box bounds)
    # Using sparse or dense? nvar ~ 494, nrows ~ 1007 -> dense is tiny (0.5M ints, 0.01s in HiGHS!)
    I256 = np.eye(256, dtype=int)
    Z256_a = np.zeros((1, 256), dtype=int)
    row_sum_xF = np.zeros((1, nvar), dtype=int)
    row_sum_xF[0, :nF] = 1
    A_ub = np.vstack([
        np.hstack([M_w, -I256]),
        np.hstack([-M_w, -I256]),
        row_sum_xF,
        np.eye(nvar, dtype=int),
    ])
    b_ub = np.concatenate([
        -base_w,
        base_w,
        [n8],
        np.ones(nF, dtype=int),
        np.full(nZ, 4, dtype=int),
        np.full(256, 64, dtype=int),
    ])
    c_obj = np.concatenate([np.zeros(nF + nZ, dtype=int), np.ones(256, dtype=int)])
    nrows = len(b_ub)
    box_start = 513  # rows 513..513+nvar-1 are vars <= ub!

    res = linprog(c_obj.astype(float), A_ub=A_ub.astype(float), b_ub=b_ub.astype(float), bounds=(0, None), method='highs')
    if res.status not in (0, 2):
        res = linprog(c_obj.astype(float), A_ub=A_ub.astype(float), b_ub=b_ub.astype(float), bounds=(0, None),
                      method='highs', options={'presolve': False})
    if not expect_kill:
        return res.status, (res.fun if res.status == 0 else None)

    if res.status != 0:
        # PLAIN LP INFEASIBLE! Certify exact Fraction Farkas ray u >= 0: A_ub^T u >= 0, b_ub^T u < 0!
        c_s = np.zeros(nvar + 1); c_s[-1] = 1.0
        A_s = np.hstack([A_ub.astype(float), np.zeros((nrows, 1))])
        A_s[:512, -1] = -1.0  # relax |w_tot| <= a + s
        r_s = linprog(c_s, A_ub=A_s, b_ub=b_ub.astype(float), bounds=(0, None), method='highs')
        if r_s.status != 0:
            r_s = linprog(c_s, A_ub=A_s, b_ub=b_ub.astype(float), bounds=(0, None),
                          method='highs', options={'presolve': False})
        assert r_s.status == 0 and r_s.fun > 1e-6, f"Expected strictly infeasible, got status={r_s.status} s={r_s.fun}"
        u_raw = np.maximum(0.0, -r_s.ineqlin.marginals)
        for max_den in (1024, 10**5, 10**7):
            # Integer scaling: multiply u_raw by max_den -> exact integer vector! (1000x faster than Fraction loops!)
            u_int = np.rint(u_raw * max_den).astype(np.int64)
            u_int = np.maximum(0, u_int)
            # Check A_ub^T @ u_int >= 0 (in exact int64!)
            col_sums = A_ub.T @ u_int
            neg_idx = np.where(col_sums < 0)[0]
            if len(neg_idx):
                u_int[box_start + neg_idx] += -col_sums[neg_idx]
            # Exact Python arbitrary-precision int verification (zero int64 overflow risk!)
            u_py = [int(v) for v in u_int]
            # Verify column sums >= 0 in exact Python ints via matrix-vector check
            col_check = (A_ub.T.astype(object) @ np.array(u_py, dtype=object))
            assert all(val >= 0 for val in col_check)
            dot_b = int(b_ub.astype(object) @ np.array(u_py, dtype=object))
            if dot_b < 0:
                return "INFEAS_EXACT", Fraction(dot_b, max_den)
        raise RuntimeError("Failed to rationalize plain-infeasible Farkas certificate!")

    assert res.status == 0 and res.fun > 64 * t_target + 1e-4, f"NOT KILLED! status={res.status} fun={res.fun}"
    u_raw = np.maximum(0.0, -res.ineqlin.marginals)
    for max_den in (1024, 10**5, 10**7):
        u_int = np.maximum(0, np.rint(u_raw * max_den).astype(np.int64))
        # Exact int check: A_ub^T @ u_int + max_den * c_obj >= 0
        col_sums = A_ub.T @ u_int + max_den * c_obj
        neg_idx = np.where(col_sums < 0)[0]
        if len(neg_idx):
            u_int[box_start + neg_idx] += -col_sums[neg_idx]
        # Verify in exact Python arbitrary-precision integers!
        u_py = np.array([int(v) for v in u_int], dtype=object)
        col_check = A_ub.T.astype(object) @ u_py + max_den * c_obj.astype(object)
        assert all(val >= 0 for val in col_check)
        num = -(b_ub.astype(object) @ u_py)
        lb = Fraction(int(num), max_den)
        if lb > 64 * t_target:
            return "L1_EXACT", lb
    raise RuntimeError(f"Failed to rationalize L1 certificate! HiGHS fun={res.fun}")

# MANDATORY POSITIVE CONTROL: QR(17)!
print("=== POSITIVE CONTROL: QR(17) ===")
qr17_us = [13, 49, 55, 57, 79, 88, 110, 113, 122, 178, 199, 203, 210, 213, 214, 215, 248]
st102, val102 = certify_rep_exact_L1(qr17_us, 0, 102, expect_kill=False)
st100, val100 = certify_rep_exact_L1(qr17_us, 4, 100, expect_kill=False)
assert st102 == 0 and abs(val102 - 6528.0) < 1e-6, f"QR17 t=102 pos ctrl fail: {st102} {val102}"
assert st100 == 0 and val100 <= 6400.0 + 1e-6, f"QR17 t=100 pos ctrl fail: {st100} {val100}"
print(f"  [POS CTRL PASS] QR(17): t=102 (n_8=0) min_L1={val102:.2f} (exact 64*102=6528); "
      f"t=100 (n_8=4) min_L1={val100:.2f} (<= 6400, not falsely killed!)")
with open("exact_n18_n20_o8_orbs.txt") as f:
    lines = [ln.strip() for ln in f if ln.strip()]

print(f"Loaded {len(lines)} EXACT O^-(8,2) orbit reps from exact_n18_n20_o8_orbs.txt")
cnt = {"n18": [0, 0, 0], "n20": [0, 0, 0]} # [total, infeas, l1]
min_lb = {"n18": None, "n20": None}
for idx, ln in enumerate(lines):
    parts = ln.split("|")
    tag = parts[0].strip()
    n8 = int(parts[1].strip())
    us = [int(x) for x in parts[-1].split()]
    kind, val = certify_rep_exact_L1(us, n8, 100, expect_kill=True)
    cnt[tag][0] += 1
    if kind == "INFEAS_EXACT":
        cnt[tag][1] += 1
    else:
        cnt[tag][2] += 1
        if min_lb[tag] is None or val < min_lb[tag]:
            min_lb[tag] = val

for tag in ("n18", "n20"):
    tot, infc, l1c = cnt[tag]
    ml = float(min_lb[tag]) if min_lb[tag] is not None else None
    print(f"  [{tag} 100% EXACT RATIONAL CERTIFIED] {tot}/{tot} exact O^-(8,2) orbits KILLED! "
          f"(plain_infeas={infc}, L1_exact={l1c}, min_L1_lb={ml} > 6400)")
print("ALL EXACT O^-(8,2) ORBITS OF n_0 = 18 (v != 0) AND n_0 = 20 CERTIFIED IN EXACT RATIONAL ARITHMETIC!")
