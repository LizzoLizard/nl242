#!/usr/bin/env python3
"""
100% EXACT RATIONAL (fractions.Fraction) FARKAS CERTIFICATE VERIFIER
for ALL Signed (Q*, v)-Weighted Delsarte LPs used to close (t=100, r=8, |Z|=120)!

Zero floating-point trust:
  1. Verifies EVERY LP identity directly on concrete valid codes (QR(17), n18 Q=0/1, n20)!
  2. Solves each LP with scipy.optimize.linprog (HiGHS) to find a candidate dual ray y,
     rationalizes y to exact fractions.Fraction (with bounded denominator), and verifies
     in EXACT ARBITRARY-PRECISION RATIONAL ARITHMETIC that:
       - y_ineq >= 0 for all inequality rows (A_ub x <= b_ub)
       - y^T A >= 0 for every variable column x >= 0
       - y^T b < 0  (Farkas' Lemma => PRIMAL 100% INFEASIBLE!)
  3. Also verifies the exact rational certificate for H_64 w = 4 (min n_8^(1) = 8 > 4)!
"""
import math
from fractions import Fraction
import numpy as np
from scipy.optimize import linprog

def Q8(u):
    return (((u>>0)&1) ^ ((u>>1)&1) ^ (((u>>0)&1)&((u>>1)&1)) ^
            (((u>>2)&1)&((u>>3)&1)) ^ (((u>>4)&1)&((u>>5)&1)) ^ (((u>>6)&1)&((u>>7)&1)))

def B8(x, y):
    return ((((x>>0)&1)&((y>>1)&1)) ^ (((x>>1)&1)&((y>>0)&1)) ^
            (((x>>2)&1)&((y>>3)&1)) ^ (((x>>3)&1)&((y>>2)&1)) ^
            (((x>>4)&1)&((y>>5)&1)) ^ (((x>>5)&1)&((y>>4)&1)) ^
            (((x>>6)&1)&((y>>7)&1)) ^ (((x>>7)&1)&((y>>6)&1)))

def J8(u):
    # Symplectic dual: <J8(u), w> == B8(u, w)
    out = 0
    for b in range(0, 8, 2):
        b0, b1 = (u >> b) & 1, (u >> (b + 1)) & 1
        out |= (b1 << b) | (b0 << (b + 1))
    return out

def pop(x):
    return bin(x).count("1")

def krawtchouk(j, w, m):
    s = 0
    for r in range(j + 1):
        if r <= w and j - r <= m - w:
            term = math.comb(w, r) * math.comb(m - w, j - r)
            s += -term if (r & 1) else term
    return s

# Compute exact bucket sizes directly from Q8!
def bucket_sizes(mode):
    # mode: 'v0', 'q0', 'q1'
    if mode == 'v0':
        v = 0
    elif mode == 'q0':
        v = 4  # Q8(4) = 0
        assert Q8(v) == 0 and v != 0
    elif mode == 'q1':
        v = 1  # Q8(1) = 1
        assert Q8(v) == 1
    cnt = {(0,0): 0, (0,1): 0, (1,0): 0, (1,1): 0}
    for y in range(1, 256):
        cnt[(Q8(y), pop(y & v) & 1)] += 1
    return cnt

# Sanity check identities on concrete codes!
def verify_identities_on_code(name, us):
    m = len(us)
    n0 = m + 1
    ws = [0] * 256
    for y in range(256):
        ws[y] = sum(pop(y & u) & 1 for u in us)
    # Deduce v
    v = 0
    for b in range(8):
        q_e = 1 if b < 2 else 0
        if (((ws[1 << b] >> 1) & 1) ^ q_e):
            v |= (1 << b)
    for y in range(1, 256):
        assert (ws[y] & 3) == (2 if (Q8(y) ^ (pop(y & v) & 1)) else 0), f"mod4 fail y={y}"
    # Check Q* j=1
    q1 = sum(((-1)**Q8(y)) * krawtchouk(1, ws[y], m) for y in range(256))
    assert q1 == -16 * m, f"Q* j=1 fail: {q1} != {-16*m}"
    # Check Q* j=2
    N1 = sum(1 for i in range(m) for k in range(i+1, m) if B8(us[i], us[k]))
    N1_from_w = sum(ws[J8(u)] for u in us)
    assert 2 * N1 == N1_from_w, f"2N1 mismatch"
    q2 = sum(((-1)**Q8(y)) * krawtchouk(2, ws[y], m) for y in range(256))
    assert q2 == -16 * (math.comb(m, 2) - 2 * N1), f"Q* j=2 fail"
    # Check v-weighted j=1..6
    if v != 0:
        b1 = sum(((-1)**(pop(y & v) & 1)) * krawtchouk(1, ws[y], m) for y in range(256))
        assert b1 == (256 if v in us else 0), f"v j=1 fail"
        for j in range(1, 7):
            bj = sum(((-1)**(pop(y & v) & 1)) * krawtchouk(j, ws[y], m) for y in range(256))
            assert bj >= 0 and bj % 256 == 0, f"v j={j} fail"
        # Check Q*v j=1
        qv1 = sum(((-1)**(Q8(y) ^ (pop(y & v) & 1))) * krawtchouk(1, ws[y], m) for y in range(256))
        exp_qv1 = -16 * ((-1)**Q8(v)) * (m - 2 * ws[J8(v)])
        assert qv1 == exp_qv1, f"Q*v j=1 fail: {qv1} != {exp_qv1}"
        assert Q8(J8(v)) == Q8(v) and (pop(J8(v) & v) & 1) == 0
    print(f"  [IDENTITY CHECK PASS] {name}: n0={n0}, v={v}, Q(v)={Q8(v)}, min_w={min(ws[1:])}, max_w={max(ws[1:])}")

def build_and_certify(name, n0, mode, d_aff_min, forbid_h64_w=None):
    """
    Build exact integer-matrix LP:
      A_eq x = b_eq
      A_ub x <= b_ub
      x >= 0
    Find Farkas certificate y = (y_eq, y_ub) in EXACT Fraction arithmetic:
      y_ub >= 0
      y_eq^T A_eq + y_ub^T A_ub >= 0  (componentwise)
      y_eq^T b_eq + y_ub^T b_ub < 0   (STRICTLY NEGATIVE!)
    """
    m = n0 - 1
    cnt = bucket_sizes(mode)
    qv_val = 0 if mode in ('v0', 'q0') else 1

    # Variables:
    #   x[(q, b, w)] for allowed (q, b, w)
    #   z[(b, w)]    for q=0 allowed (0, b, w): counts i in 1..m with J(u_i) in bucket (0,b,w)
    #   t[w]         (if mode != 'v0') for allowed (qv_val, 0, w): indicator of w(J(v))
    x_vars = []
    for (q, b), Nqb in cnt.items():
        if Nqb == 0:
            continue
        for w in range(1, n0):
            if (w & 3) != (2 if (q ^ b) else 0):
                continue
            # H_64 w >= 6 AND affine minimum distance d_aff_min:
            d56 = d_aff_min
            d64 = max(6, d_aff_min)
            if q == 0:
                if w < d64 or (n0 - w) < d56:
                    continue
                if forbid_h64_w is not None and w == forbid_h64_w:
                    continue
            else:
                if w < d56 or (n0 - w) < d64:
                    continue
                if forbid_h64_w is not None and (n0 - w) == forbid_h64_w:
                    continue
            x_vars.append((q, b, w))

    z_vars = [(b, w) for (q, b, w) in x_vars if q == 0]
    t_vars = [w for (q, b, w) in x_vars if mode != 'v0' and q == qv_val and b == 0]

    nx, nz, nt = len(x_vars), len(z_vars), len(t_vars)
    nvar = nx + nz + nt
    x_idx = {v: i for i, v in enumerate(x_vars)}
    z_idx = {v: nx + i for i, v in enumerate(z_vars)}
    t_idx = {v: nx + nz + i for i, v in enumerate(t_vars)}

    A_eq, b_eq = [], []
    A_ub, b_ub = [], []

    def add_eq(coeffs, rhs):
        row = [0] * nvar
        for idx, val in coeffs.items():
            row[idx] += val
        A_eq.append(row)
        b_eq.append(rhs)

    def add_ub(coeffs, rhs):
        row = [0] * nvar
        for idx, val in coeffs.items():
            row[idx] += val
        A_ub.append(row)
        b_ub.append(rhs)

    # 1. Bucket sums: sum_w x_{q,b,w} = N_{q,b}
    for (q, b), Nqb in cnt.items():
        if Nqb == 0:
            continue
        add_eq({x_idx[(q, b, w)]: 1 for (qq, bb, w) in x_vars if qq == q and bb == b}, Nqb)

    # 2. Standard Delsarte Krawtchouk j=1, 2 (EQ == 0) and j=3..m (GEQ 0 => -sum <= K_j(0))
    for j in (1, 2):
        add_eq({i: krawtchouk(j, w, m) for i, (q, b, w) in enumerate(x_vars)}, -krawtchouk(j, 0, m))
    for j in range(3, min(m + 1, 15)):
        add_ub({i: -krawtchouk(j, w, m) for i, (q, b, w) in enumerate(x_vars)}, krawtchouk(j, 0, m))

    # 3. Q*-weighted j=1: sum (-1)^q K_1(w;m) x = -17*m
    add_eq({i: ((-1)**q) * krawtchouk(1, w, m) for i, (q, b, w) in enumerate(x_vars)}, -17 * m)

    # 4. Q*-weighted j=2 with z_{b,w}:
    #    sum (-1)^q K_2(w;m) x - 16 * sum w * z_{b,w} = -17 * C(m, 2)
    c_q2 = {i: ((-1)**q) * krawtchouk(2, w, m) for i, (q, b, w) in enumerate(x_vars)}
    for (b, w) in z_vars:
        c_q2[z_idx[(b, w)]] = -16 * w
    add_eq(c_q2, -17 * math.comb(m, 2))
    # z constraints: sum z = m, and z_{b,w} - x_{0,b,w} <= 0
    add_eq({z_idx[v]: 1 for v in z_vars}, m)
    for (b, w) in z_vars:
        add_ub({z_idx[(b, w)]: 1, x_idx[(0, b, w)]: -1}, 0)

    # 5. v-weighted and Q*v-weighted (when v != 0)
    if mode != 'v0':
        if mode == 'q1':
            # B_1^(v) == 0 (v in F => v not in Z_0!)
            add_eq({i: ((-1)**b) * krawtchouk(1, w, m) for i, (q, b, w) in enumerate(x_vars)}, -krawtchouk(1, 0, m))
        else:
            # 0 <= 256*B_1^(v) <= 256
            add_ub({i: -((-1)**b) * krawtchouk(1, w, m) for i, (q, b, w) in enumerate(x_vars)}, krawtchouk(1, 0, m))
            add_ub({i: ((-1)**b) * krawtchouk(1, w, m) for i, (q, b, w) in enumerate(x_vars)}, 256 - krawtchouk(1, 0, m))
        for j in range(2, min(m + 1, 15)):
            add_ub({i: -((-1)**b) * krawtchouk(j, w, m) for i, (q, b, w) in enumerate(x_vars)}, krawtchouk(j, 0, m))
        # Q*v j=1: sum (-1)^{q+b} K_1(w;m) x - 32*(-1)^{Q(v)} * sum w * t_w = (-16*(-1)^{Q(v)} - 1)*m
        sgn = 1 if qv_val == 0 else -1
        c_qv1 = {i: ((-1)**(q + b)) * krawtchouk(1, w, m) for i, (q, b, w) in enumerate(x_vars)}
        for w in t_vars:
            c_qv1[t_idx[w]] = -32 * sgn * w
        add_eq(c_qv1, (-16 * sgn - 1) * m)
        add_eq({t_idx[w]: 1 for w in t_vars}, 1)
        for w in t_vars:
            add_ub({t_idx[w]: 1, x_idx[(qv_val, 0, w)]: -1}, 0)

    # First check primal feasibility with HiGHS
    Ae = np.array(A_eq, dtype=float)
    be = np.array(b_eq, dtype=float)
    Au = np.array(A_ub, dtype=float)
    bu = np.array(b_ub, dtype=float)
    res_p = linprog(np.zeros(nvar), A_ub=Au, b_ub=bu, A_eq=Ae, b_eq=be, bounds=(0, None), method='highs')
    if res_p.status == 0:
        print(f"  [FEASIBLE]   {name}")
        return False

    # Solve Farkas dual directly:
    #   minimize  y_eq^T b_eq + y_ub^T b_ub
    #   subject to y_eq^T A_eq + y_ub^T A_ub >= 0  (i.e. -A_eq^T y_eq - A_ub^T y_ub <= 0)
    #              y_ub >= 0,  -1 <= y_eq <= 1, 0 <= y_ub <= 1  (bounded box so dual isn't unbounded!)
    neq, nub = len(A_eq), len(A_ub)
    c_dual = np.concatenate([be, bu])
    M_dual = -np.hstack([Ae.T, Au.T])
    bounds_dual = [(-1.0, 1.0)] * neq + [(0.0, 1.0)] * nub
    res_d = linprog(c_dual, A_ub=M_dual, b_ub=np.zeros(nvar), bounds=bounds_dual, method='highs')
    assert res_d.status == 0 and res_d.fun < -1e-7, f"Dual failed for {name}: status={res_d.status} fun={res_d.fun}"

    # Now rationalize y to exact Fractions and verify STRICT Farkas certificate in exact arithmetic!
    # Wait: if we have tiny slack Violations in y^T A >= 0 after rounding, we can add a tiny margin epsilon
    # to the dual LP:  -A_eq^T y_eq - A_ub^T y_ub <= -1e-4  (strictly interior dual ray!)
    # Wait: some columns might be tight at 0, so let's rationalize with increasing max_den OR solve
    # with objective + margin on slack! Actually let's test direct limit_denominator first, and if any
    # column has tiny negative residual, bump to strict interior or higher denominator!
    y_raw = res_d.x
    verified = False
    for margin in (0.0, 1e-6, 1e-5, 1e-4):
        if margin > 0:
            res_d2 = linprog(c_dual, A_ub=M_dual, b_ub=np.full(nvar, -margin), bounds=bounds_dual, method='highs')
            if res_d2.status == 0 and res_d2.fun < -1e-7:
                y_raw = res_d2.x
        for max_den in (10**4, 10**6, 10**9, 10**12):
            ye = [Fraction(float(v)).limit_denominator(max_den) for v in y_raw[:neq]]
            yu = [max(Fraction(0), Fraction(float(v)).limit_denominator(max_den)) for v in y_raw[neq:]]
            # Exact rational check!
            obj = sum(ye[r] * b_eq[r] for r in range(neq)) + sum(yu[r] * b_ub[r] for r in range(nub))
            if obj >= 0:
                continue
            min_col = None
            ok = True
            for c in range(nvar):
                val = sum(ye[r] * A_eq[r][c] for r in range(neq)) + sum(yu[r] * A_ub[r][c] for r in range(nub))
                if val < 0:
                    ok = False
                    break
                if min_col is None or val < min_col:
                    min_col = val
            if ok:
                print(f"  [EXACT FARKAS PASS] {name}: y^T b = {float(obj):.6g} (< 0), min(y^T A) = {float(min_col):.6g} (>= 0), max_den<={max_den}")
                verified = True
                break
        if verified:
            break
    if not verified:
        # Fallback: exact rational dual simplex via exact basis solve on active constraints!
        # Actually let's maximize min_col while keeping y^T b == -1!
        # min t s.t. -A^T y + t * (-1) <= 0  -> max eps s.t. y^T A >= eps, y^T b == -1, y_ub >= 0!
        c2 = np.zeros(neq + nub + 1); c2[-1] = -1.0
        M2 = np.hstack([-Ae.T, -Au.T, np.ones((nvar, 1))])
        Aeq2 = np.array([np.concatenate([be, bu, [0.0]])])
        beq2 = np.array([-1.0])
        bnds2 = [(None, None)] * neq + [(0.0, None)] * nub + [(0.0, 1.0)]
        r2 = linprog(c2, A_ub=M2, b_ub=np.zeros(nvar), A_eq=Aeq2, b_eq=beq2, bounds=bnds2, method='highs')
        if r2.status == 0 and r2.x[-1] > 1e-12:
            y_raw = r2.x[:-1]
            for max_den in (10**6, 10**9, 10**12, 10**15):
                ye = [Fraction(float(v)).limit_denominator(max_den) for v in y_raw[:neq]]
                yu = [max(Fraction(0), Fraction(float(v)).limit_denominator(max_den)) for v in y_raw[neq:]]
                obj = sum(ye[r] * b_eq[r] for r in range(neq)) + sum(yu[r] * b_ub[r] for r in range(nub))
                if obj >= 0: continue
                if all(sum(ye[r]*A_eq[r][c] for r in range(neq)) + sum(yu[r]*A_ub[r][c] for r in range(nub)) >= 0 for c in range(nvar)):
                    print(f"  [EXACT FARKAS PASS (max-margin)] {name}: y^T b = {float(obj):.6g} (< 0), max_den<={max_den}")
                    verified = True
                    break
    if not verified:
        # Exact rational solve of active basis: if HiGHS says infeasible with tiny active cols, use exact Fraction Gaussian elim
        raise RuntimeError(f"Could not rationalize Farkas certificate for {name}!")
    return True

print("=== STEP 1: Verify ALL LP identities on real valid codes ===")
# Load real reps from exact_n18_n20_o8_orbs.txt (5 n18 reps + first 3 n20 reps)
with open("exact_n18_n20_o8_orbs.txt") as f:
    n18_i = n20_i = 0
    for ln in f:
        if not ln.strip(): continue
        tag = ln.split("|")[0].strip()
        us = [int(x) for x in ln.split("|")[-1].split()]
        if tag == "n18":
            n18_i += 1
            verify_identities_on_code(f"n18_orb{n18_i}", us)
        elif tag == "n20" and n20_i < 3:
            n20_i += 1
            verify_identities_on_code(f"n20_orb{n20_i}", us)

print("\n=== STEP 2: EXACT RATIONAL (Fraction) FARKAS CERTIFICATES ===")
# All 11 required Signed Delsarte exclusions:
cases = [
    ("n_0=18, Q(v)=0, d_aff>=6", 18, "q0", 6, None),
    ("n_0=18, Q(v)=1, d_aff>=6", 18, "q1", 6, None),
    ("n_0=20, v=0,    d_aff>=8", 20, "v0", 8, None),
    ("n_0=20, Q(v)=0, d_aff>=8", 20, "q0", 8, None),
    ("n_0=20, Q(v)=1, d_aff>=8", 20, "q1", 8, None),
    ("n_0=22, Q(v)=0, d_aff>=8", 22, "q0", 8, None),
    ("n_0=22, Q(v)=1, d_aff>=8", 22, "q1", 8, None),
    ("n_0=24, Q(v)=1, d_aff>=10", 24, "q1", 10, None),
    ("n_0=24, Q(v)=1, d_aff=8 forbid H64_w8", 24, "q1", 8, 8),
    ("n_0=26, v=0,    d_aff>=10", 26, "v0", 10, None),
    ("n_0=26, v=0,    d_aff=8 forbid H64_w8", 26, "v0", 8, 8),
]
for args in cases:
    assert build_and_certify(*args), f"Expected INFEASIBLE for {args[0]}"

# Positive control: QR(17) has n_0=18, v=0, d_aff=6 -> MUST BE FEASIBLE!
print("\n=== STEP 3: Positive Control (QR(17) at n_0=18, v=0, d_aff>=6 MUST BE FEASIBLE) ===")
assert not build_and_certify("POSCTRL: n_0=18, v=0, d_aff>=6 (QR17)", 18, "v0", 6, None)
print("ALL 11 EXACT RATIONAL FARKAS CERTIFICATES + POSITIVE CONTROL PASSED 100%!")
