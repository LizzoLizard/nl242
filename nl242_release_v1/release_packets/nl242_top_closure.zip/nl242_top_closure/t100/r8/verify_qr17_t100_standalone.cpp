// Standalone, zero-dependency exact integer verifier for (t=100, r=8, |Z|=120, n_0=18, n_8=4, v=0):
//   - Constructs QR(17) ([17, 8, 6] even-weight subcode of [17, 9, 5] quadratic residue code) from scratch.
//     (Uniqueness of QR(17) as the sole n_0=18, v=0, |Z|=120 code up to O^-(8,2) is proved in verify_t102_r8_closed.cpp.)
//   - POSITIVE CONTROL (t=102, n_8=0): recovers the real t=102 low block V (top102 == 4896, unique forced V,
//     verified WHT(V) in {0, +-8} on Z with 18 zeros and {+-12} on F, wt(V) == 102)!
//   - MAIN PROOF (t=100, n_8=4): tests ALL 53,550 unordered 4-subsets S_8 subset F with XOR(S_8) == 0:
//     53,142 killed immediately by top100(|w_{F,true}|) < 4768 (= 4*(1224 - 8*4));
//     remaining 408 hit top100 == 4768 with strictly unique top-100 support (ge == 100), forcing a unique V
//     in {-1, 0, +1}^256 whose WHT violates the {0, +-8}/{+-4, +-12} spectrum on ALL 408/408 (real_V == 0)!
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <vector>

inline int pop8(int x) { return __builtin_popcount(static_cast<unsigned>(x)); }
void fwht256(int a[256]) {
    for (int st = 1; st < 256; st *= 2)
        for (int i = 0; i < 256; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
bool invert8(const uint8_t M[8], uint8_t inv[8]) {
    uint16_t A[8]; for (int i = 0; i < 8; ++i) A[i] = static_cast<uint16_t>(M[i] | (1u << (8 + i)));
    for (int col = 0; col < 8; ++col) {
        int piv = -1; for (int i = col; i < 8; ++i) if ((A[i] >> col) & 1u) { piv = i; break; }
        if (piv == -1) return false;
        std::swap(A[col], A[piv]);
        for (int i = 0; i < 8; ++i) if (i != col && ((A[i] >> col) & 1u)) A[i] ^= A[col];
    }
    for (int i = 0; i < 8; ++i) inv[i] = static_cast<uint8_t>(A[i] >> 8);
    return true;
}

int main() {
    int mons3[93], nm = 0;
    for (int m = 0; m < 256; ++m) if (pop8(m) <= 3) mons3[nm++] = m;

    // 1. Standard Q8^-(u) = u0 + u1 + u0*u1 + u2*u3 + u4*u5 + u6*u7 (|Z| = 120)
    //    and the unique n_0 = 18, v = 0, |Z| = 120 code QR(17) ([17, 8, 6] even-weight QR code):
    uint8_t Qtab[256], Qcarry[256]; int zcnt = 0;
    for (int u = 0; u < 256; ++u) {
        int s = (((u>>0)&1) + ((u>>1)&1) + (((u>>0)&1)&((u>>1)&1)) +
                 (((u>>2)&1)&((u>>3)&1)) + (((u>>4)&1)&((u>>5)&1)) + (((u>>6)&1)&((u>>7)&1)));
        Qtab[u] = s & 1; Qcarry[u] = (s * (s - 1) / 2) & 1;
        if (!Qtab[u]) zcnt++;
    }
    if (zcnt != 120) throw std::logic_error("zcnt != 120");
    static const int qr17_us[17] = {13, 49, 55, 57, 79, 88, 110, 113, 122, 178, 199, 203, 210, 213, 214, 215, 248};
    bool inZ0[256]{}; inZ0[0] = true;
    for (int u : qr17_us) {
        if (Qtab[u] != 0) throw std::logic_error("QR(17) col not in Z");
        inZ0[u] = true;
    }
    // Verify QR(17) code weight distribution: min_w == 6 and w(y) == 2*Q8(y) (mod 4) for all y != 0!
    int min_w = 100;
    for (int y = 1; y < 256; ++y) {
        int w = 0; for (int u : qr17_us) if (__builtin_parity(y & u)) w++;
        if ((w & 3) != (Qtab[y] ? 2 : 0)) throw std::logic_error("QR(17) mod4 fail");
        if (w < min_w) min_w = w;
    }
    if (min_w != 6) throw std::logic_error("QR(17) min_w != 6");

    // 2. Solve RM(3,8) phase g on F (unique up to shift + sign since rank(RM(3,8)|_Z) = 84)
    struct Row93 { uint64_t lo = 0, hi = 0; int rhs = 0; };
    Row93 rpivs[93]; bool has_piv[93]{};
    auto setb = [](Row93& r, int b) { if (b < 64) r.lo |= (1ULL << b); else r.hi |= (1ULL << (b - 64)); };
    auto firstb = [](const Row93& r) -> int {
        if (r.lo) return __builtin_ctzll(r.lo);
        if (r.hi) return 64 + __builtin_ctzll(r.hi);
        return -1;
    };
    for (int u = 0; u < 256; ++u) {
        if (Qtab[u] != 0) continue;
        Row93 r;
        for (int k = 0; k < 93; ++k) if ((u & mons3[k]) == mons3[k]) setb(r, k);
        r.rhs = (inZ0[u] ? 0 : 1) ^ Qcarry[u];
        while (true) {
            int b = firstb(r); if (b == -1) { if (r.rhs) throw std::logic_error("inconsistent"); break; }
            if (has_piv[b]) { r.lo ^= rpivs[b].lo; r.hi ^= rpivs[b].hi; r.rhs ^= rpivs[b].rhs; }
            else { rpivs[b] = r; has_piv[b] = true; break; }
        }
    }
    uint64_t sol_lo = 0, sol_hi = 0;
    for (int b = 92; b >= 0; --b) {
        if (!has_piv[b]) continue;
        int par = (__builtin_popcountll(rpivs[b].lo & sol_lo) + __builtin_popcountll(rpivs[b].hi & sol_hi)) & 1;
        if (rpivs[b].rhs ^ par) { if (b < 64) sol_lo |= (1ULL << b); else sol_hi |= (1ULL << (b - 64)); }
    }
    uint8_t g[256]{};
    for (int u = 0; u < 256; ++u) {
        int s = 0;
        for (int k = 0; k < 93; ++k) {
            bool on = (k < 64) ? ((sol_lo >> k) & 1ULL) : ((sol_hi >> (k - 64)) & 1ULL);
            if (on && ((u & mons3[k]) == mons3[k])) s ^= 1;
        }
        g[u] = static_cast<uint8_t>(s ^ Qcarry[u]);
    }

    std::vector<int> F_pts; bool inF[256]{}; int fF[256]{};
    for (int u = 0; u < 256; ++u) if (Qtab[u] == 1) { F_pts.push_back(u); inF[u] = true; fF[u] = g[u] ? 3 : -3; }
    int wF0[256]; for (int i = 0; i < 256; ++i) wF0[i] = fF[i];
    fwht256(wF0);

    // 3. POSITIVE CONTROL (t=102, n_8=0): top102(|wF0|) == 4896 uniquely forces real V of QR(17)!
    {
        int aw[256], tmp[256];
        for (int x = 0; x < 256; ++x) aw[x] = tmp[x] = std::abs(wF0[x]);
        std::nth_element(tmp, tmp + 154, tmp + 256);
        int top102 = 0; for (int x = 154; x < 256; ++x) top102 += tmp[x];
        int thr = tmp[154], ge = 0;
        int V[256]{};
        for (int x = 0; x < 256; ++x) if (aw[x] >= thr) { ge++; V[x] = (wF0[x] > 0) ? 1 : -1; }
        fwht256(V);
        int nz0 = 0; bool ok = (top102 == 4896 && ge == 102 && V[0] == 0);
        for (int u = 0; u < 256 && ok; ++u) {
            int a = std::abs(V[u]);
            if (Qtab[u] == 0) { if (a == 0) nz0++; else if (a != 8) ok = false; }
            else { if (a != 12) ok = false; }
        }
        if (!ok || nz0 != 18) throw std::logic_error("POS CTRL t=102 FAILED!");
        std::cout << "[POS CTRL PASS] QR(17) at t=102 (n_8=0): top102=" << top102
                  << ", ge=" << ge << ", recovered genuine V (n_0=" << nz0 << ", n_8=0)!\n";
    }

    // 4. MAIN PROOF (t=100, n_8=4): ALL 53,550 XOR=0 4-subsets S_8 subset F!
    int dtab[256][256];
    for (int u : F_pts) {
        int c = g[u] ? -4 : 4;
        for (int x = 0; x < 256; ++x) dtab[u][x] = __builtin_parity(u & x) ? -c : c;
    }
    int nF = (int)F_pts.size();
    int total = 0, pass_top = 0, unique_forced = 0, real_V = 0;
    for (int i = 0; i < nF; ++i) {
        int u0 = F_pts[i];
        for (int j = i + 1; j < nF; ++j) {
            int u1 = F_pts[j];
            for (int k = j + 1; k < nF; ++k) {
                int u2 = F_pts[k], u3 = u0 ^ u1 ^ u2;
                if (u3 <= u2 || !inF[u3]) continue;
                total++;
                int w[256], aw[256], tmp[256];
                for (int x = 0; x < 256; ++x) {
                    w[x] = wF0[x] + dtab[u0][x] + dtab[u1][x] + dtab[u2][x] + dtab[u3][x];
                    aw[x] = tmp[x] = std::abs(w[x]);
                }
                std::nth_element(tmp, tmp + 156, tmp + 256);
                int top100 = 0; for (int x = 156; x < 256; ++x) top100 += tmp[x];
                if (top100 < 4768) continue;
                pass_top++;
                int thr = tmp[156], ge = 0;
                for (int x = 0; x < 256; ++x) if (aw[x] >= thr) ge++;
                if (top100 != 4768 || ge != 100) throw std::logic_error("Unexpected non-unique tight top100!");
                unique_forced++;
                int V[256]{};
                for (int x = 0; x < 256; ++x) if (aw[x] >= thr) V[x] = (w[x] > 0) ? 1 : -1;
                fwht256(V);
                bool ok = (V[0] == 0);
                for (int u = 0; u < 256 && ok; ++u) {
                    int a = std::abs(V[u]);
                    if (Qtab[u] == 0) { if (a != 0 && a != 8) ok = false; }
                    else { if (a != 4 && a != 12) ok = false; }
                }
                if (ok) real_V++;
            }
        }
    }
    std::cout << "[MAIN PROOF PASS] QR(17) at t=100 (n_0=18, n_8=4, v=0): total_S8=" << total
              << " top100_killed=" << (total - pass_top) << " unique_forced=" << unique_forced
              << " REAL_V=" << real_V << "\n";
    return real_V == 0 ? 0 : 1;
}
