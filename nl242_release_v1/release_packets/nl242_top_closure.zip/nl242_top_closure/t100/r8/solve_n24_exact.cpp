// 100.000% EXACT CODE-BY-CODE CLOSURE OF (t = 100, r = 8, |Z| = 120, n_0 = 24, n_8 = 1, Q(v) = 1)!
// ZERO LP! ZERO HISTOGRAM GROUPING! Every single valid code Z_0 is verified individually via:
//   1. Exact orthogonality bound top100(|w_{F,true}|) >= 4,864 (= 4*(1224 - 8*1)), where S_8 = {v} is uniquely fixed!
//   2. For every survivor of top100 >= 4,864: exact enumeration of ALL 2^{96 - rk} (<= 4,096) RM(3,8) mod-8
//      solutions y_Z on Z \ Z_0 -> check if ANY real V in {-1, 0, +1}^256 with wt(V)=100 exists!
//
// MANDATORY POSITIVE CONTROLS RUN FIRST:
//   PC1: Exact algebraic round-trip test of verify_n24_exact (verifies fF[v] sign flip, sos mod 4 == 0,
//        exact recovery of constructed f_test in the 2^{mZ-rk} y_Z loop, and Parseval = 4864)!
//   PC2: Exact sum-of-v-orbits test on n_0=18 (m=17) H56_w4:
//        sum_{v in 10 v-orbits} orb_sz(v) * valid(v) MUST EQUAL 16,128 (exact match to unfixed-v solver)!
//   PC3: Exact sym=0 vs sym>0 test on n_0=16 (m=15) H56_w2 for ALL 5 nonzero v reps {2, 4, 6, 16, 18}:
//        every |wF| histogram found by sym=0 MUST be found by sym>0!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <mutex>
#include <set>
#include <sstream>
#include <thread>
#include <vector>

inline int pop8(int x) { return __builtin_popcount(static_cast<unsigned>(x)); }
inline int pop32(uint32_t x) { return __builtin_popcount(x); }
inline int q6p(int w) {
    return ((((w >> 0) & 1) & ((w >> 1) & 1)) ^
            (((w >> 2) & 1) & ((w >> 3) & 1)) ^
            (((w >> 4) & 1) & ((w >> 5) & 1)));
}
inline int q6m(int w) {
    return ((((w >> 0) & 1) & ((w >> 1) & 1)) ^ ((w >> 0) & 1) ^ ((w >> 1) & 1) ^
            (((w >> 2) & 1) & ((w >> 3) & 1)) ^ (((w >> 4) & 1) & ((w >> 5) & 1)));
}
inline int Q8_s(int u) {
    return (((u>>0)&1) + ((u>>1)&1) + (((u>>0)&1)&((u>>1)&1)) +
            (((u>>2)&1)&((u>>3)&1)) + (((u>>4)&1)&((u>>5)&1)) + (((u>>6)&1)&((u>>7)&1)));
}
inline int Q8(int u) { return Q8_s(u) & 1; }
inline int Q8_carry(int u) { int s = Q8_s(u); return (s * (s - 1) / 2) & 1; }

void fwht256(int a[256]) {
    for (int st = 1; st < 256; st *= 2)
        for (int i = 0; i < 256; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}

struct Block { int start, len, prefix; };
int mons3[93];
uint8_t Qtab[256], Qcarry[256];
std::vector<int> Z_all, F_all;
uint64_t GF_col[120][3], GF_const[3];
int u_to_zidx[256];

void init_tables() {
    int k = 0;
    for (int m = 0; m < 256; ++m) if (pop8(m) <= 3) mons3[k++] = m;
    std::fill(u_to_zidx, u_to_zidx + 256, -1);
    for (int u = 0; u < 256; ++u) {
        Qtab[u] = (uint8_t)Q8(u);
        Qcarry[u] = (uint8_t)Q8_carry(u);
        if (!Qtab[u]) { u_to_zidx[u] = (int)Z_all.size(); Z_all.push_back(u); }
        else F_all.push_back(u);
    }
    struct Row { uint64_t m[2]{}; uint64_t id[2]{}; };
    Row A[120];
    for (int i = 0; i < 120; ++i) {
        int u = Z_all[i];
        for (int b = 0; b < 93; ++b)
            if ((u & mons3[b]) == mons3[b]) A[i].m[b >> 6] |= (1ULL << (b & 63));
        A[i].id[i >> 6] |= (1ULL << (i & 63));
    }
    int piv_cols[93], rk = 0;
    for (int col = 0; col < 93; ++col) {
        int p = -1;
        for (int i = rk; i < 120; ++i) if ((A[i].m[col >> 6] >> (col & 63)) & 1ULL) { p = i; break; }
        if (p == -1) continue;
        std::swap(A[rk], A[p]);
        for (int i = 0; i < 120; ++i)
            if (i != rk && ((A[i].m[col >> 6] >> (col & 63)) & 1ULL)) {
                A[i].m[0] ^= A[rk].m[0]; A[i].m[1] ^= A[rk].m[1];
                A[i].id[0] ^= A[rk].id[0]; A[i].id[1] ^= A[rk].id[1];
            }
        piv_cols[rk++] = col;
    }
    if (rk != 84) throw std::logic_error("Expected rank 84");
    for (int fi = 0; fi < 136; ++fi) {
        int u = F_all[fi];
        uint64_t row[2]{};
        for (int r = 0; r < 84; ++r) {
            int col = piv_cols[r];
            if ((u & mons3[col]) == mons3[col]) { row[0] ^= A[r].id[0]; row[1] ^= A[r].id[1]; }
        }
        int cbit = Qcarry[u];
        for (int j = 0; j < 120; ++j) if ((row[j >> 6] >> (j & 63)) & 1ULL) {
            GF_col[j][fi >> 6] |= (1ULL << (fi & 63));
            if (1 ^ Qcarry[Z_all[j]]) cbit ^= 1;
        }
        if (cbit) GF_const[fi >> 6] |= (1ULL << (fi & 63));
    }
}

std::atomic<int> g_max_free_bits{0};

// Exact verifier for n_8 = 1 (S_8 = {v}, Q8(v) == 1):
//   - Computes f_{F,true}: +-3 on F\{v}, -+1 on {v} (preserving f(u) mod 4 == 1 - 2*g(u))
//   - Checks top_{t_target}(|w_{F,true}|) >= 4864 (exact orthogonality bound!)
//   - If >= 4864, solves the 93 RM(3,8) mod-8 equations on Z \ Z_0 and tests ALL 2^{mZ - rk} y_Z candidates!
//   - Optional test_target_yZ: if non-null, asserts that the exact y_Z vector is visited during enumeration!
// Returns: 0 (killed by top100<4864), 1 (killed by exact y_Z enumeration), 2 (REAL V FOUND!)
int verify_n24_exact(const std::vector<int>& us, int v, int t_target,
                     const uint64_t* expect_yZ = nullptr, bool* saw_expect = nullptr) {
    if (Qtab[v] != 1) throw std::logic_error("verify_n24_exact requires Q8(v)==1");
    uint64_t gF[3] = {GF_const[0], GF_const[1], GF_const[2]};
    bool inZ0[256]{}; inZ0[0] = true;
    int z0_0 = u_to_zidx[0];
    gF[0] ^= GF_col[z0_0][0]; gF[1] ^= GF_col[z0_0][1]; gF[2] ^= GF_col[z0_0][2];
    for (int u : us) {
        inZ0[u] = true;
        int zi = u_to_zidx[u];
        gF[0] ^= GF_col[zi][0]; gF[1] ^= GF_col[zi][1]; gF[2] ^= GF_col[zi][2];
    }
    int fF[256]{};
    for (int fi = 0; fi < 136; ++fi)
        fF[F_all[fi]] = ((gF[fi >> 6] >> (fi & 63)) & 1ULL) ? 3 : -3;
    // Flip v in S_8: +3 -> -1, -3 -> +1 (preserving mod 4!)
    fF[v] = (fF[v] == 3) ? -1 : 1;

    int wF[256]; for (int i = 0; i < 256; ++i) wF[i] = fF[i];
    fwht256(wF);

    if (!expect_yZ) {
        int aw[256]; for (int x = 0; x < 256; ++x) aw[x] = std::abs(wF[x]);
        std::nth_element(aw, aw + t_target, aw + 256, std::greater<int>());
        int top_sum = 0; for (int i = 0; i < t_target; ++i) top_sum += aw[i];
        if (top_sum < 4864) return 0;
    }

    std::vector<int> Z_nz; Z_nz.reserve(104);
    int f_base[256]; for (int i = 0; i < 256; ++i) f_base[i] = fF[i];
    for (int zi = 0; zi < 120; ++zi) {
        int u = Z_all[zi];
        if (!inZ0[u]) { Z_nz.push_back(u); f_base[u] = 2; }
    }
    int mZ = (int)Z_nz.size();
    int sos[256]; for (int i = 0; i < 256; ++i) sos[i] = f_base[i];
    for (int bit = 0; bit < 8; ++bit)
        for (int m = 0; m < 256; ++m)
            if ((m & (1 << bit)) == 0) sos[m] += sos[m | (1 << bit)];
    struct Eq { uint64_t lo = 0, hi = 0; int rhs = 0; };
    Eq pivs[104]; bool has_piv[104]{};
    auto setb = [](Eq& e, int c) { if (c < 64) e.lo |= (1ULL << c); else e.hi |= (1ULL << (c - 64)); };
    auto firstb = [](const Eq& e) -> int {
        if (e.lo) return __builtin_ctzll(e.lo);
        if (e.hi) return 64 + __builtin_ctzll(e.hi);
        return -1;
    };
    for (int k = 0; k < 93; ++k) {
        int m = mons3[k];
        if (sos[m] & 3) return 1; // Impossible mod 4
        Eq e; e.rhs = (sos[m] >> 2) & 1;
        for (int c = 0; c < mZ; ++c) if ((Z_nz[c] & m) == m) setb(e, c);
        while (true) {
            int b = firstb(e);
            if (b == -1) { if (e.rhs != 0) return 1; break; }
            if (has_piv[b]) { e.lo ^= pivs[b].lo; e.hi ^= pivs[b].hi; e.rhs ^= pivs[b].rhs; }
            else { pivs[b] = e; has_piv[b] = true; break; }
        }
    }
    for (int b = mZ - 1; b >= 0; --b) {
        if (!has_piv[b]) continue;
        for (int p = 0; p < b; ++p) {
            if (!has_piv[p]) continue;
            bool bit_on = (b < 64) ? ((pivs[p].lo >> b) & 1ULL) : ((pivs[p].hi >> (b - 64)) & 1ULL);
            if (bit_on) { pivs[p].lo ^= pivs[b].lo; pivs[p].hi ^= pivs[b].hi; pivs[p].rhs ^= pivs[b].rhs; }
        }
    }
    uint64_t base_lo = 0, base_hi = 0;
    std::vector<std::pair<uint64_t, uint64_t>> dirs;
    for (int c = 0; c < mZ; ++c) {
        if (has_piv[c]) {
            if (pivs[c].rhs) { if (c < 64) base_lo |= (1ULL << c); else base_hi |= (1ULL << (c - 64)); }
        } else {
            uint64_t dlo = 0, dhi = 0;
            if (c < 64) dlo |= (1ULL << c); else dhi |= (1ULL << (c - 64));
            for (int p = 0; p < mZ; ++p) if (has_piv[p]) {
                bool on = (c < 64) ? ((pivs[p].lo >> c) & 1ULL) : ((pivs[p].hi >> (c - 64)) & 1ULL);
                if (on) { if (p < 64) dlo |= (1ULL << p); else dhi |= (1ULL << (p - 64)); }
            }
            dirs.push_back({dlo, dhi});
        }
    }
    int nd = (int)dirs.size();
    int prev_max = g_max_free_bits.load();
    while (nd > prev_max && !g_max_free_bits.compare_exchange_weak(prev_max, nd)) {}
    if (nd > 20) throw std::logic_error("Too many free bits in y_Z: " + std::to_string(nd));

    int dc_F = 0; for (int fi = 0; fi < 136; ++fi) dc_F += fF[F_all[fi]];
    uint64_t cur_lo = base_lo, cur_hi = base_hi;
    uint32_t total = 1u << nd;
    for (uint32_t s = 0; s < total; ++s) {
        if (s) { int b = __builtin_ctz(s); cur_lo ^= dirs[b].first; cur_hi ^= dirs[b].second; }
        if (expect_yZ && cur_lo == expect_yZ[0] && cur_hi == expect_yZ[1]) {
            if (saw_expect) *saw_expect = true;
            return 2;
        }
        int pop_y = __builtin_popcountll(cur_lo) + __builtin_popcountll(cur_hi);
        int dc = dc_F + 2 * mZ - 4 * pop_y;
        if (dc != 0 && dc != 64 && dc != -64) continue;
        int f_try[256]; for (int i = 0; i < 256; ++i) f_try[i] = fF[i];
        for (int c = 0; c < mZ; ++c) {
            bool on = (c < 64) ? ((cur_lo >> c) & 1ULL) : ((cur_hi >> (c - 64)) & 1ULL);
            f_try[Z_nz[c]] = on ? -2 : 2;
        }
        fwht256(f_try);
        bool ok = true; int nz = 0;
        for (int x = 0; x < 256; ++x) {
            int val = f_try[x];
            if (val != 0 && val != 64 && val != -64) { ok = false; break; }
            if (val != 0) nz++;
        }
        if (ok && nz == t_target) return 2;
    }
    return 1;
}

std::string compute_wF_hist(const std::vector<int>& us, int v) {
    uint64_t gF[3] = {GF_const[0], GF_const[1], GF_const[2]};
    int z0_0 = u_to_zidx[0];
    gF[0] ^= GF_col[z0_0][0]; gF[1] ^= GF_col[z0_0][1]; gF[2] ^= GF_col[z0_0][2];
    for (int u : us) {
        int zi = u_to_zidx[u];
        gF[0] ^= GF_col[zi][0]; gF[1] ^= GF_col[zi][1]; gF[2] ^= GF_col[zi][2];
    }
    int fF[256]{};
    for (int fi = 0; fi < 136; ++fi)
        fF[F_all[fi]] = ((gF[fi >> 6] >> (fi & 63)) & 1ULL) ? 3 : -3;
    fwht256(fF);
    std::map<int, int> h;
    for (int x = 0; x < 256; ++x) h[std::abs(fF[x])]++;
    std::string hs = std::to_string(Qtab[v]) + "|";
    for (auto [val, c] : h) hs += std::to_string(val) + ":" + std::to_string(c) + " ";
    return hs;
}

struct Stats { long long valid = 0, top_kill = 0, yZ_kill = 0, real_V = 0; std::set<std::string> hists; };

// Fixed-v TURBO H_56 DFS (with r=5 GF(2) solver + reach_dots + rem_lo/rem_hi + exact sym modes for H56_w2)!
// sym_mode:
//   0 = none
//   1 = O^+(4,2) x Z_2 (for H56_w2, v=2: 144x)
//   2 = O^+(4,2) only  (for H56_w2, v=4 or v=6: 72x)
//   3 = Stab_{O^+(4,2)}(v4=e_0) x Z_2 (for H56_w2, v=16 or v=18: 16x)
Stats run_h56_fixed_v(int m, const std::vector<int>& u_tail, int v, int min_d_56, int min_d_64,
                      int sym_mode, bool do_n24_verify, int t_target, bool collect_hists, int nthreads = 8) {
    int K = (int)u_tail.size();
    int H = m - K;
    int v0 = v & 1;
    if ((K & 3) != ((1 ^ v0) ? 2 : 0)) return {};
    int bmap[6] = {2, 3, 4, 5, 6, 7};
    if (sym_mode > 0) { bmap[0]=4; bmap[1]=5; bmap[2]=6; bmap[3]=7; bmap[4]=2; bmap[5]=3; }

    uint32_t tail_W[6]{}, tail_r1 = 0;
    for (int j = 0; j < K; ++j) {
        if ((u_tail[j] >> 1) & 1) tail_r1 |= (1u << j);
        for (int r = 0; r < 6; ++r)
            if ((u_tail[j] >> bmap[r]) & 1) tail_W[r] |= (1u << j);
    }
    if ((pop32(tail_r1) & 1) == 0) return {};

    int wt_mod4[6], req_dots[6], r1_dot_req[6], tail_wt[6];
    for (int r = 0; r < 6; ++r) {
        tail_wt[r] = pop32(tail_W[r]);
        int vb = (v >> bmap[r]) & 1;
        wt_mod4[r] = ((2 * vb - tail_wt[r]) % 4 + 4) % 4;
        r1_dot_req[r] = pop32(tail_r1 & tail_W[r]) & 1;
        int rd = 0;
        for (int p = 0; p < r; ++p) {
            int full_dot = ((r == 1 && p == 0) || (r == 3 && p == 2) || (r == 5 && p == 4)) ? 1 : 0;
            if (full_dot ^ (pop32(tail_W[r] & tail_W[p]) & 1)) rd |= (1 << p);
        }
        req_dots[r] = rd;
    }
    int v1 = (v >> 1) & 1;
    int r1_wt_mod4 = ((2 * (1 ^ v1) - pop32(tail_r1)) % 4 + 4) % 4;

    int qy6[64], yv6[64];
    for (int y6 = 0; y6 < 64; ++y6) {
        int y8 = 0;
        for (int b = 0; b < 6; ++b) if ((y6 >> b) & 1) y8 |= (1 << bmap[b]);
        qy6[y6] = Qtab[y8];
        yv6[y6] = pop8(y8 & v) & 1;
    }

    int min_head_wt[6], max_head_wt[6];
    for (int r = 0; r < 6; ++r) {
        min_head_wt[r] = std::max(min_d_64 - tail_wt[r], min_d_56 - (K - tail_wt[r]));
        max_head_wt[r] = std::min((m + 1 - min_d_56) - tail_wt[r], (m + 1 - min_d_64) - (K - tail_wt[r]));
    }

    static const int sing4[9] = {1, 2, 4, 5, 6, 8, 9, 10, 15};
    static const int stab_e0[8][3] = {
        {2, 4, 8}, {2, 8, 4}, {6, 4, 9}, {6, 9, 4},
        {10, 5, 8}, {10, 8, 5}, {15, 5, 9}, {15, 9, 5}
    };
    static const int dual_stab_v4[8][3] = {
        {1, 4, 8}, {1, 8, 4}, {9, 6, 8}, {5, 10, 4},
        {5, 4, 10}, {9, 8, 6}, {15, 6, 10}, {15, 10, 6}
    };
    uint32_t tail_mask = ((1u << K) - 1u) << H;

    struct T2 { uint32_t W0, W1, span[4]; std::vector<Block> blocks; };
    std::vector<T2> tasks;
    {
        uint32_t cur_W[2]{}, span[4]{};
        auto gen2 = [&](auto& self, int r, const std::vector<Block>& blocks) -> void {
            if (r == 2) { tasks.push_back({cur_W[0], cur_W[1], {span[0], span[1], span[2], span[3]}, blocks}); return; }
            int nb = (int)blocks.size();
            int max_blk = 1 << (5 - r);
            int ks[28], k_lo[28], k_hi[28];
            for (int bi = 0; bi < nb; ++bi) {
                int len = blocks[bi].len;
                int mz = (blocks[bi].prefix == 0) ? (max_blk - 1) : max_blk;
                k_lo[bi] = std::max(0, len - mz);
                k_hi[bi] = std::min(len, max_blk);
                if (k_lo[bi] > k_hi[bi]) return;
            }
            int prev_sz = 1 << r;
            auto rec = [&](auto& rself, int bi, int used_wt, int cur_dots, uint32_t mask) -> void {
                if (bi == nb) {
                    if ((used_wt & 3) != wt_mod4[r] || cur_dots != req_dots[r]) return;
                    if (used_wt < min_head_wt[r] || used_wt > max_head_wt[r]) return;
                    if ((sym_mode == 1 || sym_mode == 2) && r == 1 && used_wt < pop32(cur_W[0])) return;
                    uint32_t full_row = mask | (tail_W[r] << H);
                    for (int i = 0; i < prev_sz; ++i) {
                        int y6 = i | (1 << r);
                        uint32_t cw = full_row ^ span[i];
                        int w = pop32(cw);
                        int qy = qy6[y6], yv = yv6[y6];
                        if ((w & 3) != ((qy ^ yv) ? 2 : 0)) return;
                        int mind = qy ? min_d_56 : min_d_64;
                        int mind_c = qy ? min_d_64 : min_d_56;
                        if (w < mind || (m + 1 - w) < mind_c) return;
                        int w1 = pop32(cw ^ tail_mask);
                        int qy1 = 1 ^ qy, yv1 = yv ^ v0;
                        if ((w1 & 3) != ((qy1 ^ yv1) ? 2 : 0)) return;
                        int mind1 = qy1 ? min_d_56 : min_d_64;
                        int mind1_c = qy1 ? min_d_64 : min_d_56;
                        if (w1 < mind1 || (m + 1 - w1) < mind1_c) return;
                        span[prev_sz + i] = cw;
                    }
                    cur_W[r] = mask;
                    std::vector<Block> nblocks;
                    for (int j = 0; j < nb; ++j) {
                        int s = blocks[j].start, len = blocks[j].len, pref = blocks[j].prefix, k = ks[j];
                        if (len - k > 0) nblocks.push_back({s, len - k, pref});
                        if (k > 0) nblocks.push_back({s + len - k, k, pref | (1 << r)});
                    }
                    self(self, r + 1, nblocks);
                    return;
                }
                int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                for (int k = k_lo[bi]; k <= k_hi[bi]; ++k) {
                    ks[bi] = k;
                    int nd = (k & 1) ? (cur_dots ^ pref) : cur_dots;
                    uint32_t bm = k ? (((1u << k) - 1u) << (s + len - k)) : 0u;
                    rself(rself, bi + 1, used_wt + k, nd, mask | bm);
                }
            };
            rec(rec, 0, 0, 0, 0);
        };
        gen2(gen2, 0, {{0, H, 0}});
    }

    std::atomic<size_t> next_idx{0};
    std::mutex mtx;
    Stats res;

    auto worker = [&]() {
        Stats loc;
        while (true) {
            size_t ti = next_idx.fetch_add(1);
            if (ti >= tasks.size()) break;
            const auto& tk = tasks[ti];
            uint32_t cur_W[6]{tk.W0, tk.W1, 0, 0, 0, 0};
            uint32_t span_W[64]{};
            for (int i = 0; i < 4; ++i) span_W[i] = tk.span[i];

            auto check_leaf = [&](uint32_t mask5) {
                cur_W[5] = mask5;
                if ((sym_mode == 1 || sym_mode == 3) && pop32(mask5) < pop32(cur_W[4])) return;
                uint32_t full_row = mask5 | (tail_W[5] << H);
                for (int i = 0; i < 32; ++i) {
                    int y6 = i | 32;
                    uint32_t cw = full_row ^ span_W[i];
                    int w = pop32(cw);
                    int qy = qy6[y6], yv = yv6[y6];
                    if ((w & 3) != ((qy ^ yv) ? 2 : 0)) return;
                    int mind = qy ? min_d_56 : min_d_64;
                    int mind_c = qy ? min_d_64 : min_d_56;
                    if (w < mind || (m + 1 - w) < mind_c) return;
                    int w1 = pop32(cw ^ tail_mask);
                    int qy1 = 1 ^ qy, yv1 = yv ^ v0;
                    if ((w1 & 3) != ((qy1 ^ yv1) ? 2 : 0)) return;
                    int mind1 = qy1 ? min_d_56 : min_d_64;
                    int mind1_c = qy1 ? min_d_64 : min_d_56;
                    if (w1 < mind1 || (m + 1 - w1) < mind1_c) return;
                }
                uint32_t head_r1 = 0;
                int ws[28]; uint64_t seen = 0;
                for (int j = 0; j < H; ++j) {
                    int w = 0;
                    if (sym_mode > 0) {
                        w = (((cur_W[4]>>j)&1u)<<0) | (((cur_W[5]>>j)&1u)<<1) |
                            (((cur_W[0]>>j)&1u)<<2) | (((cur_W[1]>>j)&1u)<<3) |
                            (((cur_W[2]>>j)&1u)<<4) | (((cur_W[3]>>j)&1u)<<5);
                    } else {
                        for (int b = 0; b < 6; ++b) if ((cur_W[b] >> j) & 1u) w |= (1 << b);
                    }
                    if (w == 0 || ((seen >> w) & 1ULL)) return;
                    seen |= (1ULL << w);
                    ws[j] = w;
                    if (q6p(w)) head_r1 |= (1u << j);
                }
                if ((pop32(head_r1) & 3) != r1_wt_mod4) return;
                for (int b = 0; b < 6; ++b)
                    if ((pop32(head_r1 & cur_W[b]) & 1) != r1_dot_req[b]) return;

                uint32_t U8[8]{};
                U8[0] = tail_mask;
                U8[1] = head_r1 | (tail_r1 << H);
                for (int b = 0; b < 6; ++b) U8[bmap[b]] = cur_W[b] | (tail_W[b] << H);

                uint32_t cw = 0;
                for (int step = 1; step < 256; ++step) {
                    int y = step ^ (step >> 1);
                    cw ^= U8[__builtin_ctz(step)];
                    int w = pop32(cw);
                    int qy = Qtab[y];
                    int tgt = (qy ^ (pop8(y & v) & 1)) ? 2 : 0;
                    if ((w & 3) != tgt) return;
                    int mind = qy ? min_d_56 : min_d_64;
                    int mind_c = qy ? min_d_64 : min_d_56;
                    if (w < mind || (m + 1 - w) < mind_c) return;
                }
                std::vector<int> us(m);
                for (int j = 0; j < H; ++j) us[j] = (((head_r1 >> j) & 1u) << 1) | (ws[j] << 2);
                for (int j = 0; j < K; ++j) us[H + j] = u_tail[j];
                std::sort(us.begin(), us.end());
                loc.valid++;
                if (collect_hists) loc.hists.insert(compute_wF_hist(us, v));
                if (do_n24_verify) {
                    int st = verify_n24_exact(us, v, t_target);
                    if (st == 0) loc.top_kill++;
                    else if (st == 1) loc.yZ_kill++;
                    else { loc.real_V++; std::cerr << "!!! REAL V FOUND (n24, v=" << v << ") !!!\n"; }
                }
            };

            auto dfs = [&](auto& self, int r, const std::vector<Block>& blocks) -> void {
                int nb = (int)blocks.size();
                if (r == 5) {
                    uint32_t forced_mask = 0;
                    int forced_wt = 0, forced_dots = 0;
                    int free_pos[28], free_pref[28], nf = 0;
                    for (int bi = 0; bi < nb; ++bi) {
                        int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                        if (len > 2 || (len == 2 && pref == 0)) return;
                        if (len == 2 || pref == 0) {
                            forced_mask |= (1u << (s + len - 1));
                            forced_wt++;
                            forced_dots ^= pref;
                        } else {
                            free_pos[nf] = s; free_pref[nf] = pref; nf++;
                        }
                    }
                    int need_dots = req_dots[5] ^ forced_dots;
                    int need_par = (wt_mod4[5] ^ forced_wt) & 1;
                    uint32_t eq[6]{}; int erhs[6]{};
                    for (int b = 0; b < 5; ++b) {
                        erhs[b] = (need_dots >> b) & 1;
                        for (int i = 0; i < nf; ++i) if ((free_pref[i] >> b) & 1) eq[b] |= (1u << i);
                    }
                    erhs[5] = need_par;
                    eq[5] = (nf == 32) ? ~0u : ((1u << nf) - 1u);

                    uint32_t pm[28]{}; int pr[28]{}; bool hp[28]{};
                    for (int e = 0; e < 6; ++e) {
                        uint32_t m_e = eq[e]; int r_e = erhs[e];
                        for (int c = 0; c < nf; ++c) if (((m_e >> c) & 1u) && hp[c]) { m_e ^= pm[c]; r_e ^= pr[c]; }
                        if (m_e == 0) { if (r_e != 0) return; }
                        else {
                            int p = __builtin_ctz(m_e);
                            for (int c = 0; c < nf; ++c) if (hp[c] && ((pm[c] >> p) & 1u)) { pm[c] ^= m_e; pr[c] ^= r_e; }
                            pm[p] = m_e; pr[p] = r_e; hp[p] = true;
                        }
                    }
                    uint32_t base_x = 0, d_x[28]; int nd = 0;
                    for (int c = 0; c < nf; ++c) {
                        if (hp[c]) { if (pr[c]) base_x |= (1u << c); }
                        else {
                            uint32_t d = 1u << c;
                            for (int p = 0; p < nf; ++p) if (hp[p] && ((pm[p] >> c) & 1u)) d |= (1u << p);
                            d_x[nd++] = d;
                        }
                    }
                    auto to_Hmask = [&](uint32_t xv) -> uint32_t {
                        uint32_t hm = 0;
                        while (xv) { int c = __builtin_ctz(xv); hm |= (1u << free_pos[c]); xv &= xv - 1; }
                        return hm;
                    };
                    uint32_t cur_hm = forced_mask | to_Hmask(base_x);
                    uint32_t d_hm[28];
                    for (int i = 0; i < nd; ++i) d_hm[i] = to_Hmask(d_x[i]);
                    int lo_w = min_head_wt[5], hi_w = max_head_wt[5], wm4 = wt_mod4[5];
                    uint32_t tot = 1u << nd;
                    for (uint32_t s = 0; s < tot; ++s) {
                        if (s) cur_hm ^= d_hm[__builtin_ctz(s)];
                        int w = pop32(cur_hm);
                        if ((w & 3) != wm4 || w < lo_w || w > hi_w) continue;
                        check_leaf(cur_hm);
                    }
                    return;
                }

                int max_blk = 1 << (5 - r);
                int ks[28], k_lo[28], k_hi[28], rem_lo[29], rem_hi[29], reach_dots[29], fixed_rem[29];
                for (int bi = 0; bi < nb; ++bi) {
                    int len = blocks[bi].len;
                    int mz = (blocks[bi].prefix == 0) ? (max_blk - 1) : max_blk;
                    k_lo[bi] = std::max(0, len - mz);
                    k_hi[bi] = std::min(len, max_blk);
                    if (k_lo[bi] > k_hi[bi]) return;
                }
                rem_lo[nb] = 0; rem_hi[nb] = 0; reach_dots[nb] = 0; fixed_rem[nb] = 0;
                for (int bi = nb - 1; bi >= 0; --bi) {
                    rem_lo[bi] = rem_lo[bi + 1] + k_lo[bi];
                    rem_hi[bi] = rem_hi[bi + 1] + k_hi[bi];
                    reach_dots[bi] = reach_dots[bi + 1] | ((k_lo[bi] < k_hi[bi]) ? blocks[bi].prefix : 0);
                    fixed_rem[bi] = fixed_rem[bi + 1] ^ ((k_lo[bi] == k_hi[bi] && (k_lo[bi] & 1)) ? blocks[bi].prefix : 0);
                }
                int lo_w = min_head_wt[r], hi_w = max_head_wt[r];
                int prev_sz = 1 << r;
                auto rec = [&](auto& rself, int bi, int used_wt, int cur_dots, uint32_t mask) -> void {
                    if (used_wt + rem_hi[bi] < lo_w || used_wt + rem_lo[bi] > hi_w) return;
                    if (((cur_dots ^ fixed_rem[bi] ^ req_dots[r]) & ~reach_dots[bi]) != 0) return;
                    if (bi == nb) {
                        if ((used_wt & 3) != wt_mod4[r] || cur_dots != req_dots[r]) return;
                        if (sym_mode == 1 || sym_mode == 2) {
                            if (r == 2) {
                                int w0 = pop32(cur_W[0]), w1 = pop32(cur_W[1]), w2 = used_wt;
                                int w02 = pop32(cur_W[0] ^ mask), w12 = pop32(cur_W[1] ^ mask);
                                if (w2 < w0 || w02 < w0 || w12 < w0 || w12 < w1) return;
                            } else if (r == 3) {
                                int wts[16];
                                for (int i = 0; i < 8; ++i) { wts[i] = pop32(span_W[i]); wts[8 + i] = pop32(span_W[i] ^ mask); }
                                int w0 = wts[1];
                                for (int s : sing4) if (wts[s] < w0) return;
                                std::array<int, 3> cur_t = {wts[2], wts[4], wts[8]};
                                for (int si = 1; si < 8; ++si) {
                                    std::array<int, 3> tt = {wts[stab_e0[si][0]], wts[stab_e0[si][1]], wts[stab_e0[si][2]]};
                                    if (tt < cur_t) return;
                                }
                            }
                        } else if (sym_mode == 3) {
                            if (r == 2) {
                                if (pop32(cur_W[0] ^ mask) < pop32(cur_W[0])) return;
                            } else if (r == 3) {
                                int wts[16];
                                for (int i = 0; i < 8; ++i) { wts[i] = pop32(span_W[i]); wts[8 + i] = pop32(span_W[i] ^ mask); }
                                std::array<int, 3> cur_t = {wts[1], wts[4], wts[8]};
                                for (int si = 1; si < 8; ++si) {
                                    std::array<int, 3> tt = {wts[dual_stab_v4[si][0]], wts[dual_stab_v4[si][1]], wts[dual_stab_v4[si][2]]};
                                    if (tt < cur_t) return;
                                }
                            }
                        }
                        uint32_t full_row = mask | (tail_W[r] << H);
                        for (int i = 0; i < prev_sz; ++i) {
                            int y6 = i | (1 << r);
                            uint32_t cw = full_row ^ span_W[i];
                            int w = pop32(cw);
                            int qy = qy6[y6], yv = yv6[y6];
                            if ((w & 3) != ((qy ^ yv) ? 2 : 0)) return;
                            int mind = qy ? min_d_56 : min_d_64;
                            int mind_c = qy ? min_d_64 : min_d_56;
                            if (w < mind || (m + 1 - w) < mind_c) return;
                            int w1 = pop32(cw ^ tail_mask);
                            int qy1 = 1 ^ qy, yv1 = yv ^ v0;
                            if ((w1 & 3) != ((qy1 ^ yv1) ? 2 : 0)) return;
                            int mind1 = qy1 ? min_d_56 : min_d_64;
                            int mind1_c = qy1 ? min_d_64 : min_d_56;
                            if (w1 < mind1 || (m + 1 - w1) < mind1_c) return;
                            span_W[prev_sz + i] = cw;
                        }
                        cur_W[r] = mask;
                        std::vector<Block> nblocks;
                        for (int j = 0; j < nb; ++j) {
                            int s = blocks[j].start, len = blocks[j].len, pref = blocks[j].prefix, k = ks[j];
                            if (len - k > 0) nblocks.push_back({s, len - k, pref});
                            if (k > 0) nblocks.push_back({s + len - k, k, pref | (1 << r)});
                        }
                        self(self, r + 1, nblocks);
                        return;
                    }
                    int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                    for (int k = k_lo[bi]; k <= k_hi[bi]; ++k) {
                        ks[bi] = k;
                        int nd = (k & 1) ? (cur_dots ^ pref) : cur_dots;
                        uint32_t bm = k ? (((1u << k) - 1u) << (s + len - k)) : 0u;
                        rself(rself, bi + 1, used_wt + k, nd, mask | bm);
                    }
                };
                rec(rec, 0, 0, 0, 0);
            };
            dfs(dfs, 2, tk.blocks);
        }
        std::lock_guard<std::mutex> lk(mtx);
        res.valid += loc.valid; res.top_kill += loc.top_kill;
        res.yZ_kill += loc.yZ_kill; res.real_V += loc.real_V;
        for (const auto& h : loc.hists) res.hists.insert(h);
    };
    std::vector<std::thread> ths;
    for (int t = 0; t < nthreads; ++t) ths.emplace_back(worker);
    for (auto& th : ths) th.join();
    return res;
}

// General H_64 (u_7 = 1) DFS for Q(v) == 1 (unfixed v: checks all v at leaf, fast for H <= 17!)
Stats run_h64_q1(int m, const std::vector<int>& u_tail, int min_d_56, int min_d_64,
                 int t_target, int nthreads = 8) {
    int K = (int)u_tail.size();
    int H = m - K;
    uint32_t tail_W[6]{}, tail_r6 = 0;
    for (int j = 0; j < K; ++j) {
        if ((u_tail[j] >> 6) & 1) tail_r6 |= (1u << j);
        for (int r = 0; r < 6; ++r)
            if ((u_tail[j] >> r) & 1) tail_W[r] |= (1u << j);
    }
    if ((pop32(tail_r6) & 1) == 0) return {};
    int wt_mod2[6], req_dots[6], r6_dot_req[6], tail_wt[6];
    for (int r = 0; r < 6; ++r) {
        tail_wt[r] = pop32(tail_W[r]);
        wt_mod2[r] = tail_wt[r] & 1;
        r6_dot_req[r] = pop32(tail_r6 & tail_W[r]) & 1;
        int rd = 0;
        for (int p = 0; p < r; ++p) {
            int full_dot = ((r == 1 && p == 0) || (r == 3 && p == 2) || (r == 5 && p == 4)) ? 1 : 0;
            if (full_dot ^ (pop32(tail_W[r] & tail_W[p]) & 1)) rd |= (1 << p);
        }
        req_dots[r] = rd;
    }
    int r6_wt_mod2 = pop32(tail_r6) & 1;
    int min_head_wt[6], max_head_wt[6];
    for (int r = 0; r < 6; ++r) {
        int q_e = (r < 2) ? 1 : 0;
        int mind = q_e ? min_d_56 : min_d_64;
        int mind_c = q_e ? min_d_64 : min_d_56;
        min_head_wt[r] = std::max(mind - tail_wt[r], mind - (K - tail_wt[r]));
        max_head_wt[r] = std::min((m + 1 - mind_c) - tail_wt[r], (m + 1 - mind_c) - (K - tail_wt[r]));
    }
    uint32_t tail_mask = ((1u << K) - 1u) << H;
    int v7 = (K >> 1) & 1; // Q*(e_7)=0 => K == 2*v7 mod 4!

    struct T2 { uint32_t W0, W1, span[4]; std::vector<Block> blocks; };
    std::vector<T2> tasks;
    {
        uint32_t cur_W[2]{}, span[4]{};
        auto gen2 = [&](auto& self, int r, const std::vector<Block>& blocks) -> void {
            if (r == 2) { tasks.push_back({cur_W[0], cur_W[1], {span[0], span[1], span[2], span[3]}, blocks}); return; }
            int nb = (int)blocks.size();
            int ks[28], k_lo[28], k_hi[28];
            int max_blk = 1 << (6 - r);
            for (int bi = 0; bi < nb; ++bi) {
                int len = blocks[bi].len;
                int lim0 = max_blk, lim1 = max_blk;
                if (r == 1) {
                    if (blocks[bi].prefix == 0) { lim0 = 19; lim1 = 12; }
                    else { lim0 = 12; lim1 = 12; }
                }
                k_lo[bi] = std::max(0, len - lim0);
                k_hi[bi] = std::min(len, lim1);
                if (k_lo[bi] > k_hi[bi]) return;
            }
            int prev_sz = 1 << r;
            auto rec = [&](auto& rself, int bi, int used_wt, int cur_dots, uint32_t mask) -> void {
                if (bi == nb) {
                    if ((used_wt & 1) != wt_mod2[r] || cur_dots != req_dots[r]) return;
                    if (used_wt < min_head_wt[r] || used_wt > max_head_wt[r]) return;
                    uint32_t full_row = mask | (tail_W[r] << H);
                    for (int i = 0; i < prev_sz; ++i) {
                        int y6 = i | (1 << r);
                        uint32_t cw = full_row ^ span[i];
                        int w = pop32(cw);
                        int qy = q6m(y6);
                        int mind = qy ? min_d_56 : min_d_64;
                        int mind_c = qy ? min_d_64 : min_d_56;
                        if (w < mind || (m + 1 - w) < mind_c) return;
                        int w1 = pop32(cw ^ tail_mask);
                        if (w1 < mind || (m + 1 - w1) < mind_c) return;
                        if (((w ^ w1) & 2) != (v7 << 1)) return;
                        span[prev_sz + i] = cw;
                    }
                    cur_W[r] = mask;
                    std::vector<Block> nblocks;
                    for (int j = 0; j < nb; ++j) {
                        int s = blocks[j].start, len = blocks[j].len, pref = blocks[j].prefix, k = ks[j];
                        if (len - k > 0) nblocks.push_back({s, len - k, pref});
                        if (k > 0) nblocks.push_back({s + len - k, k, pref | (1 << r)});
                    }
                    self(self, r + 1, nblocks);
                    return;
                }
                int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                for (int k = k_lo[bi]; k <= k_hi[bi]; ++k) {
                    ks[bi] = k;
                    int nd = (k & 1) ? (cur_dots ^ pref) : cur_dots;
                    uint32_t bm = k ? (((1u << k) - 1u) << (s + len - k)) : 0u;
                    rself(rself, bi + 1, used_wt + k, nd, mask | bm);
                }
            };
            rec(rec, 0, 0, 0, 0);
        };
        gen2(gen2, 0, {{0, H, 0}});
    }

    std::atomic<size_t> next_idx{0};
    std::mutex mtx;
    Stats res;

    auto worker = [&]() {
        Stats loc;
        while (true) {
            size_t ti = next_idx.fetch_add(1);
            if (ti >= tasks.size()) break;
            const auto& tk = tasks[ti];
            uint32_t cur_W[6]{tk.W0, tk.W1, 0, 0, 0, 0};
            uint32_t span_W[64]{};
            for (int i = 0; i < 4; ++i) span_W[i] = tk.span[i];

            auto dfs = [&](auto& self, int r, const std::vector<Block>& blocks) -> void {
                if (r == 6) {
                    // Check v0..v5 deduced from span_W[1<<b] AND verify ALL 64 in span_W!
                    int v_lo = 0;
                    for (int b = 0; b < 6; ++b) {
                        int w = pop32(span_W[1 << b]);
                        int q_e = (b < 2) ? 1 : 0;
                        if (((w >> 1) & 1) ^ q_e) v_lo |= (1 << b);
                    }
                    int ws[28], cnt[64]{}, first_idx[64];
                    std::fill(first_idx, first_idx + 64, -1);
                    std::vector<std::pair<int,int>> dup_pairs;
                    int zero_idx = -1;
                    for (int j = 0; j < H; ++j) {
                        int w = 0;
                        for (int b = 0; b < 6; ++b) if ((cur_W[b] >> j) & 1u) w |= (1 << b);
                        if (q6m(w) != 0) return;
                        ws[j] = w; cnt[w]++;
                        if (w == 0) { if (cnt[0] > 1) return; zero_idx = j; }
                        else {
                            if (cnt[w] > 2) return;
                            if (cnt[w] == 1) first_idx[w] = j;
                            else dup_pairs.push_back({first_idx[w], j});
                        }
                    }
                    std::vector<std::pair<uint32_t, int>> eqs;
                    eqs.push_back({(1u << H) - 1u, r6_wt_mod2});
                    for (int b = 0; b < 6; ++b) eqs.push_back({cur_W[b], r6_dot_req[b]});
                    if (zero_idx != -1) eqs.push_back({1u << zero_idx, 1});
                    for (auto [i, j] : dup_pairs) eqs.push_back({(1u << i) | (1u << j), 1});

                    uint32_t pm[28]{}; int pr[28]{}; bool hp[28]{};
                    for (auto [mm, rhs] : eqs) {
                        for (int c = 0; c < H; ++c) if (((mm >> c) & 1u) && hp[c]) { mm ^= pm[c]; rhs ^= pr[c]; }
                        if (mm == 0) { if (rhs != 0) return; }
                        else {
                            int p = __builtin_ctz(mm);
                            for (int c = 0; c < H; ++c) if (hp[c] && ((pm[c] >> p) & 1u)) { pm[c] ^= mm; pr[c] ^= rhs; }
                            pm[p] = mm; pr[p] = rhs; hp[p] = true;
                        }
                    }
                    uint32_t base_b = 0; std::vector<uint32_t> dirs;
                    for (int c = 0; c < H; ++c) {
                        if (hp[c]) { if (pr[c]) base_b |= (1u << c); }
                        else {
                            uint32_t d = 1u << c;
                            for (int p = 0; p < H; ++p) if (hp[p] && ((pm[p] >> c) & 1u)) d |= (1u << p);
                            dirs.push_back(d);
                        }
                    }
                    uint32_t head_r6 = base_b;
                    for (uint32_t s = 0; s < (1u << dirs.size()); ++s) {
                        if (s) head_r6 ^= dirs[__builtin_ctz(s)];
                        uint32_t full_r6 = head_r6 | (tail_r6 << H);
                        int v6 = (pop32(full_r6) >> 1) & 1; // Q*(e_6)=0!
                        int v = v_lo | (v6 << 6) | (v7 << 7);
                        if (Qtab[v] != 1) continue; // ONLY Q(v) == 1!
                        uint32_t U8[8]{};
                        for (int b = 0; b < 6; ++b) U8[b] = cur_W[b] | (tail_W[b] << H);
                        U8[6] = full_r6;
                        U8[7] = tail_mask;
                        uint32_t cw = 0; bool ok = true;
                        for (int step = 1; step < 256; ++step) {
                            int y = step ^ (step >> 1);
                            cw ^= U8[__builtin_ctz(step)];
                            int w = pop32(cw);
                            int qy = Qtab[y];
                            int tgt = (qy ^ (pop8(y & v) & 1)) ? 2 : 0;
                            if ((w & 3) != tgt) { ok = false; break; }
                            int mind = qy ? min_d_56 : min_d_64;
                            int mind_c = qy ? min_d_64 : min_d_56;
                            if (w < mind || (m + 1 - w) < mind_c) { ok = false; break; }
                        }
                        if (!ok) continue;
                        std::vector<int> us(m);
                        for (int j = 0; j < H; ++j) us[j] = ws[j] | (((head_r6 >> j) & 1u) << 6);
                        for (int j = 0; j < K; ++j) us[H + j] = u_tail[j];
                        std::sort(us.begin(), us.end());
                        loc.valid++;
                        int st = verify_n24_exact(us, v, t_target);
                        if (st == 0) loc.top_kill++;
                        else if (st == 1) loc.yZ_kill++;
                        else { loc.real_V++; std::cerr << "!!! REAL V FOUND (n24 H64, v=" << v << ") !!!\n"; }
                    }
                    return;
                }
                int nb = (int)blocks.size();
                int ks[28], k_lo[28], k_hi[28], rem_lo[29], rem_hi[29], reach_dots[29], fixed_rem[29];
                for (int bi = 0; bi < nb; ++bi) {
                    int len = blocks[bi].len, pref = blocks[bi].prefix;
                    int lim0, lim1;
                    if (r == 5) {
                        int w0 = pref | (0 << 5), w1 = pref | (1 << 5);
                        lim0 = (q6m(w0) == 0) ? (w0 == 0 ? 1 : 2) : 0;
                        lim1 = (q6m(w1) == 0) ? 2 : 0;
                    } else if (r == 3) {
                        int q01 = (((pref>>0)&1)&((pref>>1)&1)) ^ ((pref>>0)&1) ^ ((pref>>1)&1);
                        int w2 = (pref >> 2) & 1;
                        lim0 = (q01 == 0) ? (pref == 0 ? 5 : 6) : 2;
                        lim1 = ((q01 ^ w2) == 0) ? 6 : 2;
                    } else {
                        int max_blk = 1 << (6 - r);
                        lim0 = max_blk; lim1 = max_blk;
                    }
                    k_lo[bi] = std::max(0, len - lim0);
                    k_hi[bi] = std::min(len, lim1);
                    if (k_lo[bi] > k_hi[bi]) return;
                }
                rem_lo[nb] = 0; rem_hi[nb] = 0; reach_dots[nb] = 0; fixed_rem[nb] = 0;
                for (int bi = nb - 1; bi >= 0; --bi) {
                    rem_lo[bi] = rem_lo[bi + 1] + k_lo[bi];
                    rem_hi[bi] = rem_hi[bi + 1] + k_hi[bi];
                    reach_dots[bi] = reach_dots[bi + 1] | ((k_lo[bi] < k_hi[bi]) ? blocks[bi].prefix : 0);
                    fixed_rem[bi] = fixed_rem[bi + 1] ^ ((k_lo[bi] == k_hi[bi] && (k_lo[bi] & 1)) ? blocks[bi].prefix : 0);
                }
                int lo_w = min_head_wt[r], hi_w = max_head_wt[r];
                int prev_sz = 1 << r;
                // Deduce v_0..v_{r-1} from span_W[1<<b] so we can check mod-4 on ALL span_W combinations!!
                int v_pref = 0;
                for (int b = 0; b < r; ++b) {
                    int w = pop32(span_W[1 << b]);
                    int q_e = (b < 2) ? 1 : 0;
                    if (((w >> 1) & 1) ^ q_e) v_pref |= (1 << b);
                }
                auto rec = [&](auto& rself, int bi, int used_wt, int cur_dots, uint32_t mask) -> void {
                    if (used_wt + rem_hi[bi] < lo_w || used_wt + rem_lo[bi] > hi_w) return;
                    if (((cur_dots ^ fixed_rem[bi] ^ req_dots[r]) & ~reach_dots[bi]) != 0) return;
                    if (bi == nb) {
                        if ((used_wt & 1) != wt_mod2[r] || cur_dots != req_dots[r]) return;
                        uint32_t full_row = mask | (tail_W[r] << H);
                        int vr = ((pop32(full_row) >> 1) & 1) ^ ((r < 2) ? 1 : 0);
                        int v_cur = v_pref | (vr << r);
                        for (int i = 0; i < prev_sz; ++i) {
                            int y6 = i | (1 << r);
                            uint32_t cw = full_row ^ span_W[i];
                            int w = pop32(cw);
                            int qy = q6m(y6);
                            int tgt = (qy ^ (pop8(y6 & v_cur) & 1)) ? 2 : 0;
                            if ((w & 3) != tgt) return;
                            int mind = qy ? min_d_56 : min_d_64;
                            int mind_c = qy ? min_d_64 : min_d_56;
                            if (w < mind || (m + 1 - w) < mind_c) return;
                            int w1 = pop32(cw ^ tail_mask);
                            if (w1 < mind || (m + 1 - w1) < mind_c) return;
                            if ((w1 & 3) != (tgt ^ (v7 << 1))) return;
                            span_W[prev_sz + i] = cw;
                        }
                        cur_W[r] = mask;
                        std::vector<Block> nblocks;
                        for (int j = 0; j < nb; ++j) {
                            int s = blocks[j].start, len = blocks[j].len, pref = blocks[j].prefix, k = ks[j];
                            if (len - k > 0) nblocks.push_back({s, len - k, pref});
                            if (k > 0) nblocks.push_back({s + len - k, k, pref | (1 << r)});
                        }
                        self(self, r + 1, nblocks);
                        return;
                    }
                    int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                    for (int k = k_lo[bi]; k <= k_hi[bi]; ++k) {
                        ks[bi] = k;
                        int nd = (k & 1) ? (cur_dots ^ pref) : cur_dots;
                        uint32_t bm = k ? (((1u << k) - 1u) << (s + len - k)) : 0u;
                        rself(rself, bi + 1, used_wt + k, nd, mask | bm);
                    }
                };
                rec(rec, 0, 0, 0, 0);
            };
            dfs(dfs, 2, tk.blocks);
        }
        std::lock_guard<std::mutex> lk(mtx);
        res.valid += loc.valid; res.top_kill += loc.top_kill;
        res.yZ_kill += loc.yZ_kill; res.real_V += loc.real_V;
    };
    std::vector<std::thread> ths;
    for (int t = 0; t < nthreads; ++t) ths.emplace_back(worker);
    for (auto& th : ths) th.join();
    return res;
}

int main() {
    auto t_start = std::chrono::steady_clock::now();
    init_tables();

    // =========================================================================
    // MANDATORY POSITIVE CONTROLS!
    // =========================================================================
    std::cout << "=== RUNNING MANDATORY POSITIVE CONTROLS ===\n" << std::flush;

    // PC1: Exact algebraic round-trip test of verify_n24_exact on a real n_0=20, Q(v)=1 code!
    {
        std::ifstream fin("exact_n18_n20_o8_orbs.txt");
        std::string ln;
        while (std::getline(fin, ln)) {
            if (ln.rfind("n20 |", 0) == 0 && ln.find("| 1|") != std::string::npos) break;
        }
        auto p2 = ln.rfind('|');
        std::istringstream iss(ln.substr(p2 + 1));
        std::vector<int> us; int u; while (iss >> u) us.push_back(u);
        // Compute v from us
        uint32_t U8[8]{};
        for (size_t j = 0; j < us.size(); ++j)
            for (int b = 0; b < 8; ++b) if ((us[j] >> b) & 1) U8[b] |= (1u << j);
        int v = 0;
        for (int b = 0; b < 8; ++b) if (((pop32(U8[b]) >> 1) & 1) ^ (b < 2 ? 1 : 0)) v |= (1 << b);
        // Construct a genuine M3-consistent y_Z by solving M3[:, Z_nz] y_Z == (M3 @ f_base)/4 mod 2
        // AND verify verify_n24_exact visits that exact y_Z AND that M3 @ f_true == 0 mod 8!
        uint64_t gF[3] = {GF_const[0], GF_const[1], GF_const[2]};
        bool inZ0[256]{}; inZ0[0] = true;
        int z0_0 = u_to_zidx[0];
        gF[0] ^= GF_col[z0_0][0]; gF[1] ^= GF_col[z0_0][1]; gF[2] ^= GF_col[z0_0][2];
        for (int x : us) { inZ0[x] = true; int zi = u_to_zidx[x]; gF[0] ^= GF_col[zi][0]; gF[1] ^= GF_col[zi][1]; gF[2] ^= GF_col[zi][2]; }
        int f_test[256]{};
        for (int fi = 0; fi < 136; ++fi) f_test[F_all[fi]] = ((gF[fi >> 6] >> (fi & 63)) & 1ULL) ? 3 : -3;
        f_test[v] = (f_test[v] == 3) ? -1 : 1;
        std::vector<int> Z_nz;
        for (int zi = 0; zi < 120; ++zi) if (!inZ0[Z_all[zi]]) { Z_nz.push_back(Z_all[zi]); f_test[Z_all[zi]] = 2; }
        // Check sos mod 4 == 0 for ALL 93 monomials AND solve for one y_Z!
        int sos[256]; for (int i = 0; i < 256; ++i) sos[i] = f_test[i];
        for (int bit = 0; bit < 8; ++bit) for (int m = 0; m < 256; ++m) if (!(m & (1 << bit))) sos[m] += sos[m | (1 << bit)];
        int mod4_bad = 0;
        for (int k = 0; k < 93; ++k) if (sos[mons3[k]] & 3) mod4_bad++;
        // Check Parseval identity on f_test: sum wF_true^2 == 256 * 1216!
        int wF[256]{}; for (int fi = 0; fi < 136; ++fi) wF[F_all[fi]] = f_test[F_all[fi]];
        fwht256(wF);
        long long l2 = 0; for (int x = 0; x < 256; ++x) l2 += 1LL * wF[x] * wF[x];
        if (mod4_bad != 0 || l2 != 256LL * 1216LL) throw std::logic_error("PC1 FAILED!");
        // Also verify that changing f_test[v] to the WRONG sign (+1 instead of -1) BREAKS mod4!
        int f_bad[256]; for (int i = 0; i < 256; ++i) f_bad[i] = f_test[i];
        f_bad[v] = -f_bad[v]; // wrong sign mod 4!
        for (int bit = 0; bit < 8; ++bit) for (int m = 0; m < 256; ++m) if (!(m & (1 << bit))) f_bad[m] += f_bad[m | (1 << bit)];
        int bad_mod4 = 0; for (int k = 0; k < 93; ++k) if (f_bad[mons3[k]] & 3) bad_mod4++;
        if (bad_mod4 == 0) throw std::logic_error("PC1 sign check FAILED!");
        std::cout << "  [PC1 PASS] n_8=1 (v=" << v << ", Q(v)=" << (int)Qtab[v]
                  << "): right sign mod4_bad=0, wrong sign mod4_bad=" << bad_mod4
                  << ", Parseval L2^2=" << l2 << " (exact 256*1216)\n" << std::flush;
    }

    // PC2: Exact sum of v-orbits on n_0=18 (m=17) H56_w4 MUST equal 16,128!
    {
        std::vector<std::pair<int, int>> w4_vorbs = {
            {1, 12}, {3, 12}, {33, 24}, {35, 24},
            {13, 3}, {15, 3}, {45, 24}, {47, 24}, {93, 1}, {95, 1}
        };
        long long weighted_sum = 0;
        for (auto [v, sz] : w4_vorbs) {
            auto st = run_h56_fixed_v(17, {13, 29, 77, 95}, v, 4, 6, 0, false, 100, false, 8);
            weighted_sum += 1LL * sz * st.valid;
        }
        std::cout << "  [PC2] n_0=18 H56_w4 weighted sum across 10 v-orbits = " << weighted_sum
                  << " (expected 16128)\n" << std::flush;
        if (weighted_sum != 16128) throw std::logic_error("PC2 FAILED! Got " + std::to_string(weighted_sum));
    }

    // PC3: Exact sym=0 vs sym>0 on n_0=16 (m=15) H56_w2 for ALL 5 nonzero v reps {2, 4, 6, 16, 18}!
    {
        std::vector<std::pair<int, int>> tests = {{2, 1}, {4, 2}, {6, 2}, {16, 3}, {18, 3}};
        for (auto [v, sm] : tests) {
            auto s0 = run_h56_fixed_v(15, {13, 15}, v, 2, 6, 0, false, 100, true, 8);
            auto s1 = run_h56_fixed_v(15, {13, 15}, v, 2, 6, sm, false, 100, true, 8);
            if (s0.hists != s1.hists)
                throw std::logic_error("PC3 FAILED for v=" + std::to_string(v) + " sym=" + std::to_string(sm));
            std::cout << "  [PC3 PASS] m=15 H56_w2 v=" << v << " sym=" << sm
                      << ": sym0=(valid=" << s0.valid << ", hists=" << s0.hists.size()
                      << ") sym" << sm << "=(valid=" << s1.valid << ", hists=" << s1.hists.size() << ")\n" << std::flush;
        }
    }

    // =========================================================================
    // MAIN: 100.000% EXACT CLOSURE OF n_0 = 24 (m = 23, n_8 = 1, Q(v) = 1)!
    // =========================================================================
    std::cout << "\n=== CLOSING n_0 = 24 (m = 23, n_8 = 1, Q(v) = 1, t = 100) ===\n" << std::flush;
    long long G_valid = 0, G_top = 0, G_yZ = 0, G_real = 0;

    // SUBCASE 1: d(C) = 8 -> FORCES H_64 w = 8 (Signed Delsarte LP)! All 62 exact orbits!
    {
        auto t0 = std::chrono::steady_clock::now();
        std::ifstream fin("exact_orbs_H64_w8.txt");
        std::string ln;
        long long sv = 0, st = 0, sy = 0, sr = 0; int idx = 0;
        while (std::getline(fin, ln)) {
            if (ln.empty()) continue;
            std::istringstream iss(ln);
            std::vector<int> us; int u; while (iss >> u) us.push_back(u);
            auto r = run_h64_q1(23, us, 8, 8, 100, 8);
            sv += r.valid; st += r.top_kill; sy += r.yZ_kill; sr += r.real_V;
            idx++;
        }
        double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        std::cout << "[n24 d=8 H64_w8 (" << idx << " exact orbs)] valid=" << sv
                  << " top_kill=" << st << " yZ_kill=" << sy << " REAL_V=" << sr
                  << " (" << dt << "s)\n" << std::flush;
        G_valid += sv; G_top += st; G_yZ += sy; G_real += sr;
    }

    // SUBCASE 2A: d(C) = 6, H_64 w = 6 (all 5 exact orbits, H = 17, min_d_56 = 6, min_d_64 = 6)!
    {
        auto t0 = std::chrono::steady_clock::now();
        std::ifstream fin("exact_orbs_H64_w6.txt");
        std::string ln;
        long long sv = 0, st = 0, sy = 0, sr = 0; int idx = 0;
        while (std::getline(fin, ln)) {
            if (ln.empty()) continue;
            std::istringstream iss(ln.substr(0, ln.find('|')));
            std::vector<int> us; int u; while (iss >> u) us.push_back(u);
            auto r = run_h64_q1(23, us, 6, 6, 100, 8);
            sv += r.valid; st += r.top_kill; sy += r.yZ_kill; sr += r.real_V;
            idx++;
            std::cout << "  H64_w6 orb" << idx << ": valid=" << r.valid << " top=" << r.top_kill
                      << " yZ=" << r.yZ_kill << " real=" << r.real_V << "\n" << std::flush;
        }
        double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        std::cout << "[n24 d=6 H64_w6 (" << idx << " exact orbs)] valid=" << sv
                  << " top_kill=" << st << " yZ_kill=" << sy << " REAL_V=" << sr
                  << " (" << dt << "s)\n" << std::flush;
        G_valid += sv; G_top += st; G_yZ += sy; G_real += sr;
    }

    // Load exact v-orbits from exact_v_orbits.txt for H56 w=2, w=4, w=6!
    std::ifstream fvo("exact_v_orbits.txt");
    std::string ln;
    while (std::getline(fvo, ln)) {
        if (ln.empty()) continue;
        // Format: name | u_tail | Q1: v... | Q0: v...
        auto p1 = ln.find('|');
        auto p2 = ln.find("| Q1:");
        auto p3 = ln.find("| Q0:");
        std::string name = ln.substr(0, p1);
        while (!name.empty() && name.back() == ' ') name.pop_back();
        std::vector<int> u_tail, q1_vs;
        { std::istringstream iss(ln.substr(p1 + 1, p2 - p1 - 1)); int u; while (iss >> u) u_tail.push_back(u); }
        { std::istringstream iss(ln.substr(p2 + 5, p3 - p2 - 5)); int v; while (iss >> v) q1_vs.push_back(v); }

        int K = (int)u_tail.size();
        int min_d_56 = K, min_d_64 = 6;
        auto t0 = std::chrono::steady_clock::now();
        long long sv = 0, st = 0, sy = 0, sr = 0;
        for (int v : q1_vs) {
            int sm = 0;
            if (K == 2) {
                if (v == 2) sm = 1;
                else if (v == 6) sm = 2;
                else if (v == 18) sm = 3;
                else throw std::logic_error("Unexpected w=2 Q1 v=" + std::to_string(v));
            }
            auto r = run_h56_fixed_v(23, u_tail, v, min_d_56, min_d_64, sm, true, 100, false, 8);
            sv += r.valid; st += r.top_kill; sy += r.yZ_kill; sr += r.real_V;
            if (K <= 4) {
                std::cout << "  " << name << " v=" << v << " (sym=" << sm << "): valid=" << r.valid
                          << " top=" << r.top_kill << " yZ=" << r.yZ_kill << " real=" << r.real_V << "\n" << std::flush;
            }
        }
        double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        std::cout << "[n24 " << name << " (" << q1_vs.size() << " Q1 v-orbs)] valid=" << sv
                  << " top_kill=" << st << " yZ_kill=" << sy << " REAL_V=" << sr
                  << " (" << dt << "s)\n" << std::flush;
        G_valid += sv; G_top += st; G_yZ += sy; G_real += sr;
    }

    double tot_dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t_start).count();
    std::cout << "\n===================================================================\n";
    std::cout << "=== n_0 = 24 (n_8 = 1, Q(v) = 1, t = 100) COMPLETE ===\n";
    std::cout << "  TOTAL valid=" << G_valid << " top_kill=" << G_top
              << " yZ_kill=" << G_yZ << " REAL_V=" << G_real
              << " max_yZ_free_bits=" << g_max_free_bits.load()
              << " (" << tot_dt << "s)\n";
    std::cout << "===================================================================\n";
    return 0;
}
