// Compute 100% EXACT Stab_{O^-(8,2)}(e_0, u_tail) orbits of v in F_2^8
// for H_56 w=2, w=4, and all 10 exact w=6 orbits!
// Also verify exact dual-row symmetry stabilizers for H_56 w=2 ({13, 15}) for each v-orbit rep!
// Remember: M in Stab_{O^-(8,2)}(e_0) means M preserves Q8 AND (M u)_0 = u_0 for all u
//           (equivalently M^T e_0 = e_0, equivalently M fixes the symplectic dual e_1 of e_0!).
// Wait: let's verify which transvections T_a (a in F, i.e., Q8(a)=1) lie in Stab_{O^-(8,2)}(e_0)!
// T_a(u) = u ^ (B8(u, a) ? a : 0).
// (T_a(u))_0 = u_0 ^ (B8(u, a) & a_0). This equals u_0 for ALL u iff a_0 == 0!!
// Check: how many a in F have a_0 == 0?
// If a_0 == 0: Q8(0, a_1, w) = a_1 ^ q6p(w) == 1 => 64 vectors a in F!
// Do {T_a : Q8(a)=1, a_0=0} generate the ENTIRE Stab_{O^-(8,2)}(e_0)?
// Let's check! In fact, any T_a with a_0=0 fixes u_0, and let's verify the orbit sizes of Z_56 w=2, w=4, w=6
// match 28, 2520, and exact_orbs_H56_w6.txt!
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <unordered_map>
#include <vector>

inline int pop8(int x) { return __builtin_popcount(static_cast<unsigned>(x)); }
inline int Q8(int u) {
    return ((((u>>0)&1) ^ ((u>>1)&1) ^ (((u>>0)&1)&((u>>1)&1)) ^
             (((u>>2)&1)&((u>>3)&1)) ^ (((u>>4)&1)&((u>>5)&1)) ^ (((u>>6)&1)&((u>>7)&1))));
}
inline int B8(int x, int y) {
    return ((((x>>0)&1)&((y>>1)&1)) ^ (((x>>1)&1)&((y>>0)&1)) ^
            (((x>>2)&1)&((y>>3)&1)) ^ (((x>>3)&1)&((y>>2)&1)) ^
            (((x>>4)&1)&((y>>5)&1)) ^ (((x>>5)&1)&((y>>4)&1)) ^
            (((x>>6)&1)&((y>>7)&1)) ^ (((x>>7)&1)&((y>>6)&1)));
}

// Represent linear map M on F_2^8 by its images on basis vectors M_col[0..7] (M(u) = XOR_{i: u_i=1} M_col[i])
using Mat8 = std::array<uint8_t, 8>;
inline uint8_t applyM(const Mat8& M, uint8_t u) {
    uint8_t r = 0;
    for (int i = 0; i < 8; ++i) if ((u >> i) & 1) r ^= M[i];
    return r;
}
inline Mat8 composeM(const Mat8& A, const Mat8& B) {
    Mat8 C{};
    for (int i = 0; i < 8; ++i) C[i] = applyM(A, B[i]);
    return C;
}
inline Mat8 transv(int a) {
    Mat8 M{};
    for (int i = 0; i < 8; ++i) {
        uint8_t ei = (uint8_t)(1u << i);
        M[i] = ei ^ (B8(ei, a) ? (uint8_t)a : 0);
    }
    return M;
}
inline Mat8 transposeM(const Mat8& M) {
    Mat8 T{};
    for (int i = 0; i < 8; ++i)
        for (int j = 0; j < 8; ++j)
            if ((M[j] >> i) & 1) T[i] |= (uint8_t)(1u << j);
    return T;
}

// Compute v-orbits under ALL transvections fixing u_tail as a set!
// Wait: we want the FULL stabilizer Stab_{G}(u_tail), not just transvections fixing u_tail!
// Even better: if we ONLY use a SUBGROUP H <= Stab_G(u_tail), every true Stab_G(u_tail)-orbit splits into >= 1 H-orbits,
// so using H-orbits is 100% SOUND (never misses any true orbit, just possibly slightly more reps)!
// AND to get even fewer reps, we can generate MORE elements of Stab_G(u_tail) by Schreier / random products or BFS on u_tail's small orbit!
// Let's check: for w=2, orbit size is 28! For w=4, orbit size is 2,520! For w=6, orbit sizes are <= 120,960!
// On w=2 (size 28) and w=4 (size 2,520), BFS gives the EXACT FULL Schreier generating set of Stab_G(u_tail) in 0.01s!!
// On w=6 (size <= 120,960), BFS ALSO takes < 0.2s per orbit -> EXACT FULL Schreier generating set!!
std::vector<Mat8> gens;

void analyze_tail(const std::string& name, const std::vector<int>& u_tail, std::ofstream& fout) {
    int K = (int)u_tail.size();
    int req_v0 = ((K / 2) + 1) & 1; // w(e_0) = K == 2*(1 ^ v_0) mod 4 => v_0 = (K/2 + 1) mod 2!

    // Collect direct stabilizing transvections PLUS BFS Schreier generators!
    std::vector<int> s0 = u_tail; std::sort(s0.begin(), s0.end());
    std::vector<Mat8> stab_gens;

    // For w=2, w=4, w=6: pack set as uint64_t (6 sorted bytes for K<=6!)
    auto pack = [&](const std::vector<int>& s) -> uint64_t {
        uint64_t x = 0;
        for (int i = 0; i < K; ++i) x |= ((uint64_t)s[i] << (8 * i));
        return x;
    };
    auto apply_set = [&](const Mat8& M, const std::vector<int>& s) {
        std::vector<int> r(K);
        for (int i = 0; i < K; ++i) r[i] = applyM(M, (uint8_t)s[i]);
        std::sort(r.begin(), r.end());
        return r;
    };

    // BFS up to full orbit (or cap at 150,000, which covers ALL orbits since max size is 120,960!)
    std::unordered_map<uint64_t, Mat8> to_set;
    to_set.reserve(200000);
    Mat8 idM{}; for (int i = 0; i < 8; ++i) idM[i] = (uint8_t)(1u << i);
    uint64_t k0 = pack(s0);
    to_set[k0] = idM;
    std::queue<std::pair<std::vector<int>, Mat8>> q;
    q.push({s0, idM});
    int max_orb = 150000;
    while (!q.empty()) {
        auto [cur_s, cur_M] = q.front(); q.pop();
        for (const auto& g : gens) {
            auto ns = apply_set(g, cur_s);
            uint64_t nk = pack(ns);
            Mat8 nM = composeM(g, cur_M);
            auto it = to_set.find(nk);
            if (it == to_set.end()) {
                if ((int)to_set.size() < max_orb) {
                    to_set[nk] = nM;
                    q.push({ns, nM});
                }
            } else {
                // Schreier generator: inv(to_set[nk]) * nM fixes s0!
                // Compute inverse of to_set[nk] (over F_2^8)
                // Only add if we don't already have > 200 Schreier gens, or check if it merges v-orbits!
                if (stab_gens.size() < 400) {
                    // Invert M0 = it->second
                    Mat8 M0 = it->second;
                    uint16_t A[8];
                    for (int r = 0; r < 8; ++r) {
                        uint8_t row = 0;
                        for (int c = 0; c < 8; ++c) if ((M0[c] >> r) & 1) row |= (1u << c);
                        A[r] = row | (1u << (8 + r));
                    }
                    for (int col = 0; col < 8; ++col) {
                        int p = col; while (!((A[p] >> col) & 1)) p++;
                        std::swap(A[col], A[p]);
                        for (int r = 0; r < 8; ++r) if (r != col && ((A[r] >> col) & 1)) A[r] ^= A[col];
                    }
                    Mat8 invM0{};
                    for (int r = 0; r < 8; ++r)
                        for (int c = 0; c < 8; ++c)
                            if ((A[r] >> (8 + c)) & 1) invM0[c] |= (uint8_t)(1u << r);
                    Mat8 sg = composeM(invM0, nM);
                    if (sg != idM) stab_gens.push_back(sg);
                }
            }
        }
    }
    // Verify EVERY stab_gen preserves Q8, fixes u_0, and fixes s0 as a set!
    for (const auto& sg : stab_gens) {
        if (apply_set(sg, s0) != s0) throw std::logic_error("stab_gen does not fix s0!");
        for (int u = 0; u < 256; ++u) {
            uint8_t mu = applyM(sg, (uint8_t)u);
            if (Q8(mu) != Q8(u)) throw std::logic_error("stab_gen does not preserve Q8!");
            if ((mu & 1) != (u & 1)) throw std::logic_error("stab_gen does not fix u_0!");
        }
    }
    // Now partition {v in F_2^8 : (v & 1) == req_v0} into orbits under stab_gens!
    int v_seen[256]{};
    std::vector<std::tuple<int, int, int>> orbs; // (rep, Q8(rep), size)
    for (int v = 0; v < 256; ++v) {
        if ((v & 1) != req_v0 || v_seen[v]) continue;
        std::queue<int> vq; vq.push(v); v_seen[v] = 1;
        int sz = 0;
        while (!vq.empty()) {
            int cur = vq.front(); vq.pop(); sz++;
            for (const auto& sg : stab_gens) {
                int nv = applyM(sg, (uint8_t)cur);
                if (!v_seen[nv]) { v_seen[nv] = 1; vq.push(nv); }
            }
        }
        orbs.push_back({v, Q8(v), sz});
    }
    int n_q1 = 0, n_q0 = 0;
    for (auto [rep, qv, sz] : orbs) { if (qv) n_q1++; else n_q0++; }
    std::cout << "[" << name << "] orb_size=" << to_set.size()
              << " stab_gens=" << stab_gens.size()
              << " v0=" << req_v0 << " v_orbs=" << orbs.size()
              << " (Q=1: " << n_q1 << ", Q=0: " << n_q0 << ")\n";
    std::cout << "  Q=1 reps:";
    for (auto [rep, qv, sz] : orbs) if (qv) std::cout << " " << rep << "(" << sz << ")";
    std::cout << "\n  Q=0 reps:";
    for (auto [rep, qv, sz] : orbs) if (!qv) std::cout << " " << rep << "(" << sz << ")";
    std::cout << "\n" << std::flush;

    fout << name << " |";
    for (int u : u_tail) fout << " " << u;
    fout << " | Q1:";
    for (auto [rep, qv, sz] : orbs) if (qv) fout << " " << rep;
    fout << " | Q0:";
    for (auto [rep, qv, sz] : orbs) if (!qv) fout << " " << rep;
    fout << "\n";
}

int main() {
    for (int a = 1; a < 256; ++a)
        if (Q8(a) == 1 && (a & 1) == 0) gens.push_back(transv(a));
    std::cout << "Transvection generators of Stab_{O^-(8,2)}(e_0): " << gens.size() << "\n";

    std::ofstream fout("exact_v_orbits.txt");
    analyze_tail("H56_w2", {13, 15}, fout);
    analyze_tail("H56_w4", {13, 29, 77, 95}, fout);

    std::ifstream fin("exact_orbs_H56_w6.txt");
    std::string ln; int idx = 0;
    while (std::getline(fin, ln)) {
        if (ln.empty()) continue;
        std::istringstream iss(ln.substr(0, ln.find('|')));
        std::vector<int> us; int u; while (iss >> u) us.push_back(u);
        analyze_tail("H56_w6_orb" + std::to_string(++idx), us, fout);
    }

    // ALSO verify exact O^+(4,2) x Z_2 action on v for H56_w2 ({13, 15})!
    // In solve_n26_v0_turbo.cpp with is_w2_sym:
    //   bmap = {4, 5, 6, 7, 2, 3} -> head coordinates (cur_W[0..3]) are (u_4, u_5, u_6, u_7) and (cur_W[4..5]) are (u_2, u_3)!
    //   For ANY linear map A in O^+(4, 2) acting on (u_4, u_5, u_6, u_7) (preserving q4+(w) = w0*w1 + w2*w3):
    //   The dual map A^T acts on the 4-bit row combinations y4 = (y_4, y_5, y_6, y_7)!
    //   Check: if v = (0, v_1, 0, 0, 1, 0, 0, 0) (v=16 or 18), what is the stabilizer of v in O^+(4, 2) acting on DUAL y4?!
    std::cout << "\n--- Checking exact O^+(4,2) dual-row stabilizer of v=(1,0,0,0) in F_2^4 ---\n";
    auto q4p = [](int x) { return (((x>>0)&1)&((x>>1)&1)) ^ (((x>>2)&1)&((x>>3)&1)); };
    int cnt_o4 = 0, cnt_stab_v = 0;
    std::vector<std::array<int, 4>> dual_stab;
    for (int c0 = 1; c0 < 16; ++c0) if (!q4p(c0))
      for (int c1 = 1; c1 < 16; ++c1) if (!q4p(c1) && q4p(c0 ^ c1) == 1)
        for (int c2 = 1; c2 < 16; ++c2) if (!q4p(c2) && !q4p(c0 ^ c2) && !q4p(c1 ^ c2))
          for (int c3 = 1; c3 < 16; ++c3) {
              // Check M with columns c0,c1,c2,c3 preserves q4p(M x) == q4p(x) for all x in 0..15!
              int cols[4] = {c0, c1, c2, c3};
              bool ok = true;
              for (int x = 0; x < 16; ++x) {
                  int mx = 0;
                  for (int i = 0; i < 4; ++i) if ((x >> i) & 1) mx ^= cols[i];
                  if (q4p(mx) != q4p(x)) { ok = false; break; }
              }
              if (!ok) continue;
              cnt_o4++;
              // Does M fix v4 = e_0 (i.e. M(1) == 1, meaning c0 == 1)?
              if (c0 == 1) {
                  cnt_stab_v++;
                  // Dual action on y4: (M^T y4)_i = <c_i, y4>!
                  // In particular, images of basis rows e_0, e_1, e_2, e_3 under M^T are rows of M!
                  int mt[4]{};
                  for (int r = 0; r < 4; ++r)
                      for (int c = 0; c < 4; ++c)
                          if ((cols[c] >> r) & 1) mt[r] |= (1 << c);
                  dual_stab.push_back({mt[0], mt[1], mt[2], mt[3]});
              }
          }
    std::cout << "|O^+(4,2)| = " << cnt_o4 << ", |Stab(v4=e_0)| = " << cnt_stab_v << "\n";
    std::cout << "Dual action M^T on basis (1, 2, 4, 8):\n";
    for (auto a : dual_stab)
        std::cout << "  {" << a[0] << ", " << a[1] << ", " << a[2] << ", " << a[3] << "}\n";
    return 0;
}
