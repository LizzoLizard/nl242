#!/usr/bin/env python3
"""
100% SELF-CONTAINED EXACT PROOF OF H_64 w >= 6 FOR ALL n_8 <= 7 (hence ALL n_0 >= 12 at t = 100)!
Steps:
  1. Verify rank(RM(3,7)|_{Z_64}) == 56 => ker == 8 == dim(Q_7 * RM(1,7)) (g|_{F_64} unique up to shift & sign!).
  2. Enumerate ALL C(64, 2) = 2,016 2-subsets of Z_64: verify 0 satisfy RM(3,7) parity checks!
  3. Enumerate ALL C(64, 4) = 635,376 4-subsets of Z_64: verify 5,376 valid, and ALL 5,376 form ONE SINGLE ORBIT
     under Stab_{O^-(8,2)}(e_7) (transvections T_a with Q8(a)=1, a_7=0)!
  4. Prove in EXACT Fraction arithmetic (LP dual certificate) that on this unique orbit rep,
     min sum_{u' in F_64} x_F(u') >= 8 (so n_8 >= n_8^(1) >= 8, impossible for all n_8 <= 7)!
"""
from fractions import Fraction
import numpy as np
from scipy.optimize import linprog

def Q8_s(u):
    return (((u>>0)&1) + ((u>>1)&1) + (((u>>0)&1)&((u>>1)&1)) +
            (((u>>2)&1)&((u>>3)&1)) + (((u>>4)&1)&((u>>5)&1)) + (((u>>6)&1)&((u>>7)&1)))
def Q8(u): return Q8_s(u) & 1
def Q8_carry(u): s = Q8_s(u); return (s * (s - 1) // 2) & 1
def B8(x, y):
    return ((((x>>0)&1)&((y>>1)&1)) ^ (((x>>1)&1)&((y>>0)&1)) ^
            (((x>>2)&1)&((y>>3)&1)) ^ (((x>>3)&1)&((y>>2)&1)) ^
            (((x>>4)&1)&((y>>5)&1)) ^ (((x>>5)&1)&((y>>4)&1)) ^
            (((x>>6)&1)&((y>>7)&1)) ^ (((x>>7)&1)&((y>>6)&1)))
def pop(x): return bin(x).count("1")

# 1. Z_64 and F_64 on H_64 (u_7 = 1, i.e., u = 128 + u')
Z64 = [u for u in range(128, 256) if Q8(u) == 0]
F64 = [u for u in range(128, 256) if Q8(u) == 1]
assert len(Z64) == 64 and len(F64) == 64
mons7 = [m for m in range(128) if pop(m) <= 3]
assert len(mons7) == 64

# Build 64 x 64 matrix M_Z[i, k] = ((Z64[i] & 127) & mons7[k] == mons7[k]) over GF(2)
A = []
for i, u in enumerate(Z64):
    c = u & 127
    m_bits = 0
    for k, mon in enumerate(mons7):
        if (c & mon) == mon:
            m_bits |= (1 << k)
    A.append([m_bits, 1 << i])

rk = 0
piv_cols = []
for col in range(64):
    p = -1
    for i in range(rk, 64):
        if (A[i][0] >> col) & 1:
            p = i; break
    if p == -1: continue
    A[rk], A[p] = A[p], A[rk]
    for i in range(64):
        if i != rk and ((A[i][0] >> col) & 1):
            A[i][0] ^= A[rk][0]
            A[i][1] ^= A[rk][1]
    piv_cols.append(col)
    rk += 1

assert rk == 56, f"Expected rank 56, got {rk}"
print(f"[STEP 1 PASS] rank(RM(3,7)|_{{Z_64}}) = {rk}, ker = {64 - rk} == dim(Q_7 * RM(1,7)) (quotient_dim = 0!)")

# Extract the 8 parity checks on Z_64
col_syn = [0] * 64
req_syn = 0
for j in range(8):
    h = A[56 + j][1]
    rhs = 0
    for i in range(64):
        if (h >> i) & 1:
            col_syn[i] |= (1 << j)
            rhs ^= (1 ^ Q8_carry(Z64[i]))
    if rhs:
        req_syn |= (1 << j)

# 2. Check ALL 2-subsets of Z_64
cnt2 = 0
for i in range(64):
    for j in range(i + 1, 64):
        if (col_syn[i] ^ col_syn[j]) == req_syn:
            cnt2 += 1
assert cnt2 == 0
print(f"[STEP 2 PASS] H_64 w = 2: 0 / {64*63//2} valid 2-subsets!")

# 3. Check ALL 4-subsets of Z_64 + single Stab_{O^-(8,2)}(e_7) orbit!
syn_pos = [[] for _ in range(256)]
for i in range(64):
    syn_pos[col_syn[i]].append(i)

valid4 = set()
for i in range(64):
    s1 = req_syn ^ col_syn[i]
    for j in range(i + 1, 64):
        s2 = s1 ^ col_syn[j]
        for k in range(j + 1, 64):
            need = s2 ^ col_syn[k]
            for l in syn_pos[need]:
                if l > k:
                    valid4.add((i, j, k, l))
assert len(valid4) == 5376, f"Expected 5376, got {len(valid4)}"

# BFS under all 64 transvections T_a (1 <= a < 128, Q8(a) == 1)
u_to_i = {u: i for i, u in enumerate(Z64)}
perms = []
for a in range(1, 128):
    if Q8(a) != 1: continue
    perms.append([u_to_i[u ^ (a if B8(u, a) else 0)] for u in Z64])

orbs4 = []
seen_all = set()
for s in valid4:
    if s in seen_all: continue
    cur_orb = {s}
    q = [s]
    while q:
        cur = q.pop()
        for p in perms:
            nxt = tuple(sorted(p[x] for x in cur))
            if nxt not in cur_orb:
                cur_orb.add(nxt)
                q.append(nxt)
    seen_all |= cur_orb
    orbs4.append((s, len(cur_orb)))
assert len(seen_all) == len(valid4) == 5376
print(f"[STEP 3 PASS] H_64 w = 4: {len(valid4)} valid 4-subsets split into {len(orbs4)} Stab(e_7) orbit(s): {[sz for _, sz in orbs4]}")
# 4. Solve unique g|_{F_64} for EVERY orbit in orbs4 and prove min n_8^(1) >= 8 via EXACT Fraction LP dual!
H7 = np.zeros((128, 128), dtype=int)
for x in range(128):
    for u in range(128):
        H7[x, u] = -1 if (pop(x & u) & 1) else 1

for oi, (rep, osz) in enumerate(orbs4):
    inS = set(rep)
    rhs_Z = [(0 if i in inS else 1) ^ Q8_carry(Z64[i]) for i in range(64)]
    gF = {}
    for u in F64:
        c = u & 127
        s = Q8_carry(u)
        for r in range(56):
            mon = mons7[piv_cols[r]]
            if (c & mon) == mon:
                h = A[r][1]
                for i in range(64):
                    if (h >> i) & 1:
                        s ^= rhs_Z[i]
        gF[u] = s

    fF0 = np.zeros(128, dtype=int)
    for u in F64:
        fF0[u & 127] = 3 if gF[u] else -3
    wF0 = H7 @ fF0

    Z_nz = [Z64[i] & 127 for i in range(64) if i not in inS]
    F_pts = [u & 127 for u in F64]
    assert len(Z_nz) == 60 and len(F_pts) == 64

    nvar = 64 + 60
    M_w = np.zeros((128, nvar), dtype=int)
    base_w = wF0.copy()
    for j, u in enumerate(F_pts):
        sgn = 4 * (1 - 2 * gF[128 + u])
        M_w[:, j] = H7[:, u] * sgn
    for k, u in enumerate(Z_nz):
        M_w[:, 64 + k] = H7[:, u]
        base_w -= 2 * H7[:, u]

    A_ub = np.vstack([M_w, -M_w, np.hstack([np.eye(64, dtype=int), np.zeros((64, 60), dtype=int)]),
                      np.hstack([np.zeros((60, 64), dtype=int), np.eye(60, dtype=int)])])
    b_ub = np.concatenate([64 - base_w, 64 + base_w, np.ones(64, dtype=int), np.full(60, 4, dtype=int)])
    c_obj = np.concatenate([np.ones(64, dtype=int), np.zeros(60, dtype=int)])

    res = linprog(c_obj.astype(float), A_ub=A_ub.astype(float), b_ub=b_ub.astype(float), bounds=(0, None), method='highs')
    print(f"  Orbit {oi+1}/{len(orbs4)} (size={osz}, rep={[Z64[x] for x in rep]}): HiGHS LP min n_8^(1) = {res.fun:.6f}")

    u_raw = np.maximum(0.0, -res.ineqlin.marginals)
    for max_den in (128, 256, 1024, 10**6):
        u_frac = [Fraction(float(v)).limit_denominator(max_den) for v in u_raw]
        col_slacks = [Fraction(int(c_obj[col])) + sum(u_frac[r] * int(A_ub[r, col]) for r in range(len(b_ub))) for col in range(nvar)]
        for col in range(nvar):
            if col_slacks[col] < 0:
                u_frac[256 + col] += -col_slacks[col]
                col_slacks[col] = Fraction(0)
        assert all(val >= 0 for val in u_frac)
        assert all(sum(u_frac[r] * int(A_ub[r, col]) for r in range(len(b_ub))) + Fraction(int(c_obj[col])) >= 0 for col in range(nvar))
        lb = -sum(u_frac[r] * int(b_ub[r]) for r in range(len(b_ub)))
        if lb >= 8:
            print(f"    [EXACT RATIONAL DUAL PASS] Orbit {oi+1}: min n_8^(1) >= {lb} (max_den<={max_den})!")
            break
    else:
        raise RuntimeError(f"Failed to certify lb >= 8 on orbit {oi+1}!")

print("\n[ALL PASS] H_64 w >= 6 IS 100.000% PROVED IN EXACT RATIONAL ARITHMETIC FOR ALL n_8 <= 7!")
