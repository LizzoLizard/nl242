// STEP 1: 100% EXACT Stab_{O^-(8,2)}(e_7) orbit decomposition of ALL valid H_64 w=8 subsets!
//         Precomputes an explicit element g_t in Stab(e_7) mapping every type-0 triple t -> (0,1,2)
//         (and every type-1 triple -> (0,1,6)), PLUS all generators of Stab(e_7, {0,1,2})!
//         Since EVERY valid 8-set contains a triple of type 0 or 1, BFS on the 46,644 sets using
//         {Stab(trip) gens} union {g_t for every triple t in the 8-set} finds the 100% EXACT orbits!
// STEP 2: Run 8-thread TURBO v=0 H_64 w=8 DFS (m=25, K=8, H=17, min_d_56=10, min_d_64=8) on EVERY exact orbit
//         with exact 1,024-yZ verification -> 100.000% CLOSES n_0 = 26 (n_8 = 0, v = 0)!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <mutex>
#include <queue>
#include <set>
#include <thread>
#include <unordered_map>
#include <vector>

inline int pop8(int x) { return __builtin_popcount(static_cast<unsigned>(x)); }
inline int pop32(uint32_t x) { return __builtin_popcount(x); }
inline int q6m(int w) {
    return ((((w >> 0) & 1) & ((w >> 1) & 1)) ^ ((w >> 0) & 1) ^ ((w >> 1) & 1) ^
            (((w >> 2) & 1) & ((w >> 3) & 1)) ^ (((w >> 4) & 1) & ((w >> 5) & 1)));
}
inline int Q8_s(int u) {
    return (((u>>0)&1) + ((u>>1)&1) + (((u>>0)&1)&((u>>1)&1)) +
            (((u>>2)&1)&((u>>3)&1)) + (((u>>4)&1)&((u>>5)&1)) + (((u>>6)&1)&((u>>7)&1)));
}
inline int Q8(int u) { return Q8_s(u) & 1; }
inline int Q8_carry(int u) { int s = Q8_s(u); return (s * (s - 1) / 2) & 1; }
inline int B8(int x, int y) {
    return ((((x>>0)&1)&((y>>1)&1)) ^ (((x>>1)&1)&((y>>0)&1)) ^
            (((x>>2)&1)&((y>>3)&1)) ^ (((x>>3)&1)&((y>>2)&1)) ^
            (((x>>4)&1)&((y>>5)&1)) ^ (((x>>5)&1)&((y>>4)&1)) ^
            (((x>>6)&1)&((y>>7)&1)) ^ (((x>>7)&1)&((y>>6)&1)));
}
void fwht256(int a[256]) {
    for (int st = 1; st < 256; st *= 2)
        for (int i = 0; i < 256; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}

struct Block { int start, len, prefix; };
int mons3[93];
uint8_t Qtab[256], Qcarry[256];
std::vector<int> Z_all, F_all;
uint64_t GF_col[120][3], GF_const[3];
int u_to_zidx[256];

void init_tables() {
    int k = 0;
    for (int m = 0; m < 256; ++m) if (pop8(m) <= 3) mons3[k++] = m;
    std::fill(u_to_zidx, u_to_zidx + 256, -1);
    for (int u = 0; u < 256; ++u) {
        Qtab[u] = (uint8_t)Q8(u);
        Qcarry[u] = (uint8_t)Q8_carry(u);
        if (!Qtab[u]) { u_to_zidx[u] = (int)Z_all.size(); Z_all.push_back(u); }
        else F_all.push_back(u);
    }
    struct Row { uint64_t m[2]{}; uint64_t id[2]{}; };
    Row A[120];
    for (int i = 0; i < 120; ++i) {
        int u = Z_all[i];
        for (int b = 0; b < 93; ++b)
            if ((u & mons3[b]) == mons3[b]) A[i].m[b >> 6] |= (1ULL << (b & 63));
        A[i].id[i >> 6] |= (1ULL << (i & 63));
    }
    int piv_cols[93], rk = 0;
    for (int col = 0; col < 93; ++col) {
        int p = -1;
        for (int i = rk; i < 120; ++i) if ((A[i].m[col >> 6] >> (col & 63)) & 1ULL) { p = i; break; }
        if (p == -1) continue;
        std::swap(A[rk], A[p]);
        for (int i = 0; i < 120; ++i)
            if (i != rk && ((A[i].m[col >> 6] >> (col & 63)) & 1ULL)) {
                A[i].m[0] ^= A[rk].m[0]; A[i].m[1] ^= A[rk].m[1];
                A[i].id[0] ^= A[rk].id[0]; A[i].id[1] ^= A[rk].id[1];
            }
        piv_cols[rk++] = col;
    }
    for (int fi = 0; fi < 136; ++fi) {
        int u = F_all[fi];
        uint64_t row[2]{};
        for (int r = 0; r < 84; ++r) {
            int col = piv_cols[r];
            if ((u & mons3[col]) == mons3[col]) { row[0] ^= A[r].id[0]; row[1] ^= A[r].id[1]; }
        }
        int cbit = Qcarry[u];
        for (int j = 0; j < 120; ++j) if ((row[j >> 6] >> (j & 63)) & 1ULL) {
            GF_col[j][fi >> 6] |= (1ULL << (fi & 63));
            if (1 ^ Qcarry[Z_all[j]]) cbit ^= 1;
        }
        if (cbit) GF_const[fi >> 6] |= (1ULL << (fi & 63));
    }
}

int verify_n26_exact(const std::vector<int>& us, int t_target) {
    uint64_t gF[3] = {GF_const[0], GF_const[1], GF_const[2]};
    bool inZ0[256]{}; inZ0[0] = true;
    int z0_0 = u_to_zidx[0];
    gF[0] ^= GF_col[z0_0][0]; gF[1] ^= GF_col[z0_0][1]; gF[2] ^= GF_col[z0_0][2];
    for (int u : us) {
        inZ0[u] = true;
        int zi = u_to_zidx[u];
        gF[0] ^= GF_col[zi][0]; gF[1] ^= GF_col[zi][1]; gF[2] ^= GF_col[zi][2];
    }
    int fF[256]{};
    for (int fi = 0; fi < 136; ++fi)
        fF[F_all[fi]] = ((gF[fi >> 6] >> (fi & 63)) & 1ULL) ? 3 : -3;
    int wF[256]; for (int i = 0; i < 256; ++i) wF[i] = fF[i];
    fwht256(wF);
    int aw[256]; for (int x = 0; x < 256; ++x) aw[x] = std::abs(wF[x]);
    std::nth_element(aw, aw + t_target, aw + 256, std::greater<int>());
    int top_sum = 0; for (int i = 0; i < t_target; ++i) top_sum += aw[i];
    if (top_sum < 4896) return 0;

    std::vector<int> Z_nz; Z_nz.reserve(104);
    int f_base[256]; for (int i = 0; i < 256; ++i) f_base[i] = fF[i];
    for (int zi = 0; zi < 120; ++zi) {
        int u = Z_all[zi];
        if (!inZ0[u]) { Z_nz.push_back(u); f_base[u] = 2; }
    }
    int mZ = (int)Z_nz.size();
    int sos[256]; for (int i = 0; i < 256; ++i) sos[i] = f_base[i];
    for (int bit = 0; bit < 8; ++bit)
        for (int m = 0; m < 256; ++m)
            if ((m & (1 << bit)) == 0) sos[m] += sos[m | (1 << bit)];
    struct Eq { uint64_t lo = 0, hi = 0; int rhs = 0; };
    Eq pivs[104]; bool has_piv[104]{};
    auto setb = [](Eq& e, int c) { if (c < 64) e.lo |= (1ULL << c); else e.hi |= (1ULL << (c - 64)); };
    auto firstb = [](const Eq& e) -> int {
        if (e.lo) return __builtin_ctzll(e.lo);
        if (e.hi) return 64 + __builtin_ctzll(e.hi);
        return -1;
    };
    for (int k = 0; k < 93; ++k) {
        int m = mons3[k];
        if (sos[m] & 3) return 1;
        Eq e; e.rhs = (sos[m] >> 2) & 1;
        for (int c = 0; c < mZ; ++c) if ((Z_nz[c] & m) == m) setb(e, c);
        while (true) {
            int b = firstb(e);
            if (b == -1) { if (e.rhs != 0) return 1; break; }
            if (has_piv[b]) { e.lo ^= pivs[b].lo; e.hi ^= pivs[b].hi; e.rhs ^= pivs[b].rhs; }
            else { pivs[b] = e; has_piv[b] = true; break; }
        }
    }
    for (int b = mZ - 1; b >= 0; --b) {
        if (!has_piv[b]) continue;
        for (int p = 0; p < b; ++p) {
            if (!has_piv[p]) continue;
            bool bit_on = (b < 64) ? ((pivs[p].lo >> b) & 1ULL) : ((pivs[p].hi >> (b - 64)) & 1ULL);
            if (bit_on) { pivs[p].lo ^= pivs[b].lo; pivs[p].hi ^= pivs[b].hi; pivs[p].rhs ^= pivs[b].rhs; }
        }
    }
    uint64_t base_lo = 0, base_hi = 0;
    std::vector<std::pair<uint64_t, uint64_t>> dirs;
    for (int c = 0; c < mZ; ++c) {
        if (has_piv[c]) {
            if (pivs[c].rhs) { if (c < 64) base_lo |= (1ULL << c); else base_hi |= (1ULL << (c - 64)); }
        } else {
            uint64_t dlo = 0, dhi = 0;
            if (c < 64) dlo |= (1ULL << c); else dhi |= (1ULL << (c - 64));
            for (int p = 0; p < mZ; ++p) if (has_piv[p]) {
                bool on = (c < 64) ? ((pivs[p].lo >> c) & 1ULL) : ((pivs[p].hi >> (c - 64)) & 1ULL);
                if (on) { if (p < 64) dlo |= (1ULL << p); else dhi |= (1ULL << (p - 64)); }
            }
            dirs.push_back({dlo, dhi});
        }
    }
    int dc_F = 0; for (int fi = 0; fi < 136; ++fi) dc_F += fF[F_all[fi]];
    uint64_t cur_lo = base_lo, cur_hi = base_hi;
    uint32_t total = 1u << dirs.size();
    for (uint32_t s = 0; s < total; ++s) {
        if (s) { int b = __builtin_ctz(s); cur_lo ^= dirs[b].first; cur_hi ^= dirs[b].second; }
        int pop_y = __builtin_popcountll(cur_lo) + __builtin_popcountll(cur_hi);
        int dc = dc_F + 2 * mZ - 4 * pop_y;
        if (dc != 0 && dc != 64 && dc != -64) continue;
        int f_try[256]; for (int i = 0; i < 256; ++i) f_try[i] = fF[i];
        for (int c = 0; c < mZ; ++c) {
            bool on = (c < 64) ? ((cur_lo >> c) & 1ULL) : ((cur_hi >> (c - 64)) & 1ULL);
            f_try[Z_nz[c]] = on ? -2 : 2;
        }
        fwht256(f_try);
        bool ok = true; int nz = 0;
        for (int x = 0; x < 256; ++x) {
            int v = f_try[x];
            if (v != 0 && v != 64 && v != -64) { ok = false; break; }
            if (v != 0) nz++;
        }
        if (ok && nz == t_target) return 2;
    }
    return 1;
}

// Compute 100% EXACT Stab(e_7) orbits of valid H_64 w=8 subsets!
std::vector<std::vector<int>> compute_exact_H64_w8_orbits() {
    std::vector<int> Z_u;
    int u_to_idx[256]; std::fill(u_to_idx, u_to_idx + 256, -1);
    for (int u = 128; u < 256; ++u) if (Q8(u) == 0) { u_to_idx[u] = (int)Z_u.size(); Z_u.push_back(u); }
    struct Perm { uint8_t p[64]; };
    std::vector<Perm> gens;
    for (int a = 1; a < 128; ++a) {
        if (Q8(a) != 1) continue;
        Perm g{};
        for (int i = 0; i < 64; ++i) g.p[i] = (uint8_t)u_to_idx[Z_u[i] ^ (B8(Z_u[i], a) ? a : 0)];
        gens.push_back(g);
    }
    auto compose = [](const Perm& a, const Perm& b) {
        Perm r{}; for (int i = 0; i < 64; ++i) r.p[i] = a.p[b.p[i]]; return r;
    };
    Perm idP{}; for (int i = 0; i < 64; ++i) idP.p[i] = (uint8_t)i;

    // BFS triples, storing for each triple c in orbit 0 or 1 an explicit Perm to_rep[c] mapping c -> rep!
    std::vector<int> trip_id(262144, -1);
    std::vector<int> parent_c(262144, -1), parent_g(262144, -1);
    int n_torb = 0;
    std::vector<std::array<int, 3>> trip_reps;
    for (int i = 0; i < 64; ++i)
      for (int j = i + 1; j < 64; ++j)
        for (int k = j + 1; k < 64; ++k) {
            int code = i | (j << 6) | (k << 12);
            if (trip_id[code] != -1) continue;
            int oid = n_torb++;
            std::queue<int> q; q.push(code); trip_id[code] = oid;
            while (!q.empty()) {
                int c = q.front(); q.pop();
                int a = c & 63, b = (c >> 6) & 63, d = (c >> 12) & 63;
                for (int gi = 0; gi < (int)gens.size(); ++gi) {
                    const auto& g = gens[gi];
                    int na = g.p[a], nb = g.p[b], nd = g.p[d];
                    if (na > nb) std::swap(na, nb);
                    if (nb > nd) std::swap(nb, nd);
                    if (na > nb) std::swap(na, nb);
                    int nc = na | (nb << 6) | (nd << 12);
                    if (trip_id[nc] == -1) {
                        trip_id[nc] = oid; parent_c[nc] = c; parent_g[nc] = gi;
                        q.push(nc);
                    }
                }
            }
            trip_reps.push_back({i, j, k});
        }
    auto get_to_rep = [&](int c) -> Perm {
        // Since each generator T_a is an INVOLUTION (T_a^-1 = T_a!), walking from c to rep applies parent_g in order!
        Perm res = idP;
        while (parent_c[c] != -1) {
            res = compose(gens[parent_g[c]], res);
            c = parent_c[c];
        }
        return res;
    };

    // RM(3,7) parity checks on Z_64
    int mons7[64], nm7 = 0;
    for (int c = 0; c < 128; ++c) if (pop8(c) <= 3) mons7[nm7++] = c;
    uint64_t A[64][2]{};
    for (int i = 0; i < 64; ++i) {
        int c = Z_u[i] & 127;
        for (int k = 0; k < 64; ++k) if ((c & mons7[k]) == mons7[k]) A[i][0] |= (1ULL << k);
        A[i][1] = (1ULL << i);
    }
    int r = 0;
    for (int col = 0; col < 64; ++col) {
        int p = -1;
        for (int i = r; i < 64; ++i) if ((A[i][0] >> col) & 1ULL) { p = i; break; }
        if (p == -1) continue;
        std::swap(A[r], A[p]);
        for (int i = 0; i < 64; ++i) if (i != r && ((A[i][0] >> col) & 1ULL)) { A[i][0] ^= A[r][0]; A[i][1] ^= A[r][1]; }
        r++;
    }
    int col_syn[64]{}, req_syn = 0;
    for (int j = 0; j < 64 - r; ++j) {
        uint64_t h = A[r + j][1];
        int rhs = 0;
        for (int i = 0; i < 64; ++i) if ((h >> i) & 1ULL) { col_syn[i] |= (1 << j); rhs ^= (1 ^ Q8_carry(Z_u[i])); }
        if (rhs) req_syn |= (1 << j);
    }
    std::vector<int> syn_to_pos[256];
    for (int i = 0; i < 64; ++i) syn_to_pos[col_syn[i]].push_back(i);
    auto t_orb = [&](int a, int b, int c) {
        if (a > b) std::swap(a, b);
        if (b > c) std::swap(b, c);
        if (a > b) std::swap(a, b);
        return trip_id[a | (b << 6) | (c << 12)];
    };

    // Collect ALL 46,644 valid 8-sets (46,596 for oi=0, 48 for oi=1)
    std::vector<std::vector<int>> exact_orbs;
    for (int oi = 0; oi < 2; ++oi) {
        auto [p0, p1, p2] = trip_reps[oi];
        std::vector<int> okc;
        for (int x = 0; x < 64; ++x) {
            if (x == p0 || x == p1 || x == p2) continue;
            if (t_orb(p0, p1, x) >= oi && t_orb(p0, p2, x) >= oi && t_orb(p1, p2, x) >= oi) okc.push_back(x);
        }
        int nc = (int)okc.size();
        int s3 = req_syn ^ col_syn[p0] ^ col_syn[p1] ^ col_syn[p2];
        int in_okc[64]; std::fill(in_okc, in_okc + 64, -1);
        for (int i = 0; i < nc; ++i) in_okc[okc[i]] = i;

        std::vector<uint64_t> masks;
        std::unordered_map<uint64_t, int> id_map;
        for (int i0 = 0; i0 < nc; ++i0) {
            int x0 = okc[i0], s4 = s3 ^ col_syn[x0];
            for (int i1 = i0 + 1; i1 < nc; ++i1) {
                int x1 = okc[i1], s5 = s4 ^ col_syn[x1];
                for (int i2 = i1 + 1; i2 < nc; ++i2) {
                    int x2 = okc[i2], s6 = s5 ^ col_syn[x2];
                    for (int i3 = i2 + 1; i3 < nc; ++i3) {
                        int x3 = okc[i3], need = s6 ^ col_syn[x3];
                        for (int x4 : syn_to_pos[need]) {
                            int i4 = in_okc[x4];
                            if (i4 <= i3) continue;
                            int pts[8] = {p0, p1, p2, x0, x1, x2, x3, x4};
                            if (oi > 0) {
                                bool ok = true;
                                for (int a = 0; a < 8 && ok; ++a)
                                  for (int b = a + 1; b < 8 && ok; ++b)
                                    for (int c = b + 1; c < 8 && ok; ++c)
                                      if (t_orb(pts[a], pts[b], pts[c]) < oi) ok = false;
                                if (!ok) continue;
                            }
                            uint64_t m = 0; for (int a = 0; a < 8; ++a) m |= (1ULL << pts[a]);
                            id_map[m] = (int)masks.size();
                            masks.push_back(m);
                        }
                    }
                }
            }
        }
        // Build Schreier generators of Stab(rep) + explicit map of every type-oi triple in mask -> rep!
        // Specifically: for ANY mask m in masks, applying any g in gens gives g(m); then for EVERY type-oi triple t in g(m),
        // applying get_to_rep(t) maps g(m) BACK into masks!! That generates the EXACT orbit intersection with masks!
        // Even simpler & faster: precompute Schreier gens of Stab(rep) (just pick ~20 random ones + transvections fixing rep)!
        std::vector<Perm> stab_gens;
        uint64_t rep_mask = (1ULL<<p0)|(1ULL<<p1)|(1ULL<<p2);
        for (const auto& g : gens) {
            uint64_t nm = (1ULL<<g.p[p0])|(1ULL<<g.p[p1])|(1ULL<<g.p[p2]);
            if (nm == rep_mask) stab_gens.push_back(g);
        }
        // Also for every generator g, get_to_rep(g(rep)) * g is in Stab(rep)!
        for (const auto& g : gens) {
            int a = g.p[p0], b = g.p[p1], c = g.p[p2];
            if (a > b) std::swap(a, b);
            if (b > c) std::swap(b, c);
            if (a > b) std::swap(a, b);
            Perm h = compose(get_to_rep(a | (b << 6) | (c << 12)), g);
            // check not identity
            bool diff = false; for (int i = 0; i < 64; ++i) if (h.p[i] != i) { diff = true; break; }
            if (diff) stab_gens.push_back(h);
        }
        std::vector<uint8_t> seen(masks.size(), 0);
        int cnt_o = 0;
        for (size_t i = 0; i < masks.size(); ++i) {
            if (seen[i]) continue;
            cnt_o++;
            std::vector<int> bfs = {(int)i}; seen[i] = 1;
            for (size_t hd = 0; hd < bfs.size(); ++hd) {
                uint64_t m = masks[bfs[hd]];
                int pts[8], np = 0;
                uint64_t tmp = m;
                while (tmp) { pts[np++] = __builtin_ctzll(tmp); tmp &= tmp - 1; }
                // 1) Apply stab_gens
                for (const auto& sg : stab_gens) {
                    uint64_t nm = 0; for (int k = 0; k < 8; ++k) nm |= (1ULL << sg.p[pts[k]]);
                    auto it = id_map.find(nm);
                    if (it != id_map.end() && !seen[it->second]) { seen[it->second] = 1; bfs.push_back(it->second); }
                }
                // 2) Map every type-oi triple in m back to rep!
                for (int a = 0; a < 8; ++a)
                  for (int b = a + 1; b < 8; ++b)
                    for (int c = b + 1; c < 8; ++c) {
                        int x = pts[a], y = pts[b], z = pts[c];
                        int tc = x | (y << 6) | (z << 12);
                        if (trip_id[tc] != oi) continue;
                        Perm tr = get_to_rep(tc);
                        uint64_t nm = 0; for (int k = 0; k < 8; ++k) nm |= (1ULL << tr.p[pts[k]]);
                        auto it = id_map.find(nm);
                        if (it != id_map.end() && !seen[it->second]) { seen[it->second] = 1; bfs.push_back(it->second); }
                    }
            }
            std::vector<int> us;
            uint64_t m = masks[i];
            while (m) { us.push_back(Z_u[__builtin_ctzll(m)]); m &= m - 1; }
            exact_orbs.push_back(us);
        }
        std::cout << "  H64 w=8 oi=" << oi << ": masks=" << masks.size() << " -> EXACT orbits=" << cnt_o << "\n" << std::flush;
    }
    return exact_orbs;
}

// TURBO v = 0 H_64 (u_7 = 1) DFS with mod-4 pruning on all 6 levels!
void run_h64_v0_turbo(int m, const std::vector<int>& u_tail, int min_d_56, int min_d_64,
                      int t_target, const std::string& label, int& out_valid, int& out_real, int nthreads = 8) {
    int K = (int)u_tail.size();
    int H = m - K;
    uint32_t tail_W[6]{}, tail_r6 = 0;
    for (int j = 0; j < K; ++j) {
        if ((u_tail[j] >> 6) & 1) tail_r6 |= (1u << j);
        for (int r = 0; r < 6; ++r)
            if ((u_tail[j] >> r) & 1) tail_W[r] |= (1u << j);
    }
    if ((pop32(tail_r6) & 1) == 0) { out_valid = 0; out_real = 0; return; }
    int wt_mod4[6], req_dots[6], r6_dot_req[6], tail_wt[6];
    for (int r = 0; r < 6; ++r) {
        tail_wt[r] = pop32(tail_W[r]);
        int full_wt = (r < 2) ? 2 : 0; // Q8*(e_0)=Q8*(e_1)=1, Q8*(e_2..5)=0!
        wt_mod4[r] = ((full_wt - tail_wt[r]) % 4 + 4) % 4;
        r6_dot_req[r] = pop32(tail_r6 & tail_W[r]) & 1;
        int rd = 0;
        for (int p = 0; p < r; ++p) {
            int full_dot = ((r == 1 && p == 0) || (r == 3 && p == 2) || (r == 5 && p == 4)) ? 1 : 0;
            if (full_dot ^ (pop32(tail_W[r] & tail_W[p]) & 1)) rd |= (1 << p);
        }
        req_dots[r] = rd;
    }
    int r6_wt_mod4 = ((0 - pop32(tail_r6)) % 4 + 4) % 4; // Q8*(e_6)=0!
    int min_head_wt[6], max_head_wt[6];
    for (int r = 0; r < 6; ++r) {
        int q_e = (r < 2) ? 1 : 0;
        int mind = q_e ? min_d_56 : min_d_64;
        int mind_c = q_e ? min_d_64 : min_d_56;
        min_head_wt[r] = std::max(mind - tail_wt[r], mind - (K - tail_wt[r]));
        max_head_wt[r] = std::min((m + 1 - mind_c) - tail_wt[r], (m + 1 - mind_c) - (K - tail_wt[r]));
    }
    uint32_t tail_mask = ((1u << K) - 1u) << H;

    struct T2 { uint32_t W0, W1, span[4]; std::vector<Block> blocks; };
    std::vector<T2> tasks;
    {
        uint32_t cur_W[2]{}, span[4]{};
        auto gen2 = [&](auto& self, int r, const std::vector<Block>& blocks) -> void {
            if (r == 2) { tasks.push_back({cur_W[0], cur_W[1], {span[0], span[1], span[2], span[3]}, blocks}); return; }
            int nb = (int)blocks.size();
            int ks[28], k_lo[28], k_hi[28];
            int max_blk = 1 << (6 - r);
            for (int bi = 0; bi < nb; ++bi) {
                int len = blocks[bi].len;
                int lim0 = max_blk, lim1 = max_blk;
                if (r == 1) {
                    if (blocks[bi].prefix == 0) { lim0 = 19; lim1 = 12; }
                    else { lim0 = 12; lim1 = 12; }
                }
                k_lo[bi] = std::max(0, len - lim0);
                k_hi[bi] = std::min(len, lim1);
                if (k_lo[bi] > k_hi[bi]) return;
            }
            int prev_sz = 1 << r;
            auto rec = [&](auto& rself, int bi, int used_wt, int cur_dots, uint32_t mask) -> void {
                if (bi == nb) {
                    if ((used_wt & 3) != wt_mod4[r] || cur_dots != req_dots[r]) return;
                    if (used_wt < min_head_wt[r] || used_wt > max_head_wt[r]) return;
                    uint32_t full_row = mask | (tail_W[r] << H);
                    for (int i = 0; i < prev_sz; ++i) {
                        int y6 = i | (1 << r);
                        uint32_t cw = full_row ^ span[i];
                        int w = pop32(cw);
                        int qy = q6m(y6);
                        if ((w & 3) != (qy ? 2 : 0)) return;
                        int mind = qy ? min_d_56 : min_d_64;
                        int mind_c = qy ? min_d_64 : min_d_56;
                        if (w < mind || (m + 1 - w) < mind_c) return;
                        int w1 = pop32(cw ^ tail_mask);
                        if ((w1 & 3) != (qy ? 2 : 0)) return;
                        if (w1 < mind || (m + 1 - w1) < mind_c) return;
                        span[prev_sz + i] = cw;
                    }
                    cur_W[r] = mask;
                    std::vector<Block> nblocks;
                    for (int j = 0; j < nb; ++j) {
                        int s = blocks[j].start, len = blocks[j].len, pref = blocks[j].prefix, k = ks[j];
                        if (len - k > 0) nblocks.push_back({s, len - k, pref});
                        if (k > 0) nblocks.push_back({s + len - k, k, pref | (1 << r)});
                    }
                    self(self, r + 1, nblocks);
                    return;
                }
                int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                for (int k = k_lo[bi]; k <= k_hi[bi]; ++k) {
                    ks[bi] = k;
                    int nd = (k & 1) ? (cur_dots ^ pref) : cur_dots;
                    uint32_t bm = k ? (((1u << k) - 1u) << (s + len - k)) : 0u;
                    rself(rself, bi + 1, used_wt + k, nd, mask | bm);
                }
            };
            rec(rec, 0, 0, 0, 0);
        };
        gen2(gen2, 0, {{0, H, 0}});
    }

    std::atomic<size_t> next_idx{0};
    std::atomic<int> a_valid{0}, a_real{0};

    auto worker = [&]() {
        while (true) {
            size_t ti = next_idx.fetch_add(1);
            if (ti >= tasks.size()) break;
            const auto& tk = tasks[ti];
            uint32_t cur_W[6]{tk.W0, tk.W1, 0, 0, 0, 0};
            uint32_t span_W[64]{};
            for (int i = 0; i < 4; ++i) span_W[i] = tk.span[i];

            auto dfs = [&](auto& self, int r, const std::vector<Block>& blocks) -> void {
                if (r == 6) {
                    int ws[28], cnt[64]{}, first_idx[64];
                    std::fill(first_idx, first_idx + 64, -1);
                    std::vector<std::pair<int,int>> dup_pairs;
                    int zero_idx = -1;
                    for (int j = 0; j < H; ++j) {
                        int w = 0;
                        for (int b = 0; b < 6; ++b) if ((cur_W[b] >> j) & 1u) w |= (1 << b);
                        if (q6m(w) != 0) return;
                        ws[j] = w; cnt[w]++;
                        if (w == 0) { if (cnt[0] > 1) return; zero_idx = j; }
                        else {
                            if (cnt[w] > 2) return;
                            if (cnt[w] == 1) first_idx[w] = j;
                            else dup_pairs.push_back({first_idx[w], j});
                        }
                    }
                    std::vector<std::pair<uint32_t, int>> eqs;
                    eqs.push_back({(1u << H) - 1u, r6_wt_mod4 & 1});
                    for (int b = 0; b < 6; ++b) eqs.push_back({cur_W[b], r6_dot_req[b]});
                    if (zero_idx != -1) eqs.push_back({1u << zero_idx, 1});
                    for (auto [i, j] : dup_pairs) eqs.push_back({(1u << i) | (1u << j), 1});

                    uint32_t pm[28]{}; int pr[28]{}; bool hp[28]{};
                    for (auto [mm, rhs] : eqs) {
                        for (int c = 0; c < H; ++c) if (((mm >> c) & 1u) && hp[c]) { mm ^= pm[c]; rhs ^= pr[c]; }
                        if (mm == 0) { if (rhs != 0) return; }
                        else {
                            int p = __builtin_ctz(mm);
                            for (int c = 0; c < H; ++c) if (hp[c] && ((pm[c] >> p) & 1u)) { pm[c] ^= mm; pr[c] ^= rhs; }
                            pm[p] = mm; pr[p] = rhs; hp[p] = true;
                        }
                    }
                    uint32_t base_b = 0; std::vector<uint32_t> dirs;
                    for (int c = 0; c < H; ++c) {
                        if (hp[c]) { if (pr[c]) base_b |= (1u << c); }
                        else {
                            uint32_t d = 1u << c;
                            for (int p = 0; p < H; ++p) if (hp[p] && ((pm[p] >> c) & 1u)) d |= (1u << p);
                            dirs.push_back(d);
                        }
                    }
                    uint32_t head_r6 = base_b;
                    for (uint32_t s = 0; s < (1u << dirs.size()); ++s) {
                        if (s) head_r6 ^= dirs[__builtin_ctz(s)];
                        if ((pop32(head_r6) & 3) != r6_wt_mod4) continue;
                        uint32_t U8[8]{};
                        for (int b = 0; b < 6; ++b) U8[b] = cur_W[b] | (tail_W[b] << H);
                        U8[6] = head_r6 | (tail_r6 << H);
                        U8[7] = tail_mask;
                        uint32_t cw = 0; bool ok = true;
                        for (int step = 1; step < 256; ++step) {
                            int y = step ^ (step >> 1);
                            cw ^= U8[__builtin_ctz(step)];
                            int w = pop32(cw);
                            int qy = Q8(y);
                            if ((w & 3) != (qy ? 2 : 0)) { ok = false; break; }
                            int mind = qy ? min_d_56 : min_d_64;
                            int mind_c = qy ? min_d_64 : min_d_56;
                            if (w < mind || (m + 1 - w) < mind_c) { ok = false; break; }
                        }
                        if (!ok) continue;
                        std::vector<int> us(m);
                        for (int j = 0; j < H; ++j) us[j] = ws[j] | (((head_r6 >> j) & 1u) << 6);
                        for (int j = 0; j < K; ++j) us[H + j] = u_tail[j];
                        std::sort(us.begin(), us.end());
                        a_valid.fetch_add(1);
                        int st = verify_n26_exact(us, t_target);
                        if (st == 2) { a_real.fetch_add(1); std::cerr << "!!! REAL V FOUND in " << label << " !!!\n"; }
                    }
                    return;
                }
                int nb = (int)blocks.size();
                int ks[28], k_lo[28], k_hi[28], rem_lo[29], rem_hi[29], reach_dots[29], fixed_rem[29];
                for (int bi = 0; bi < nb; ++bi) {
                    int len = blocks[bi].len, pref = blocks[bi].prefix;
                    int lim0, lim1;
                    if (r == 5) {
                        int w0 = pref | (0 << 5), w1 = pref | (1 << 5);
                        lim0 = (q6m(w0) == 0) ? (w0 == 0 ? 1 : 2) : 0;
                        lim1 = (q6m(w1) == 0) ? 2 : 0;
                    } else if (r == 3) {
                        int q01 = (((pref>>0)&1)&((pref>>1)&1)) ^ ((pref>>0)&1) ^ ((pref>>1)&1);
                        int w2 = (pref >> 2) & 1;
                        lim0 = (q01 == 0) ? (pref == 0 ? 5 : 6) : 2;
                        lim1 = ((q01 ^ w2) == 0) ? 6 : 2;
                    } else {
                        int max_blk = 1 << (6 - r);
                        lim0 = max_blk; lim1 = max_blk;
                    }
                    k_lo[bi] = std::max(0, len - lim0);
                    k_hi[bi] = std::min(len, lim1);
                    if (k_lo[bi] > k_hi[bi]) return;
                }
                rem_lo[nb] = 0; rem_hi[nb] = 0; reach_dots[nb] = 0; fixed_rem[nb] = 0;
                for (int bi = nb - 1; bi >= 0; --bi) {
                    rem_lo[bi] = rem_lo[bi + 1] + k_lo[bi];
                    rem_hi[bi] = rem_hi[bi + 1] + k_hi[bi];
                    reach_dots[bi] = reach_dots[bi + 1] | ((k_lo[bi] < k_hi[bi]) ? blocks[bi].prefix : 0);
                    fixed_rem[bi] = fixed_rem[bi + 1] ^ ((k_lo[bi] == k_hi[bi] && (k_lo[bi] & 1)) ? blocks[bi].prefix : 0);
                }
                int lo_w = min_head_wt[r], hi_w = max_head_wt[r];
                int prev_sz = 1 << r;
                auto rec = [&](auto& rself, int bi, int used_wt, int cur_dots, uint32_t mask) -> void {
                    if (used_wt + rem_hi[bi] < lo_w || used_wt + rem_lo[bi] > hi_w) return;
                    if (((cur_dots ^ fixed_rem[bi] ^ req_dots[r]) & ~reach_dots[bi]) != 0) return;
                    if (bi == nb) {
                        if ((used_wt & 3) != wt_mod4[r] || cur_dots != req_dots[r]) return;
                        uint32_t full_row = mask | (tail_W[r] << H);
                        for (int i = 0; i < prev_sz; ++i) {
                            int y6 = i | (1 << r);
                            uint32_t cw = full_row ^ span_W[i];
                            int w = pop32(cw);
                            int qy = q6m(y6);
                            if ((w & 3) != (qy ? 2 : 0)) return;
                            int mind = qy ? min_d_56 : min_d_64;
                            int mind_c = qy ? min_d_64 : min_d_56;
                            if (w < mind || (m + 1 - w) < mind_c) return;
                            int w1 = pop32(cw ^ tail_mask);
                            if ((w1 & 3) != (qy ? 2 : 0)) return;
                            if (w1 < mind || (m + 1 - w1) < mind_c) return;
                            span_W[prev_sz + i] = cw;
                        }
                        cur_W[r] = mask;
                        std::vector<Block> nblocks;
                        for (int j = 0; j < nb; ++j) {
                            int s = blocks[j].start, len = blocks[j].len, pref = blocks[j].prefix, k = ks[j];
                            if (len - k > 0) nblocks.push_back({s, len - k, pref});
                            if (k > 0) nblocks.push_back({s + len - k, k, pref | (1 << r)});
                        }
                        self(self, r + 1, nblocks);
                        return;
                    }
                    int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                    for (int k = k_lo[bi]; k <= k_hi[bi]; ++k) {
                        ks[bi] = k;
                        int nd = (k & 1) ? (cur_dots ^ pref) : cur_dots;
                        uint32_t bm = k ? (((1u << k) - 1u) << (s + len - k)) : 0u;
                        rself(rself, bi + 1, used_wt + k, nd, mask | bm);
                    }
                };
                rec(rec, 0, 0, 0, 0);
            };
            dfs(dfs, 2, tk.blocks);
        }
    };
    std::vector<std::thread> ths;
    for (int t = 0; t < nthreads; ++t) ths.emplace_back(worker);
    for (auto& th : ths) th.join();
    out_valid = a_valid.load(); out_real = a_real.load();
}

int main() {
    auto t0 = std::chrono::steady_clock::now();
    init_tables();
    auto orbs = compute_exact_H64_w8_orbits();
    std::cout << "Total EXACT H64 w=8 orbits: " << orbs.size()
              << " (" << std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count() << "s)\n" << std::flush;
    std::ofstream fout("exact_orbs_H64_w8.txt");
    for (auto& o : orbs) {
        for (size_t i = 0; i < o.size(); ++i) fout << (i ? " " : "") << o[i];
        fout << "\n";
    }
    fout.close();

    // POS CTRL: QR(17) has H_64 w=8 slices! Running m=17, min_d_56=6, min_d_64=8, t=102 across all orbs MUST find QR(17)!
    int pc_v = 0, pc_r = 0;
    for (size_t i = 0; i < orbs.size(); ++i) {
        int v = 0, r = 0;
        run_h64_v0_turbo(17, orbs[i], 6, 8, 102, "PC_QR17", v, r, 8);
        pc_v += v; pc_r += r;
    }
    std::cout << "[POS CTRL QR(17) on H64 w=8] total_valid=" << pc_v << " REAL_V=" << pc_r
              << " (" << std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count() << "s)\n" << std::flush;
    if (pc_r == 0) throw std::logic_error("POS CTRL FAILED!");

    // MAIN: n_0 = 26 (m=25, v=0, n_8=0), d(C) = 8 -> min_d_56=10, min_d_64=8 across ALL exact H64 w=8 orbits!
    auto t1 = std::chrono::steady_clock::now();
    long long tot_v = 0, tot_r = 0;
    for (size_t i = 0; i < orbs.size(); ++i) {
        int v = 0, r = 0;
        run_h64_v0_turbo(25, orbs[i], 10, 8, 100, "n26_H64_w8_orb" + std::to_string(i+1), v, r, 8);
        tot_v += v; tot_r += r;
        if (v > 0 || (i + 1) % 10 == 0 || i + 1 == orbs.size()) {
            double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t1).count();
            std::cout << "  orb " << (i+1) << "/" << orbs.size() << ": valid=" << v << " real_V=" << r
                      << " (cum_valid=" << tot_v << ", cum_real=" << tot_r << ", " << dt << "s)\n" << std::flush;
        }
    }
    std::cout << "\n=== n_0 = 26, H_64 w = 8 (d=8) COMPLETE: total_valid=" << tot_v
              << " REAL_V=" << tot_r << " ===\n";
    return 0;
}
