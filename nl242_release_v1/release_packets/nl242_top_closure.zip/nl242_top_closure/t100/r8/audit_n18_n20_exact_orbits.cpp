// 100.000% EXACT O^-(8,2)-ORBIT AUDITOR FOR n_0 = 18 (v != 0) AND n_0 = 20 (all v)!
// ZERO HISTOGRAM-COLLISION GAP!
// Every single valid code Z_0 generated across ALL exhaustive subcases of:
//   - n_0 = 18 (m = 17, v != 0): d_aff = 2 (H56 w=2, 5 nonzero v-orbs) + d_aff = 4 (H56 w=4, 10 v-orbs)
//   - n_0 = 20 (m = 19, all v):  d_aff = 6 (H64 w=6 5 orbs + H56 w=6 10 orbs all v-orbs)
//                              + d_aff = 4 (H56 w=4, 10 v-orbs)
//                              + d_aff = 2 (H56 w=2, all 6 v-orbs {0,2,4,6,16,18} with verified sym!)
// is EITHER:
//   (a) explicitly matched to an existing orbit rep R by an EXPLICIT LINEAR BIJECTION M in O^-(8,2)
//       verified on ALL 256 vectors x in F_2^8 (Q8(M(x)) == Q8(x) AND (x in Z_0) == (M(x) in R)), OR
//   (b) added as a brand-new exact O^-(8,2) orbit rep and dumped to exact_n18_n20_o8_orbs.txt
//       for EXACT fractions.Fraction L_1 LP dual certification!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <mutex>
#include <set>
#include <sstream>
#include <thread>
#include <vector>

inline int pop8(int x) { return __builtin_popcount(static_cast<unsigned>(x)); }
inline int pop32(uint32_t x) { return __builtin_popcount(x); }
inline int q6p(int w) {
    return ((((w >> 0) & 1) & ((w >> 1) & 1)) ^
            (((w >> 2) & 1) & ((w >> 3) & 1)) ^
            (((w >> 4) & 1) & ((w >> 5) & 1)));
}
inline int q6m(int w) {
    return ((((w >> 0) & 1) & ((w >> 1) & 1)) ^ ((w >> 0) & 1) ^ ((w >> 1) & 1) ^
            (((w >> 2) & 1) & ((w >> 3) & 1)) ^ (((w >> 4) & 1) & ((w >> 5) & 1)));
}
inline int Q8_s(int u) {
    return (((u>>0)&1) + ((u>>1)&1) + (((u>>0)&1)&((u>>1)&1)) +
            (((u>>2)&1)&((u>>3)&1)) + (((u>>4)&1)&((u>>5)&1)) + (((u>>6)&1)&((u>>7)&1)));
}
inline int Q8(int u) { return Q8_s(u) & 1; }
inline int Q8_carry(int u) { int s = Q8_s(u); return (s * (s - 1) / 2) & 1; }
inline int B8(int x, int y) {
    return ((((x>>0)&1)&((y>>1)&1)) ^ (((x>>1)&1)&((y>>0)&1)) ^
            (((x>>2)&1)&((y>>3)&1)) ^ (((x>>3)&1)&((y>>2)&1)) ^
            (((x>>4)&1)&((y>>5)&1)) ^ (((x>>5)&1)&((y>>4)&1)) ^
            (((x>>6)&1)&((y>>7)&1)) ^ (((x>>7)&1)&((y>>6)&1)));
}
void fwht256(int a[256]) {
    for (int st = 1; st < 256; st *= 2)
        for (int i = 0; i < 256; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}

struct Block { int start, len, prefix; };
int mons3[93];
uint8_t Qtab[256], Qcarry[256], Btab[256][256];
std::vector<int> Z_all, F_all;
uint64_t GF_col[120][3], GF_const[3];
int u_to_zidx[256];

void init_tables() {
    int k = 0; for (int m = 0; m < 256; ++m) if (pop8(m) <= 3) mons3[k++] = m;
    std::fill(u_to_zidx, u_to_zidx + 256, -1);
    for (int u = 0; u < 256; ++u) {
        Qtab[u] = (uint8_t)Q8(u); Qcarry[u] = (uint8_t)Q8_carry(u);
        if (!Qtab[u]) { u_to_zidx[u] = (int)Z_all.size(); Z_all.push_back(u); }
        else F_all.push_back(u);
        for (int w = 0; w < 256; ++w) Btab[u][w] = (uint8_t)B8(u, w);
    }
    struct Row { uint64_t m[2]{}; uint64_t id[2]{}; };
    Row A[120];
    for (int i = 0; i < 120; ++i) {
        int u = Z_all[i];
        for (int b = 0; b < 93; ++b) if ((u & mons3[b]) == mons3[b]) A[i].m[b >> 6] |= (1ULL << (b & 63));
        A[i].id[i >> 6] |= (1ULL << (i & 63));
    }
    int piv_cols[93], rk = 0;
    for (int col = 0; col < 93; ++col) {
        int p = -1; for (int i = rk; i < 120; ++i) if ((A[i].m[col >> 6] >> (col & 63)) & 1ULL) { p = i; break; }
        if (p == -1) continue;
        std::swap(A[rk], A[p]);
        for (int i = 0; i < 120; ++i)
            if (i != rk && ((A[i].m[col >> 6] >> (col & 63)) & 1ULL)) {
                A[i].m[0] ^= A[rk].m[0]; A[i].m[1] ^= A[rk].m[1];
                A[i].id[0] ^= A[rk].id[0]; A[i].id[1] ^= A[rk].id[1];
            }
        piv_cols[rk++] = col;
    }
    for (int fi = 0; fi < 136; ++fi) {
        int u = F_all[fi]; uint64_t row[2]{};
        for (int r = 0; r < 84; ++r)
            if ((u & mons3[piv_cols[r]]) == mons3[piv_cols[r]]) { row[0] ^= A[r].id[0]; row[1] ^= A[r].id[1]; }
        int cbit = Qcarry[u];
        for (int j = 0; j < 120; ++j) if ((row[j >> 6] >> (j & 63)) & 1ULL) {
            GF_col[j][fi >> 6] |= (1ULL << (fi & 63));
            if (1 ^ Qcarry[Z_all[j]]) cbit ^= 1;
        }
        if (cbit) GF_const[fi >> 6] |= (1ULL << (fi & 63));
    }
}

struct RepCode {
    std::vector<int> us;
    int v;
    bool inZ[256]{};
    std::vector<int> tags; // per element of us
};

RepCode make_rep(const std::vector<int>& us, int v) {
    RepCode r; r.us = us; r.v = v; r.inZ[0] = true;
    for (int u : us) r.inZ[u] = true;
    r.tags.resize(us.size());
    for (size_t i = 0; i < us.size(); ++i) {
        int u = us[i], degB = 0, tri = 0;
        for (int w : us) {
            if (Btab[u][w]) degB++;
            if (w != u && r.inZ[u ^ w]) tri++;
        }
        r.tags[i] = (degB << 8) | (tri << 2) | (Btab[u][v] << 1) | ((u == v) ? 1 : 0);
    }
    return r;
}

// EXPLICIT VERIFIED O^-(8,2) ISOMORPHISM CHECK:
// Returns true ONLY IF an explicit linear bijection M: F_2^8 -> F_2^8 is found and verified on ALL 256 x in F_2^8
// satisfying Q8(M(x)) == Q8(x), in1[x] == in2[M(x)], and M(v1) == v2!
bool is_o8_isomorphic(const RepCode& A, const RepCode& B) {
    if (A.us.size() != B.us.size() || Qtab[A.v] != Qtab[B.v] || (A.v == 0) != (B.v == 0)) return false;
    int m = (int)A.us.size();
    // Group B elements by tag
    std::map<int, std::vector<int>> b_by_tag;
    for (int i = 0; i < m; ++i) b_by_tag[B.tags[i]].push_back(B.us[i]);
    // Check tag multisets match!
    std::map<int, int> cntA;
    for (int t : A.tags) cntA[t]++;
    if (cntA.size() != b_by_tag.size()) return false;
    for (auto [t, c] : cntA) {
        auto it = b_by_tag.find(t);
        if (it == b_by_tag.end() || (int)it->second.size() != c) return false;
    }
    // Choose a basis b_0..b_7 of F_2^8 from A.us, preferring smallest candidate bucket size!
    std::vector<int> order(m);
    for (int i = 0; i < m; ++i) order[i] = i;
    std::sort(order.begin(), order.end(), [&](int i, int j) {
        return b_by_tag[A.tags[i]].size() < b_by_tag[A.tags[j]].size();
    });
    int bas[8], btag[8], nb = 0;
    int span_chk[256]{}; int nsp = 1; span_chk[0] = 0;
    bool in_sp[256]{}; in_sp[0] = true;
    for (int idx : order) {
        int u = A.us[idx];
        if (in_sp[u]) continue;
        bas[nb] = u; btag[nb] = A.tags[idx]; nb++;
        int old = nsp;
        for (int i = 0; i < old; ++i) { int x = span_chk[i] ^ u; span_chk[nsp++] = x; in_sp[x] = true; }
        if (nb == 8) break;
    }
    if (nb != 8) return false;

    int dom[256], img[256];
    dom[0] = 0; img[0] = 0;
    bool used_r[256]{};
    bool found = false;
    auto bt = [&](auto& self, int k) -> void {
        if (found) return;
        if (k == 8) {
            // Double-check ALL 256 vectors (already checked incrementally, but explicit full check = 100% proof!)
            for (int i = 0; i < 256; ++i) {
                if (Qtab[dom[i]] != Qtab[img[i]]) return;
                if (A.inZ[dom[i]] != B.inZ[img[i]]) return;
                if ((dom[i] == A.v) != (img[i] == B.v)) return;
            }
            found = true;
            return;
        }
        int sz = 1 << k;
        int bk = bas[k];
        for (int rk : b_by_tag[btag[k]]) {
            if (used_r[rk]) continue;
            bool ok = true;
            for (int i = 0; i < sz; ++i) {
                int x = dom[i] ^ bk;
                int y = img[i] ^ rk;
                if (Qtab[x] != Qtab[y] || A.inZ[x] != B.inZ[y] || (x == A.v) != (y == B.v)) { ok = false; break; }
                dom[sz + i] = x; img[sz + i] = y;
            }
            if (!ok) continue;
            used_r[rk] = true;
            self(self, k + 1);
            used_r[rk] = false;
            if (found) return;
        }
    };
    bt(bt, 0);
    return found;
}

std::string quick_inv(const RepCode& R) {
    uint64_t gF[3] = {GF_const[0], GF_const[1], GF_const[2]};
    gF[0] ^= GF_col[u_to_zidx[0]][0]; gF[1] ^= GF_col[u_to_zidx[0]][1]; gF[2] ^= GF_col[u_to_zidx[0]][2];
    for (int u : R.us) {
        int zi = u_to_zidx[u];
        gF[0] ^= GF_col[zi][0]; gF[1] ^= GF_col[zi][1]; gF[2] ^= GF_col[zi][2];
    }
    int fF[256]{};
    for (int fi = 0; fi < 136; ++fi) fF[F_all[fi]] = ((gF[fi >> 6] >> (fi & 63)) & 1ULL) ? 3 : -3;
    fwht256(fF);
    std::map<int, int> h; for (int x = 0; x < 256; ++x) h[std::abs(fF[x])]++;
    std::string s = std::to_string((R.v == 0) ? 2 : (int)Qtab[R.v]) + "|";
    for (auto [val, c] : h) s += std::to_string(val) + ":" + std::to_string(c) + " ";
    return s;
}

struct OrbitStore {
    std::mutex mtx;
    std::map<std::string, std::vector<RepCode>> buckets;
    long long total_codes = 0, total_matched = 0, total_orbs = 0;

    void add_code(const std::vector<int>& us, int v) {
        RepCode rc = make_rep(us, v);
        std::string inv = quick_inv(rc);
        std::lock_guard<std::mutex> lk(mtx);
        total_codes++;
        auto& vec = buckets[inv];
        for (const auto& rep : vec) {
            if (is_o8_isomorphic(rc, rep)) { total_matched++; return; }
        }
        vec.push_back(std::move(rc));
        total_orbs++;
    }
};

void run_h56_fixed_v(int m, const std::vector<int>& u_tail, int v, int min_d_56, int min_d_64,
                     int sym_mode, OrbitStore& store, int nthreads = 8) {
    int K = (int)u_tail.size(), H = m - K, v0 = v & 1;
    if ((K & 3) != ((1 ^ v0) ? 2 : 0)) return;
    int bmap[6] = {2, 3, 4, 5, 6, 7};
    if (sym_mode > 0) { bmap[0]=4; bmap[1]=5; bmap[2]=6; bmap[3]=7; bmap[4]=2; bmap[5]=3; }
    uint32_t tail_W[6]{}, tail_r1 = 0;
    for (int j = 0; j < K; ++j) {
        if ((u_tail[j] >> 1) & 1) tail_r1 |= (1u << j);
        for (int r = 0; r < 6; ++r) if ((u_tail[j] >> bmap[r]) & 1) tail_W[r] |= (1u << j);
    }
    if ((pop32(tail_r1) & 1) == 0) return;
    int wt_mod4[6], req_dots[6], r1_dot_req[6], tail_wt[6];
    for (int r = 0; r < 6; ++r) {
        tail_wt[r] = pop32(tail_W[r]);
        wt_mod4[r] = ((2 * ((v >> bmap[r]) & 1) - tail_wt[r]) % 4 + 4) % 4;
        r1_dot_req[r] = pop32(tail_r1 & tail_W[r]) & 1;
        int rd = 0;
        for (int p = 0; p < r; ++p) {
            int full_dot = ((r == 1 && p == 0) || (r == 3 && p == 2) || (r == 5 && p == 4)) ? 1 : 0;
            if (full_dot ^ (pop32(tail_W[r] & tail_W[p]) & 1)) rd |= (1 << p);
        }
        req_dots[r] = rd;
    }
    int r1_wt_mod4 = ((2 * (1 ^ ((v >> 1) & 1)) - pop32(tail_r1)) % 4 + 4) % 4;
    int qy6[64], yv6[64];
    for (int y6 = 0; y6 < 64; ++y6) {
        int y8 = 0; for (int b = 0; b < 6; ++b) if ((y6 >> b) & 1) y8 |= (1 << bmap[b]);
        qy6[y6] = Qtab[y8]; yv6[y6] = pop8(y8 & v) & 1;
    }
    int min_head_wt[6], max_head_wt[6];
    for (int r = 0; r < 6; ++r) {
        min_head_wt[r] = std::max(min_d_64 - tail_wt[r], min_d_56 - (K - tail_wt[r]));
        max_head_wt[r] = std::min((m + 1 - min_d_56) - tail_wt[r], (m + 1 - min_d_64) - (K - tail_wt[r]));
    }
    static const int sing4[9] = {1, 2, 4, 5, 6, 8, 9, 10, 15};
    static const int stab_e0[8][3] = {
        {2, 4, 8}, {2, 8, 4}, {6, 4, 9}, {6, 9, 4},
        {10, 5, 8}, {10, 8, 5}, {15, 5, 9}, {15, 9, 5}
    };
    static const int dual_stab_v4[8][3] = {
        {1, 4, 8}, {1, 8, 4}, {9, 6, 8}, {5, 10, 4},
        {5, 4, 10}, {9, 8, 6}, {15, 6, 10}, {15, 10, 6}
    };
    uint32_t tail_mask = ((1u << K) - 1u) << H;

    struct T2 { uint32_t W0, W1, span[4]; std::vector<Block> blocks; };
    std::vector<T2> tasks;
    {
        uint32_t cur_W[2]{}, span[4]{};
        auto gen2 = [&](auto& self, int r, const std::vector<Block>& blocks) -> void {
            if (r == 2) { tasks.push_back({cur_W[0], cur_W[1], {span[0], span[1], span[2], span[3]}, blocks}); return; }
            int nb = (int)blocks.size(), max_blk = 1 << (5 - r), ks[28], k_lo[28], k_hi[28];
            for (int bi = 0; bi < nb; ++bi) {
                int len = blocks[bi].len, mz = (blocks[bi].prefix == 0) ? (max_blk - 1) : max_blk;
                k_lo[bi] = std::max(0, len - mz); k_hi[bi] = std::min(len, max_blk);
                if (k_lo[bi] > k_hi[bi]) return;
            }
            int prev_sz = 1 << r;
            auto rec = [&](auto& rself, int bi, int used_wt, int cur_dots, uint32_t mask) -> void {
                if (bi == nb) {
                    if ((used_wt & 3) != wt_mod4[r] || cur_dots != req_dots[r]) return;
                    if (used_wt < min_head_wt[r] || used_wt > max_head_wt[r]) return;
                    if ((sym_mode == 1 || sym_mode == 2) && r == 1 && used_wt < pop32(cur_W[0])) return;
                    uint32_t full_row = mask | (tail_W[r] << H);
                    for (int i = 0; i < prev_sz; ++i) {
                        int y6 = i | (1 << r); uint32_t cw = full_row ^ span[i];
                        int w = pop32(cw), qy = qy6[y6], yv = yv6[y6];
                        if ((w & 3) != ((qy ^ yv) ? 2 : 0)) return;
                        int mind = qy ? min_d_56 : min_d_64, mind_c = qy ? min_d_64 : min_d_56;
                        if (w < mind || (m + 1 - w) < mind_c) return;
                        int w1 = pop32(cw ^ tail_mask), qy1 = 1 ^ qy, yv1 = yv ^ v0;
                        if ((w1 & 3) != ((qy1 ^ yv1) ? 2 : 0)) return;
                        int mind1 = qy1 ? min_d_56 : min_d_64, mind1_c = qy1 ? min_d_64 : min_d_56;
                        if (w1 < mind1 || (m + 1 - w1) < mind1_c) return;
                        span[prev_sz + i] = cw;
                    }
                    cur_W[r] = mask;
                    std::vector<Block> nblocks;
                    for (int j = 0; j < nb; ++j) {
                        int s = blocks[j].start, len = blocks[j].len, pref = blocks[j].prefix, k = ks[j];
                        if (len - k > 0) nblocks.push_back({s, len - k, pref});
                        if (k > 0) nblocks.push_back({s + len - k, k, pref | (1 << r)});
                    }
                    self(self, r + 1, nblocks);
                    return;
                }
                int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                for (int k = k_lo[bi]; k <= k_hi[bi]; ++k) {
                    ks[bi] = k;
                    int nd = (k & 1) ? (cur_dots ^ pref) : cur_dots;
                    uint32_t bm = k ? (((1u << k) - 1u) << (s + len - k)) : 0u;
                    rself(rself, bi + 1, used_wt + k, nd, mask | bm);
                }
            };
            rec(rec, 0, 0, 0, 0);
        };
        gen2(gen2, 0, {{0, H, 0}});
    }

    std::atomic<size_t> next_idx{0};
    auto worker = [&]() {
        while (true) {
            size_t ti = next_idx.fetch_add(1);
            if (ti >= tasks.size()) break;
            const auto& tk = tasks[ti];
            uint32_t cur_W[6]{tk.W0, tk.W1, 0, 0, 0, 0}, span_W[64]{};
            for (int i = 0; i < 4; ++i) span_W[i] = tk.span[i];

            auto check_leaf = [&](uint32_t mask5) {
                cur_W[5] = mask5;
                if ((sym_mode == 1 || sym_mode == 3) && pop32(mask5) < pop32(cur_W[4])) return;
                uint32_t full_row = mask5 | (tail_W[5] << H);
                for (int i = 0; i < 32; ++i) {
                    int y6 = i | 32; uint32_t cw = full_row ^ span_W[i];
                    int w = pop32(cw), qy = qy6[y6], yv = yv6[y6];
                    if ((w & 3) != ((qy ^ yv) ? 2 : 0)) return;
                    int mind = qy ? min_d_56 : min_d_64, mind_c = qy ? min_d_64 : min_d_56;
                    if (w < mind || (m + 1 - w) < mind_c) return;
                    int w1 = pop32(cw ^ tail_mask), qy1 = 1 ^ qy, yv1 = yv ^ v0;
                    if ((w1 & 3) != ((qy1 ^ yv1) ? 2 : 0)) return;
                    int mind1 = qy1 ? min_d_56 : min_d_64, mind1_c = qy1 ? min_d_64 : min_d_56;
                    if (w1 < mind1 || (m + 1 - w1) < mind1_c) return;
                }
                uint32_t head_r1 = 0; int ws[28]; uint64_t seen = 0;
                for (int j = 0; j < H; ++j) {
                    int w = 0;
                    if (sym_mode > 0) {
                        w = (((cur_W[4]>>j)&1u)<<0) | (((cur_W[5]>>j)&1u)<<1) |
                            (((cur_W[0]>>j)&1u)<<2) | (((cur_W[1]>>j)&1u)<<3) |
                            (((cur_W[2]>>j)&1u)<<4) | (((cur_W[3]>>j)&1u)<<5);
                    } else {
                        for (int b = 0; b < 6; ++b) if ((cur_W[b] >> j) & 1u) w |= (1 << b);
                    }
                    if (w == 0 || ((seen >> w) & 1ULL)) return;
                    seen |= (1ULL << w); ws[j] = w;
                    if (q6p(w)) head_r1 |= (1u << j);
                }
                if ((pop32(head_r1) & 3) != r1_wt_mod4) return;
                for (int b = 0; b < 6; ++b) if ((pop32(head_r1 & cur_W[b]) & 1) != r1_dot_req[b]) return;
                uint32_t U8[8]{}; U8[0] = tail_mask; U8[1] = head_r1 | (tail_r1 << H);
                for (int b = 0; b < 6; ++b) U8[bmap[b]] = cur_W[b] | (tail_W[b] << H);
                uint32_t cw = 0;
                for (int step = 1; step < 256; ++step) {
                    int y = step ^ (step >> 1); cw ^= U8[__builtin_ctz(step)];
                    int w = pop32(cw), qy = Qtab[y];
                    if ((w & 3) != ((qy ^ (pop8(y & v) & 1)) ? 2 : 0)) return;
                    int mind = qy ? min_d_56 : min_d_64, mind_c = qy ? min_d_64 : min_d_56;
                    if (w < mind || (m + 1 - w) < mind_c) return;
                }
                std::vector<int> us(m);
                for (int j = 0; j < H; ++j) us[j] = (((head_r1 >> j) & 1u) << 1) | (ws[j] << 2);
                for (int j = 0; j < K; ++j) us[H + j] = u_tail[j];
                std::sort(us.begin(), us.end());
                store.add_code(us, v);
            };

            auto dfs = [&](auto& self, int r, const std::vector<Block>& blocks) -> void {
                int nb = (int)blocks.size();
                if (r == 5) {
                    uint32_t forced_mask = 0; int forced_wt = 0, forced_dots = 0;
                    int free_pos[28], free_pref[28], nf = 0;
                    for (int bi = 0; bi < nb; ++bi) {
                        int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                        if (len > 2 || (len == 2 && pref == 0)) return;
                        if (len == 2 || pref == 0) { forced_mask |= (1u << (s + len - 1)); forced_wt++; forced_dots ^= pref; }
                        else { free_pos[nf] = s; free_pref[nf] = pref; nf++; }
                    }
                    int need_dots = req_dots[5] ^ forced_dots, need_par = (wt_mod4[5] ^ forced_wt) & 1;
                    uint32_t eq[6]{}; int erhs[6]{};
                    for (int b = 0; b < 5; ++b) {
                        erhs[b] = (need_dots >> b) & 1;
                        for (int i = 0; i < nf; ++i) if ((free_pref[i] >> b) & 1) eq[b] |= (1u << i);
                    }
                    erhs[5] = need_par; eq[5] = (nf == 32) ? ~0u : ((1u << nf) - 1u);
                    uint32_t pm[28]{}; int pr[28]{}; bool hp[28]{};
                    for (int e = 0; e < 6; ++e) {
                        uint32_t m_e = eq[e]; int r_e = erhs[e];
                        for (int c = 0; c < nf; ++c) if (((m_e >> c) & 1u) && hp[c]) { m_e ^= pm[c]; r_e ^= pr[c]; }
                        if (m_e == 0) { if (r_e != 0) return; }
                        else {
                            int p = __builtin_ctz(m_e);
                            for (int c = 0; c < nf; ++c) if (hp[c] && ((pm[c] >> p) & 1u)) { pm[c] ^= m_e; pr[c] ^= r_e; }
                            pm[p] = m_e; pr[p] = r_e; hp[p] = true;
                        }
                    }
                    uint32_t base_x = 0, d_x[28]; int nd = 0;
                    for (int c = 0; c < nf; ++c) {
                        if (hp[c]) { if (pr[c]) base_x |= (1u << c); }
                        else { uint32_t d = 1u << c; for (int p = 0; p < nf; ++p) if (hp[p] && ((pm[p] >> c) & 1u)) d |= (1u << p); d_x[nd++] = d; }
                    }
                    auto to_Hmask = [&](uint32_t xv) -> uint32_t {
                        uint32_t hm = 0; while (xv) { int c = __builtin_ctz(xv); hm |= (1u << free_pos[c]); xv &= xv - 1; } return hm;
                    };
                    uint32_t cur_hm = forced_mask | to_Hmask(base_x), d_hm[28];
                    for (int i = 0; i < nd; ++i) d_hm[i] = to_Hmask(d_x[i]);
                    int lo_w = min_head_wt[5], hi_w = max_head_wt[5], wm4 = wt_mod4[5];
                    for (uint32_t s = 0; s < (1u << nd); ++s) {
                        if (s) cur_hm ^= d_hm[__builtin_ctz(s)];
                        int w = pop32(cur_hm);
                        if ((w & 3) != wm4 || w < lo_w || w > hi_w) continue;
                        check_leaf(cur_hm);
                    }
                    return;
                }
                int max_blk = 1 << (5 - r), ks[28], k_lo[28], k_hi[28], rem_lo[29], rem_hi[29], reach_dots[29], fixed_rem[29];
                for (int bi = 0; bi < nb; ++bi) {
                    int len = blocks[bi].len, mz = (blocks[bi].prefix == 0) ? (max_blk - 1) : max_blk;
                    k_lo[bi] = std::max(0, len - mz); k_hi[bi] = std::min(len, max_blk);
                    if (k_lo[bi] > k_hi[bi]) return;
                }
                rem_lo[nb]=0; rem_hi[nb]=0; reach_dots[nb]=0; fixed_rem[nb]=0;
                for (int bi = nb - 1; bi >= 0; --bi) {
                    rem_lo[bi] = rem_lo[bi+1] + k_lo[bi]; rem_hi[bi] = rem_hi[bi+1] + k_hi[bi];
                    reach_dots[bi] = reach_dots[bi+1] | ((k_lo[bi] < k_hi[bi]) ? blocks[bi].prefix : 0);
                    fixed_rem[bi] = fixed_rem[bi+1] ^ ((k_lo[bi] == k_hi[bi] && (k_lo[bi] & 1)) ? blocks[bi].prefix : 0);
                }
                int lo_w = min_head_wt[r], hi_w = max_head_wt[r], prev_sz = 1 << r;
                auto rec = [&](auto& rself, int bi, int used_wt, int cur_dots, uint32_t mask) -> void {
                    if (used_wt + rem_hi[bi] < lo_w || used_wt + rem_lo[bi] > hi_w) return;
                    if (((cur_dots ^ fixed_rem[bi] ^ req_dots[r]) & ~reach_dots[bi]) != 0) return;
                    if (bi == nb) {
                        if ((used_wt & 3) != wt_mod4[r] || cur_dots != req_dots[r]) return;
                        if (sym_mode == 1 || sym_mode == 2) {
                            if (r == 2) {
                                int w0 = pop32(cur_W[0]), w1 = pop32(cur_W[1]), w2 = used_wt;
                                int w02 = pop32(cur_W[0] ^ mask), w12 = pop32(cur_W[1] ^ mask);
                                if (w2 < w0 || w02 < w0 || w12 < w0 || w12 < w1) return;
                            } else if (r == 3) {
                                int wts[16]; for (int i = 0; i < 8; ++i) { wts[i] = pop32(span_W[i]); wts[8+i] = pop32(span_W[i] ^ mask); }
                                int w0 = wts[1]; for (int s : sing4) if (wts[s] < w0) return;
                                std::array<int,3> cur_t = {wts[2], wts[4], wts[8]};
                                for (int si = 1; si < 8; ++si) {
                                    std::array<int,3> tt = {wts[stab_e0[si][0]], wts[stab_e0[si][1]], wts[stab_e0[si][2]]};
                                    if (tt < cur_t) return;
                                }
                            }
                        } else if (sym_mode == 3) {
                            if (r == 2 && pop32(cur_W[0] ^ mask) < pop32(cur_W[0])) return;
                            else if (r == 3) {
                                int wts[16]; for (int i = 0; i < 8; ++i) { wts[i] = pop32(span_W[i]); wts[8+i] = pop32(span_W[i] ^ mask); }
                                std::array<int,3> cur_t = {wts[1], wts[4], wts[8]};
                                for (int si = 1; si < 8; ++si) {
                                    std::array<int,3> tt = {wts[dual_stab_v4[si][0]], wts[dual_stab_v4[si][1]], wts[dual_stab_v4[si][2]]};
                                    if (tt < cur_t) return;
                                }
                            }
                        }
                        uint32_t full_row = mask | (tail_W[r] << H);
                        for (int i = 0; i < prev_sz; ++i) {
                            int y6 = i | (1 << r); uint32_t cw = full_row ^ span_W[i];
                            int w = pop32(cw), qy = qy6[y6], yv = yv6[y6];
                            if ((w & 3) != ((qy ^ yv) ? 2 : 0)) return;
                            int mind = qy ? min_d_56 : min_d_64, mind_c = qy ? min_d_64 : min_d_56;
                            if (w < mind || (m + 1 - w) < mind_c) return;
                            int w1 = pop32(cw ^ tail_mask), qy1 = 1 ^ qy, yv1 = yv ^ v0;
                            if ((w1 & 3) != ((qy1 ^ yv1) ? 2 : 0)) return;
                            int mind1 = qy1 ? min_d_56 : min_d_64, mind1_c = qy1 ? min_d_64 : min_d_56;
                            if (w1 < mind1 || (m + 1 - w1) < mind1_c) return;
                            span_W[prev_sz + i] = cw;
                        }
                        cur_W[r] = mask;
                        std::vector<Block> nblocks;
                        for (int j = 0; j < nb; ++j) {
                            int s = blocks[j].start, len = blocks[j].len, pref = blocks[j].prefix, k = ks[j];
                            if (len - k > 0) nblocks.push_back({s, len - k, pref});
                            if (k > 0) nblocks.push_back({s + len - k, k, pref | (1 << r)});
                        }
                        self(self, r + 1, nblocks);
                        return;
                    }
                    int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
                    for (int k = k_lo[bi]; k <= k_hi[bi]; ++k) {
                        ks[bi] = k;
                        int nd = (k & 1) ? (cur_dots ^ pref) : cur_dots;
                        uint32_t bm = k ? (((1u << k) - 1u) << (s + len - k)) : 0u;
                        rself(rself, bi + 1, used_wt + k, nd, mask | bm);
                    }
                };
                rec(rec, 0, 0, 0, 0);
            };
            dfs(dfs, 2, tk.blocks);
        }
    };
    std::vector<std::thread> ths;
    for (int t = 0; t < nthreads; ++t) ths.emplace_back(worker);
    for (auto& th : ths) th.join();
}

void run_h64_all(int m, const std::vector<int>& u_tail, int min_d_56, int min_d_64, OrbitStore& store, int nthreads = 8) {
    int K = (int)u_tail.size(), H = m - K;
    uint32_t tail_W[6]{}, tail_r6 = 0;
    for (int j = 0; j < K; ++j) {
        if ((u_tail[j] >> 6) & 1) tail_r6 |= (1u << j);
        for (int r = 0; r < 6; ++r) if ((u_tail[j] >> r) & 1) tail_W[r] |= (1u << j);
    }
    if ((pop32(tail_r6) & 1) == 0) return;
    int wt_mod2[6], req_dots[6], r6_dot_req[6], tail_wt[6];
    for (int r = 0; r < 6; ++r) {
        tail_wt[r] = pop32(tail_W[r]); wt_mod2[r] = tail_wt[r] & 1;
        r6_dot_req[r] = pop32(tail_r6 & tail_W[r]) & 1;
        int rd = 0;
        for (int p = 0; p < r; ++p) {
            int full_dot = ((r == 1 && p == 0) || (r == 3 && p == 2) || (r == 5 && p == 4)) ? 1 : 0;
            if (full_dot ^ (pop32(tail_W[r] & tail_W[p]) & 1)) rd |= (1 << p);
        }
        req_dots[r] = rd;
    }
    int r6_wt_mod2 = pop32(tail_r6) & 1;
    int min_head_wt[6], max_head_wt[6];
    for (int r = 0; r < 6; ++r) {
        int q_e = (r < 2) ? 1 : 0;
        int mind = q_e ? min_d_56 : min_d_64, mind_c = q_e ? min_d_64 : min_d_56;
        min_head_wt[r] = std::max(mind - tail_wt[r], mind - (K - tail_wt[r]));
        max_head_wt[r] = std::min((m + 1 - mind_c) - tail_wt[r], (m + 1 - mind_c) - (K - tail_wt[r]));
    }
    uint32_t tail_mask = ((1u << K) - 1u) << H;
    int v7 = (K >> 1) & 1;
    uint32_t cur_W[6]{}, span_W[64]{};
    auto dfs = [&](auto& self, int r, const std::vector<Block>& blocks) -> void {
        if (r == 6) {
            int v_lo = 0;
            for (int b = 0; b < 6; ++b) if (((pop32(span_W[1 << b]) >> 1) & 1) ^ (b < 2 ? 1 : 0)) v_lo |= (1 << b);
            int ws[28], cnt[64]{}, first_idx[64]; std::fill(first_idx, first_idx + 64, -1);
            std::vector<std::pair<int,int>> dup_pairs; int zero_idx = -1;
            for (int j = 0; j < H; ++j) {
                int w = 0; for (int b = 0; b < 6; ++b) if ((cur_W[b] >> j) & 1u) w |= (1 << b);
                if (q6m(w) != 0) return;
                ws[j] = w; cnt[w]++;
                if (w == 0) { if (cnt[0] > 1) return; zero_idx = j; }
                else { if (cnt[w] > 2) return; if (cnt[w] == 1) first_idx[w] = j; else dup_pairs.push_back({first_idx[w], j}); }
            }
            std::vector<std::pair<uint32_t, int>> eqs;
            eqs.push_back({(1u << H) - 1u, r6_wt_mod2});
            for (int b = 0; b < 6; ++b) eqs.push_back({cur_W[b], r6_dot_req[b]});
            if (zero_idx != -1) eqs.push_back({1u << zero_idx, 1});
            for (auto [i, j] : dup_pairs) eqs.push_back({(1u << i) | (1u << j), 1});
            uint32_t pm[28]{}; int pr[28]{}; bool hp[28]{};
            for (auto [mm, rhs] : eqs) {
                for (int c = 0; c < H; ++c) if (((mm >> c) & 1u) && hp[c]) { mm ^= pm[c]; rhs ^= pr[c]; }
                if (mm == 0) { if (rhs != 0) return; }
                else {
                    int p = __builtin_ctz(mm);
                    for (int c = 0; c < H; ++c) if (hp[c] && ((pm[c] >> p) & 1u)) { pm[c] ^= mm; pr[c] ^= rhs; }
                    pm[p] = mm; pr[p] = rhs; hp[p] = true;
                }
            }
            uint32_t base_b = 0; std::vector<uint32_t> dirs;
            for (int c = 0; c < H; ++c) {
                if (hp[c]) { if (pr[c]) base_b |= (1u << c); }
                else { uint32_t d = 1u << c; for (int p = 0; p < H; ++p) if (hp[p] && ((pm[p] >> c) & 1u)) d |= (1u << p); dirs.push_back(d); }
            }
            uint32_t head_r6 = base_b;
            for (uint32_t s = 0; s < (1u << dirs.size()); ++s) {
                if (s) head_r6 ^= dirs[__builtin_ctz(s)];
                uint32_t full_r6 = head_r6 | (tail_r6 << H);
                int v = v_lo | (((pop32(full_r6) >> 1) & 1) << 6) | (v7 << 7);
                uint32_t U8[8]{}; for (int b = 0; b < 6; ++b) U8[b] = cur_W[b] | (tail_W[b] << H);
                U8[6] = full_r6; U8[7] = tail_mask;
                uint32_t cw = 0; bool ok = true;
                for (int step = 1; step < 256; ++step) {
                    int y = step ^ (step >> 1); cw ^= U8[__builtin_ctz(step)];
                    int w = pop32(cw), qy = Qtab[y];
                    if ((w & 3) != ((qy ^ (pop8(y & v) & 1)) ? 2 : 0)) { ok = false; break; }
                    int mind = qy ? min_d_56 : min_d_64, mind_c = qy ? min_d_64 : min_d_56;
                    if (w < mind || (m + 1 - w) < mind_c) { ok = false; break; }
                }
                if (!ok) continue;
                std::vector<int> us(m);
                for (int j = 0; j < H; ++j) us[j] = ws[j] | (((head_r6 >> j) & 1u) << 6);
                for (int j = 0; j < K; ++j) us[H + j] = u_tail[j];
                std::sort(us.begin(), us.end());
                store.add_code(us, v);
            }
            return;
        }
        int nb = (int)blocks.size(), ks[28], k_lo[28], k_hi[28];
        for (int bi = 0; bi < nb; ++bi) {
            int len = blocks[bi].len, pref = blocks[bi].prefix, lim0, lim1;
            if (r == 5) { int w0 = pref, w1 = pref | 32; lim0 = (q6m(w0)==0)?(w0==0?1:2):0; lim1 = (q6m(w1)==0)?2:0; }
            else if (r == 3) {
                int q01 = (((pref>>0)&1)&((pref>>1)&1)) ^ ((pref>>0)&1) ^ ((pref>>1)&1), w2 = (pref>>2)&1;
                lim0 = (q01==0)?(pref==0?5:6):2; lim1 = ((q01^w2)==0)?6:2;
            } else if (r == 1) {
                if (pref == 0) { lim0 = 19; lim1 = 12; } else { lim0 = 12; lim1 = 12; }
            } else { int max_blk = 1 << (6 - r); lim0 = max_blk; lim1 = max_blk; }
            k_lo[bi] = std::max(0, len - lim0); k_hi[bi] = std::min(len, lim1);
            if (k_lo[bi] > k_hi[bi]) return;
        }
        int prev_sz = 1 << r, v_pref = 0;
        for (int b = 0; b < r; ++b) if (((pop32(span_W[1 << b]) >> 1) & 1) ^ (b < 2 ? 1 : 0)) v_pref |= (1 << b);
        auto rec = [&](auto& rself, int bi, int used_wt, int cur_dots, uint32_t mask) -> void {
            if (bi == nb) {
                if ((used_wt & 1) != wt_mod2[r] || cur_dots != req_dots[r]) return;
                if (used_wt < min_head_wt[r] || used_wt > max_head_wt[r]) return;
                uint32_t full_row = mask | (tail_W[r] << H);
                int vr = ((pop32(full_row) >> 1) & 1) ^ ((r < 2) ? 1 : 0), v_cur = v_pref | (vr << r);
                for (int i = 0; i < prev_sz; ++i) {
                    int y6 = i | (1 << r); uint32_t cw = full_row ^ span_W[i];
                    int w = pop32(cw), qy = q6m(y6), tgt = (qy ^ (pop8(y6 & v_cur) & 1)) ? 2 : 0;
                    if ((w & 3) != tgt) return;
                    int mind = qy ? min_d_56 : min_d_64, mind_c = qy ? min_d_64 : min_d_56;
                    if (w < mind || (m + 1 - w) < mind_c) return;
                    int w1 = pop32(cw ^ tail_mask);
                    if (w1 < mind || (m + 1 - w1) < mind_c || (w1 & 3) != (tgt ^ (v7 << 1))) return;
                    span_W[prev_sz + i] = cw;
                }
                cur_W[r] = mask;
                std::vector<Block> nblocks;
                for (int j = 0; j < nb; ++j) {
                    int s = blocks[j].start, len = blocks[j].len, pref = blocks[j].prefix, k = ks[j];
                    if (len - k > 0) nblocks.push_back({s, len - k, pref});
                    if (k > 0) nblocks.push_back({s + len - k, k, pref | (1 << r)});
                }
                self(self, r + 1, nblocks);
                return;
            }
            int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
            for (int k = k_lo[bi]; k <= k_hi[bi]; ++k) {
                ks[bi] = k;
                int nd = (k & 1) ? (cur_dots ^ pref) : cur_dots;
                uint32_t bm = k ? (((1u << k) - 1u) << (s + len - k)) : 0u;
                rself(rself, bi + 1, used_wt + k, nd, mask | bm);
            }
        };
        rec(rec, 0, 0, 0, 0);
    };
    dfs(dfs, 0, {{0, H, 0}});
}

int main() {
    auto t0 = std::chrono::steady_clock::now();
    init_tables();

    struct VOrbEntry { std::string name; std::vector<int> tail, vs_all, vs_nz; };
    std::vector<VOrbEntry> entries;
    {
        std::ifstream fvo("exact_v_orbits.txt");
        std::string ln;
        while (std::getline(fvo, ln)) {
            if (ln.empty()) continue;
            auto p1 = ln.find('|'), p2 = ln.find("| Q1:"), p3 = ln.find("| Q0:");
            VOrbEntry e;
            e.name = ln.substr(0, p1);
            while (!e.name.empty() && e.name.back() == ' ') e.name.pop_back();
            { std::istringstream iss(ln.substr(p1 + 1, p2 - p1 - 1)); int u; while (iss >> u) e.tail.push_back(u); }
            { std::istringstream iss(ln.substr(p2 + 5, p3 - p2 - 5)); int v; while (iss >> v) { e.vs_all.push_back(v); if (v) e.vs_nz.push_back(v); } }
            { std::istringstream iss(ln.substr(p3 + 5)); int v; while (iss >> v) { e.vs_all.push_back(v); if (v) e.vs_nz.push_back(v); } }
            entries.push_back(e);
        }
    }

    OrbitStore s18, s20;
    // 1. n_0 = 18 (m = 17, v != 0): d = 2 (H56_w2, 5 nz v-orbs) + d = 4 (H56_w4, 10 v-orbs)
    for (const auto& e : entries) {
        int K = (int)e.tail.size();
        if (K == 2 || K == 4) {
            for (int v : e.vs_nz) {
                int sm = 0;
                if (K == 2) sm = (v == 2) ? 1 : ((v == 4 || v == 6) ? 2 : 3);
                run_h56_fixed_v(17, e.tail, v, K, 6, sm, s18, 8);
            }
        }
    }
    std::cout << "[n_0=18 v!=0 EXACT O^-(8,2) ORBIT AUDIT] total_codes=" << s18.total_codes
              << " iso_matched=" << s18.total_matched << " EXACT_O8_ORBITS=" << s18.total_orbs
              << " (hists=" << s18.buckets.size() << ")\n" << std::flush;

    // 2. n_0 = 20 (m = 19, ALL v): H64_w6 (5 orbs) + H56_w6 (10 orbs) + H56_w4 + H56_w2 (all 6 v-orbs {0,2,4,6,16,18})!
    {
        std::ifstream fin("exact_orbs_H64_w6.txt");
        std::string ln;
        while (std::getline(fin, ln)) {
            if (ln.empty()) continue;
            std::istringstream iss(ln.substr(0, ln.find('|')));
            std::vector<int> us; int u; while (iss >> u) us.push_back(u);
            run_h64_all(19, us, 6, 6, s20, 8);
        }
    }
    for (const auto& e : entries) {
        int K = (int)e.tail.size();
        for (int v : e.vs_all) {
            int sm = 0;
            if (K == 2) sm = (v == 0 || v == 2) ? 1 : ((v == 4 || v == 6) ? 2 : 3);
            run_h56_fixed_v(19, e.tail, v, K, 6, sm, s20, 8);
        }
    }
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "[n_0=20 ALL-v EXACT O^-(8,2) ORBIT AUDIT] total_codes=" << s20.total_codes
              << " iso_matched=" << s20.total_matched << " EXACT_O8_ORBITS=" << s20.total_orbs
              << " (hists=" << s20.buckets.size() << ", " << dt << "s)\n" << std::flush;

    std::ofstream fout("exact_n18_n20_o8_orbs.txt");
    for (const auto& [inv, vec] : s18.buckets)
        for (size_t i = 0; i < vec.size(); ++i) {
            fout << "n18 | 4 | " << vec[i].v << " | " << inv << " |";
            for (int u : vec[i].us) fout << " " << u;
            fout << "\n";
        }
    for (const auto& [inv, vec] : s20.buckets)
        for (size_t i = 0; i < vec.size(); ++i) {
            fout << "n20 | 3 | " << vec[i].v << " | " << inv << " |";
            for (int u : vec[i].us) fout << " " << u;
            fout << "\n";
        }
    std::cout << "Dumped ALL " << (s18.total_orbs + s20.total_orbs)
              << " EXACT O^-(8,2) orbit reps to exact_n18_n20_o8_orbs.txt!\n";
    return 0;
}
