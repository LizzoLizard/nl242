// Non-empty positive control for sym_mode = 1, 2, 3 on H56_w2 ({13, 15}):
// Test m = 15 (n_0 = 16) with min_d_56 = 2, min_d_64 = 4 (non-empty for ALL 5 nonzero v reps {2, 4, 6, 16, 18}!)
// AND m = 19 (n_0 = 20) with min_d_56 = 2, min_d_64 = 6 for v = 2 (sym 0 vs 1) and v = 6 (sym 0 vs 2)!
// Asserts that sym=0 and sym>0 find the EXACT SAME set of (v, |wF| hist) pairs!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <mutex>
#include <set>
#include <thread>
#include <vector>

inline int pop8(int x) { return __builtin_popcount(static_cast<unsigned>(x)); }
inline int pop32(uint32_t x) { return __builtin_popcount(x); }
inline int q6p(int w) {
    return ((((w >> 0) & 1) & ((w >> 1) & 1)) ^
            (((w >> 2) & 1) & ((w >> 3) & 1)) ^
            (((w >> 4) & 1) & ((w >> 5) & 1)));
}
inline int Q8_s(int u) {
    return (((u>>0)&1) + ((u>>1)&1) + (((u>>0)&1)&((u>>1)&1)) +
            (((u>>2)&1)&((u>>3)&1)) + (((u>>4)&1)&((u>>5)&1)) + (((u>>6)&1)&((u>>7)&1)));
}
inline int Q8(int u) { return Q8_s(u) & 1; }
inline int Q8_carry(int u) { int s = Q8_s(u); return (s * (s - 1) / 2) & 1; }
void fwht256(int a[256]) {
    for (int st = 1; st < 256; st *= 2)
        for (int i = 0; i < 256; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
struct Block { int start, len, prefix; };
int mons3[93]; uint8_t Qtab[256], Qcarry[256];
std::vector<int> Z_all, F_all;
uint64_t GF_col[120][3], GF_const[3]; int u_to_zidx[256];
void init_tables() {
    int k = 0; for (int m = 0; m < 256; ++m) if (pop8(m) <= 3) mons3[k++] = m;
    std::fill(u_to_zidx, u_to_zidx + 256, -1);
    for (int u = 0; u < 256; ++u) {
        Qtab[u] = (uint8_t)Q8(u); Qcarry[u] = (uint8_t)Q8_carry(u);
        if (!Qtab[u]) { u_to_zidx[u] = (int)Z_all.size(); Z_all.push_back(u); }
        else F_all.push_back(u);
    }
    struct Row { uint64_t m[2]{}; uint64_t id[2]{}; };
    Row A[120];
    for (int i = 0; i < 120; ++i) {
        int u = Z_all[i];
        for (int b = 0; b < 93; ++b) if ((u & mons3[b]) == mons3[b]) A[i].m[b >> 6] |= (1ULL << (b & 63));
        A[i].id[i >> 6] |= (1ULL << (i & 63));
    }
    int piv_cols[93], rk = 0;
    for (int col = 0; col < 93; ++col) {
        int p = -1; for (int i = rk; i < 120; ++i) if ((A[i].m[col >> 6] >> (col & 63)) & 1ULL) { p = i; break; }
        if (p == -1) continue;
        std::swap(A[rk], A[p]);
        for (int i = 0; i < 120; ++i)
            if (i != rk && ((A[i].m[col >> 6] >> (col & 63)) & 1ULL)) {
                A[i].m[0] ^= A[rk].m[0]; A[i].m[1] ^= A[rk].m[1];
                A[i].id[0] ^= A[rk].id[0]; A[i].id[1] ^= A[rk].id[1];
            }
        piv_cols[rk++] = col;
    }
    for (int fi = 0; fi < 136; ++fi) {
        int u = F_all[fi]; uint64_t row[2]{};
        for (int r = 0; r < 84; ++r)
            if ((u & mons3[piv_cols[r]]) == mons3[piv_cols[r]]) { row[0] ^= A[r].id[0]; row[1] ^= A[r].id[1]; }
        int cbit = Qcarry[u];
        for (int j = 0; j < 120; ++j) if ((row[j >> 6] >> (j & 63)) & 1ULL) {
            GF_col[j][fi >> 6] |= (1ULL << (fi & 63));
            if (1 ^ Qcarry[Z_all[j]]) cbit ^= 1;
        }
        if (cbit) GF_const[fi >> 6] |= (1ULL << (fi & 63));
    }
}
std::string hist_of(const std::vector<int>& us) {
    uint64_t gF[3] = {GF_const[0], GF_const[1], GF_const[2]};
    int z0_0 = u_to_zidx[0];
    gF[0] ^= GF_col[z0_0][0]; gF[1] ^= GF_col[z0_0][1]; gF[2] ^= GF_col[z0_0][2];
    for (int u : us) { int zi = u_to_zidx[u]; gF[0] ^= GF_col[zi][0]; gF[1] ^= GF_col[zi][1]; gF[2] ^= GF_col[zi][2]; }
    int fF[256]{};
    for (int fi = 0; fi < 136; ++fi) fF[F_all[fi]] = ((gF[fi >> 6] >> (fi & 63)) & 1ULL) ? 3 : -3;
    fwht256(fF);
    std::map<int, int> h; for (int x = 0; x < 256; ++x) h[std::abs(fF[x])]++;
    std::string hs; for (auto [k, v] : h) hs += std::to_string(k) + ":" + std::to_string(v) + " ";
    return hs;
}

std::pair<long long, std::set<std::string>> run_test(int m, int v, int min_d_56, int min_d_64, int sym_mode) {
    std::vector<int> u_tail = {13, 15};
    int K = 2, H = m - 2, v0 = v & 1;
    int bmap[6] = {2, 3, 4, 5, 6, 7};
    if (sym_mode > 0) { bmap[0]=4; bmap[1]=5; bmap[2]=6; bmap[3]=7; bmap[4]=2; bmap[5]=3; }
    uint32_t tail_W[6]{}, tail_r1 = 0;
    for (int j = 0; j < K; ++j) {
        if ((u_tail[j] >> 1) & 1) tail_r1 |= (1u << j);
        for (int r = 0; r < 6; ++r) if ((u_tail[j] >> bmap[r]) & 1) tail_W[r] |= (1u << j);
    }
    int wt_mod4[6], req_dots[6], r1_dot_req[6], tail_wt[6];
    for (int r = 0; r < 6; ++r) {
        tail_wt[r] = pop32(tail_W[r]);
        wt_mod4[r] = ((2 * ((v >> bmap[r]) & 1) - tail_wt[r]) % 4 + 4) % 4;
        r1_dot_req[r] = pop32(tail_r1 & tail_W[r]) & 1;
        int rd = 0;
        for (int p = 0; p < r; ++p) {
            int full_dot = ((r == 1 && p == 0) || (r == 3 && p == 2) || (r == 5 && p == 4)) ? 1 : 0;
            if (full_dot ^ (pop32(tail_W[r] & tail_W[p]) & 1)) rd |= (1 << p);
        }
        req_dots[r] = rd;
    }
    int r1_wt_mod4 = ((2 * (1 ^ ((v >> 1) & 1)) - pop32(tail_r1)) % 4 + 4) % 4;
    int qy6[64], yv6[64];
    for (int y6 = 0; y6 < 64; ++y6) {
        int y8 = 0; for (int b = 0; b < 6; ++b) if ((y6 >> b) & 1) y8 |= (1 << bmap[b]);
        qy6[y6] = Qtab[y8]; yv6[y6] = pop8(y8 & v) & 1;
    }
    int min_head_wt[6], max_head_wt[6];
    for (int r = 0; r < 6; ++r) {
        min_head_wt[r] = std::max(min_d_64 - tail_wt[r], min_d_56 - (K - tail_wt[r]));
        max_head_wt[r] = std::min((m + 1 - min_d_56) - tail_wt[r], (m + 1 - min_d_64) - (K - tail_wt[r]));
    }
    static const int sing4[9] = {1, 2, 4, 5, 6, 8, 9, 10, 15};
    static const int stab_e0[8][3] = {
        {2, 4, 8}, {2, 8, 4}, {6, 4, 9}, {6, 9, 4},
        {10, 5, 8}, {10, 8, 5}, {15, 5, 9}, {15, 9, 5}
    };
    static const int dual_stab_v4[8][3] = {
        {1, 4, 8}, {1, 8, 4}, {9, 6, 8}, {5, 10, 4},
        {5, 4, 10}, {9, 8, 6}, {15, 6, 10}, {15, 10, 6}
    };
    uint32_t tail_mask = ((1u << K) - 1u) << H;
    uint32_t cur_W[6]{}, span_W[64]{};
    long long valid = 0; std::set<std::string> hists;

    auto dfs = [&](auto& self, int r, const std::vector<Block>& blocks) -> void {
        if (r == 6) {
            uint32_t head_r1 = 0; int ws[28]; uint64_t seen = 0;
            for (int j = 0; j < H; ++j) {
                int w = 0;
                if (sym_mode > 0) {
                    w = (((cur_W[4]>>j)&1u)<<0) | (((cur_W[5]>>j)&1u)<<1) |
                        (((cur_W[0]>>j)&1u)<<2) | (((cur_W[1]>>j)&1u)<<3) |
                        (((cur_W[2]>>j)&1u)<<4) | (((cur_W[3]>>j)&1u)<<5);
                } else {
                    for (int b = 0; b < 6; ++b) if ((cur_W[b] >> j) & 1u) w |= (1 << b);
                }
                if (w == 0 || ((seen >> w) & 1ULL)) return;
                seen |= (1ULL << w); ws[j] = w;
                if (q6p(w)) head_r1 |= (1u << j);
            }
            if ((pop32(head_r1) & 3) != r1_wt_mod4) return;
            for (int b = 0; b < 6; ++b) if ((pop32(head_r1 & cur_W[b]) & 1) != r1_dot_req[b]) return;
            uint32_t U8[8]{}; U8[0] = tail_mask; U8[1] = head_r1 | (tail_r1 << H);
            for (int b = 0; b < 6; ++b) U8[bmap[b]] = cur_W[b] | (tail_W[b] << H);
            uint32_t cw = 0;
            for (int step = 1; step < 256; ++step) {
                int y = step ^ (step >> 1); cw ^= U8[__builtin_ctz(step)];
                int w = pop32(cw), qy = Qtab[y];
                if ((w & 3) != ((qy ^ (pop8(y & v) & 1)) ? 2 : 0)) return;
                int mind = qy ? min_d_56 : min_d_64, mind_c = qy ? min_d_64 : min_d_56;
                if (w < mind || (m + 1 - w) < mind_c) return;
            }
            std::vector<int> us(m);
            for (int j = 0; j < H; ++j) us[j] = (((head_r1 >> j) & 1u) << 1) | (ws[j] << 2);
            for (int j = 0; j < K; ++j) us[H + j] = u_tail[j];
            valid++; hists.insert(hist_of(us));
            return;
        }
        int nb = (int)blocks.size(), max_blk = 1 << (5 - r);
        int ks[28], k_lo[28], k_hi[28], rem_lo[29], rem_hi[29], reach_dots[29], fixed_rem[29];
        for (int bi = 0; bi < nb; ++bi) {
            int len = blocks[bi].len, mz = (blocks[bi].prefix == 0) ? (max_blk - 1) : max_blk;
            k_lo[bi] = std::max(0, len - mz); k_hi[bi] = std::min(len, max_blk);
            if (k_lo[bi] > k_hi[bi]) return;
        }
        rem_lo[nb]=0; rem_hi[nb]=0; reach_dots[nb]=0; fixed_rem[nb]=0;
        for (int bi = nb - 1; bi >= 0; --bi) {
            rem_lo[bi] = rem_lo[bi+1] + k_lo[bi]; rem_hi[bi] = rem_hi[bi+1] + k_hi[bi];
            reach_dots[bi] = reach_dots[bi+1] | ((k_lo[bi] < k_hi[bi]) ? blocks[bi].prefix : 0);
            fixed_rem[bi] = fixed_rem[bi+1] ^ ((k_lo[bi] == k_hi[bi] && (k_lo[bi] & 1)) ? blocks[bi].prefix : 0);
        }
        int lo_w = min_head_wt[r], hi_w = max_head_wt[r], prev_sz = 1 << r;
        auto rec = [&](auto& rself, int bi, int used_wt, int cur_dots, uint32_t mask) -> void {
            if (used_wt + rem_hi[bi] < lo_w || used_wt + rem_lo[bi] > hi_w) return;
            if (((cur_dots ^ fixed_rem[bi] ^ req_dots[r]) & ~reach_dots[bi]) != 0) return;
            if (bi == nb) {
                if ((used_wt & 3) != wt_mod4[r] || cur_dots != req_dots[r]) return;
                if ((sym_mode == 1 || sym_mode == 2) && r == 1 && used_wt < pop32(cur_W[0])) return;
                if ((sym_mode == 1 || sym_mode == 3) && r == 5 && used_wt < pop32(cur_W[4])) return;
                if (sym_mode == 1 || sym_mode == 2) {
                    if (r == 2) {
                        int w0 = pop32(cur_W[0]), w1 = pop32(cur_W[1]), w2 = used_wt;
                        int w02 = pop32(cur_W[0] ^ mask), w12 = pop32(cur_W[1] ^ mask);
                        if (w2 < w0 || w02 < w0 || w12 < w0 || w12 < w1) return;
                    } else if (r == 3) {
                        int wts[16];
                        for (int i = 0; i < 8; ++i) { wts[i] = pop32(span_W[i]); wts[8+i] = pop32(span_W[i] ^ mask); }
                        int w0 = wts[1]; for (int s : sing4) if (wts[s] < w0) return;
                        std::array<int,3> cur_t = {wts[2], wts[4], wts[8]};
                        for (int si = 1; si < 8; ++si) {
                            std::array<int,3> tt = {wts[stab_e0[si][0]], wts[stab_e0[si][1]], wts[stab_e0[si][2]]};
                            if (tt < cur_t) return;
                        }
                    }
                } else if (sym_mode == 3) {
                    if (r == 2 && pop32(cur_W[0] ^ mask) < pop32(cur_W[0])) return;
                    else if (r == 3) {
                        int wts[16];
                        for (int i = 0; i < 8; ++i) { wts[i] = pop32(span_W[i]); wts[8+i] = pop32(span_W[i] ^ mask); }
                        std::array<int,3> cur_t = {wts[1], wts[4], wts[8]};
                        for (int si = 1; si < 8; ++si) {
                            std::array<int,3> tt = {wts[dual_stab_v4[si][0]], wts[dual_stab_v4[si][1]], wts[dual_stab_v4[si][2]]};
                            if (tt < cur_t) return;
                        }
                    }
                }
                uint32_t full_row = mask | (tail_W[r] << H);
                for (int i = 0; i < prev_sz; ++i) {
                    int y6 = i | (1 << r); uint32_t cw = full_row ^ span_W[i];
                    int w = pop32(cw), qy = qy6[y6], yv = yv6[y6];
                    if ((w & 3) != ((qy ^ yv) ? 2 : 0)) return;
                    int mind = qy ? min_d_56 : min_d_64, mind_c = qy ? min_d_64 : min_d_56;
                    if (w < mind || (m + 1 - w) < mind_c) return;
                    int w1 = pop32(cw ^ tail_mask), qy1 = 1 ^ qy, yv1 = yv ^ v0;
                    if ((w1 & 3) != ((qy1 ^ yv1) ? 2 : 0)) return;
                    int mind1 = qy1 ? min_d_56 : min_d_64, mind1_c = qy1 ? min_d_64 : min_d_56;
                    if (w1 < mind1 || (m + 1 - w1) < mind1_c) return;
                    span_W[prev_sz + i] = cw;
                }
                cur_W[r] = mask;
                std::vector<Block> nblocks;
                for (int j = 0; j < nb; ++j) {
                    int s = blocks[j].start, len = blocks[j].len, pref = blocks[j].prefix, k = ks[j];
                    if (len - k > 0) nblocks.push_back({s, len - k, pref});
                    if (k > 0) nblocks.push_back({s + len - k, k, pref | (1 << r)});
                }
                self(self, r + 1, nblocks);
                return;
            }
            int s = blocks[bi].start, len = blocks[bi].len, pref = blocks[bi].prefix;
            for (int k = k_lo[bi]; k <= k_hi[bi]; ++k) {
                ks[bi] = k;
                int nd = (k & 1) ? (cur_dots ^ pref) : cur_dots;
                uint32_t bm = k ? (((1u << k) - 1u) << (s + len - k)) : 0u;
                rself(rself, bi + 1, used_wt + k, nd, mask | bm);
            }
        };
        rec(rec, 0, 0, 0, 0);
    };
    dfs(dfs, 0, {{0, H, 0}});
    return {valid, hists};
}

int main() {
    init_tables();
    for (auto [m_t, v, sm] : std::vector<std::tuple<int,int,int>>{{19, 2, 1}, {15, 4, 2}, {15, 6, 2}, {15, 16, 3}, {15, 18, 3}}) {
        int d64 = (m_t == 19) ? 6 : 4;
        auto [v0, h0] = run_test(m_t, v, 2, d64, 0);
        auto [v1, h1] = run_test(m_t, v, 2, d64, sm);
        std::cout << "m=" << m_t << " d64=" << d64 << " v=" << v << " sym=" << sm
                  << ": sym0=(valid=" << v0 << ", hists=" << h0.size()
                  << ") sym" << sm << "=(valid=" << v1 << ", hists=" << h1.size() << ")";
        if (h0 == h1 && v0 > 0) std::cout << "  [NON-EMPTY EXACT MATCH PASS!]\n";
        else { std::cout << "  [MISMATCH or EMPTY!]\n"; if (h0 != h1) return 1; }
    }
    return 0;
}
