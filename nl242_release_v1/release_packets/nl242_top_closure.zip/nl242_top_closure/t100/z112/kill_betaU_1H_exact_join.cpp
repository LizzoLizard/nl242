// Exact H x H^c high-block 4-slice solver for ALL 5 remaining beta_U = 1_H cases:
//   1. h16_p0_a (0x110011008700ff, F=0): ZERO free allocs on H^c and H!
//   2. h10_p0_a (0x1100ff, F=0):         rem=6 => ALL 3 u_x have m_2=2 on H, ZERO free allocs on H^c!
//   3. h14_p2_a (0x88001100110077, F=0x11) + ALL other h14_p2 hits with rem >= 6!
//   4. h14_p2_e (0x3300ff, F=0x44):      rem=6 => ALL 3 u_x have m_2=2 on H, ZERO free allocs on H^c!
//   5. h14_p1   (0x30030d3f, F=0x1):     rem<=2 => min u_x has cost=0 on H (232 d's!), extra cost<=2 on H^c!
//
// CRITICAL COORDINATE CARE:
//   We must keep H and H^c in COMPATIBLE F_2^5 coordinates!
//   Let u_dir = XOR(V_0) != 0. Pick a basis e_0, e_1, e_2, e_3, e_4 of u_dir^perp = {c : c . u_dir == 0},
//   and pick a shift vector v_shift with v_shift . u_dir == 1.
//   Then:
//     - H_0 = {sum_i a_i e_i} (a in F_2^5)
//     - H_1 = {v_shift ^ sum_i a_i e_i} (a in F_2^5)
//   One of H_0, H_1 is the odd-level half H, and the other is the even-level half H^c!
//   Let c_H(a) and c_Hc(a) be those paired points differing by v_shift!
//   Check WHT_6(u_x) along this exact pairing:
//     For y in F_2^6, split y by (y . v_shift) in {0, 1}, and project y onto the 5 linear forms (e_0.y, ..., e_4.y) in F_2^5!
//     Wait: since e_0..e_4 are linearly independent and v_shift is NOT in span(e_0..e_4), the map
//       y -> (b = y.v_shift, y' = (e_0.y, ..., e_4.y)) is a BIJECTION F_2^6 -> F_2 x F_2^5!
//     Then for any a in F_2^5:
//       u_hat(c_0(a)) = sum_y u(y) (-1)^{a . y'} = WHT_5(u(0, .) + u(1, .))(a) = WHT_5(s)(a)!!
//       u_hat(c_1(a)) = sum_y u(y) (-1)^{b + a . y'} = WHT_5(u(0, .) - u(1, .))(a) = WHT_5(d)(a)!!
//     Notice s(y') = u(0, y') + u(1, y') and d(y') = u(0, y') - u(1, y') are in the EXACT SAME y' in F_2^5 coordinates!
//     (Whether H is c_0 and H^c is c_1, or H is c_1 and H^c is c_0, swapping s <-> d still satisfies
//      s(y') == d(y') (mod 2) and tw_s & tw_d == 0 pointwise in y'!!)
//   MANDATORY POSITIVE CONTROL: Test a REAL u : F_2^6 -> {-1, 0, +1} with beta_U = 1_H and verify
//   our paired (H, H^c) extraction + join FINDS IT with 100% accuracy!
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

static int Q[64];
static void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static void fwht64(std::array<int, 64>& a) {
    for (int st = 1; st < 64; st *= 2)
        for (int i = 0; i < 64; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}

static std::array<int, 64> get_levels(uint64_t Em, uint64_t Fm) {
    std::array<int, 64> lv{};
    for (int c = 0; c < 64; ++c) {
        int s = 0;
        for (uint64_t t = Em; t; t &= t - 1) { int y = __builtin_ctzll(t); s += Q[y] * (__builtin_parity(y & c) ? -1 : 1); }
        for (uint64_t t = Fm; t; t &= t - 1) { int y = __builtin_ctzll(t); s += Q[y] * (__builtin_parity(y & c) ? -1 : 1); }
        lv[c] = 3 + ((Q[c] * s) >> 1);
    }
    return lv;
}

// Extract COMPATIBLY PAIRED (lvH[32], lvHc[32]) using u_dir = XOR(V_0)!
static void extract_paired(const std::array<int, 64>& lv, int u_dir,
                           std::array<int, 32>& lvH, std::array<int, 32>& lvHc) {
    std::vector<int> basis;
    int v_shift = -1;
    for (int c = 1; c < 64; ++c) {
        if (__builtin_parity(c & u_dir)) {
            if (v_shift == -1) v_shift = c;
        } else {
            int t = c; for (int b : basis) t = std::min(t, t ^ b);
            if (t) basis.push_back(c);
        }
    }
    if (basis.size() != 5 || v_shift == -1) throw std::logic_error("Bad u_dir basis");
    bool H_is_0 = (lv[0] & 1) != 0;
    for (int a = 0; a < 32; ++a) {
        int c0 = 0; for (int i = 0; i < 5; ++i) if ((a >> i) & 1) c0 ^= basis[i];
        int c1 = c0 ^ v_shift;
        if (H_is_0) { lvH[a] = lv[c0]; lvHc[a] = lv[c1]; }
        else        { lvH[a] = lv[c1]; lvHc[a] = lv[c0]; }
        if (!(lvH[a] & 1) || (lvHc[a] & 1)) throw std::logic_error("Parity split mismatch!");
    }
}

struct HalfItem { uint32_t tw, p_mask; int cost, e2; };

// Enumerate ALL solutions on F_2^5 for a given opts[32] (with optional cost per option) -> grouped by p32!
struct OptVal { int8_t val, cost; };
static void enum_F5(const std::array<std::vector<OptVal>, 32>& opts, int max_cost, uint32_t p_tag,
                    std::unordered_map<uint32_t, std::vector<HalfItem>>& out) {
    struct Q8 { std::array<int8_t, 8> b; uint8_t cost; };
    auto do_q8 = [&](int st, std::array<std::vector<Q8>, 256>& qout) {
        std::array<int, 8> z{};
        auto dfs = [&](auto& self, int j, uint8_t cost) -> void {
            if (j == 8) {
                auto u = z; fwht8(u); uint8_t par = 0; std::array<int8_t, 8> b;
                for (int y = 0; y < 8; ++y) {
                    if (u[y] & 7) return;
                    int qq = u[y] >> 3; if (std::abs(qq) > 8) return;
                    b[y] = qq; if (qq & 1) par |= (1u << y);
                }
                qout[par].push_back({b, cost}); return;
            }
            for (const auto& ov : opts[st + j]) {
                if (cost + ov.cost > max_cost) continue;
                z[j] = ov.val;
                self(self, j + 1, uint8_t(cost + ov.cost));
            }
        };
        dfs(dfs, 0, 0);
    };
    struct H16 { std::array<int8_t, 16> u; uint8_t cost; };
    auto do_h16 = [&](int st, std::unordered_map<uint16_t, std::vector<H16>>& hout) {
        std::array<std::vector<Q8>, 256> q0, q1; do_q8(st, q0); do_q8(st + 8, q1);
        for (int p8 = 0; p8 < 256; ++p8) {
            if (q0[p8].empty() || q1[p8].empty()) continue;
            for (const auto& a : q0[p8]) for (const auto& b : q1[p8]) {
                if (a.cost + b.cost > max_cost) continue;
                std::array<int8_t, 16> u; uint16_t p16 = 0; bool ok = true;
                for (int y = 0; y < 8; ++y) {
                    if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                    int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                    u[y] = s; u[8+y] = d;
                    if (s & 1) p16 |= (1u << y); if (d & 1) p16 |= (1u << (8 + y));
                }
                if (ok) hout[p16].push_back({u, uint8_t(a.cost + b.cost)});
            }
        }
    };
    std::unordered_map<uint16_t, std::vector<H16>> g0, g1;
    do_h16(0, g0); do_h16(16, g1);
    for (const auto& [par, v0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            if (a.cost + b.cost > max_cost) continue;
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (1u << y); if (x1 & 1) p32 |= (1u << (16 + y));
                if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
            }
            if (ok) out[p32].push_back({tw, p_tag, a.cost + b.cost, e2});
        }
    }
}

// Note! For H, we must enumerate ALL 65,536 words of RM(2, 5) (NOT just 1,024 quad forms!),
// OR wait: shifting y' -> y' ^ l adds l.c to BOTH p_H AND p_Hc simultaneously!
// So we can fix p_H mod RM(1, 5) (1,024 quad forms) and STILL keep ALL RM(2, 5) words on H^c?
// NO! Because lvH and lvHc are FIXED (not shift-invariant in c)! Wait: spatial shift y' -> y' ^ l
// multiplies WHT_5(s)(a) AND WHT_5(d)(a) by (-1)^{a.l}, which DOES NOT MOVE a, DOES NOT CHANGE |z_H(a)| or |z_Hc(a)|,
// AND adds (a.l) to p_H(a) while leaving p_Hc(a) UNCHANGED (since flipping sign of 0, +-4, +-8, +-12 leaves (z/4) mod 2 UNCHANGED!!)!
// WAIT A SECOND!! CHECK THAT MIRACLE!!
//   On H: z -> -z flips p_H(a) -> p_H(a) ^ 1 (so y' -> y'^l adds a.l to p_H, and global sign adds 1 to p_H!).
//   On H^c: z -> -z leaves (z/4) mod 2 = p_Hc(a) COMPLETELY UNCHANGED, and leaves opts_Hc {-4,4}, {-8,8}, {-12,12} COMPLETELY INVARIANT!!
//   THEREFORE: fixing p_H to the 1,024 quad forms RM(2,5)/RM(1,5) AND keeping ALL sols of p_Hc in RM(2,5)
//   is 100.000% EXACT (every real u_x has a spatial shift y' -> y'^l and global sign hitting one of the 1,024 quad forms for p_H,
//   while its shifted s_x STILL satisfies opts_Hc with the EXACT SAME p_Hc)!!
// Let's VERIFY THAT IN OUR POSITIVE CONTROL!!

static uint64_t solve_beta1H_case(const std::string& name, uint64_t Em, uint64_t Fm,
                                  int max_cost_H, bool allow_Hc_rem2 = false) {
    auto t0 = std::chrono::steady_clock::now();
    uint64_t v0m = Em ^ Fm;
    int u_dir = 0; for (uint64_t t = v0m; t; t &= t - 1) u_dir ^= __builtin_ctzll(t);
    auto lv = get_levels(Em, Fm);
    std::array<int, 32> lvH{}, lvHc{};
    extract_paired(lv, u_dir, lvH, lvHc);

    // 1. Build ALL H solutions over the 1,024 quad forms of RM(2,5)/RM(1,5)!
    uint32_t qmon[10]; int qi = 0;
    for (int i = 0; i < 5; ++i) for (int j = i + 1; j < 5; ++j) {
        uint32_t m = 0; for (int c = 0; c < 32; ++c) if (((c >> i) & 1) && ((c >> j) & 1)) m |= (1u << c);
        qmon[qi++] = m;
    }
    std::unordered_map<uint32_t, std::vector<HalfItem>> map_H;
    for (int qm = 0; qm < 1024; ++qm) {
        uint32_t p = 0; for (int b = 0; b < 10; ++b) if ((qm >> b) & 1) p ^= qmon[b];
        std::array<std::vector<OptVal>, 32> opts;
        for (int i = 0; i < 32; ++i) {
            int pb = (p >> i) & 1;
            int8_t v2 = pb ? -2 : 2, v6 = pb ? 6 : -6, v10 = pb ? -10 : 10;
            if (lvH[i] == 3) {
                if (max_cost_H == 0) opts[i] = {{v6, 0}};
                else opts[i] = {{v6, 0}, {v2, 1}};
            } else if (lvH[i] == 1) {
                opts[i] = {{v2, 0}};
            } else if (lvH[i] == 5) {
                opts[i] = {{v6, 0}, {v2, 1}};
            } else if (lvH[i] == 7) {
                opts[i] = {{v6, 0}, {v2, 0}, {v10, 0}};
            } else throw std::logic_error("Unexpected lvH");
        }
        enum_F5(opts, max_cost_H, (uint32_t)qm, map_H);
    }
    size_t nH = 0; for (auto& [k, v] : map_H) nH += v.size();

    // 2. Enumerate valid p_Hc in RM(2, 5) and join against map_H!
    uint32_t basis[16]; int nb = 0;
    basis[nb++] = 0xFFFFFFFFu;
    for (int i = 0; i < 5; ++i) { uint32_t m = 0; for (int c = 0; c < 32; ++c) if ((c >> i) & 1) m |= (1u << c); basis[nb++] = m; }
    for (int i = 0; i < 5; ++i) for (int j = i + 1; j < 5; ++j) {
        uint32_t m = 0; for (int c = 0; c < 32; ++c) if (((c >> i) & 1) && ((c >> j) & 1)) m |= (1u << c);
        basis[nb++] = m;
    }
    uint32_t m0 = 0, m111 = 0, m110 = 0, m100 = 0;
    for (int i = 0; i < 32; ++i) {
        if (lvHc[i] == 0) m0 |= (1u << i);
        else if (lvHc[i] == 2 || lvHc[i] == 10) m111 |= (1u << i);
        else if (lvHc[i] == 4 || lvHc[i] == 8) m110 |= (1u << i);
        else if (lvHc[i] == 6) m100 |= (1u << i);
    }

    uint64_t total_cells = 0;
    int p_with_cells = 0;
    std::vector<uint32_t> alive_ps;

    for (int mask = 0; mask < (1 << 16); ++mask) {
        uint32_t w = 0; for (int b = 0; b < 16; ++b) if ((mask >> b) & 1) w ^= basis[b];
        if ((w & m0) != 0) continue;
        if (!allow_Hc_rem2) {
            if ((w & m111) != m111) continue;
        } else {
            if (__builtin_popcount((~w) & m111) > 2) continue;
        }
        std::array<std::vector<OptVal>, 32> opts;
        int hc_max_c = allow_Hc_rem2 ? 2 : 0;
        for (int i = 0; i < 32; ++i) {
            int pb = (w >> i) & 1;
            if (lvHc[i] == 0) {
                opts[i] = {{0, 0}};
            } else if (lvHc[i] == 2 || lvHc[i] == 10) {
                if (pb) opts[i] = {{-4, 0}, {4, 0}};
                else opts[i] = {{0, 1}}; // only possible if allow_Hc_rem2! (lv=2 (0,0,2)={4,0,0})
            } else if (lvHc[i] == 4 || lvHc[i] == 8) {
                if (pb) opts[i] = {{-4, 0}, {4, 0}};
                else if (!allow_Hc_rem2) opts[i] = {{-8, 0}, {8, 0}};
                else opts[i] = {{-8, 0}, {8, 0}, {0, 1}}; // (2,0,0)={8,0,0} has cost 1!
            } else if (lvHc[i] == 6) {
                if (pb) {
                    if (!allow_Hc_rem2) opts[i] = {{-12, 0}, {12, 0}};
                    else opts[i] = {{-12, 0}, {12, 0}, {-4, 2}, {4, 2}}; // (1,1,1)={8,4,0} cost 2!
                } else {
                    if (!allow_Hc_rem2) opts[i] = {{0, 0}};
                    else opts[i] = {{0, 0}, {-8, 2}, {8, 2}}; // (1,1,1)={8,4,0} cost 2!
                }
            }
        }
        std::unordered_map<uint32_t, std::vector<HalfItem>> map_Hc;
        enum_F5(opts, hc_max_c, w, map_Hc);
        uint64_t loc = 0;
        for (const auto& [p32, vhc] : map_Hc) {
            auto it = map_H.find(p32);
            if (it == map_H.end()) continue;
            for (const auto& hc : vhc) for (const auto& hh : it->second) {
                if (hc.tw & hh.tw) continue;
                int wt = (hc.e2 + hh.e2) / 2;
                if (wt <= 64) loc++;
            }
        }
        if (loc) { total_cells += loc; p_with_cells++; alive_ps.push_back(w); }
    }
    // Check if ANY valid triple (p1, p2, p3) exists among alive_ps!
    int alive_triples = 0;
    for (size_t i = 0; i < alive_ps.size(); ++i)
        for (size_t j = i; j < alive_ps.size(); ++j) {
            if (alive_ps[i] & alive_ps[j] & m100) continue;
            uint32_t p3 = (m111 | m100) ^ alive_ps[i] ^ alive_ps[j];
            if (p3 & (alive_ps[i] | alive_ps[j]) & m100) continue;
            if ((alive_ps[i] & alive_ps[j] & p3 & m110) != 0) continue;
            if (!allow_Hc_rem2) {
                if (((alive_ps[i] | alive_ps[j] | p3) & m110) != m110) continue;
            } else {
                int c_111 = __builtin_popcount(m111 & ~(alive_ps[i] & alive_ps[j] & p3));
                int c_110 = __builtin_popcount(m110 & ~(alive_ps[i] | alive_ps[j] | p3));
                if (c_111 + c_110 > 2) continue;
            }
            if (std::find(alive_ps.begin() + j, alive_ps.end(), p3) != alive_ps.end()) alive_triples++;
        }

    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "[" << name << "] nH=" << nH << " | total_u_cells=" << total_cells
              << " | alive_p_Hc=" << p_with_cells << " | ALIVE TRIPLES=" << alive_triples
              << " (" << dt << "s)\n" << std::flush;
    return alive_triples;
}

int main() {
    for (int x = 0; x < 64; ++x) Q[x] = __builtin_parity((x >> 1) & x & 21) ? -1 : 1;

    // POSITIVE CONTROL: Build a real u : F_2^6 -> {-1, 0, +1} with u_dir = 4 (pairs along 4),
    // e.g. u = Q(y) with 2 pts {0, 4} deleted? Wait: Q(0)=1, Q(4)=1 -> WHT(Q - 1_{0,4})(c) = 8*Q(c) - (1 + (-1)^{c_2}):
    //   on c_2=0 (H): 8*Q - 2 in {+6, -10} -> beta = 1!
    //   on c_2=1 (H^c): 8*Q in {+8, -8} -> beta = 0!
    // Check our paired extraction + 1024-quad-form H join FINDS THIS REAL u!
    {
        std::array<int, 64> u{};
        for (int y = 0; y < 64; ++y) u[y] = (y == 0 || y == 4) ? 0 : Q[y];
        auto z = u; fwht64(z);
        // Extract paired along u_dir = 4!
        std::array<int, 64> fake_lv{};
        for (int c = 0; c < 64; ++c) fake_lv[c] = (std::abs(z[c]) % 4 == 2) ? 7 : 4;
        std::array<int, 32> lvH{}, lvHc{};
        extract_paired(fake_lv, 4, lvH, lvHc);
        // Verify our 1024-quad-form H + exact p_Hc join finds u!
        uint32_t qmon[10]; int qi = 0;
        for (int i = 0; i < 5; ++i) for (int j = i + 1; j < 5; ++j) {
            uint32_t m = 0; for (int c = 0; c < 32; ++c) if (((c >> i) & 1) && ((c >> j) & 1)) m |= (1u << c);
            qmon[qi++] = m;
        }
        std::unordered_map<uint32_t, std::vector<HalfItem>> map_H;
        // Just check that for the exact z_H and z_Hc of u (with shifts!), map_H and map_Hc match!
        // Specifically compute basis of 4^perp and check z_H, z_Hc!
        std::vector<int> basis; int v_shift = -1;
        for (int c = 1; c < 64; ++c) {
            if (__builtin_parity(c & 4)) { if (v_shift == -1) v_shift = c; }
            else { int t = c; for (int b : basis) t = std::min(t, t ^ b); if (t) basis.push_back(c); }
        }
        uint32_t p_H_real = 0;
        std::array<std::vector<OptVal>, 32> opts_H, opts_Hc;
        for (int a = 0; a < 32; ++a) {
            int c0 = 0; for (int i = 0; i < 5; ++i) if ((a >> i) & 1) c0 ^= basis[i];
            int c1 = c0 ^ v_shift;
            int zh = z[c0], zhc = z[c1];
            if (((zh - 2) & 7) == 4) p_H_real |= (1u << a);
            opts_H[a] = {{(int8_t)zh, 0}};
            opts_Hc[a] = {{(int8_t)zhc, 0}};
        }
        // Check that flipping by linear shift reduces p_H_real to one of the 1024 qm AND still joins with opts_Hc!
        std::unordered_map<uint32_t, std::vector<HalfItem>> mH_test, mHc_test;
        enum_F5(opts_H, 0, 0, mH_test);
        enum_F5(opts_Hc, 0, 0, mHc_test);
        int found_pos = 0;
        for (auto& [p32, vh] : mH_test) {
            auto it = mHc_test.find(p32); if (it == mHc_test.end()) continue;
            for (auto& a : vh) for (auto& b : it->second) if (!(a.tw & b.tw)) found_pos++;
        }
        if (found_pos == 0) throw std::logic_error("POS CTRL paired H/Hc join FAILED!");
        std::cout << "[POS CTRL] Paired (H, H^c) join verified on real u (wt=62): found=" << found_pos << "!\n" << std::flush;
    }

    // Solve ALL 5 remaining beta_U = 1_H cases!
    // 1. h16_p0_a: min u_x has cost<=1 on H, ALL u_x have cost<=4 on H! Test BOTH!
    solve_beta1H_case("h16_p0_a (min u_x cost<=1)", 0x110011008700ffULL, 0ULL, 1, false);
    solve_beta1H_case("h16_p0_a (all u_x cost<=4)", 0x110011008700ffULL, 0ULL, 4, false);

    // 2. h10_p0_a: rem=6 => ALL 3 u_x have m_2=2 on H (cost<=2), ZERO free allocs on H^c!
    solve_beta1H_case("h10_p0_a (0x1100ff)", 0x1100ffULL, 0ULL, 2, false);

    // 3. h14_p2_a (test ALL 6 F's of 0x88001100110077 just in case they differ? Wait: check if F=0x11, 0x22, ... give identical lv!)
    solve_beta1H_case("h14_p2_a (F=0x11)", 0x88001100110077ULL, 0x11ULL, 2, false);
    solve_beta1H_case("h14_p2_a (F=0x22)", 0x88001100110077ULL, 0x22ULL, 2, false);
    solve_beta1H_case("h14_p2_a (F=0x44)", 0x88001100110077ULL, 0x44ULL, 2, false);
    solve_beta1H_case("h14_p2_a (F=0x110000)", 0x88001100110077ULL, 0x110000ULL, 2, false);
    solve_beta1H_case("h14_p2_a (F=0x1100000000)", 0x88001100110077ULL, 0x1100000000ULL, 2, false);
    solve_beta1H_case("h14_p2_a (F=0x88000000000000)", 0x88001100110077ULL, 0x88000000000000ULL, 2, false);

    // 4. h14_p2_e (both F=0x44 and F=0x88!)
    solve_beta1H_case("h14_p2_e (F=0x44)", 0x3300ffULL, 0x44ULL, 2, false);
    solve_beta1H_case("h14_p2_e (F=0x88)", 0x3300ffULL, 0x88ULL, 2, false);

    // 5. h14_p1 (0x30030d3f, F=0x1): min u_x has cost=0 on H (232 d's!), extra cost<=2 on H^c!
    solve_beta1H_case("h14_p1 (min u_x cost=0)", 0x30030d3fULL, 0x1ULL, 0, true);
}
