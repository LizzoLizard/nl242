// Exact complete solver for the |V0|=6, beta=1_H, min_D=36 cell (which is the ONLY survivor of h=6,
// and also appears at h=10 p=2 and h=14 p=4)!
// Enumerates ALL valid v_x (x in {1, 2, 3}) matching the EXACT H_1 constraints + H_1^c constraints,
// then checks if ANY triple (v_1, v_2, v_3) completes v_0 to a valid t=100, |Z|=112 low block V!
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include <vector>

static void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static void fwht64(std::array<int, 64>& a) {
    for (int st = 1; st < 64; st *= 2)
        for (int i = 0; i < 64; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}

struct HalfSol {
    std::array<int8_t, 32> z;
    uint32_t p32, tw, m10, m6Z, m8;
    int e2;
};

static void enum_half(const std::array<std::vector<int>, 32>& opts,
                      uint32_t mask_RH, uint32_t mask_HZ,
                      std::unordered_map<uint32_t, std::vector<HalfSol>>& res) {
    res.clear();
    struct Q8 { std::array<int8_t, 8> b, z; };
    auto do_q8 = [&](int st, std::array<std::vector<Q8>, 256>& out) {
        std::array<int, 8> z{};
        auto dfs = [&](auto& self, int j) -> void {
            if (j == 8) {
                auto u = z; fwht8(u); uint8_t par = 0; std::array<int8_t, 8> b, z8;
                for (int y = 0; y < 8; ++y) {
                    if (u[y] & 7) return;
                    int q = u[y] >> 3; if (std::abs(q) > 8) return;
                    b[y] = q; z8[y] = z[y]; if (q & 1) par |= (1u << y);
                }
                out[par].push_back({b, z8}); return;
            }
            for (int val : opts[st + j]) { z[j] = val; self(self, j + 1); }
        };
        dfs(dfs, 0);
    };
    struct H16 { std::array<int8_t, 16> u, z; };
    auto do_h16 = [&](int st, std::unordered_map<uint16_t, std::vector<H16>>& out) {
        std::array<std::vector<Q8>, 256> q0, q1; do_q8(st, q0); do_q8(st + 8, q1);
        for (int p8 = 0; p8 < 256; ++p8) {
            if (q0[p8].empty() || q1[p8].empty()) continue;
            for (const auto& a : q0[p8]) for (const auto& b : q1[p8]) {
                std::array<int8_t, 16> u, z16; uint16_t p16 = 0; bool ok = true;
                for (int y = 0; y < 8; ++y) {
                    if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                    int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                    u[y] = s; u[8+y] = d; z16[y] = a.z[y]; z16[8+y] = b.z[y];
                    if (s & 1) p16 |= (1u << y); if (d & 1) p16 |= (1u << (8 + y));
                }
                if (ok) out[p16].push_back({u, z16});
            }
        }
    };
    std::unordered_map<uint16_t, std::vector<H16>> g0, g1;
    do_h16(0, g0); do_h16(16, g1);
    for (const auto& [par, v0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p32 = 0, tw = 0, m10 = 0, m6Z = 0, m8 = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (1u << y); if (x1 & 1) p32 |= (1u << (16 + y));
                if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
            }
            if (!ok) continue;
            std::array<int8_t, 32> z32;
            for (int i = 0; i < 16; ++i) { z32[i] = a.z[i]; z32[16+i] = b.z[i]; }
            for (int i = 0; i < 32; ++i) {
                int az = std::abs((int)z32[i]);
                if (((mask_RH >> i) & 1) && az == 10) m10 |= (1u << i);
                if (((mask_HZ >> i) & 1) && az == 6) m6Z |= (1u << i);
                if (az == 8) m8 |= (1u << i);
            }
            res[p32].push_back({z32, p32, tw, m10, m6Z, m8, e2});
        }
    }
}

int main() {
    int Q[64];
    for (int c = 0; c < 64; ++c) Q[c] = __builtin_parity((c >> 1) & c & 21); // 1=Z6 (28), 0=F6 (36)
    int pts[6] = {0, 1, 4, 5, 16, 17};
    std::array<int, 64> v0{};
    for (int p : pts) v0[p] = 1;
    auto z0 = v0; fwht64(z0);
    // H = {2*i}, H^c = {2*i+1}
    uint32_t mask_HF6 = 0, mask_RH = 0, mask_HZ = 0, mask_HcF = 0;
    for (int i = 0; i < 32; ++i) {
        int cH = 2 * i, cHc = 2 * i + 1;
        if (Q[cH] == 1) mask_HZ |= (1u << i);
        else if (std::abs(z0[cH]) == 6) mask_HF6 |= (1u << i);
        else mask_RH |= (1u << i);
        if (Q[cHc] == 0) mask_HcF |= (1u << i);
    }

    // Build H^c solution maps for v2/v3 (p=0: 0 on HcF, {0,+-8} on ~HcF) AND for v1 (p=q5: +-12 on HcF, {0,+-8} on ~HcF)!
    std::array<std::vector<int>, 32> opts_Hc2, opts_Hc1;
    for (int i = 0; i < 32; ++i) {
        if ((mask_HcF >> i) & 1) { opts_Hc2[i] = {0}; opts_Hc1[i] = {-12, 12}; }
        else { opts_Hc2[i] = {-8, 0, 8}; opts_Hc1[i] = {-8, 0, 8}; }
    }
    std::unordered_map<uint32_t, std::vector<HalfSol>> map_Hc2, map_Hc1;
    enum_half(opts_Hc2, 0, 0, map_Hc2);
    enum_half(opts_Hc1, 0, 0, map_Hc1);
    std::cout << "Built map_Hc2 (keys=" << map_Hc2.size() << ") and map_Hc1 (keys=" << map_Hc1.size() << ")\n" << std::flush;

    // Notice! On H_1, ANY valid v_x (x=1,2,3) has p_x|_H in RM(2,5) = quad(10 bits) + lin(5 bits) + const(1 bit).
    // Wait: linear shift l in F_2^5 shifts y' -> y' ^ l on BOTH H and H^c simultaneously!
    // Wait: map_Hc1 and map_Hc2 are ALREADY invariant under y' -> y' ^ l (since WHT_5(s(.^l))(c) = (-1)^{c.l} WHT_5(s)(c),
    // which preserves |z_x(c)|!!)!
    // So if we test ALL 1024 quadratic forms q in RM(2,5)/RM(1,5) for p_x|_H, ANY valid v_x is a spatial shift y' -> y'^l
    // and global sign of a solution with p_x|_H = q!!
    // LET'S COUNT how many valid full cells v_2 (with H^c in map_Hc2) and v_1 (with H^c in map_Hc1) exist!
    uint32_t qmon[10]; int qi = 0;
    for (int a = 0; a < 5; ++a) for (int b = a + 1; b < 5; ++b) {
        uint32_t m = 0; for (int i = 0; i < 32; ++i) if (((i >> a) & 1) && ((i >> b) & 1)) m |= (1u << i);
        qmon[qi++] = m;
    }

    uint64_t total_H = 0, total_v2 = 0, total_v1 = 0;
    int v1_q_ok = 0, v2_q_ok = 0;
    // Also record all (m10, m6Z, m8, wt) signatures of valid v2 and v1!
    struct CellSig { uint32_t m10, m6Z, m8; int wt; int qid; };
    std::vector<CellSig> sigs_v1, sigs_v2;

    for (int qm = 0; qm < 1024; ++qm) {
        uint32_t p = 0;
        for (int b = 0; b < 10; ++b) if ((qm >> b) & 1) p ^= qmon[b];
        std::array<std::vector<int>, 32> opts_H;
        for (int i = 0; i < 32; ++i) {
            int pb = (p >> i) & 1;
            if ((mask_HF6 >> i) & 1) opts_H[i] = {pb ? 6 : -6};
            else if ((mask_RH >> i) & 1) opts_H[i] = pb ? std::vector<int>{-2, 10} : std::vector<int>{2, -10};
            else opts_H[i] = pb ? std::vector<int>{-2, 6} : std::vector<int>{2, -6};
        }
        std::unordered_map<uint32_t, std::vector<HalfSol>> map_H;
        enum_half(opts_H, mask_RH, mask_HZ, map_H);
        bool any1 = false, any2 = false;
        for (const auto& [p32, vh] : map_H) {
            total_H += vh.size();
            auto it2 = map_Hc2.find(p32);
            if (it2 != map_Hc2.end()) {
                for (const auto& h : vh) for (const auto& hc : it2->second) {
                    if (h.tw & hc.tw) continue;
                    int wt = (h.e2 + hc.e2) / 2;
                    if (wt > 64) continue;
                    total_v2++; any2 = true;
                    sigs_v2.push_back({h.m10, h.m6Z, hc.m8, wt, qm});
                }
            }
            auto it1 = map_Hc1.find(p32);
            if (it1 != map_Hc1.end()) {
                for (const auto& h : vh) for (const auto& hc : it1->second) {
                    if (h.tw & hc.tw) continue;
                    int wt = (h.e2 + hc.e2) / 2;
                    if (wt > 64) continue;
                    total_v1++; any1 = true;
                    sigs_v1.push_back({h.m10, h.m6Z, hc.m8, wt, qm});
                }
            }
        }
        if (any1) v1_q_ok++;
        if (any2) v2_q_ok++;
    }
    std::cout << "ALL 1024 quad forms scanned!\n";
    std::cout << "  total_H=" << total_H << "\n";
    std::cout << "  v1 (p=q5 on H^c): " << total_v1 << " cells (in " << v1_q_ok << " q-forms)\n";
    std::cout << "  v2/v3 (p=0 on H^c): " << total_v2 << " cells (in " << v2_q_ok << " q-forms)\n";
    // Print wt distribution of v1 and v2!
    int w1[65]{}, w2[65]{};
    for (auto& s : sigs_v1) w1[s.wt]++;
    for (auto& s : sigs_v2) w2[s.wt]++;
    std::cout << "  v1 wt dist:"; for (int i = 0; i <= 64; ++i) if (w1[i]) std::cout << " " << i << ":" << w1[i]; std::cout << "\n";
    std::cout << "  v2 wt dist:"; for (int i = 0; i <= 64; ++i) if (w2[i]) std::cout << " " << i << ":" << w2[i]; std::cout << "\n";
    // Check if ANY triple (v1, v2, v3) satisfies:
    //   m10 partition of mask_RH, m6Z partition of mask_HZ, m8 partition of ~mask_HcF, AND wt1+wt2+wt3 == 94!!
    // Deduplicate sigs by (m10, m6Z, m8, wt)!
    auto dedup = [](std::vector<CellSig>& v) {
        std::sort(v.begin(), v.end(), [](const CellSig& a, const CellSig& b) {
            return std::tie(a.m10, a.m6Z, a.m8, a.wt) < std::tie(b.m10, b.m6Z, b.m8, b.wt);
        });
        v.erase(std::unique(v.begin(), v.end(), [](const CellSig& a, const CellSig& b) {
            return std::tie(a.m10, a.m6Z, a.m8, a.wt) == std::tie(b.m10, b.m6Z, b.m8, b.wt);
        }), v.end());
    };
    dedup(sigs_v1); dedup(sigs_v2);
    std::cout << "  Unique (m10,m6Z,m8,wt) sigs: v1=" << sigs_v1.size() << " v2=" << sigs_v2.size() << "\n";
    uint32_t mask_HcZ = ~mask_HcF;
    // Hash v1 by (m10, m6Z, m8) -> bitmask of valid wts (Wait: wt in 0..64 -> uint64_t mask!)
    struct Key { uint32_t a, b, c; bool operator==(const Key& o) const { return a==o.a && b==o.b && c==o.c; } };
    struct KHash { size_t operator()(const Key& k) const { return ((size_t)k.a * 1000003ULL ^ k.b) * 1000003ULL ^ k.c; } };
    std::unordered_map<Key, std::vector<int>, KHash> v1_map;
    for (auto& s : sigs_v1) v1_map[{s.m10, s.m6Z, s.m8}].push_back(s.wt);

    uint64_t joins = 0;
    for (size_t i = 0; i < sigs_v2.size(); ++i) {
        const auto& a = sigs_v2[i];
        for (size_t j = i; j < sigs_v2.size(); ++j) {
            const auto& b = sigs_v2[j];
            if ((a.m10 & b.m10) || (a.m6Z & b.m6Z) || (a.m8 & b.m8)) continue;
            uint32_t r10 = mask_RH ^ a.m10 ^ b.m10;
            uint32_t r6Z = mask_HZ ^ a.m6Z ^ b.m6Z;
            uint32_t r8 = mask_HcZ ^ a.m8 ^ b.m8;
            auto it = v1_map.find({r10, r6Z, r8});
            if (it == v1_map.end()) continue;
            for (int w1v : it->second) {
                if (w1v + a.wt + b.wt == 94) {
                    joins++;
                    if (joins <= 10)
                        std::cout << "  JOIN! wts=(" << w1v << "," << a.wt << "," << b.wt << ")\n";
                }
            }
        }
    }
    std::cout << "TOTAL JOINS FOR |V0|=6, min_D=36 (t=100): " << joins << "\n";
}
