// Parallel 8-thread exact scan of h=16 p=2 on shapes14.bin (560,256 shapes)
// + cross-check of h=14 p=0 on shapes14.bin (must equal 1 orbit, 0x220011001100ff)!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <iostream>
#include <mutex>
#include <thread>
#include <vector>

static int Q[64], W[64][64];
static uint64_t F6_all[64], Z6_all[64];
static void init() {
    for (int x = 0; x < 64; ++x) {
        Q[x] = __builtin_parity((x >> 1) & x & 21) ? -1 : 1;
        for (int y = 0; y < 64; ++y) W[x][y] = __builtin_parity(x & y) ? -1 : 1;
    }
    for (int c0 = 0; c0 < 64; ++c0) {
        uint64_t fm = 0;
        for (int c = 0; c < 64; ++c) if (Q[c ^ c0] == 1) fm |= (1ULL << c);
        F6_all[c0] = fm; Z6_all[c0] = ~fm;
    }
}

struct V0Res { bool ok; bool beta0; int minD; int surv_cnt; };
static V0Res check_v0(uint64_t v0_mask) {
    int m = __builtin_popcountll(v0_mask);
    if (m == 0) return {true, true, 0, 1};
    int pts[16], k = 0, xor_v = 0;
    for (uint64_t t = v0_mask; t; t &= t - 1) { int y = __builtin_ctzll(t); pts[k++] = y; xor_v ^= y; }
    int n_sgn = 1 << (m - 1);
    int surv = 0, minD = 999;
    int z[64];
    for (int c = 0; c < 64; ++c) { int s = 0; for (int i = 0; i < m; ++i) s += W[pts[i]][c]; z[c] = s; }
    int cur_mask = 0, neg_cnt = 0;
    for (int g = 0; g < n_sgn; ++g) {
        if (g > 0) {
            int bit = __builtin_ctz(g), idx = bit + 1;
            int flip_to_neg = !((cur_mask >> bit) & 1);
            cur_mask ^= (1 << bit);
            int delta = flip_to_neg ? -2 : 2;
            neg_cnt += flip_to_neg ? 1 : -1;
            int y = pts[idx];
            for (int c = 0; c < 64; ++c) z[c] += delta * W[y][c];
        }
        if (xor_v == 0 && (neg_cnt & 1) != ((m / 2) & 1)) continue;
        int maxz = 0;
        for (int c = 0; c < 64; ++c) { int a = std::abs(z[c]); if (a > maxz) maxz = a; }
        if (maxz > 12) continue;
        if (xor_v == 0) {
            uint64_t m12 = 0, m48 = 0;
            for (int c = 0; c < 64; ++c) {
                int a = std::abs(z[c]);
                if (a == 12) m12 |= (1ULL << c);
                else if (a == 4 || a == 8) m48 |= (1ULL << c);
            }
            for (int c0 = 0; c0 < 64; ++c0) {
                if (m12 & Z6_all[c0]) continue;
                int c2n8 = 4 * __builtin_popcountll(m48 & F6_all[c0]);
                if (c2n8 <= 28) { surv++; if (c2n8 + 8 < minD) minD = c2n8 + 8; }
            }
        } else {
            uint64_t mH = 0, mZbad = 0, mHFbad = 0, mHcFbad = 0;
            for (int c = 0; c < 64; ++c) {
                int a = std::abs(z[c]);
                bool inH = (a & 3) == 2;
                if (inH) {
                    mH |= (1ULL << c);
                    if (a == 10) mZbad |= (1ULL << c);
                    if (a == 2 || a == 10) mHFbad |= (1ULL << c);
                } else {
                    if (a == 12) mZbad |= (1ULL << c);
                    if (a == 4 || a == 8) mHcFbad |= (1ULL << c);
                }
            }
            for (int c0 = 0; c0 < 64; ++c0) {
                if (mZbad & Z6_all[c0]) continue;
                int D = __builtin_popcountll(mH & Z6_all[c0])
                      + 2 * __builtin_popcountll(mHFbad & F6_all[c0])
                      + 4 * __builtin_popcountll(mHcFbad & F6_all[c0]);
                if (D <= 36) { surv++; if (D < minD) minD = D; }
            }
        }
    }
    return {surv > 0, xor_v == 0, minD, surv};
}

int main() {
    init();
    FILE* f = fopen("shapes/shapes14.bin", "rb");
    std::vector<uint64_t> masks; uint64_t m;
    while (fread(&m, 8, 1, f) == 1) masks.push_back(m);
    fclose(f);
    std::cout << "Loaded " << masks.size() << " shapes14.\n" << std::flush;

    auto t0 = std::chrono::steady_clock::now();
    std::atomic<size_t> next_i{0};
    std::atomic<uint64_t> h14_p0_cnt{0}, h16_p2_lv{0}, h16_p2_v0{0};
    struct Hit { uint64_t E, F, V0; int wt3, minD; bool beta0; int surv; };
    std::vector<Hit> hits;
    std::mutex mu;

    std::vector<std::thread> ths;
    for (int ti = 0; ti < 8; ++ti) {
        ths.emplace_back([&]() {
            int pts[14], terms[14][64], base[64];
            while (true) {
                size_t st = next_i.fetch_add(256);
                if (st >= masks.size()) break;
                size_t en = std::min(masks.size(), st + 256);
                for (size_t idx = st; idx < en; ++idx) {
                    uint64_t mask = masks[idx];
                    int k = 0; for (uint64_t t = mask; t; t &= t - 1) pts[k++] = __builtin_ctzll(t);
                    for (int c = 0; c < 64; ++c) base[c] = 0;
                    for (int i = 0; i < 14; ++i) {
                        int x = pts[i], qx = Q[x];
                        for (int c = 0; c < 64; ++c) { int v = qx * W[x][c]; terms[i][c] = v; base[c] += v; }
                    }
                    // Cross-check h=14 p=0:
                    {
                        int wt3 = 0; bool ok = true;
                        for (int c = 0; c < 64; ++c) {
                            int lv = 3 + ((Q[c] * base[c]) >> 1);
                            if (lv < 0 || lv > 12) { ok = false; break; }
                            if (lv % 3) if (++wt3 > 18) { ok = false; break; }
                        }
                        if (ok) h14_p0_cnt++;
                    }
                    // Scan h=16 p=2 (91 pairs):
                    for (int i = 0; i < 14; ++i) {
                        int bi[64];
                        for (int c = 0; c < 64; ++c) bi[c] = base[c] + terms[i][c];
                        for (int j = i + 1; j < 14; ++j) {
                            int wt3 = 0; bool ok = true;
                            for (int c = 0; c < 64; ++c) {
                                int lv = 3 + ((Q[c] * (bi[c] + terms[j][c])) >> 1);
                                if (lv < 0 || lv > 12) { ok = false; break; }
                                if (lv % 3) if (++wt3 > 16) { ok = false; break; }
                            }
                            if (!ok) continue;
                            h16_p2_lv++;
                            uint64_t fmask = (1ULL << pts[i]) | (1ULL << pts[j]);
                            uint64_t v0m = mask ^ fmask;
                            auto res = check_v0(v0m);
                            if (res.ok) {
                                h16_p2_v0++;
                                std::lock_guard<std::mutex> lk(mu);
                                hits.push_back({mask, fmask, v0m, wt3, res.minD, res.beta0, res.surv_cnt});
                            }
                        }
                    }
                }
            }
        });
    }
    for (auto& th : ths) th.join();
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "DONE in " << dt << "s!\n";
    std::cout << "  [CROSS-CHECK] h=14 p=0 count on shapes14: " << h14_p0_cnt.load() << " (expected 1!)\n";
    std::cout << "  h=16 p=2 (size=14, |V0|=12): pass_levels=" << h16_p2_lv.load()
              << " -> SURVIVE EXACT v0 = " << h16_p2_v0.load() << "\n";
    for (const auto& x : hits) {
        std::cout << "    E=0x" << std::hex << x.E << " F=0x" << x.F << " V0=0x" << x.V0 << std::dec
                  << " wt3=" << x.wt3 << " " << (x.beta0 ? "beta0" : "beta1H")
                  << " minD=" << x.minD << " surv=" << x.surv << "\n";
    }
}
