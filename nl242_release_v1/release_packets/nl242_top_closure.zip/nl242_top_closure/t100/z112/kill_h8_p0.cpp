// Exhaustive high-block 4-slice (beta_U == 1) test for the FINAL remaining rank-6 case at t=100:
//   h=8, p=0 (V_0 = L_1 = {0,1,4,5,16,17,20,21}, hist = {3:56, 7:8}, k = 24)!
// Since k - 8 = 16, total extra +-2s on the 56 lv=3 fibers across u_1, u_2, u_3 is <= 16,
// so at least one u_x has cost = #{c in lv=3 : |u_x_hat(c)| == 2} <= floor(16/3) = 5!
// Symmetry: e_5 = 32 is in L_1^perp (and in fact L_1^perp = {0,2,8,10,32,34,40,42} = span(2, 8, 32)!).
// Wait: permute bits so L_1^perp has 1 pt in each 8-block (put bits 1, 3, 5 as the TOP 3 bits (blocks 0..7) ->
// wait: if bits 1, 3, 5 are the TOP 3 bits, then L_1^perp = {(b5,b3,b1,0,0,0)} has 1 point at offset 0 of EVERY 8-block!!).
// AND swapping half 0 (top bit=0) <-> half 1 (top bit=1) preserves L_1^perp AND RM(2,6), so WLOG cost(half 0) <= 2!!
// Wait: EVEN BETTER! Inside half 1 (two 16-blocks: top2 = 10 and 11), swapping bit 3 (the 2nd top bit!) ALSO preserves L_1^perp AND RM(2,6),
// so WLOG cost(block 10) <= cost(block 11), meaning:
//   cost(half 0) <= 2 (and WLOG cost(00) <= cost(01) => cost(00) <= 1!), AND
//   if cost(half 1) <= 5, cost(10) <= 2 and cost(11) <= 5!!
// WAIT: does swapping 00 <-> 01 commute with swapping 10 <-> 11? NO! Flipping bit 3 swaps BOTH 00<->01 AND 10<->11!
// So we can ONLY enforce ONE of them: WLOG cost(half 0) <= 2 (using bit 5), AND inside half 1 WLOG cost(10) <= cost(11) (using bit 3 -> cost(10) <= 2, while half 0 still has cost(00)+cost(01) <= 2!).
// YES!! Flipping bit 5 preserves {00,01} <-> {10,11}, and flipping bit 3 preserves BOTH half 0 and half 1 individually while swapping 10 <-> 11!
// So WLOG: cost(half 0) <= 2, cost(10) <= 2, cost(11) <= 5 - cost(half 0) - cost(10)!!
// Let's check exact hits by cost in 0..5 across ALL 32,768 quadratic forms!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <thread>
#include <unordered_map>
#include <vector>

static int Q[64];
static uint64_t qmon[15];
static void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}

int main() {
    for (int x = 0; x < 64; ++x) Q[x] = __builtin_parity((x >> 1) & x & 21) ? -1 : 1;
    // Verify L1 = {0,1,4,5,16,17,20,21} has lv=7 on {0,2,8,10,32,34,40,42} = {c : (c & 0x15) == 0}!
    int L1[8] = {0, 1, 4, 5, 16, 17, 20, 21};
    uint64_t lv7_orig = 0;
    for (int c = 0; c < 64; ++c) {
        int s = 0; for (int y : L1) s += Q[y] * (__builtin_parity(y & c) ? -1 : 1);
        int lv = 3 + ((Q[c] * s) >> 1);
        if (lv == 7) lv7_orig |= (1ULL << c);
        else if (lv != 3) throw std::logic_error("Bad L1 lv");
    }
    // Bit permutation: new bits (0,1,2) = old bits (0,2,4); new bits (3,4,5) = old bits (1,3,5)!
    // Then in new coords, lv7 is EXACTLY {nc : (nc & 7) == 0} = {0, 8, 16, 24, 32, 40, 48, 56}!!
    int perm[6] = {0, 2, 4, 1, 3, 5};
    uint64_t lv7 = 0;
    for (int c = 0; c < 64; ++c) if ((lv7_orig >> c) & 1ULL) {
        int nc = 0; for (int i = 0; i < 6; ++i) if ((c >> perm[i]) & 1) nc |= (1 << i);
        lv7 |= (1ULL << nc);
    }
    if (lv7 != 0x0101010101010101ULL) throw std::logic_error("Bad lv7 perm!");
    std::cout << "Permuted lv7 = 0x" << std::hex << lv7 << std::dec << " (EXACTLY offset 0 of every 8-block!)\n" << std::flush;

    int qi = 0;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        uint64_t m = 0; for (int c = 0; c < 64; ++c) if (((c >> i) & 1) && ((c >> j) & 1)) m |= (1ULL << c);
        qmon[qi++] = m;
    }

    auto t0 = std::chrono::steady_clock::now();
    std::atomic<int> next_q{0};
    std::atomic<uint64_t> hits_by_cost[6]{};
    // Also track min wt per cost!
    std::atomic<int> min_wt[6]; for (int i = 0; i < 6; ++i) min_wt[i] = 999;

    std::vector<std::thread> ths;
    for (int ti = 0; ti < 8; ++ti) {
        ths.emplace_back([&]() {
            struct Q8 { std::array<int8_t, 8> b; uint8_t cost; };
            struct H16 { std::array<int8_t, 16> u; uint8_t cost; };
            while (true) {
                int q0 = next_q.fetch_add(16);
                if (q0 >= (1 << 15)) break;
                int q1 = std::min(1 << 15, q0 + 16);
                for (int qm = q0; qm < q1; ++qm) {
                    uint64_t p = 0; for (int b = 0; b < 15; ++b) if ((qm >> b) & 1) p ^= qmon[b];

                    auto do_q8 = [&](int st, int max_c, std::array<std::vector<Q8>, 256>& qout) {
                        std::array<int, 8> z{};
                        auto dfs = [&](auto& self, int j, uint8_t cost) -> void {
                            if (j == 8) {
                                auto u = z; fwht8(u); uint8_t par = 0; std::array<int8_t, 8> b;
                                for (int y = 0; y < 8; ++y) {
                                    if (u[y] & 7) return;
                                    int qq = u[y] >> 3; if (std::abs(qq) > 8) return;
                                    b[y] = qq; if (qq & 1) par |= (1u << y);
                                }
                                qout[par].push_back({b, cost}); return;
                            }
                            int c = st + j; int pb = (p >> c) & 1;
                            int v2 = pb ? -2 : 2, v6 = pb ? 6 : -6, v10 = pb ? -10 : 10;
                            if (j == 0) { // lv == 7!
                                z[0] = v6; self(self, 1, cost);
                                z[0] = v2; self(self, 1, cost);
                                z[0] = v10; self(self, 1, cost);
                            } else {
                                z[j] = v6; self(self, j + 1, cost);
                                if (cost < max_c) { z[j] = v2; self(self, j + 1, cost + 1); }
                            }
                        };
                        dfs(dfs, 0, 0);
                    };
                    auto do_h16 = [&](int st, int max_c, std::unordered_map<uint16_t, std::vector<H16>>& hout) {
                        std::array<std::vector<Q8>, 256> qa, qb;
                        do_q8(st, max_c, qa); do_q8(st + 8, max_c, qb);
                        for (int p8 = 0; p8 < 256; ++p8) {
                            if (qa[p8].empty() || qb[p8].empty()) continue;
                            for (const auto& a : qa[p8]) for (const auto& b : qb[p8]) {
                                if (a.cost + b.cost > max_c) continue;
                                std::array<int8_t, 16> u; uint16_t p16 = 0; bool ok = true;
                                for (int y = 0; y < 8; ++y) {
                                    if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                                    int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                                    u[y] = s; u[8+y] = d;
                                    if (s & 1) p16 |= (1u << y); if (d & 1) p16 |= (1u << (8 + y));
                                }
                                if (ok) hout[p16].push_back({u, uint8_t(a.cost + b.cost)});
                            }
                        }
                    };
                    // Half 0 (0..31): max_c = 2!
                    std::unordered_map<uint16_t, std::vector<H16>> g0, g1;
                    do_h16(0, 2, g0);
                    if (g0.empty()) continue;
                    do_h16(16, 2, g1);
                    if (g1.empty()) continue;
                    std::unordered_map<uint32_t, std::vector<std::tuple<uint32_t, int, int>>> h0;
                    int min_c0 = 99;
                    for (const auto& [par, v0] : g0) {
                        auto it = g1.find(par); if (it == g1.end()) continue;
                        for (const auto& a : v0) for (const auto& b : it->second) {
                            int c0 = a.cost + b.cost;
                            if (c0 > 2) continue;
                            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
                            for (int y = 0; y < 16; ++y) {
                                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                                e2 += x0*x0 + x1*x1;
                                if (x0 & 1) p32 |= (1u << y); if (x1 & 1) p32 |= (1u << (16 + y));
                                if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
                            }
                            if (ok) { h0[p32].push_back({tw, c0, e2}); if (c0 < min_c0) min_c0 = c0; }
                        }
                    }
                    if (h0.empty()) continue;

                    // Half 1 (32..63): WLOG cost(32..47) <= cost(48..63) => cost(32..47) <= 2, cost(48..63) <= 5 - min_c0!
                    int max_c1 = 5 - min_c0;
                    std::unordered_map<uint16_t, std::vector<H16>> g2, g3;
                    do_h16(32, std::min(2, max_c1), g2);
                    if (g2.empty()) continue;
                    do_h16(48, max_c1, g3);
                    if (g3.empty()) continue;
                    for (const auto& [par, v2] : g2) {
                        auto it3 = g3.find(par); if (it3 == g3.end()) continue;
                        for (const auto& a : v2) for (const auto& b : it3->second) {
                            if (a.cost > b.cost) continue;
                            int c1 = a.cost + b.cost;
                            if (c1 > max_c1) continue;
                            uint32_t p32 = 0, tw1 = 0; int e1 = 0; bool ok = true;
                            for (int y = 0; y < 16; ++y) {
                                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                                e1 += x0*x0 + x1*x1;
                                if (x0 & 1) p32 |= (1u << y); if (x1 & 1) p32 |= (1u << (16 + y));
                                if (std::abs(x0) == 2) tw1 |= (1u << y); if (std::abs(x1) == 2) tw1 |= (1u << (16 + y));
                            }
                            if (!ok) continue;
                            auto it0 = h0.find(p32); if (it0 == h0.end()) continue;
                            for (auto [tw0, c0, e0] : it0->second) {
                                if (tw0 & tw1) continue;
                                int tot_c = c0 + c1;
                                if (tot_c > 5) continue;
                                int wt = (e0 + e1) / 2;
                                hits_by_cost[tot_c]++;
                                int old = min_wt[tot_c].load();
                                while (wt < old && !min_wt[tot_c].compare_exchange_weak(old, wt));
                            }
                        }
                    }
                }
            }
        });
    }
    for (auto& th : ths) th.join();
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "h=8 p=0 (L_1) ALL 32,768 quad forms scanned in " << dt << "s!\n";
    for (int c = 0; c <= 5; ++c)
        std::cout << "  cost=" << c << ": hits=" << hits_by_cost[c].load() << " min_wt=" << min_wt[c].load() << "\n";
}
