// Exact scan of (h, p) on shapes11, 12, 13 with BOTH levels filter (0<=lv<=12, wt3<=32-h)
// AND exact v0 defect bound across ALL 2^(|V0|-1) signings and ALL 64 Q_6 translates!
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>

static int Q[64], W[64][64];
static uint64_t F6_all[64], Z6_all[64];
static void init() {
    for (int x = 0; x < 64; ++x) {
        Q[x] = __builtin_parity((x >> 1) & x & 21) ? -1 : 1;
        for (int y = 0; y < 64; ++y) W[x][y] = __builtin_parity(x & y) ? -1 : 1;
    }
    for (int c0 = 0; c0 < 64; ++c0) {
        uint64_t fm = 0;
        for (int c = 0; c < 64; ++c) if (Q[c ^ c0] == 1) fm |= (1ULL << c);
        F6_all[c0] = fm; Z6_all[c0] = ~fm;
    }
}

struct V0Res { bool ok; bool beta0; int minD; int surv_cnt; };
static V0Res check_v0(uint64_t v0_mask) {
    int m = __builtin_popcountll(v0_mask);
    if (m == 0) return {true, true, 0, 1};
    int pts[16], k = 0, xor_v = 0;
    for (uint64_t t = v0_mask; t; t &= t - 1) { int y = __builtin_ctzll(t); pts[k++] = y; xor_v ^= y; }
    int n_sgn = 1 << (m - 1);
    int surv = 0, minD = 999;
    // Incremental Gray code over signings of pts[1..m-1]!
    int z[64];
    for (int c = 0; c < 64; ++c) {
        int s = 0; for (int i = 0; i < m; ++i) s += W[pts[i]][c];
        z[c] = s;
    }
    int cur_mask = 0; // bit i-1 = 1 means pts[i] has sign -1
    int neg_cnt = 0;
    for (int g = 0; g < n_sgn; ++g) {
        if (g > 0) {
            int bit = __builtin_ctz(g); // Gray code flip bit in 0..m-2
            int idx = bit + 1;
            int flip_to_neg = !((cur_mask >> bit) & 1);
            cur_mask ^= (1 << bit);
            int delta = flip_to_neg ? -2 : 2;
            neg_cnt += flip_to_neg ? 1 : -1;
            int y = pts[idx];
            for (int c = 0; c < 64; ++c) z[c] += delta * W[y][c];
        }
        if (xor_v == 0 && (neg_cnt & 1) != ((m / 2) & 1)) continue;
        int maxz = 0;
        for (int c = 0; c < 64; ++c) { int a = std::abs(z[c]); if (a > maxz) maxz = a; }
        if (maxz > 12) continue;
        if (xor_v == 0) {
            uint64_t m12 = 0, m48 = 0;
            for (int c = 0; c < 64; ++c) {
                int a = std::abs(z[c]);
                if (a == 12) m12 |= (1ULL << c);
                else if (a == 4 || a == 8) m48 |= (1ULL << c);
            }
            for (int c0 = 0; c0 < 64; ++c0) {
                if (m12 & Z6_all[c0]) continue;
                int c2n8 = 4 * __builtin_popcountll(m48 & F6_all[c0]);
                if (c2n8 <= 28) { surv++; if (c2n8 + 8 < minD) minD = c2n8 + 8; }
            }
        } else {
            uint64_t mH = 0, mZbad = 0, mHFbad = 0, mHcFbad = 0;
            for (int c = 0; c < 64; ++c) {
                int a = std::abs(z[c]);
                bool inH = (a & 3) == 2;
                if (inH) {
                    mH |= (1ULL << c);
                    if (a == 10) mZbad |= (1ULL << c);
                    if (a == 2 || a == 10) mHFbad |= (1ULL << c);
                } else {
                    if (a == 12) mZbad |= (1ULL << c);
                    if (a == 4 || a == 8) mHcFbad |= (1ULL << c);
                }
            }
            for (int c0 = 0; c0 < 64; ++c0) {
                if (mZbad & Z6_all[c0]) continue;
                int D = __builtin_popcountll(mH & Z6_all[c0])
                      + 2 * __builtin_popcountll(mHFbad & F6_all[c0])
                      + 4 * __builtin_popcountll(mHcFbad & F6_all[c0]);
                if (D <= 36) { surv++; if (D < minD) minD = D; }
            }
        }
    }
    return {surv > 0, xor_v == 0, minD, surv};
}

void run_pair(const char* fn, int size, int h) {
    int p = h - size, max_wt3 = 32 - h;
    FILE* f = fopen(fn, "rb");
    if (!f) { perror(fn); exit(1); }
    std::vector<uint64_t> masks; uint64_t m;
    while (fread(&m, 8, 1, f) == 1) masks.push_back(m);
    fclose(f);

    uint64_t pass_lv = 0, pass_v0 = 0;
    struct Hit { uint64_t E, F, V0; int wt3, minD; bool beta0; int surv; };
    std::vector<Hit> hits;

    int pts[16], terms[16][64], base[64];
    for (uint64_t mask : masks) {
        int k = 0; for (uint64_t t = mask; t; t &= t - 1) pts[k++] = __builtin_ctzll(t);
        for (int c = 0; c < 64; ++c) base[c] = 0;
        for (int i = 0; i < size; ++i) {
            int x = pts[i], qx = Q[x];
            for (int c = 0; c < 64; ++c) { int v = qx * W[x][c]; terms[i][c] = v; base[c] += v; }
        }
        int s[64]; for (int c = 0; c < 64; ++c) s[c] = base[c];
        auto dfs = [&](auto& self, int idx, int rem, uint64_t fmask) -> void {
            if (rem == 0) {
                int wt3 = 0;
                for (int c = 0; c < 64; ++c) {
                    int lv = 3 + ((Q[c] * s[c]) >> 1);
                    if (lv < 0 || lv > 12) return;
                    if (lv % 3) if (++wt3 > max_wt3) return;
                }
                pass_lv++;
                uint64_t v0m = mask ^ fmask;
                auto res = check_v0(v0m);
                if (res.ok) {
                    pass_v0++;
                    hits.push_back({mask, fmask, v0m, wt3, res.minD, res.beta0, res.surv_cnt});
                }
                return;
            }
            for (int i = idx; i <= size - rem; ++i) {
                for (int c = 0; c < 64; ++c) s[c] += terms[i][c];
                self(self, i + 1, rem - 1, fmask | (1ULL << pts[i]));
                for (int c = 0; c < 64; ++c) s[c] -= terms[i][c];
            }
        };
        dfs(dfs, 0, p, 0);
    }
    std::cout << "h=" << h << " p=" << p << " (size=" << size << ", |V0|=" << (h - 2*p)
              << "): pass_levels=" << pass_lv << " -> SURVIVE EXACT v0 = " << pass_v0 << "\n" << std::flush;
    for (size_t i = 0; i < std::min<size_t>(hits.size(), 15); ++i) {
        auto& x = hits[i];
        std::cout << "    E=0x" << std::hex << x.E << " F=0x" << x.F << " V0=0x" << x.V0 << std::dec
                  << " wt3=" << x.wt3 << " " << (x.beta0 ? "beta0" : "beta1H")
                  << " minD=" << x.minD << " surv=" << x.surv << "\n";
    }
    if (hits.size() > 15) std::cout << "    ... (" << hits.size() - 15 << " more)\n";
}

int main() {
    init();
    run_pair("shapes/shapes12.bin", 12, 12);
    run_pair("shapes/shapes11.bin", 11, 12);
    run_pair("shapes/shapes13.bin", 13, 14);
    run_pair("shapes/shapes12.bin", 12, 14);
    run_pair("shapes/shapes11.bin", 11, 14);
    run_pair("shapes/shapes13.bin", 13, 16);
    run_pair("shapes/shapes12.bin", 12, 16);
    run_pair("shapes/shapes11.bin", 11, 16);
}
