// Test on F_2^5: Does ANY d : F_2^5 -> {-2, -1, 0, +1, +2} have |WHT_5(d)(c)| in {2, 6} everywhere
// with m_2 = #{c in F_2^5 : |WHT_5(d)(c)| == 2} <= 6?!
// Scans ALL 1,024 quadratic forms p in RM(2, 5)/RM(1, 5) via exact 16+16 half-join!
// Includes mandatory positive control (m_2 = 32 -> wt-4 d with |WHT_5|=2 everywhere, AND a real d with +-6s)!
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include <vector>

static void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}

int main() {
    uint32_t qmon[10]; int qi = 0;
    for (int i = 0; i < 5; ++i) for (int j = i + 1; j < 5; ++j) {
        uint32_t m = 0; for (int c = 0; c < 32; ++c) if (((c >> i) & 1) && ((c >> j) & 1)) m |= (1u << c);
        qmon[qi++] = m;
    }
    const int MAX_M2 = 4;
    uint64_t hits_by_m2[33]{};
    for (int qm = 0; qm < 1024; ++qm) {
        uint32_t p = 0; for (int b = 0; b < 10; ++b) if ((qm >> b) & 1) p ^= qmon[b];
        struct Q8 { std::array<int8_t, 8> b; uint8_t m2; };
        auto do_q8 = [&](int st, std::array<std::vector<Q8>, 256>& out) {
            std::array<int, 8> z{};
            auto dfs = [&](auto& self, int j, uint8_t m2) -> void {
                if (j == 8) {
                    auto u = z; fwht8(u); uint8_t par = 0; std::array<int8_t, 8> b;
                    for (int y = 0; y < 8; ++y) {
                        if (u[y] & 7) return;
                        int q = u[y] >> 3; if (std::abs(q) > 8) return;
                        b[y] = q; if (q & 1) par |= (1u << y);
                    }
                    out[par].push_back({b, m2}); return;
                }
                int pb = (p >> (st + j)) & 1;
                z[j] = pb ? 6 : -6; self(self, j + 1, m2);
                if (m2 < MAX_M2) { z[j] = pb ? -2 : 2; self(self, j + 1, m2 + 1); }
            };
            dfs(dfs, 0, 0);
        };
        struct H16 { std::array<int8_t, 16> u; uint8_t m2; };
        auto do_h16 = [&](int st, std::unordered_map<uint16_t, std::vector<H16>>& out) {
            std::array<std::vector<Q8>, 256> q0, q1; do_q8(st, q0); do_q8(st + 8, q1);
            for (int p8 = 0; p8 < 256; ++p8) {
                if (q0[p8].empty() || q1[p8].empty()) continue;
                for (const auto& a : q0[p8]) for (const auto& b : q1[p8]) {
                    if (a.m2 + b.m2 > MAX_M2) continue;
                    std::array<int8_t, 16> u; uint16_t p16 = 0; bool ok = true;
                    for (int y = 0; y < 8; ++y) {
                        if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                        int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                        u[y] = s; u[8+y] = d;
                        if (s & 1) p16 |= (1u << y); if (d & 1) p16 |= (1u << (8 + y));
                    }
                    if (ok) out[p16].push_back({u, uint8_t(a.m2 + b.m2)});
                }
            }
        };
        std::unordered_map<uint16_t, std::vector<H16>> g0, g1;
        do_h16(0, g0); do_h16(16, g1);
        for (const auto& [par, v0] : g0) {
            auto it = g1.find(par); if (it == g1.end()) continue;
            for (const auto& a : v0) for (const auto& b : it->second) {
                if (a.m2 + b.m2 > MAX_M2) continue;
                bool ok = true;
                for (int y = 0; y < 16; ++y) {
                    if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                }
                if (ok) hits_by_m2[a.m2 + b.m2]++;
            }
        }
    }
    std::cout << "ALL 1024 quad forms on F_2^5 scanned for d: F_2^5 -> {-2,-1,0,1,2} with |WHT_5(d)| in {2, 6}, m_2 <= " << MAX_M2 << ":\n";
    for (int m2 = 0; m2 <= MAX_M2; ++m2)
        std::cout << "  m_2 = " << m2 << ": " << hits_by_m2[m2] << " solutions\n";
}
