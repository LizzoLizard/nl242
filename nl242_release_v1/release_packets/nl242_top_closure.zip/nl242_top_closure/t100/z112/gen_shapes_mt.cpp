// Multi-threaded exact next_layer from geom20.cpp (8 threads, sharded deduplication).
// Includes built-in verification on shapes9 -> shapes10 (must equal 2,965!).
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>
#include <thread>
#include <unordered_set>
#include <vector>

using U = uint64_t;
static int B[64][64];
static inline int lo(U b) { return __builtin_ctzll(b); }
static inline int im(int x) { return ((x & 21) << 1) | ((x & 42) >> 1); }

static void init() {
    for (int x = 0; x < 64; ++x)
        for (int y = 0; y < 64; ++y) B[x][y] = __builtin_parity(im(x) & y);
}

using Code = std::array<unsigned char, 20>;
struct Hash {
    size_t operator()(const Code& a) const {
        size_t h = 1;
        for (auto x : a) h = h * 131 + x;
        return h;
    }
};
struct Frame {
    int span[64]{}, rank = 0, gram[64]{}, rep[64];
    Frame() { std::fill(rep, rep + 64, -1); rep[0] = 0; }
    int code(int x) const { return rep[x] >= 0 ? rep[x] : 64 + gram[x]; }
    void add(int x) {
        if (rep[x] >= 0) return;
        int w = 1 << rank++;
        for (int j = 0; j < w; ++j) { int y = span[j] ^ x; rep[y] = w + j; span[w + j] = y; }
        for (int i = 0; i < 64; ++i) gram[i] += w * B[x][i];
    }
};

static void rec(U left, int origin, const Frame& f, Code& cur, Code& best, int depth, int cmp) {
    if (!left) { if (cur < best) best = cur; return; }
    int smallest = 128;
    for (U v = left; v; v &= v - 1) smallest = std::min(smallest, f.code(lo(v) ^ origin));
    if (!cmp && smallest > best[depth]) return;
    cur[depth] = smallest;
    for (U v = left; v; v &= v - 1) {
        int x = lo(v);
        if (f.code(x ^ origin) != smallest) continue;
        int c = std::lexicographical_compare(cur.begin(), cur.begin() + depth + 1, best.begin(), best.begin() + depth + 1) ? -1 :
                std::equal(cur.begin(), cur.begin() + depth + 1, best.begin()) ? 0 : 1;
        if (c > 0) continue;
        Frame next = f; next.add(x ^ origin);
        rec(left ^ (U(1) << x), origin, next, cur, best, depth + 1, c);
    }
}

static Code canon(U set) {
    Code best; best.fill(255); Code cur{}; Frame f;
    for (U v = set; v; v &= v - 1) { int x = lo(v); rec(set ^ (U(1) << x), x, f, cur, best, 0, -1); }
    return best;
}

static std::vector<U> next_layer_mt(const std::vector<U>& old, int nthreads = 8) {
    // 64 shards by hash of Code -> zero lock contention during canon, fast parallel merge!
    constexpr int NSHARDS = 64;
    struct Pair { Code c; U m; };
    std::vector<std::vector<std::vector<Pair>>> tbuf(nthreads, std::vector<std::vector<Pair>>(NSHARDS));
    std::atomic<size_t> next_idx{0};
    std::vector<std::thread> ths;
    for (int ti = 0; ti < nthreads; ++ti) {
        ths.emplace_back([&, ti]() {
            Hash hasher;
            while (true) {
                size_t start = next_idx.fetch_add(128);
                if (start >= old.size()) break;
                size_t end = std::min(old.size(), start + 128);
                for (size_t idx = start; idx < end; ++idx) {
                    U s = old[idx];
                    int o = lo(s); Frame f;
                    for (U v = s; v; v &= v - 1) f.add(lo(v) ^ o);
                    bool visited[128]{};
                    for (U v = ~s; v; v &= v - 1) {
                        int x = lo(v), c = f.code(x ^ o);
                        if (visited[c]) continue;
                        visited[c] = true;
                        U ext = s | (U(1) << x);
                        Code cd = canon(ext);
                        size_t sh = hasher(cd) & (NSHARDS - 1);
                        tbuf[ti][sh].push_back({cd, ext});
                    }
                }
            }
        });
    }
    for (auto& th : ths) th.join();

    // Parallel deduplication per shard
    std::vector<std::vector<U>> shard_out(NSHARDS);
    std::atomic<int> next_sh{0};
    ths.clear();
    for (int ti = 0; ti < nthreads; ++ti) {
        ths.emplace_back([&]() {
            while (true) {
                int sh = next_sh.fetch_add(1);
                if (sh >= NSHARDS) break;
                std::unordered_set<Code, Hash> seen;
                for (int t = 0; t < nthreads; ++t) {
                    for (const auto& p : tbuf[t][sh]) {
                        if (seen.insert(p.c).second) shard_out[sh].push_back(p.m);
                    }
                    std::vector<Pair>().swap(tbuf[t][sh]);
                }
            }
        });
    }
    for (auto& th : ths) th.join();

    std::vector<U> out;
    size_t tot = 0;
    for (int sh = 0; sh < NSHARDS; ++sh) tot += shard_out[sh].size();
    out.reserve(tot);
    for (int sh = 0; sh < NSHARDS; ++sh) {
        out.insert(out.end(), shard_out[sh].begin(), shard_out[sh].end());
    }
    return out;
}

static std::vector<U> read_bin(const std::string& fn) {
    FILE* f = fopen(fn.c_str(), "rb");
    if (!f) { perror(fn.c_str()); exit(1); }
    std::vector<U> v; U s;
    while (fread(&s, 8, 1, f) == 1) v.push_back(s);
    fclose(f);
    return v;
}
static void write_bin(const std::string& fn, const std::vector<U>& v) {
    FILE* f = fopen(fn.c_str(), "wb");
    if (!f) { perror(fn.c_str()); exit(1); }
    fwrite(v.data(), 8, v.size(), f);
    fclose(f);
}

int main() {
    init();
    // Positive control: shapes9 -> shapes10 must be 2965!
    auto s9 = read_bin("shapes/shapes9.bin");
    auto chk10 = next_layer_mt(s9, 8);
    if (chk10.size() != 2965) {
        std::cerr << "POS CTRL FAILED: got " << chk10.size() << " expected 2965\n";
        return 1;
    }
    std::cout << "[POS CTRL] shapes9 -> shapes10 = " << chk10.size() << " (EXACT MATCH!)\n" << std::flush;

    auto cur = read_bin("shapes/shapes10.bin");
    for (int n = 11; n <= 14; ++n) {
        auto t0 = std::chrono::steady_clock::now();
        cur = next_layer_mt(cur, 8);
        double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        std::cout << "shapes" << n << ": " << cur.size() << " (" << dt << "s)\n" << std::flush;
        write_bin("shapes/shapes" + std::to_string(n) + ".bin", cur);
    }
    if (cur.size() != 560256) {
        std::cerr << "CHECKSUM MISMATCH at shapes14: got " << cur.size() << " expected 560256!\n";
        return 1;
    }
    std::cout << "[CHECKSUM PASS] shapes14 == 560256 (100% EXACT MATCH WITH next15.err!)\n";
    return 0;
}
