// EXHAUSTIVE 100%-exact scan of ALL h=14, p=0 (|V_0|=14, F=empty, wt_3<=18) defect sets in F_2^6
// by removing 1 point from each of the 1,812,230 orbits in shapes15.bin!
// Identity: #{c : (w[c] - Q(x0)*(-1)^{c.x0}) == 0 mod 3} == (wt + Q(x0)*WHT(f)[x0]) / 2 >= 46 (wt + Q*f >= 92)!
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <iostream>
#include <set>
#include <stdexcept>
#include <vector>

static int Q[64], W[64][64];
static void fwht64(int a[64]) {
    for (int st = 1; st < 64; st *= 2)
        for (int i = 0; i < 64; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
int B6[64][64];
int im6(int x) { return ((x & 21) << 1) | ((x & 42) >> 1); }
using Code14 = std::array<unsigned char, 14>;
struct Frame {
    int span[64]{}, rank = 0, gram[64]{}, rep[64];
    Frame() { std::fill(rep, rep + 64, -1); rep[0] = 0; }
    int code(int x) const { return rep[x] >= 0 ? rep[x] : 64 + gram[x]; }
    void add(int x) {
        if (rep[x] >= 0) return;
        int w = 1 << rank++;
        for (int j = 0; j < w; ++j) { int y = span[j] ^ x; rep[y] = w + j; span[w + j] = y; }
        for (int i = 0; i < 64; ++i) gram[i] += w * B6[x][i];
    }
};
void rec_c(uint64_t left, int origin, const Frame& f, Code14& cur, Code14& best, int depth, int cmp) {
    if (!left) { if (cur < best) best = cur; return; }
    int smallest = 128;
    for (uint64_t v = left; v; v &= v - 1) smallest = std::min(smallest, f.code(__builtin_ctzll(v) ^ origin));
    if (!cmp && smallest > best[depth]) return;
    cur[depth] = smallest;
    for (uint64_t v = left; v; v &= v - 1) {
        int x = __builtin_ctzll(v);
        if (f.code(x ^ origin) != smallest) continue;
        int c = std::lexicographical_compare(cur.begin(), cur.begin() + depth + 1, best.begin(), best.begin() + depth + 1) ? -1 :
                std::equal(cur.begin(), cur.begin() + depth + 1, best.begin()) ? 0 : 1;
        if (c > 0) continue;
        Frame next = f; next.add(x ^ origin);
        rec_c(left ^ (1ULL << x), origin, next, cur, best, depth + 1, c);
    }
}
Code14 canon14(uint64_t set) {
    Code14 best; best.fill(255); Code14 cur{}; Frame f;
    for (uint64_t v = set; v; v &= v - 1) { int x = __builtin_ctzll(v); rec_c(set ^ (1ULL << x), x, f, cur, best, 0, -1); }
    return best;
}

int main() {
    for (int x = 0; x < 64; ++x) {
        Q[x] = __builtin_parity((x >> 1) & x & 21) ? -1 : 1;
        for (int y = 0; y < 64; ++y) { W[x][y] = __builtin_parity(x & y) ? -1 : 1; B6[x][y] = __builtin_parity(im6(x) & y); }
    }
    FILE* fp = fopen("shapes/shapes15.bin", "rb");
    std::vector<uint64_t> masks; uint64_t m;
    while (fread(&m, 8, 1, fp) == 1) masks.push_back(m);
    fclose(fp);
    // Positive control on first 200 masks
    for (int mi = 0; mi < 200; ++mi) {
        uint64_t mask = masks[mi];
        int w[64]{}; for (uint64_t t = mask; t; t &= t - 1) { int x = __builtin_ctzll(t); w[x] = Q[x]; }
        fwht64(w);
        int f[64]{}, wt = 0;
        for (int c = 0; c < 64; ++c) { int r = ((w[c] % 3) + 3) % 3; if (r == 1) { f[c] = 1; wt++; } else if (r == 2) { f[c] = -1; wt++; } }
        fwht64(f);
        for (uint64_t t = mask; t; t &= t - 1) {
            int x0 = __builtin_ctzll(t);
            int pred = (wt + Q[x0] * f[x0]) / 2, act = 0;
            for (int c = 0; c < 64; ++c) if ((w[c] - Q[x0] * W[x0][c]) % 3 == 0) act++;
            if (pred != act) throw std::logic_error("pos ctrl failed");
        }
    }
    auto t0 = std::chrono::steady_clock::now();
    std::set<Code14> uniq; std::vector<uint64_t> reps;
    uint64_t raw = 0;
    for (uint64_t mask : masks) {
        int w[64]{}; for (uint64_t t = mask; t; t &= t - 1) { int x = __builtin_ctzll(t); w[x] = Q[x]; }
        fwht64(w);
        int f[64]{}, wt = 0;
        for (int c = 0; c < 64; ++c) { int r = ((w[c] % 3) + 3) % 3; if (r == 1) { f[c] = 1; wt++; } else if (r == 2) { f[c] = -1; wt++; } }
        if (wt < 46) continue;
        fwht64(f);
        for (uint64_t t = mask; t; t &= t - 1) {
            int x0 = __builtin_ctzll(t);
            if (wt + Q[x0] * f[x0] < 92) continue;
            bool ok = true;
            for (int c = 0; c < 64; ++c) { int lv = 3 + ((Q[c] * (w[c] - Q[x0] * W[x0][c])) >> 1); if (lv < 0 || lv > 12) { ok = false; break; } }
            if (!ok) continue;
            raw++;
            uint64_t m14 = mask ^ (1ULL << x0);
            if (uniq.insert(canon14(m14)).second) reps.push_back(m14);
        }
    }
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "h=14 p=0 DONE in " << dt << "s! raw=" << raw << " UNIQUE orbits=" << reps.size() << "\n";
    for (uint64_t m14 : reps) {
        int w[64]{}; for (uint64_t t = m14; t; t &= t - 1) { int x = __builtin_ctzll(t); w[x] = Q[x]; }
        fwht64(w);
        int hist[13]{}, wt3 = 0;
        for (int c = 0; c < 64; ++c) { int lv = 3 + ((Q[c] * w[c]) >> 1); hist[lv]++; if (lv % 3) wt3++; }
        std::cout << "  0x" << std::hex << m14 << std::dec << " wt3=" << wt3 << " hist=";
        for (int l = 0; l <= 12; ++l) if (hist[l]) std::cout << l << ":" << hist[l] << " ";
        std::cout << "\n";
    }
}
