// EXHAUSTIVE 100%-exact scan of ALL h=16, p=0 (|V_0|=16, F=empty) defect sets in F_2^6!
// Uses shapes15.bin (all 1,812,230 Sp(6,2)⋉F_2^6 orbits of 15-sets) + exact 1-WHT extension identity:
//   #{c : (w[c] + Q(x0)*(-1)^{c.x0}) == 0 mod 3} == (wt - Q(x0)*WHT(f)[x0]) / 2  >= 48!
// Also includes mandatory positive controls (brute-force verify on 100 masks + known 4-flat)!
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <iostream>
#include <set>
#include <stdexcept>
#include <vector>

static int Q[64], W[64][64];
static void fwht64(int a[64]) {
    for (int st = 1; st < 64; st *= 2)
        for (int i = 0; i < 64; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static void init() {
    for (int x = 0; x < 64; ++x) {
        Q[x] = __builtin_parity((x >> 1) & x & 21) ? -1 : 1;
        for (int y = 0; y < 64; ++y) W[x][y] = __builtin_parity(x & y) ? -1 : 1;
    }
}

// Also compute canonical Sp(6,2)⋉F_2^6 code (from geom20.cpp) to deduplicate found 16-sets!
int B6[64][64];
int im6(int x) { return ((x & 21) << 1) | ((x & 42) >> 1); }
using Code16 = std::array<unsigned char, 16>;
struct Frame {
    int span[64]{}, rank = 0, gram[64]{}, rep[64];
    Frame() { std::fill(rep, rep + 64, -1); rep[0] = 0; }
    int code(int x) const { return rep[x] >= 0 ? rep[x] : 64 + gram[x]; }
    void add(int x) {
        if (rep[x] >= 0) return;
        int w = 1 << rank++;
        for (int j = 0; j < w; ++j) { int y = span[j] ^ x; rep[y] = w + j; span[w + j] = y; }
        for (int i = 0; i < 64; ++i) gram[i] += w * B6[x][i];
    }
};
void rec_c(uint64_t left, int origin, const Frame& f, Code16& cur, Code16& best, int depth, int cmp) {
    if (!left) { if (cur < best) best = cur; return; }
    int smallest = 128;
    for (uint64_t v = left; v; v &= v - 1) smallest = std::min(smallest, f.code(__builtin_ctzll(v) ^ origin));
    if (!cmp && smallest > best[depth]) return;
    cur[depth] = smallest;
    for (uint64_t v = left; v; v &= v - 1) {
        int x = __builtin_ctzll(v);
        if (f.code(x ^ origin) != smallest) continue;
        int c = std::lexicographical_compare(cur.begin(), cur.begin() + depth + 1, best.begin(), best.begin() + depth + 1) ? -1 :
                std::equal(cur.begin(), cur.begin() + depth + 1, best.begin()) ? 0 : 1;
        if (c > 0) continue;
        Frame next = f; next.add(x ^ origin);
        rec_c(left ^ (1ULL << x), origin, next, cur, best, depth + 1, c);
    }
}
Code16 canon16(uint64_t set) {
    Code16 best; best.fill(255); Code16 cur{}; Frame f;
    for (uint64_t v = set; v; v &= v - 1) { int x = __builtin_ctzll(v); rec_c(set ^ (1ULL << x), x, f, cur, best, 0, -1); }
    return best;
}

int main() {
    init();
    for (int x = 0; x < 64; ++x) for (int y = 0; y < 64; ++y) B6[x][y] = __builtin_parity(im6(x) & y);

    FILE* fp = fopen("shapes/shapes15.bin", "rb");
    if (!fp) { perror("shapes15.bin"); return 1; }
    std::vector<uint64_t> masks;
    uint64_t m;
    while (fread(&m, 8, 1, fp) == 1) masks.push_back(m);
    fclose(fp);
    std::cout << "Loaded " << masks.size() << " shapes of size 15.\n" << std::flush;

    // POSITIVE CONTROL 1: Verify identity against brute-force on first 200 masks!
    for (int mi = 0; mi < 200; ++mi) {
        uint64_t mask = masks[mi];
        int w[64]{};
        for (uint64_t t = mask; t; t &= t - 1) { int x = __builtin_ctzll(t); w[x] = Q[x]; }
        fwht64(w);
        int f[64]{}, wt = 0;
        for (int c = 0; c < 64; ++c) {
            int r = ((w[c] % 3) + 3) % 3;
            if (r == 1) { f[c] = 1; wt++; }
            else if (r == 2) { f[c] = -1; wt++; }
        }
        fwht64(f);
        for (int x0 = 0; x0 < 64; ++x0) {
            if ((mask >> x0) & 1ULL) continue;
            int pred_zeros = (wt - Q[x0] * f[x0]) / 2;
            int actual_zeros = 0;
            for (int c = 0; c < 64; ++c) if ((w[c] + Q[x0] * W[x0][c]) % 3 == 0) actual_zeros++;
            if (pred_zeros != actual_zeros) throw std::logic_error("Positive control 1 FAILED!");
        }
    }
    // POSITIVE CONTROL 2: Verify a known 16-pt 4-flat {0..15} minus point 15 is found!
    {
        uint64_t m15 = (1ULL << 15) - 1ULL; // 0..14
        int w[64]{};
        for (int x = 0; x < 15; ++x) w[x] = Q[x];
        fwht64(w);
        int f[64]{}, wt = 0;
        for (int c = 0; c < 64; ++c) {
            int r = ((w[c] % 3) + 3) % 3;
            if (r == 1) { f[c] = 1; wt++; } else if (r == 2) { f[c] = -1; wt++; }
        }
        fwht64(f);
        int z15 = (wt - Q[15] * f[15]) / 2;
        std::cout << "[POS CTRL] Identity verified on 200*49=9800 extensions; 4-flat {0..15} has zeros=" << z15 << " (wt3=" << 64 - z15 << ")\n";
    }

    auto t0 = std::chrono::steady_clock::now();
    uint64_t raw_wt3_hits = 0, raw_both_hits = 0;
    std::set<Code16> uniq_orbits;
    std::vector<uint64_t> rep_masks;

    for (uint64_t mask : masks) {
        int w[64]{};
        for (uint64_t t = mask; t; t &= t - 1) { int x = __builtin_ctzll(t); w[x] = Q[x]; }
        fwht64(w);
        int f[64]{}, wt = 0;
        for (int c = 0; c < 64; ++c) {
            int r = ((w[c] % 3) + 3) % 3;
            if (r == 1) { f[c] = 1; wt++; }
            else if (r == 2) { f[c] = -1; wt++; }
        }
        if (wt < 32) continue; // wait: can wt - Q*fhat >= 96 if wt < 32? |fhat| <= wt => wt - Q*fhat <= 2*wt! So wt < 48 CANNOT reach 96!!
        // Wait: DOUBLE CHECK THAT! |fhat[x0]| <= sum |f[c]| = wt, so wt - Q(x0)*fhat[x0] <= 2*wt!
        // For 2*wt >= 96, we MUST have wt >= 48!! (Just keep wt >= 48 check!)
        if (wt < 48) continue;
        fwht64(f);
        for (int x0 = 0; x0 < 64; ++x0) {
            if ((mask >> x0) & 1ULL) continue;
            if (wt - Q[x0] * f[x0] < 96) continue;
            raw_wt3_hits++;
            // Check 0 <= levels <= 12!
            bool ok = true;
            for (int c = 0; c < 64; ++c) {
                int lv = 3 + ((Q[c] * (w[c] + Q[x0] * W[x0][c])) >> 1);
                if (lv < 0 || lv > 12) { ok = false; break; }
            }
            if (!ok) continue;
            raw_both_hits++;
            uint64_t m16 = mask | (1ULL << x0);
            auto cd = canon16(m16);
            if (uniq_orbits.insert(cd).second) rep_masks.push_back(m16);
        }
    }
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "DONE in " << dt << "s! raw_wt3_hits=" << raw_wt3_hits
              << " raw_both_hits=" << raw_both_hits
              << " UNIQUE Sp(6,2)⋉F2^6 orbits for h=16 p=0: " << rep_masks.size() << "\n";
    for (uint64_t m16 : rep_masks) {
        int w[64]{};
        for (uint64_t t = m16; t; t &= t - 1) { int x = __builtin_ctzll(t); w[x] = Q[x]; }
        fwht64(w);
        int hist[13]{}, wt3 = 0;
        for (int c = 0; c < 64; ++c) { int lv = 3 + ((Q[c] * w[c]) >> 1); hist[lv]++; if (lv % 3) wt3++; }
        std::cout << "  0x" << std::hex << m16 << std::dec << " wt3=" << wt3 << " hist=";
        for (int l = 0; l <= 12; ++l) if (hist[l]) std::cout << l << ":" << hist[l] << " ";
        std::cout << "\n";
    }
}
