// Exact corrected killer for the ONLY two lv=5 cases (h16_p6_odd and h16_p0_a),
// using exact computer-verified lv=5 (k=1) multiset {10, 2, 2} (so every u_x has |u_x_hat| in {2, 10} on lv=5!).
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <unordered_map>
#include <vector>

static int Q[64];
static void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static std::array<int, 64> get_levels(uint64_t Em, uint64_t Fm) {
    std::array<int, 64> lv{};
    for (int c = 0; c < 64; ++c) {
        int s = 0;
        for (uint64_t t = Em; t; t &= t - 1) { int y = __builtin_ctzll(t); s += Q[y] * (__builtin_parity(y & c) ? -1 : 1); }
        for (uint64_t t = Fm; t; t &= t - 1) { int y = __builtin_ctzll(t); s += Q[y] * (__builtin_parity(y & c) ? -1 : 1); }
        lv[c] = 3 + ((Q[c] * s) >> 1);
    }
    return lv;
}
struct HalfItem { uint32_t tw; int e2; };
struct OptVal { int8_t val; };
static void enum_F5(const std::array<std::vector<OptVal>, 32>& opts,
                    std::unordered_map<uint32_t, std::vector<HalfItem>>& out) {
    struct Q8 { std::array<int8_t, 8> b; };
    auto do_q8 = [&](int st, std::array<std::vector<Q8>, 256>& qout) {
        std::array<int, 8> z{};
        auto dfs = [&](auto& self, int j) -> void {
            if (j == 8) {
                auto u = z; fwht8(u); uint8_t par = 0; std::array<int8_t, 8> b;
                for (int y = 0; y < 8; ++y) {
                    if (u[y] & 7) return;
                    int qq = u[y] >> 3; if (std::abs(qq) > 8) return;
                    b[y] = qq; if (qq & 1) par |= (1u << y);
                }
                qout[par].push_back({b}); return;
            }
            for (auto ov : opts[st + j]) { z[j] = ov.val; self(self, j + 1); }
        };
        dfs(dfs, 0);
    };
    struct H16 { std::array<int8_t, 16> u; };
    auto do_h16 = [&](int st, std::unordered_map<uint16_t, std::vector<H16>>& hout) {
        std::array<std::vector<Q8>, 256> q0, q1; do_q8(st, q0); do_q8(st + 8, q1);
        for (int p8 = 0; p8 < 256; ++p8) {
            if (q0[p8].empty() || q1[p8].empty()) continue;
            for (const auto& a : q0[p8]) for (const auto& b : q1[p8]) {
                std::array<int8_t, 16> u; uint16_t p16 = 0; bool ok = true;
                for (int y = 0; y < 8; ++y) {
                    if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                    int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                    u[y] = s; u[8+y] = d;
                    if (s & 1) p16 |= (1u << y); if (d & 1) p16 |= (1u << (8 + y));
                }
                if (ok) hout[p16].push_back({u});
            }
        }
    };
    std::unordered_map<uint16_t, std::vector<H16>> g0, g1;
    do_h16(0, g0); do_h16(16, g1);
    for (const auto& [par, v0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (1u << y); if (x1 & 1) p32 |= (1u << (16 + y));
                if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
            }
            if (ok) out[p32].push_back({tw, e2});
        }
    }
}

int main() {
    for (int x = 0; x < 64; ++x) Q[x] = __builtin_parity((x >> 1) & x & 21) ? -1 : 1;

    // 1. h16_p6_odd (ALL 4 hits): lv=3/9 -> {v6}, lv=1/11 -> {v2}, lv=5 -> {v2, v10}!
    uint64_t qmon6[15]; int qi = 0;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        uint64_t m = 0; for (int c = 0; c < 64; ++c) if (((c >> i) & 1) && ((c >> j) & 1)) m |= (1ULL << c);
        qmon6[qi++] = m;
    }
    FILE* f = fopen("shapes/shapes10.bin", "rb");
    uint64_t m; int idx = 0;
    while (fread(&m, 8, 1, f) == 1) {
        int pts[10], k = 0; for (uint64_t t = m; t; t &= t - 1) pts[k++] = __builtin_ctzll(t);
        for (int mask = 0; mask < 1024; ++mask) {
            if (__builtin_popcount(mask) != 6) continue;
            uint64_t Fm = 0; for (int i = 0; i < 10; ++i) if ((mask >> i) & 1) Fm |= (1ULL << pts[i]);
            auto lv = get_levels(m, Fm);
            bool ok = true; int wt3 = 0; bool any_even = false;
            for (int c = 0; c < 64; ++c) {
                if (lv[c] < 0 || lv[c] > 12) { ok = false; break; }
                if (lv[c] % 3) wt3++;
                if (!(lv[c] & 1)) any_even = true;
            }
            if (!ok || wt3 > 16 || any_even) continue;
            idx++;
            uint64_t hits = 0;
            for (int qm = 0; qm < (1 << 15); ++qm) {
                uint64_t p = 0; for (int b = 0; b < 15; ++b) if ((qm >> b) & 1) p ^= qmon6[b];
                std::array<std::vector<OptVal>, 32> o0, o1;
                for (int c = 0; c < 64; ++c) {
                    int pb = (p >> c) & 1;
                    int8_t v2 = pb ? -2 : 2, v6 = pb ? 6 : -6, v10 = pb ? -10 : 10;
                    auto& dst = (c < 32) ? o0[c] : o1[c - 32];
                    if (lv[c] == 3 || lv[c] == 9) dst = {{v6}};
                    else if (lv[c] == 1 || lv[c] == 11) dst = {{v2}};
                    else if (lv[c] == 5) dst = {{v2}, {v10}};
                    else throw std::logic_error("Bad lv");
                }
                std::unordered_map<uint32_t, std::vector<HalfItem>> m0, m1;
                enum_F5(o0, m0); if (m0.empty()) continue;
                enum_F5(o1, m1);
                for (auto& [p32, v0] : m0) {
                    auto it = m1.find(p32); if (it == m1.end()) continue;
                    for (auto& a : v0) for (auto& b : it->second) if (!(a.tw & b.tw)) hits++;
                }
            }
            std::cout << "[CORRECTED h16_p6_odd #" << idx << " ({v2,v10} on lv5)] hits=" << hits << "\n" << std::flush;
        }
    }
    fclose(f);

    // 2. h16_p0_a (0x110011008700ff): on H, lv=3 (24): {v6}, lv=1 (4): {v2}, lv=5 (4): {v2, v10}!
    //    Check BOTH H alone AND full H x H^c join + alive triples!
    {
        uint64_t Em = 0x110011008700ffULL;
        auto lv = get_levels(Em, 0);
        int u_dir = 4;
        std::vector<int> basis; int v_shift = -1;
        for (int c = 1; c < 64; ++c) {
            if (__builtin_parity(c & u_dir)) { if (v_shift == -1) v_shift = c; }
            else { int t = c; for (int b : basis) t = std::min(t, t ^ b); if (t) basis.push_back(c); }
        }
        bool H_is_0 = (lv[0] & 1) != 0;
        std::array<int, 32> lvH{}, lvHc{};
        for (int a = 0; a < 32; ++a) {
            int c0 = 0; for (int i = 0; i < 5; ++i) if ((a >> i) & 1) c0 ^= basis[i];
            int c1 = c0 ^ v_shift;
            if (H_is_0) { lvH[a] = lv[c0]; lvHc[a] = lv[c1]; }
            else        { lvH[a] = lv[c1]; lvHc[a] = lv[c0]; }
        }
        uint32_t qmon5[10]; qi = 0;
        for (int i = 0; i < 5; ++i) for (int j = i + 1; j < 5; ++j) {
            uint32_t mm = 0; for (int c = 0; c < 32; ++c) if (((c >> i) & 1) && ((c >> j) & 1)) mm |= (1u << c);
            qmon5[qi++] = mm;
        }
        std::unordered_map<uint32_t, std::vector<HalfItem>> map_H;
        for (int qm = 0; qm < 1024; ++qm) {
            uint32_t p = 0; for (int b = 0; b < 10; ++b) if ((qm >> b) & 1) p ^= qmon5[b];
            std::array<std::vector<OptVal>, 32> opts;
            for (int i = 0; i < 32; ++i) {
                int pb = (p >> i) & 1;
                int8_t v2 = pb ? -2 : 2, v6 = pb ? 6 : -6, v10 = pb ? -10 : 10;
                if (lvH[i] == 3) opts[i] = {{v6}};
                else if (lvH[i] == 1) opts[i] = {{v2}};
                else if (lvH[i] == 5) opts[i] = {{v2}, {v10}};
                else throw std::logic_error("Bad lvH");
            }
            enum_F5(opts, map_H);
        }
        size_t nH = 0; for (auto& [k, v] : map_H) nH += v.size();
        // Now join with H^c!
        uint32_t basis5[16]; int nb = 0; basis5[nb++] = 0xFFFFFFFFu;
        for (int i = 0; i < 5; ++i) { uint32_t mm = 0; for (int c = 0; c < 32; ++c) if ((c >> i) & 1) mm |= (1u << c); basis5[nb++] = mm; }
        for (int i = 0; i < 5; ++i) for (int j = i + 1; j < 5; ++j) {
            uint32_t mm = 0; for (int c = 0; c < 32; ++c) if (((c >> i) & 1) && ((c >> j) & 1)) mm |= (1u << c); basis5[nb++] = mm;
        }
        uint32_t m0 = 0, m111 = 0, m110 = 0, m100 = 0;
        for (int i = 0; i < 32; ++i) {
            if (lvHc[i] == 0) m0 |= (1u << i);
            else if (lvHc[i] == 2) m111 |= (1u << i);
            else if (lvHc[i] == 4) m110 |= (1u << i);
            else if (lvHc[i] == 6) m100 |= (1u << i);
        }
        uint64_t total_u = 0; std::vector<uint32_t> alive_ps;
        for (int mask = 0; mask < (1 << 16); ++mask) {
            uint32_t w = 0; for (int b = 0; b < 16; ++b) if ((mask >> b) & 1) w ^= basis5[b];
            if ((w & m0) != 0 || (w & m111) != m111) continue;
            std::array<std::vector<OptVal>, 32> opts;
            for (int i = 0; i < 32; ++i) {
                int pb = (w >> i) & 1;
                if (lvHc[i] == 0) opts[i] = {{0}};
                else if (lvHc[i] == 2) opts[i] = {{-4}, {4}};
                else if (lvHc[i] == 4) opts[i] = pb ? std::vector<OptVal>{{-4}, {4}} : std::vector<OptVal>{{-8}, {8}};
                else if (lvHc[i] == 6) opts[i] = pb ? std::vector<OptVal>{{-12}, {12}} : std::vector<OptVal>{{0}};
            }
            std::unordered_map<uint32_t, std::vector<HalfItem>> map_Hc;
            enum_F5(opts, map_Hc);
            uint64_t loc = 0;
            for (auto& [p32, vhc] : map_Hc) {
                auto it = map_H.find(p32); if (it == map_H.end()) continue;
                for (auto& hc : vhc) for (auto& hh : it->second) if (!(hc.tw & hh.tw)) loc++;
            }
            if (loc) { total_u += loc; alive_ps.push_back(w); }
        }
        int alive_triples = 0;
        for (size_t i = 0; i < alive_ps.size(); ++i)
            for (size_t j = i; j < alive_ps.size(); ++j) {
                if (alive_ps[i] & alive_ps[j] & m100) continue;
                uint32_t p3 = (m111 | m100) ^ alive_ps[i] ^ alive_ps[j];
                if (p3 & (alive_ps[i] | alive_ps[j]) & m100) continue;
                if ((alive_ps[i] & alive_ps[j] & p3 & m110) != 0) continue;
                if (((alive_ps[i] | alive_ps[j] | p3) & m110) != m110) continue;
                if (std::find(alive_ps.begin() + j, alive_ps.end(), p3) != alive_ps.end()) alive_triples++;
            }
        std::cout << "[CORRECTED h16_p0_a ({v2,v10} on lv5)] nH=" << nH
                  << " | total_u=" << total_u << " | alive_p_Hc=" << alive_ps.size()
                  << " | ALIVE TRIPLES=" << alive_triples << "\n";
    }
}
