// Fast exhaustive high-block 4-slice (beta_U == 1) killer over ALL 32,768 quadratic forms RM(2,6)/RM(1,6)!
// Optimization: choose a linear bit-permutation of the 6 frequency bits so that free (mode==2) coords
// are maximally spread across the 8 blocks of 8 (zero impact on WHT_6 / RM(2,6) since bit-perm is in GL(6,2)!).
// ALSO tracks energy e2 = sum_y (u_x(y)^2) <= 2*64 = 128 -> Wait: sum z^2 = 64*wt(u_x) <= 4096!!
// Wait: EVEN STRONGER! For h=16 p=0 b,c, h=16 p=2, h=16 p=4, h=12 p=0:
//   wt(u_1) + wt(u_2) + wt(u_3) = 156 - (64 - |V_0|) = 92 + |V_0| <= 108!
//   So AT LEAST ONE of u_1, u_2, u_3 has wt(u_x) <= (92 + |V_0|) / 3 <= 36!
//   AND EVEN WITHOUT THAT (just wt(u_x) <= 64, valid for ALL THREE u_1, u_2, u_3!):
//   Let's first check total hits with NO wt cap (just wt(u_x) <= 64) AND print min wt & #10s & #2s!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <thread>
#include <unordered_map>
#include <vector>

static int Q[64];
static uint64_t qmon[15];

static void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static void fwht64(std::array<int, 64>& a) {
    for (int st = 1; st < 64; st *= 2)
        for (int i = 0; i < 64; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}

// Find bit-permutation of 0..5 minimizing max count of mode==2 in any 8-block (and sum of 3^cnt)!
static std::array<int, 64> best_perm_mode(const std::array<int, 64>& mode_in, std::array<int, 6>& best_p) {
    std::array<int, 6> p = {0, 1, 2, 3, 4, 5};
    long long best_score = (1LL << 60);
    std::array<int, 64> best_m = mode_in;
    do {
        std::array<int, 64> m{};
        int bcnt[8]{};
        for (int c = 0; c < 64; ++c) {
            int nc = 0;
            for (int i = 0; i < 6; ++i) if ((c >> p[i]) & 1) nc |= (1 << i);
            m[nc] = mode_in[c];
            if (mode_in[c] == 2) bcnt[nc >> 3]++;
        }
        long long sc = 0;
        for (int b = 0; b < 8; ++b) { long long t = 1; for (int k = 0; k < bcnt[b]; ++k) t *= 3; sc += t; }
        // also balance left 32 vs right 32
        int l = bcnt[0]+bcnt[1]+bcnt[2]+bcnt[3], r = bcnt[4]+bcnt[5]+bcnt[6]+bcnt[7];
        sc += 100LL * std::abs(l - r);
        if (sc < best_score) { best_score = sc; best_m = m; best_p = p; }
    } while (std::next_permutation(p.begin(), p.end()));
    return best_m;
}

static uint64_t solve_case(const std::string& name, const std::array<int, 64>& mode_raw, int max_cost, int max_wt = 64) {
    std::array<int, 6> bp;
    auto mode = best_perm_mode(mode_raw, bp);
    int bcnt[8]{}; for (int c = 0; c < 64; ++c) if (mode[c] == 2) bcnt[c >> 3]++;
    auto t0 = std::chrono::steady_clock::now();
    std::atomic<int> next_qm{0};
    std::atomic<uint64_t> total_hits{0};
    std::atomic<int> min_wt_found{999};

    std::vector<std::thread> ths;
    for (int ti = 0; ti < 8; ++ti) {
        ths.emplace_back([&]() {
            while (true) {
                int qm = next_qm.fetch_add(16);
                if (qm >= (1 << 15)) break;
                int qm_end = std::min(1 << 15, qm + 16);
                for (int q = qm; q < qm_end; ++q) {
                    uint64_t p = 0;
                    for (int b = 0; b < 15; ++b) if ((q >> b) & 1) p ^= qmon[b];

                    auto do_half = [&](int offset, std::unordered_map<uint32_t, std::vector<std::tuple<uint32_t, int, int>>>& out) {
                        struct Q8 { std::array<int8_t, 8> b; uint8_t cost; };
                        auto do_q8 = [&](int st, std::array<std::vector<Q8>, 256>& qout) {
                            std::array<int, 8> z{};
                            auto dfs = [&](auto& self, int j, uint8_t cost) -> void {
                                if (j == 8) {
                                    auto u = z; fwht8(u); uint8_t par = 0; std::array<int8_t, 8> b;
                                    for (int y = 0; y < 8; ++y) {
                                        if (u[y] & 7) return;
                                        int qq = u[y] >> 3; if (std::abs(qq) > 8) return;
                                        b[y] = qq; if (qq & 1) par |= (1u << y);
                                    }
                                    qout[par].push_back({b, cost}); return;
                                }
                                int c = st + j;
                                int pb = (p >> c) & 1;
                                int v2 = pb ? -2 : 2, v6 = pb ? 6 : -6, v10 = pb ? -10 : 10;
                                int m = mode[c];
                                if (m == 1) { z[j] = v2; self(self, j + 1, cost); }
                                else if (m == 3) { z[j] = v6; self(self, j + 1, cost); }
                                else if (m == 0) {
                                    z[j] = v6; self(self, j + 1, cost);
                                    if (cost < max_cost) { z[j] = v2; self(self, j + 1, cost + 1); }
                                } else if (m == 2) {
                                    z[j] = v6; self(self, j + 1, cost);
                                    z[j] = v2; self(self, j + 1, cost);
                                    z[j] = v10; self(self, j + 1, cost);
                                }
                            };
                            dfs(dfs, 0, 0);
                        };
                        struct H16 { std::array<int8_t, 16> u; uint8_t cost; };
                        auto do_h16 = [&](int st, std::unordered_map<uint16_t, std::vector<H16>>& hout) {
                            std::array<std::vector<Q8>, 256> q0, q1;
                            do_q8(st, q0); do_q8(st + 8, q1);
                            for (int p8 = 0; p8 < 256; ++p8) {
                                if (q0[p8].empty() || q1[p8].empty()) continue;
                                for (const auto& a : q0[p8]) for (const auto& b : q1[p8]) {
                                    if (a.cost + b.cost > max_cost) continue;
                                    std::array<int8_t, 16> u; uint16_t p16 = 0; bool ok = true;
                                    for (int y = 0; y < 8; ++y) {
                                        if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                                        int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                                        u[y] = s; u[8+y] = d;
                                        if (s & 1) p16 |= (1u << y); if (d & 1) p16 |= (1u << (8 + y));
                                    }
                                    if (ok) hout[p16].push_back({u, uint8_t(a.cost + b.cost)});
                                }
                            }
                        };
                        std::unordered_map<uint16_t, std::vector<H16>> g0, g1;
                        do_h16(offset, g0); do_h16(offset + 16, g1);
                        for (const auto& [par, v0] : g0) {
                            auto it = g1.find(par); if (it == g1.end()) continue;
                            for (const auto& a : v0) for (const auto& b : it->second) {
                                if (a.cost + b.cost > max_cost) continue;
                                uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
                                for (int y = 0; y < 16; ++y) {
                                    if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                                    int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                                    e2 += x0 * x0 + x1 * x1;
                                    if (x0 & 1) p32 |= (1u << y); if (x1 & 1) p32 |= (1u << (16 + y));
                                    if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
                                }
                                if (ok && e2 <= 2 * max_wt) out[p32].push_back({tw, a.cost + b.cost, e2});
                            }
                        }
                    };
                    std::unordered_map<uint32_t, std::vector<std::tuple<uint32_t, int, int>>> h0, h1;
                    do_half(0, h0);
                    if (h0.empty()) continue;
                    do_half(32, h1);
                    uint64_t loc = 0;
                    for (const auto& [p32, v0] : h0) {
                        auto it = h1.find(p32); if (it == h1.end()) continue;
                        for (auto [tw0, c0, e0] : v0) for (auto [tw1, c1, e1] : it->second) {
                            if (tw0 & tw1) continue;
                            if (c0 + c1 > max_cost) continue;
                            int wt = (e0 + e1) / 2;
                            if (wt > max_wt) continue;
                            loc++;
                            int old = min_wt_found.load();
                            while (wt < old && !min_wt_found.compare_exchange_weak(old, wt));
                        }
                    }
                    if (loc) total_hits += loc;
                }
            }
        });
    }
    for (auto& th : ths) th.join();
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "[" << name << "] bcnt=(";
    for (int i = 0; i < 8; ++i) std::cout << bcnt[i] << (i<7?",":"");
    std::cout << ") hits=" << total_hits.load() << " min_wt=" << min_wt_found.load()
              << " (" << dt << "s)\n" << std::flush;
    return total_hits.load();
}

static std::array<int, 64> get_levels(uint64_t Em, uint64_t Fm) {
    std::array<int, 64> lv{};
    for (int c = 0; c < 64; ++c) {
        int s = 0;
        for (uint64_t t = Em; t; t &= t - 1) { int y = __builtin_ctzll(t); s += Q[y] * (__builtin_parity(y & c) ? -1 : 1); }
        for (uint64_t t = Fm; t; t &= t - 1) { int y = __builtin_ctzll(t); s += Q[y] * (__builtin_parity(y & c) ? -1 : 1); }
        lv[c] = 3 + ((Q[c] * s) >> 1);
    }
    return lv;
}

int main() {
    for (int x = 0; x < 64; ++x) Q[x] = __builtin_parity((x >> 1) & x & 21) ? -1 : 1;
    int qi = 0;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        uint64_t m = 0; for (int c = 0; c < 64; ++c) if (((c >> i) & 1) && ((c >> j) & 1)) m |= (1ULL << c);
        qmon[qi++] = m;
    }

    // POSITIVE CONTROL: Real u_pos = Q - Q*1_{0,1,2,3} has 40 +-6s and 24 +-10s;
    // Wait: test with mode=1 on {0..7}? Better: make a real u_pos with <=16 +-2/10s!
    // Take u_pos = 1_{0,1,2} - 1_{3} (wt=4, |z|=2 everywhere) -> mode=1 on 60 pts, mode=2 on 4 pts -> MUST FIND!
    // AND ALSO test a real u with +-6 and +-10: u = Q - Q*1_{0,1,2,3} with mode=3 on 40 +-6s, mode=2 on 12 of the +-10s,
    // and actually we can construct u with 48 +-6s and 16 +-2/10s? No, just test u_pos (wt=60) with ONLY 12 free mode=2!
    // Wait: for u_pos (wt=60), we can force mode=2 on 16 of its 24 +-10s? No, on the other 8 +-10s mode=3 wouldn't allow +-10!
    // Instead construct u_pos2 with wt=40 (40*64=2560 -> e.g. 48 +-6, 8 +-2, 8 +-10) OR take u_pos3:
    // Start with Q (64 pts, +-8), zero out 12 pts? Wait: Q on 3-subspace L1 has Q=+1 on all 8 pts ->
    // Flip 2 pts? Let's just find a real u with 48+ +-6s by flipping 4 pts?
    // Even simpler: in POS_CTRL, use a REAL u_pos = 1_{0,1,2} - 1_{3} (wt=4, +-2 everywhere) + 1_{0..63\...}:
    // Wait: u = Q(y) for y>=4, 0 for y<4 has z(c) = +-6 (40 pts) and +-10 (24 pts)!
    // Just add ONE extra mode=5 (forced +-10) for 12 of the 24 pts so POS_CTRL tests ALL signs (+-6 AND +-10) in 0.1s!
    // Actually even cleaner: take u = Q(y) with 4 pts zeroed (0,1,4,5 -> L1's 2-plane where Q=+1,+1,+1,+1)!
    // CHECK WHT(Q - 1_{0,1,4,5})! WHT(1_{0,1,4,5}) = +-4 on 16 pts, 0 on 48 pts -> 0 mod 4!
    // What about flipping signs of 1_{0,1,2,3} where Q=+1,+1,+1,-1 -> +-2 EVERYWHERE!
    // Wait: what if we take u = (1 on 0,1,2, -1 on 3) + 0 elsewhere: tests v2 sign!
    // And what if we test u = Q - Q*1_{0,1,2,3} on its EXACT qm? Better: test u_pos with 8 pts zeroed:
    // {0,1,2,3} (Q=+1,+1,+1,-1 -> WHT=+-2) AND {4,5,6,7} (Q=+1,+1,+1,-1 -> WHT=+-2*(-1)^{c_2})!
    // Sum of WHT of {0..3} and {4..7} is +-4 on c_2=0 and 0 on c_2=1! Still 0 mod 4.
    // What about u = Q - Q*1_{0,1,2,3} - 2*Q*1_{0}? No, 0 is already 0!
    // Just test u_pos = (+1 on 0,1,2, -1 on 3) with mode=1 on 56 pts and mode=2 on 8 pts (tests v2 & mode=2!),
    // AND ALSO check a known wt=36 beta_U=1 function (if any exists) — wait, let's check our 5 REAL cases FIRST,
    // plus POS_CTRL on u = (+1 on 0,1,2, -1 on 3) (which MUST return >= 1 hit in 0.1s!)!
    {
        std::array<int, 64> mp{};
        for (int c = 0; c < 64; ++c) mp[c] = (c < 8) ? 2 : 1;
        uint64_t h = solve_case("POS_CTRL_wt4", mp, 0);
        if (h == 0) throw std::logic_error("POS_CTRL_wt4 FAILED!");
    }

    // Case 1: h=16 p=6 odd (find the exact Em, Fm for one odd hit directly from shapes10, or hardcode? Let's test all 4 odd hits!)
    // Actually let's test Cases 2, 3, 4, 5, 6 right now!
    // Case 2: h=16 p=0 b (0xc0c00330c3f, hist={3:48, 7:16}, a=0)
    {
        auto lv = get_levels(0xc0c00330c3fULL, 0);
        std::array<int, 64> mode{};
        for (int c = 0; c < 64; ++c) mode[c] = (lv[c] == 3) ? 3 : 2;
        solve_case("h16_p0_b (0xc0c00330c3f)", mode, 0);
    }
    // Case 3: h=16 p=0 c (0x840c00220011843f, hist={3:48, 7:16}, a=0)
    {
        auto lv = get_levels(0x840c00220011843fULL, 0);
        std::array<int, 64> mode{};
        for (int c = 0; c < 64; ++c) mode[c] = (lv[c] == 3) ? 3 : 2;
        solve_case("h16_p0_c (0x840c00220011843f)", mode, 0);
    }
    // Case 4: h=16 p=2 (0x5500330077, F=0x11, hist={3:50, 7:12, 11:2}, k=16 -> min u_x has 0 extra 2s on lv3!)
    {
        auto lv = get_levels(0x5500330077ULL, 0x11ULL);
        std::array<int, 64> mode{};
        for (int c = 0; c < 64; ++c) {
            if (lv[c] == 3) mode[c] = 3;
            else if (lv[c] == 11) mode[c] = 1;
            else mode[c] = 2;
        }
        solve_case("h16_p2 (0x5500330077, F=0x11)", mode, 0);
    }
    // Case 5: h=16 p=4 (0x770077, F=0x110011, hist={3:52, 7:8, 11:4}, k=16 -> min u_x has <=1 extra 2 on lv3!)
    {
        auto lv = get_levels(0x770077ULL, 0x110011ULL);
        std::array<int, 64> mode{};
        for (int c = 0; c < 64; ++c) {
            if (lv[c] == 3) mode[c] = 0;
            else if (lv[c] == 11) mode[c] = 1;
            else mode[c] = 2;
        }
        solve_case("h16_p4 (0x770077, F=0x110011)", mode, 1);
    }
    // Case 6: h=12 p=0 (0x44002200110077, hist={3:52, 7:12}, k=20 -> min u_x has <=2 extra 2s on lv3!)
    {
        auto lv = get_levels(0x44002200110077ULL, 0);
        std::array<int, 64> mode{};
        for (int c = 0; c < 64; ++c) mode[c] = (lv[c] == 3) ? 0 : 2;
        solve_case("h12_p0 (0x44002200110077)", mode, 2);
    }
}
