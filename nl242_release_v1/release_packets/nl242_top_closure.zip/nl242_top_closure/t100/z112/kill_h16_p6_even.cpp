// Exact killer for ALL 8 h=16 p=6 even-level hits (hist={0:14, 2:6, 4:10, 6:34}, LP_feas=[(6,78,10)])!
// Proven: ZERO free allocations!
//   lv=0 (14 pts): {0,0,0}   -> p1 = p2 = p3 = 0
//   lv=2 ( 6 pts): {4,4,4}   -> p1 = p2 = p3 = 1
//   lv=4 (10 pts): {8,4,4}   -> two of p_x are 1, one is 0
//   lv=6 (34 pts): {12,0,0}  -> one of p_x is 1, two are 0 (p1, p2, p3 PARTITION lv=6!)
// First find ALL p in RM(2, 6) with p=0 on lv=0 and p=1 on lv=2!
// Since RM(2,6) has dim 22 and there are 20 linear constraints, this takes 0.001s!
#include <array>
#include <cstdint>
#include <cstdio>
#include <iostream>
#include <vector>

static int Q[64];
static std::array<int, 64> get_levels(uint64_t Em, uint64_t Fm) {
    std::array<int, 64> lv{};
    for (int c = 0; c < 64; ++c) {
        int s = 0;
        for (uint64_t t = Em; t; t &= t - 1) { int y = __builtin_ctzll(t); s += Q[y] * (__builtin_parity(y & c) ? -1 : 1); }
        for (uint64_t t = Fm; t; t &= t - 1) { int y = __builtin_ctzll(t); s += Q[y] * (__builtin_parity(y & c) ? -1 : 1); }
        lv[c] = 3 + ((Q[c] * s) >> 1);
    }
    return lv;
}

int main() {
    for (int x = 0; x < 64; ++x) Q[x] = __builtin_parity((x >> 1) & x & 21) ? -1 : 1;
    // Build 22 basis vectors of RM(2, 6)
    uint64_t basis[22]; int nb = 0;
    basis[nb++] = ~0ULL;
    for (int i = 0; i < 6; ++i) {
        uint64_t m = 0; for (int c = 0; c < 64; ++c) if ((c >> i) & 1) m |= (1ULL << c);
        basis[nb++] = m;
    }
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        uint64_t m = 0; for (int c = 0; c < 64; ++c) if (((c >> i) & 1) && ((c >> j) & 1)) m |= (1ULL << c);
        basis[nb++] = m;
    }

    FILE* f = fopen("shapes/shapes10.bin", "rb");
    uint64_t m; int idx = 0;
    while (fread(&m, 8, 1, f) == 1) {
        int pts[10], k = 0; for (uint64_t t = m; t; t &= t - 1) pts[k++] = __builtin_ctzll(t);
        for (int mask = 0; mask < 1024; ++mask) {
            if (__builtin_popcount(mask) != 6) continue;
            uint64_t Fm = 0; for (int i = 0; i < 10; ++i) if ((mask >> i) & 1) Fm |= (1ULL << pts[i]);
            auto lv = get_levels(m, Fm);
            bool ok = true; int wt3 = 0; bool any_odd = false;
            for (int c = 0; c < 64; ++c) {
                if (lv[c] < 0 || lv[c] > 12) { ok = false; break; }
                if (lv[c] % 3) wt3++;
                if (lv[c] & 1) any_odd = true;
            }
            if (!ok || wt3 > 16 || any_odd) continue;
            idx++;
            uint64_t m0 = 0, m2 = 0, m4 = 0, m6 = 0;
            for (int c = 0; c < 64; ++c) {
                if (lv[c] == 0) m0 |= (1ULL << c);
                else if (lv[c] == 2) m2 |= (1ULL << c);
                else if (lv[c] == 4) m4 |= (1ULL << c);
                else if (lv[c] == 6) m6 |= (1ULL << c);
            }
            // Solve linear system over GF(2): sum_k x_k * basis[k][c] = (c in m2) for all c in m0 | m2!
            uint32_t rows[20]; int nr = 0;
            for (int c = 0; c < 64; ++c) {
                if (!(((m0 | m2) >> c) & 1ULL)) continue;
                uint32_t r = 0;
                for (int b = 0; b < 22; ++b) if ((basis[b] >> c) & 1ULL) r |= (1u << b);
                if ((m2 >> c) & 1ULL) r |= (1u << 22);
                rows[nr++] = r;
            }
            // Gaussian elimination
            int piv_col[20], rk = 0;
            bool inconsistent = false;
            for (int col = 0; col < 22 && rk < nr; ++col) {
                int p = -1; for (int i = rk; i < nr; ++i) if ((rows[i] >> col) & 1u) { p = i; break; }
                if (p == -1) continue;
                std::swap(rows[rk], rows[p]);
                for (int i = 0; i < nr; ++i) if (i != rk && ((rows[i] >> col) & 1u)) rows[i] ^= rows[rk];
                piv_col[rk++] = col;
            }
            for (int i = rk; i < nr; ++i) if ((rows[i] >> 22) & 1u) inconsistent = true;
            if (inconsistent) {
                std::cout << "h16_p6_even #" << idx << ": INCONSISTENT (0 RM(2,6) words!)\n";
                continue;
            }
            std::vector<int> free_cols;
            for (int col = 0; col < 22; ++col) {
                bool is_p = false; for (int i = 0; i < rk; ++i) if (piv_col[i] == col) is_p = true;
                if (!is_p) free_cols.push_back(col);
            }
            std::vector<uint64_t> sols;
            for (int fm = 0; fm < (1 << free_cols.size()); ++fm) {
                uint32_t x = 0;
                for (size_t j = 0; j < free_cols.size(); ++j) if ((fm >> j) & 1) x |= (1u << free_cols[j]);
                for (int i = 0; i < rk; ++i) {
                    int val = ((rows[i] >> 22) & 1u) ^ (__builtin_parity(rows[i] & x));
                    if (val) x |= (1u << piv_col[i]);
                }
                uint64_t w = 0;
                for (int b = 0; b < 22; ++b) if ((x >> b) & 1u) w ^= basis[b];
                sols.push_back(w);
            }
            // Check how many unordered triples (p1, p2, p3) in sols satisfy:
            //   p1, p2, p3 PARTITION m6 (pairwise disjoint on m6, union = m6) AND
            //   on m4, exactly 2 of p1, p2, p3 are 1 (i.e., p1^p2^p3 == 0 on m4 AND (p1|p2|p3) == m4 on m4)!
            int triples = 0;
            for (size_t i = 0; i < sols.size(); ++i)
                for (size_t j = i; j < sols.size(); ++j) {
                    if (sols[i] & sols[j] & m6) continue;
                    uint64_t p3 = (m2 | m6) ^ sols[i] ^ sols[j];
                    // Check p3 in sols (automatic since m2|m6 = p1^p2^p3 in RM(2,6)!)
                    // Check disjoint on m6 and cover m4:
                    if ((p3 & (sols[i] | sols[j]) & m6) != 0) continue;
                    if (((sols[i] | sols[j] | p3) & m4) != m4) continue;
                    if ((sols[i] & sols[j] & p3 & m4) != 0) continue;
                    // Also verify p3 in sols (just to be 100% sure)
                    if (std::find(sols.begin() + j, sols.end(), p3) != sols.end()) triples++;
                }
            std::cout << "h16_p6_even #" << idx << ": rk=" << rk << " |sols|=" << sols.size()
                      << " valid (p1,p2,p3) triples=" << triples << "\n";
        }
    }
    fclose(f);
}
