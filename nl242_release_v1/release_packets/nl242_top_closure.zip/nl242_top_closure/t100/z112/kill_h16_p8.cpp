// Exact killer for h=16, p=8 (|V0|=0, v0=0, LP_feas=[(12, 76, 4)], hist={3:56, 11:8})!
// Proven:
//   - levels=11 on the 8-pt Lagrangian 3-subspace L1^perp (here c with c & 0x2a == 0, i.e., c in {0,1,4,5,16,17,20,21}!).
//   - Wait: let's compute levels directly from E=F=L1={0,1,4,5,16,17,20,21} so there is zero coordinate guesswork!
//   - On the 8 pts of level=11: (1,3,0) -> {2,2,2} (all three |u_x_hat(c)| == 2).
//   - On the 56 pts of level=3: 52 are (0,1,0) -> {6,6,6}, 4 are (1,0,1) -> {6,2,2} (since beta_U = const, and 52 pts force beta_U == 1!).
//   - Thus EVERY u_x (x=1,2,3) has:
//       * |u_x_hat(c)| in {2, 6} everywhere (beta_U == 1 -> p_x in RM(2,6))
//       * |u_x_hat(c)| == 2 on all 8 pts of {level==11}
//       * #{c outside {level==11} : |u_x_hat(c)| == 2} == 4 - r_x in {0, 2, 4} (so total #(|u_x_hat|==2) in {8, 10, 12}, wt(u_x) in {30, 31, 32})!
//   - Test ALL 32,768 quadratic forms p in RM(2,6)/RM(1,6) (ZERO orbit assumptions!) via exact 32+32 half-join!
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include <vector>

static void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}

int main() {
    int Q[64];
    for (int x = 0; x < 64; ++x) Q[x] = __builtin_parity((x >> 1) & x & 21) ? -1 : 1;
    int L1[8] = {0, 1, 4, 5, 16, 17, 20, 21};
    uint64_t lv11_mask = 0;
    for (int c = 0; c < 64; ++c) {
        int s = 0; for (int y : L1) s += 2 * Q[y] * (__builtin_parity(y & c) ? -1 : 1);
        int lv = 3 + (Q[c] * s) / 2;
        if (lv == 11) lv11_mask |= (1ULL << c);
        else if (lv != 3) { std::cerr << "Unexpected lv=" << lv << "\n"; return 1; }
    }
    std::cout << "|lv11|=" << __builtin_popcountll(lv11_mask) << " mask=0x" << std::hex << lv11_mask << std::dec << "\n";

    // Also run positive control: allow ANY # of 2s outside lv11 (just check if we find known wt-32 or smaller u_x)!
    uint64_t qmon[15]; int qi = 0;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        uint64_t m = 0; for (int c = 0; c < 64; ++c) if (((c >> i) & 1) && ((c >> j) & 1)) m |= (1ULL << c);
        qmon[qi++] = m;
    }

    auto t0 = std::chrono::steady_clock::now();
    uint64_t hits_le12 = 0, hits_any = 0;
    int min_m2 = 99;
    for (int qm = 0; qm < (1 << 15); ++qm) {
        uint64_t p = 0;
        for (int b = 0; b < 15; ++b) if ((qm >> b) & 1) p ^= qmon[b];
        // On each c: z = 2 + 4*p(c) mod 8 => if p(c)=0: z in {2, -6}; if p(c)=1: z in {-2, 6}!
        // On lv11_mask: |z| == 2 FORCED => z = 2 if p=0, -2 if p=1 (1 choice!).
        // Outside lv11_mask: 2 choices, and total #(|z|==2) outside lv11_mask must be <= 4!
        // Split 64 = 32 (c<32) + 32 (c>=32), with each half split 8+8+8+8!
        auto do_half = [&](int offset, std::unordered_map<uint32_t, std::vector<std::pair<uint32_t, int>>>& out) {
            // For each 32-half, enumerate all z with <= 4 extra 2s outside lv11!
            // Actually even faster: split 32 into 4 chunks of 8, tracking extra_2 count (<= 4)!
            struct Q8 { std::array<int8_t, 8> b; uint8_t ex2; };
            auto do_q8 = [&](int st, std::array<std::vector<Q8>, 256>& qout) {
                std::array<int, 8> z{};
                auto dfs = [&](auto& self, int j, uint8_t ex2) -> void {
                    if (j == 8) {
                        auto u = z; fwht8(u); uint8_t par = 0; std::array<int8_t, 8> b;
                        for (int y = 0; y < 8; ++y) {
                            if (u[y] & 7) return;
                            int q = u[y] >> 3; if (std::abs(q) > 8) return;
                            b[y] = q; if (q & 1) par |= (1u << y);
                        }
                        qout[par].push_back({b, ex2}); return;
                    }
                    int c = st + j;
                    int pb = (p >> c) & 1;
                    int v2 = pb ? -2 : 2, v6 = pb ? 6 : -6;
                    if ((lv11_mask >> c) & 1ULL) {
                        z[j] = v2; self(self, j + 1, ex2);
                    } else {
                        z[j] = v6; self(self, j + 1, ex2);
                        if (ex2 < 4) { z[j] = v2; self(self, j + 1, ex2 + 1); }
                    }
                };
                dfs(dfs, 0, 0);
            };
            struct H16 { std::array<int8_t, 16> u; uint8_t ex2; };
            auto do_h16 = [&](int st, std::unordered_map<uint16_t, std::vector<H16>>& hout) {
                std::array<std::vector<Q8>, 256> q0, q1;
                do_q8(st, q0); do_q8(st + 8, q1);
                for (int p8 = 0; p8 < 256; ++p8) {
                    if (q0[p8].empty() || q1[p8].empty()) continue;
                    for (const auto& a : q0[p8]) for (const auto& b : q1[p8]) {
                        if (a.ex2 + b.ex2 > 4) continue;
                        std::array<int8_t, 16> u; uint16_t p16 = 0; bool ok = true;
                        for (int y = 0; y < 8; ++y) {
                            if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                            int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                            u[y] = s; u[8+y] = d;
                            if (s & 1) p16 |= (1u << y); if (d & 1) p16 |= (1u << (8 + y));
                        }
                        if (ok) hout[p16].push_back({u, uint8_t(a.ex2 + b.ex2)});
                    }
                }
            };
            std::unordered_map<uint16_t, std::vector<H16>> g0, g1;
            do_h16(offset, g0); do_h16(offset + 16, g1);
            for (const auto& [par, v0] : g0) {
                auto it = g1.find(par); if (it == g1.end()) continue;
                for (const auto& a : v0) for (const auto& b : it->second) {
                    if (a.ex2 + b.ex2 > 4) continue;
                    uint32_t p32 = 0, tw = 0; bool ok = true;
                    for (int y = 0; y < 16; ++y) {
                        if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                        int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                        if (x0 & 1) p32 |= (1u << y); if (x1 & 1) p32 |= (1u << (16 + y));
                        if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
                    }
                    if (ok) out[p32].push_back({tw, a.ex2 + b.ex2});
                }
            }
        };
        std::unordered_map<uint32_t, std::vector<std::pair<uint32_t, int>>> h0, h1;
        do_half(0, h0);
        if (h0.empty()) continue;
        do_half(32, h1);
        for (const auto& [p32, v0] : h0) {
            auto it = h1.find(p32); if (it == h1.end()) continue;
            for (auto [tw0, e0] : v0) for (auto [tw1, e1] : it->second) {
                if (tw0 & tw1) continue;
                int ex = e0 + e1;
                hits_any++;
                if (8 + ex < min_m2) min_m2 = 8 + ex;
                if (ex <= 4) hits_le12++;
            }
        }
    }
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "ALL 32,768 quad forms scanned in " << dt << "s!\n";
    std::cout << "  hits (extra_2 <= 4, i.e., |S_2| <= 12): " << hits_le12 << " (min |S_2|=" << min_m2 << ")\n";
}
