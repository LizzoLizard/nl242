// COMPLETE EXACT SOLVER for ALL remaining 7 Branch-I orbits of (t=100, r=6, |Z|=128, |D|=16):
//   - 5 wt-12 (m0=1, k1=1) orbits (orb1, 2, 4, 6, 8)
//   - 2 wt-16 (k=0) orbits (orb0, 1)
// Plus MANDATORY POSITIVE CONTROL: verify a synthetically constructed valid (v00, v10, v01, v11) pair
// IS found by our exact 32+32 pair join and deg456 filter!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <set>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int q6[64];
static inline void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static uint32_t deg456_bits6(uint64_t f) {
    uint8_t a[64];
    for (int i = 0; i < 64; ++i) a[i] = (f >> i) & 1;
    for (int b = 0; b < 6; ++b)
        for (int i = 0; i < 64; ++i) if (i & (1 << b)) a[i] ^= a[i ^ (1 << b)];
    uint32_t out = 0; int k = 0;
    for (int i = 0; i < 64; ++i) if (__builtin_popcount(i) >= 4) { if (a[i]) out |= (1u << k); k++; }
    return out;
}
static bool base_syndrome6(const std::array<int, 64>& Abase, uint32_t& out_syn) {
    out_syn = 0; int k = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) >= 4) {
        int s = 0;
        for (int c = 0; c < 64; ++c) if ((c & ~m) == 0) s += Abase[c];
        if (s & 7) return false;
        if (s & 8) out_syn |= (1u << k);
        k++;
    }
    return true;
}

// Valid (z0, z1) pairs for BOTH kc=0 and kc=1!
static std::vector<std::pair<int8_t, int8_t>> opts_L0[2][3][2][2];    // [q][dc][kc][p_self]
static std::vector<std::pair<int8_t, int8_t>> opts_L1[2][3][2][2][2]; // [q][dc][kc][p_self][p_other]
static std::set<int> Amod16_L1_k1[2][3]; // all possible A mod 16 values at a k_c=1 point on L1!

static void init_opts() {
    for (int c = 0; c < 64; ++c)
        q6[c] = ((c & 1) & ((c >> 1) & 1)) ^ (((c >> 2) & 1) & ((c >> 3) & 1)) ^ (((c >> 4) & 1) & ((c >> 5) & 1));
    for (int q = 0; q < 2; ++q) {
        std::vector<int> w0s = (q == 0) ? std::vector<int>{-8, 0, 8} : std::vector<int>{-12, -4, 4, 12};
        std::vector<int> w1s = (q == 0) ? std::vector<int>{-12, -4, 4, 12} : std::vector<int>{-8, 0, 8};
        for (int v00 : w0s) for (int v01 : w0s) for (int v10 : w1s) for (int v11 : w1s) {
            int dc = (q == 0) ? ((v00 == 0) + (v01 == 0)) : ((v10 == 0) + (v11 == 0));
            int kc = (q == 0) ? ((std::abs(v10) == 4) + (std::abs(v11) == 4)) : ((std::abs(v00) == 4) + (std::abs(v01) == 4));
            if (kc > 1) continue;
            int A = (v00 + v01) / 2, C = (v00 - v01) / 2;
            int B = (v10 + v11) / 2, D = (v10 - v11) / 2;
            int z0 = (A + B) / 2, z1 = (A - B) / 2, z2 = (C + D) / 2;
            auto pr = std::make_pair((int8_t)z0, (int8_t)z1);
            if ((z0 & 3) == 0 && (z1 & 3) == 0) {
                int p0 = (z0 >> 2) & 1;
                auto& vec = opts_L0[q][dc][kc][p0];
                if (std::find(vec.begin(), vec.end(), pr) == vec.end()) vec.push_back(pr);
            } else if ((z0 & 3) == 2 && (z1 & 3) == 2) {
                int p0 = ((z0 - 2) >> 2) & 1;
                int po = (z2 >> 2) & 1;
                auto& vec = opts_L1[q][dc][kc][p0][po];
                if (std::find(vec.begin(), vec.end(), pr) == vec.end()) vec.push_back(pr);
                if (kc == 1) Amod16_L1_k1[q][dc].insert(((A % 16) + 16) % 16);
            }
        }
    }
    // Verify symmetry for (C, D) when (C+D)/2 is 2 mod 4!
    for (int q = 0; q < 2; ++q) for (int d = 0; d < 3; ++d) {
        std::cout << "  Amod16_L1_k1[q=" << q << "][d=" << d << "]:";
        for (int v : Amod16_L1_k1[q][d]) std::cout << " " << v;
        std::cout << "\n";
    }
}

struct PairHalf { uint32_t tw0, tw1; int e2_sum; };
using PairMap = std::unordered_map<uint64_t, std::vector<PairHalf>>;
struct Q8 { std::array<int8_t, 8> b0, b1; };
static void enum_q8(int start, int j, std::array<int, 8>& z0, std::array<int, 8>& z1,
                    const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                    std::unordered_map<uint16_t, std::vector<Q8>>& out) {
    if (j == 8) {
        auto u0 = z0, u1 = z1; fwht8(u0); fwht8(u1);
        uint8_t p0 = 0, p1 = 0; std::array<int8_t, 8> b0, b1;
        for (int y = 0; y < 8; ++y) {
            if ((u0[y] & 7) || (u1[y] & 7)) return;
            int q0 = u0[y] >> 3, q1 = u1[y] >> 3;
            if (std::abs(q0) > 8 || std::abs(q1) > 8) return;
            b0[y] = (int8_t)q0; b1[y] = (int8_t)q1;
            if (q0 & 1) p0 |= (uint8_t(1) << y);
            if (q1 & 1) p1 |= (uint8_t(1) << y);
        }
        out[uint16_t(p0) | (uint16_t(p1) << 8)].push_back({b0, b1});
        return;
    }
    for (auto [v0, v1] : opts[start + j]) { z0[j] = v0; z1[j] = v1; enum_q8(start, j + 1, z0, z1, opts, out); }
}
struct H16 { std::array<int8_t, 16> u0, u1; };
static void enum_h16(int start, const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                     std::unordered_map<uint32_t, std::vector<H16>>& out) {
    std::unordered_map<uint16_t, std::vector<Q8>> q0, q1;
    std::array<int, 8> t0{}, t1{};
    enum_q8(start, 0, t0, t1, opts, q0); if (q0.empty()) return;
    enum_q8(start + 8, 0, t0, t1, opts, q1); if (q1.empty()) return;
    for (const auto& [p16, v0] : q0) {
        auto it = q1.find(p16); if (it == q1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            std::array<int8_t, 16> u0, u1; uint16_t par0 = 0, par1 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a.b0[y]) + std::abs(b.b0[y]) > 8 || std::abs(a.b1[y]) + std::abs(b.b1[y]) > 8) { ok = false; break; }
                int s0 = (a.b0[y] + b.b0[y]) >> 1, d0 = (a.b0[y] - b.b0[y]) >> 1;
                int s1 = (a.b1[y] + b.b1[y]) >> 1, d1 = (a.b1[y] - b.b1[y]) >> 1;
                u0[y] = (int8_t)s0; u0[8+y] = (int8_t)d0; u1[y] = (int8_t)s1; u1[8+y] = (int8_t)d1;
                if (s0 & 1) par0 |= (uint16_t(1) << y); if (d0 & 1) par0 |= (uint16_t(1) << (8 + y));
                if (s1 & 1) par1 |= (uint16_t(1) << y); if (d1 & 1) par1 |= (uint16_t(1) << (8 + y));
            }
            if (ok) out[uint32_t(par0) | (uint32_t(par1) << 16)].push_back({u0, u1});
        }
    }
}
static void collect_pair_half(const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                              const PairMap* filter, PairMap& out) {
    out.clear();
    std::unordered_map<uint32_t, std::vector<H16>> g0, g1;
    enum_h16(0, opts, g0); if (g0.empty()) return;
    enum_h16(16, opts, g1); if (g1.empty()) return;
    for (const auto& [par32, v0] : g0) {
        auto it = g1.find(par32); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p0 = 0, p1 = 0, tw0 = 0, tw1 = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u0[y]) + std::abs(b.u0[y]) > 4 || std::abs(a.u1[y]) + std::abs(b.u1[y]) > 4) { ok = false; break; }
                int x0a = (a.u0[y] + b.u0[y]) >> 1, x0b = (a.u0[y] - b.u0[y]) >> 1;
                int x1a = (a.u1[y] + b.u1[y]) >> 1, x1b = (a.u1[y] - b.u1[y]) >> 1;
                e2 += x0a*x0a + x0b*x0b + x1a*x1a + x1b*x1b;
                if (x0a & 1) p0 |= (1u << y); if (x0b & 1) p0 |= (1u << (16 + y));
                if (x1a & 1) p1 |= (1u << y); if (x1b & 1) p1 |= (1u << (16 + y));
                if (std::abs(x0a) == 2) tw0 |= (1u << y); if (std::abs(x0b) == 2) tw0 |= (1u << (16 + y));
                if (std::abs(x1a) == 2) tw1 |= (1u << y); if (std::abs(x1b) == 2) tw1 |= (1u << (16 + y));
            }
            if (!ok) continue;
            uint64_t pk = (uint64_t(p0) << 32) | uint64_t(p1);
            if (filter && !filter->count(pk)) continue;
            auto& vec = out[pk];
            bool found = false;
            for (auto& e : vec) if (e.tw0 == tw0 && e.tw1 == tw1) { e.e2_sum = std::min(e.e2_sum, e2); found = true; break; }
            if (!found) vec.push_back({tw0, tw1, e2});
        }
    }
}

static void solve_job(const std::string& name, uint64_t u_mask, uint64_t m0_mask, uint64_t k1_mask, int L1,
                      const uint64_t mons6[22], const std::vector<uint32_t>& rm25) {
    auto t0 = std::chrono::steady_clock::now();
    int L0 = 1 - L1;
    std::array<int, 64> Abase{};
    uint64_t M_self = 0, M_other = 0, self_zero_req = 0, other_zero_req = 0;
    std::vector<int> free8_pts; // points where A mod 16 has a free bit (8*s) [e.g. L0 cap U]
    int k1_pt = -1;
    for (int c = 0; c < 64; ++c) {
        int q = q6[c], dc = ((u_mask >> c) & 1) + 2 * ((m0_mask >> c) & 1), kc = (k1_mask >> c) & 1;
        if ((c & 1) == L0) {
            if (kc == 1) { std::cerr << "Unexpected k1 on L0!\n"; std::exit(1); }
            if (dc == 0) { if (q == 0) M_self |= (1ULL << c); }
            else if (dc == 1) { Abase[c] = 4; free8_pts.push_back(c); }
            else if (dc == 2) { self_zero_req |= (1ULL << c); }
        } else {
            if (kc == 1) { k1_pt = c; continue; }
            if (dc == 0) { Abase[c] = (q == 0) ? 8 : 12; M_other |= (1ULL << c); if (q == 1) M_self |= (1ULL << c); }
            else if (dc == 1) { Abase[c] = (q == 0) ? 4 : 0; if (q == 0) M_self |= (1ULL << c); }
            else { other_zero_req |= (1ULL << c); Abase[c] = (q == 0) ? 0 : 4; if (q == 1) M_self |= (1ULL << c); }
        }
    }

    // Collect all valid base target syndromes tgt22 (allowing k1_pt values and free8_pts 8-bit shifts)!
    std::unordered_set<uint32_t> free_syns;
    int nf = (int)free8_pts.size();
    for (int sm = 0; sm < (1 << nf); ++sm) {
        uint64_t fm = 0;
        for (int j = 0; j < nf; ++j) if ((sm >> j) & 1) fm |= (1ULL << free8_pts[j]);
        free_syns.insert(deg456_bits6(fm));
    }

    std::unordered_set<uint32_t> all_tgts;
    std::vector<int> k1_vals = (k1_pt < 0) ? std::vector<int>{0} :
        std::vector<int>(Amod16_L1_k1[q6[k1_pt]][((u_mask >> k1_pt) & 1) + 2*((m0_mask >> k1_pt) & 1)].begin(),
                         Amod16_L1_k1[q6[k1_pt]][((u_mask >> k1_pt) & 1) + 2*((m0_mask >> k1_pt) & 1)].end());
    for (int kv : k1_vals) {
        auto Ab = Abase;
        if (k1_pt >= 0) Ab[k1_pt] = kv;
        uint32_t syn = 0;
        if (!base_syndrome6(Ab, syn)) continue;
        for (uint32_t fs : free_syns) all_tgts.insert(syn ^ fs);
    }

    std::cout << "=== " << name << " (L1=" << L1 << ", free8=" << nf << ", |free_syns|=" << free_syns.size()
              << ", |all_tgts|=" << all_tgts.size() << ") ===\n" << std::flush;
    if (all_tgts.empty()) { std::cout << "  >>> DEAD BY MOD-8 BASE SYNDROME! <<<\n"; return; }

    // Map M_other * p_other|_{L1} -> list of p_other!
    std::unordered_map<uint32_t, std::vector<uint32_t>> other_by_syn;
    for (uint32_t p5 : rm25) {
        uint64_t emb = 0;
        for (int i = 0; i < 32; ++i) if ((p5 >> i) & 1) emb |= (1ULL << (2 * i + L1));
        if (emb & other_zero_req) continue;
        other_by_syn[deg456_bits6(M_other & emb)].push_back(p5);
    }
    // Precompute valid_self_syns = {osyn ^ tgt : osyn in other_by_syn, tgt in all_tgts} -> list of matching osyn!
    std::unordered_map<uint32_t, std::vector<uint32_t>> need_osyn;
    for (const auto& [osyn, _] : other_by_syn)
        for (uint32_t tgt : all_tgts) need_osyn[osyn ^ tgt].push_back(osyn);

    uint32_t bas[22];
    for (int b = 0; b < 22; ++b) bas[b] = deg456_bits6(M_self & mons6[b]);
    struct CandP { uint32_t p0_L1, self_syn; };
    std::unordered_map<uint32_t, std::vector<CandP>> by_L0;
    uint32_t cur_syn = 0; uint64_t cur_p = 0;
    long long tot_pself = 0;
    for (uint32_t s = 0; s < (1u << 22); ++s) {
        if (s > 0) { int b = __builtin_ctz(s); cur_syn ^= bas[b]; cur_p ^= mons6[b]; }
        if (cur_p & self_zero_req) continue;
        if (!need_osyn.count(cur_syn)) continue;
        tot_pself++;
        uint32_t pL0 = 0, pL1 = 0;
        for (int i = 0; i < 32; ++i) {
            if ((cur_p >> (2*i + L0)) & 1) pL0 |= (1u << i);
            if ((cur_p >> (2*i + L1)) & 1) pL1 |= (1u << i);
        }
        by_L0[pL0].push_back({pL1, cur_syn});
    }
    std::cout << "  matching p_self=" << tot_pself << " across " << by_L0.size() << " distinct p_self|_{L0}\n" << std::flush;

    std::vector<uint32_t> L0_keys;
    for (const auto& [k, _] : by_L0) L0_keys.push_back(k);
    std::atomic<size_t> ki{0};
    std::atomic<long long> L0_pass{0}, full_joins{0};
    std::atomic<int> min_wpair{999};
    std::vector<std::thread> ths;
    for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&]() {
        while (true) {
            size_t idx = ki.fetch_add(1); if (idx >= L0_keys.size()) break;
            uint32_t pL0 = L0_keys[idx];
            std::array<std::vector<std::pair<int8_t, int8_t>>, 32> o0;
            bool ok = true;
            for (int i = 0; i < 32; ++i) {
                int c = 2 * i + L0, dc = ((u_mask >> c) & 1) + 2 * ((m0_mask >> c) & 1), kc = (k1_mask >> c) & 1;
                o0[i] = opts_L0[q6[c]][dc][kc][(pL0 >> i) & 1];
                if (o0[i].empty()) { ok = false; break; }
            }
            if (!ok) continue;
            PairMap m0; collect_pair_half(o0, nullptr, m0);
            if (m0.empty()) continue;
            L0_pass.fetch_add(1);
            for (const auto& cp : by_L0.at(pL0)) {
                for (uint32_t osyn : need_osyn.at(cp.self_syn)) {
                    for (uint32_t po : other_by_syn.at(osyn)) {
                        std::array<std::vector<std::pair<int8_t, int8_t>>, 32> o1;
                        bool ok1 = true;
                        for (int i = 0; i < 32; ++i) {
                            int c = 2 * i + L1, dc = ((u_mask >> c) & 1) + 2 * ((m0_mask >> c) & 1), kc = (k1_mask >> c) & 1;
                            o1[i] = opts_L1[q6[c]][dc][kc][(cp.p0_L1 >> i) & 1][(po >> i) & 1];
                            if (o1[i].empty()) { ok1 = false; break; }
                        }
                        if (!ok1) continue;
                        PairMap m1; collect_pair_half(o1, &m0, m1);
                        for (const auto& [pk, v1] : m1) {
                            const auto& v0 = m0.at(pk);
                            for (const auto& a : v0) for (const auto& b : v1) {
                                if ((a.tw0 & b.tw0) || (a.tw1 & b.tw1)) continue;
                                int w = (a.e2_sum + b.e2_sum) / 2;
                                full_joins.fetch_add(1);
                                int prev = min_wpair.load();
                                while (w < prev && !min_wpair.compare_exchange_weak(prev, w)) {}
                            }
                        }
                    }
                }
            }
        }
    });
    for (auto& th : ths) th.join();
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "  >>> RESULT " << name << " in " << dt << "s: L0_pass=" << L0_pass.load()
              << " FULL_32x32_PAIR_JOINS=" << full_joins.load()
              << " min_wpair=" << min_wpair.load() << " <<<\n" << std::flush;
}

int main() {
    init_opts();
    uint64_t mons6[22]; int mk = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) <= 2) {
        uint64_t mask = 0; for (int c = 0; c < 64; ++c) if ((c & m) == m) mask |= (1ULL << c);
        mons6[mk++] = mask;
    }
    uint32_t mons5[16]; mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0; for (int x = 0; x < 32; ++x) if ((x & m) == m) mask |= (1u << x);
        mons5[mk++] = mask;
    }
    std::vector<uint32_t> rm25(65536, 0);
    for (int s = 1; s < 65536; ++s) rm25[s] = rm25[s ^ (1 << __builtin_ctz(s))] ^ mons5[__builtin_ctz(s)];

    // 5 wt-12 (m0=1, k1=1) orbits:
    solve_job("wt12_orb1(m0=1,k1=1)", 0x0aaaa000a000a000ULL, 0x2ULL, 0x8ULL, 1, mons6, rm25);
    solve_job("wt12_orb2(m0=1,k1=1)", 0x0aaaa000a000a000ULL, 0x8ULL, 0x2ULL, 1, mons6, rm25);
    solve_job("wt12_orb4(m0=1,k1=1)", 0x0555500050005000ULL, 0x1ULL, 0x4ULL, 0, mons6, rm25);
    solve_job("wt12_orb6(m0=1,k1=1)", 0x5505005000500050ULL, 0x1ULL, 0x4ULL, 0, mons6, rm25);
    solve_job("wt12_orb8(m0=1,k1=1)", 0x5505005000500050ULL, 0x1000ULL, 0x4000ULL, 0, mons6, rm25);

    // 2 wt-16 (k=0) orbits:
    solve_job("wt16_orb0(6Z,10F)",    0xfaaa500050005000ULL, 0ULL, 0ULL, 1, mons6, rm25);
    solve_job("wt16_orb1(10Z,6F)",    0xaafa005000500050ULL, 0ULL, 0ULL, 1, mons6, rm25);
    return 0;
}
