// COMPLETE EXACT SOLVER for Branch II-A of (t = 100, r = 6, |Z| = 128, |D| = 16):
//   L00 = 0, L01 = 1, u = 1_W for unique bent 4-flat orbit W = {c4 = c5 = 0} (c in 0..15), k_c = 0 everywhere!
// Step 1: On {c4=1}, {c5=1}, {c4^c5=1} (each disjoint from W), z10 = (-1)^q6 * z00 =>
//         sum_{c in F} 8*(1^q6)*p00 == 0 (mod 16) on every 4-flat F disjoint from W!
//         Let's check directly in C++ how many p00 in RM(2,6) survive ALL 4-flats disjoint from W!
// Step 2: ALSO check C(c) = z01(c) + z11(c) (mod 16) on ALL 64 points of F_2^6 (ZERO free bits!!):
//         - c not in W (dc=0): C = 8*(1^p00) + 4*q6 + 8*q6*p01 (mod 16)
//         - c in W     (dc=1): C = (1^q6)*(4 + 8*p01) (mod 16)
//         (Verify by brute force first, then check 22-bit deg456(C) == 0!)
// Step 3: Exact 32+32 pair join on (z00, z10) (and/or (z01, z11))!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <thread>
#include <unordered_map>
#include <vector>

static int q6[64];
static inline void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static uint32_t deg456_bits6(uint64_t f) {
    uint8_t a[64];
    for (int i = 0; i < 64; ++i) a[i] = (f >> i) & 1;
    for (int b = 0; b < 6; ++b)
        for (int i = 0; i < 64; ++i) if (i & (1 << b)) a[i] ^= a[i ^ (1 << b)];
    uint32_t out = 0; int k = 0;
    for (int i = 0; i < 64; ++i) if (__builtin_popcount(i) >= 4) { if (a[i]) out |= (1u << k); k++; }
    return out;
}
static bool base_syndrome6(const std::array<int, 64>& Abase, uint32_t& out_syn) {
    out_syn = 0; int k = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) >= 4) {
        int s = 0;
        for (int c = 0; c < 64; ++c) if ((c & ~m) == 0) s += Abase[c];
        if (s & 7) return false;
        if (s & 8) out_syn |= (1u << k);
        k++;
    }
    return true;
}

static std::vector<std::pair<int8_t, int8_t>> opts_L0[2][2][2];    // [q][dc in 0..1][p00]
static std::vector<std::pair<int8_t, int8_t>> opts_L1[2][2][2][2]; // [q][dc in 0..1][p01][p00]

static void init_opts() {
    for (int c = 0; c < 64; ++c)
        q6[c] = ((c & 1) & ((c >> 1) & 1)) ^ (((c >> 2) & 1) & ((c >> 3) & 1)) ^ (((c >> 4) & 1) & ((c >> 5) & 1));
    for (int q = 0; q < 2; ++q) {
        std::vector<int> w0s = (q == 0) ? std::vector<int>{-8, 0, 8} : std::vector<int>{-12, -4, 4, 12};
        std::vector<int> w1s = (q == 0) ? std::vector<int>{-12, -4, 4, 12} : std::vector<int>{-8, 0, 8};
        for (int v00 : w0s) for (int v01 : w0s) for (int v10 : w1s) for (int v11 : w1s) {
            int dc = (q == 0) ? ((v00 == 0) + (v01 == 0)) : ((v10 == 0) + (v11 == 0));
            int kc = (q == 0) ? ((std::abs(v10) == 4) + (std::abs(v11) == 4)) : ((std::abs(v00) == 4) + (std::abs(v01) == 4));
            if (kc != 0 || dc > 1) continue;
            int A = (v00 + v01) / 2, C = (v00 - v01) / 2, B = (v10 + v11) / 2, D = (v10 - v11) / 2;
            int z00 = (A + B) / 2, z10 = (A - B) / 2, z01 = (C + D) / 2, z11 = (C - D) / 2;
            if ((z00 & 3) != 0 || (z10 & 3) != 0) continue; // L00 = 0, L01 = 1!
            int p00 = (z00 >> 2) & 1, p01 = ((z01 - 2) >> 2) & 1;
            auto pr0 = std::make_pair((int8_t)z00, (int8_t)z10);
            auto& v0 = opts_L0[q][dc][p00];
            if (std::find(v0.begin(), v0.end(), pr0) == v0.end()) v0.push_back(pr0);
            auto pr1 = std::make_pair((int8_t)z01, (int8_t)z11);
            auto& v1 = opts_L1[q][dc][p01][p00];
            if (std::find(v1.begin(), v1.end(), pr1) == v1.end()) v1.push_back(pr1);
            // Verify exact C mod 16 formula!
            int Cexp = (dc == 0) ? ((q == 0) ? (8*(1^p00)) : (4 + 8*(p01^1^p00)))
                                 : ((q == 0) ? (4 + 8*p01) : 0);
            if (((C % 16) + 16) % 16 != (Cexp % 16)) { std::cerr << "C formula mismatch!\n"; std::exit(1); }
        }
    }
    std::cout << "[OK] Branch II-A C mod 16 formula verified!\n";
}

struct PairHalf { uint32_t tw0, tw1; int e2_sum; };
using PairMap = std::unordered_map<uint64_t, std::vector<PairHalf>>;
struct Q8 { std::array<int8_t, 8> b0, b1; };
static void enum_q8(int start, int j, std::array<int, 8>& z0, std::array<int, 8>& z1,
                    const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                    std::unordered_map<uint16_t, std::vector<Q8>>& out) {
    if (j == 8) {
        auto u0 = z0, u1 = z1; fwht8(u0); fwht8(u1);
        uint8_t p0 = 0, p1 = 0; std::array<int8_t, 8> b0, b1;
        for (int y = 0; y < 8; ++y) {
            if ((u0[y] & 7) || (u1[y] & 7)) return;
            int q0 = u0[y] >> 3, q1 = u1[y] >> 3;
            if (std::abs(q0) > 8 || std::abs(q1) > 8) return;
            b0[y] = (int8_t)q0; b1[y] = (int8_t)q1;
            if (q0 & 1) p0 |= (uint8_t(1) << y); if (q1 & 1) p1 |= (uint8_t(1) << y);
        }
        out[uint16_t(p0) | (uint16_t(p1) << 8)].push_back({b0, b1});
        return;
    }
    for (auto [v0, v1] : opts[start + j]) { z0[j] = v0; z1[j] = v1; enum_q8(start, j + 1, z0, z1, opts, out); }
}
struct H16 { std::array<int8_t, 16> u0, u1; };
static void enum_h16(int start, const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                     std::unordered_map<uint32_t, std::vector<H16>>& out) {
    std::unordered_map<uint16_t, std::vector<Q8>> q0, q1; std::array<int, 8> t0{}, t1{};
    enum_q8(start, 0, t0, t1, opts, q0); if (q0.empty()) return;
    enum_q8(start + 8, 0, t0, t1, opts, q1); if (q1.empty()) return;
    for (const auto& [p16, v0] : q0) {
        auto it = q1.find(p16); if (it == q1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            std::array<int8_t, 16> u0, u1; uint16_t par0 = 0, par1 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a.b0[y]) + std::abs(b.b0[y]) > 8 || std::abs(a.b1[y]) + std::abs(b.b1[y]) > 8) { ok = false; break; }
                int s0 = (a.b0[y] + b.b0[y]) >> 1, d0 = (a.b0[y] - b.b0[y]) >> 1;
                int s1 = (a.b1[y] + b.b1[y]) >> 1, d1 = (a.b1[y] - b.b1[y]) >> 1;
                u0[y] = (int8_t)s0; u0[8+y] = (int8_t)d0; u1[y] = (int8_t)s1; u1[8+y] = (int8_t)d1;
                if (s0 & 1) par0 |= (uint16_t(1) << y); if (d0 & 1) par0 |= (uint16_t(1) << (8 + y));
                if (s1 & 1) par1 |= (uint16_t(1) << y); if (d1 & 1) par1 |= (uint16_t(1) << (8 + y));
            }
            if (ok) out[uint32_t(par0) | (uint32_t(par1) << 16)].push_back({u0, u1});
        }
    }
}
static void collect_pair_half(const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                              const PairMap* filter, PairMap& out) {
    out.clear();
    std::unordered_map<uint32_t, std::vector<H16>> g0, g1;
    enum_h16(0, opts, g0); if (g0.empty()) return;
    enum_h16(16, opts, g1); if (g1.empty()) return;
    for (const auto& [par32, v0] : g0) {
        auto it = g1.find(par32); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p0 = 0, p1 = 0, tw0 = 0, tw1 = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u0[y]) + std::abs(b.u0[y]) > 4 || std::abs(a.u1[y]) + std::abs(b.u1[y]) > 4) { ok = false; break; }
                int x0a = (a.u0[y] + b.u0[y]) >> 1, x0b = (a.u0[y] - b.u0[y]) >> 1;
                int x1a = (a.u1[y] + b.u1[y]) >> 1, x1b = (a.u1[y] - b.u1[y]) >> 1;
                e2 += x0a*x0a + x0b*x0b + x1a*x1a + x1b*x1b;
                if (x0a & 1) p0 |= (1u << y); if (x0b & 1) p0 |= (1u << (16 + y));
                if (x1a & 1) p1 |= (1u << y); if (x1b & 1) p1 |= (1u << (16 + y));
                if (std::abs(x0a) == 2) tw0 |= (1u << y); if (std::abs(x0b) == 2) tw0 |= (1u << (16 + y));
                if (std::abs(x1a) == 2) tw1 |= (1u << y); if (std::abs(x1b) == 2) tw1 |= (1u << (16 + y));
            }
            if (!ok) continue;
            uint64_t pk = (uint64_t(p0) << 32) | uint64_t(p1);
            if (filter && !filter->count(pk)) continue;
            auto& vec = out[pk];
            bool found = false;
            for (auto& e : vec) if (e.tw0 == tw0 && e.tw1 == tw1) { e.e2_sum = std::min(e.e2_sum, e2); found = true; break; }
            if (!found) vec.push_back({tw0, tw1, e2});
        }
    }
}

int main() {
    auto t0 = std::chrono::steady_clock::now();
    init_opts();
    uint64_t W = 0xFFFFULL; // {c4 = c5 = 0}
    std::array<int, 64> Cbase{};
    uint64_t M01 = 0, M00 = 0;
    for (int c = 0; c < 64; ++c) {
        int q = q6[c], dc = (W >> c) & 1;
        if (dc == 0) { Cbase[c] = (q == 0) ? 8 : 12; M00 |= (1ULL << c); if (q == 1) M01 |= (1ULL << c); }
        else { Cbase[c] = (q == 0) ? 4 : 0; if (q == 0) M01 |= (1ULL << c); }
    }
    uint32_t tgt22 = 0;
    if (!base_syndrome6(Cbase, tgt22)) { std::cout << "Branch II-A DEAD by Cbase mod 8!\n"; return 0; }
    std::cout << "Cbase tgt22 = 0x" << std::hex << tgt22 << std::dec << "\n";

    // Step 1: Enumerate all 2^15 quadratic parts of p01 (note shifting v01,v11 by y0+sign shifts p01 by ANY RM(1,6)!
    // So WLOG p01 has ZERO constant and linear terms — ONLY 32,768 p01 in RM(2,6)/RM(1,6)!!)
    uint64_t qmon[15], lmon[7]; int qk = 0, lk = 0;
    for (int m = 0; m < 64; ++m) {
        int w = __builtin_popcount(m);
        if (w <= 2) {
            uint64_t mask = 0; for (int c = 0; c < 64; ++c) if ((c & m) == m) mask |= (1ULL << c);
            if (w == 2) qmon[qk++] = mask; else lmon[lk++] = mask;
        }
    }
    std::unordered_map<uint32_t, std::vector<uint64_t>> p01_by_syn;
    for (int s = 0; s < 32768; ++s) {
        uint64_t p01 = 0;
        for (int b = 0; b < 15; ++b) if ((s >> b) & 1) p01 ^= qmon[b];
        p01_by_syn[deg456_bits6(M01 & p01)].push_back(p01);
    }

    // Also filter p00 by 4-flats disjoint from W: on {c5=1} (c in 32..63) and {c4=1} and {c4^c5=1},
    // A = 8*(1^q6)*p00 MUST have sum == 0 mod 16 on every 4-flat disjoint from W!
    // Check directly: sum_{c in F} ((1^q6)*p00)[c] == 0 (mod 2) on the 3 cosets of W:
    //   c in 16..31 (c4=1,c5=0), c in 32..47 (c4=0,c5=1), c in 48..63 (c4=1,c5=1),
    //   AND every 4-flat inside {c4=1}, {c5=1}, {c4^c5=1}!
    // Wait: let's just check ALL 2^22 p00 in RM(2,6) against p01_by_syn AND check 4-flat condition on {c5=1}!
    uint64_t mons6[22];
    for (int i = 0; i < 7; ++i) mons6[i] = lmon[i];
    for (int i = 0; i < 15; ++i) mons6[7 + i] = qmon[i];
    uint32_t bas00[22];
    for (int b = 0; b < 22; ++b) bas00[b] = deg456_bits6(M00 & mons6[b]);

    // Precompute the 6-bit deg45 condition of (1^q6)*p00 on {c5=1} (bits 32..63)!
    auto deg45_hi32 = [&](uint64_t f64) -> uint8_t {
        uint8_t a[32]; for (int i = 0; i < 32; ++i) a[i] = (f64 >> (32 + i)) & 1;
        for (int b = 0; b < 5; ++b) for (int i = 0; i < 32; ++i) if (i & (1 << b)) a[i] ^= a[i ^ (1 << b)];
        uint8_t out = 0; int k = 0;
        for (int i = 0; i < 32; ++i) if (__builtin_popcount(i) >= 4) { if (a[i]) out |= (1u << k); k++; }
        return out;
    };
    uint64_t Z6_mask = 0; for (int c = 0; c < 64; ++c) if (q6[c] == 0) Z6_mask |= (1ULL << c);
    uint8_t basA_hi[22];
    for (int b = 0; b < 22; ++b) basA_hi[b] = deg45_hi32(Z6_mask & mons6[b]);

    std::vector<std::pair<uint64_t, uint32_t>> cand_p00;
    uint32_t cur_syn = 0; uint8_t cur_hi = 0; uint64_t cur_p = 0;
    for (uint32_t s = 0; s < (1u << 22); ++s) {
        if (s > 0) { int b = __builtin_ctz(s); cur_syn ^= bas00[b]; cur_hi ^= basA_hi[b]; cur_p ^= mons6[b]; }
        if (cur_hi != 0) continue;
        uint32_t need = cur_syn ^ tgt22;
        if (p01_by_syn.count(need)) cand_p00.push_back({cur_p, need});
    }
    std::cout << "Surviving p00 after C-mod16 + A|_{c5=1}: " << cand_p00.size() << " / 4194304\n" << std::flush;

    // Run exact 32+32 pair join on (v00, v10) for ALL surviving p00 (split by c5 = 0 vs 1)!
    std::atomic<size_t> ci{0};
    std::atomic<long long> pair00_joins{0}, pair01_joins{0};
    std::vector<std::thread> ths;
    for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&]() {
        while (true) {
            size_t idx = ci.fetch_add(1); if (idx >= cand_p00.size()) break;
            uint64_t p00 = cand_p00[idx].first;
            uint32_t need = cand_p00[idx].second;
            // First check (v00, v10) with split c in 0..31 vs c in 32..63!
            std::array<std::vector<std::pair<int8_t, int8_t>>, 32> o0, o1;
            for (int i = 0; i < 32; ++i) {
                o0[i] = opts_L0[q6[i]][(W >> i) & 1][(p00 >> i) & 1];
                o1[i] = opts_L0[q6[32 + i]][0][(p00 >> (32 + i)) & 1];
            }
            PairMap m1; collect_pair_half(o1, nullptr, m1); if (m1.empty()) continue;
            PairMap m0; collect_pair_half(o0, &m1, m0); if (m0.empty()) continue;
            bool ok00 = false;
            for (const auto& [pk, v0] : m0) {
                const auto& v1 = m1.at(pk);
                for (const auto& a : v0) for (const auto& b : v1)
                    if ((a.tw0 & b.tw0) == 0 && (a.tw1 & b.tw1) == 0) { ok00 = true; break; }
                if (ok00) break;
            }
            if (!ok00) continue;
            pair00_joins.fetch_add(1);
            // Now check (v01, v11) for each matching p01 (note p01 is mod RM(1,6))!
            for (uint64_t p01 : p01_by_syn.at(need)) {
                std::array<std::vector<std::pair<int8_t, int8_t>>, 32> q0, q1;
                for (int i = 0; i < 32; ++i) {
                    q0[i] = opts_L1[q6[i]][(W >> i) & 1][(p01 >> i) & 1][(p00 >> i) & 1];
                    q1[i] = opts_L1[q6[32 + i]][0][(p01 >> (32 + i)) & 1][(p00 >> (32 + i)) & 1];
                }
                PairMap n1; collect_pair_half(q1, nullptr, n1); if (n1.empty()) continue;
                PairMap n0; collect_pair_half(q0, &n1, n0); if (n0.empty()) continue;
                for (const auto& [pk, v0] : n0) {
                    const auto& v1 = n1.at(pk);
                    for (const auto& a : v0) for (const auto& b : v1)
                        if ((a.tw0 & b.tw0) == 0 && (a.tw1 & b.tw1) == 0) pair01_joins.fetch_add(1);
                }
            }
        }
    });
    for (auto& th : ths) th.join();
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << ">>> BRANCH II-A DONE in " << dt << "s: pair00_joins=" << pair00_joins.load()
              << " pair01_joins=" << pair01_joins.load() << " <<<\n";
    return 0;
}
