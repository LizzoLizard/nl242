// Exact H^c-side (for (z00, z10)) AND H-side (for (z01, z11)) check on ALL 11 Branch-I orbits
// of (t = 100, r = 6, |Z| = 128, |D| = 16)!
// Wait: on the L==0 half (H^c for (v00,v10), H for (v01,v11)):
//   Both s0 = WHT_5^{-1}(z0) and s1 = WHT_5^{-1}(z1) MUST lie in {-2, -1, 0, +1, +2}^{32}!!
//   AND remember: we can enumerate ALL valid z0 on the 32-pt half via 8+8 quarter-join,
//   AND simultaneously track z1 (which is 100% determined on d_c=0,2,k_c=0, and has <=2 options on d_c=1 or k_c=1)!!
// Let's check ALL 65,536 p0 in RM(2,5) (actually only 1,024 mod RM(1,5) for z0 -> WAIT!
// CAREFUL!! Shifting v00 by y->y^y0 shifts p00 by L(c), which changes z00(c) by (-1)^{L(c)},
// WHICH ALSO SHIFTS z10(c) = (-1)^{q6(c)} z00(c) by (-1)^{L(c)}, preserving s10 in [-2,2]!!
// Wait: what about shifting z00 by -1 (negating v00)? Also negates z10, preserving s10 in [-2,2]!
// WAIT A SECOND! Check if shifting c -> c^y0 (i.e. multiplying z00(c) by (-1)^{y0.c}) preserves
// the EXACT relation between z00(c) and z10(c) on d_c=1 and k_c=1!
//   On d_c=0: z10 = (-1)^{q6} z00 -> multiplying both by (-1)^{y0.c} preserves it!
//   On d_c=2: z00 = z10 = 0 -> preserved!
//   On d_c=1: (z00, z10) in {(+8,-4), (-8,+4), (+4,-8), (-4,+8)} (for q6=0) or {(+8,+4), (-8,-4), (+4,+8), (-4,-8)} (for q6=1)
//     -> multiplying BOTH by (-1)^{y0.c} maps (+8,-4) <-> (-8,+4) AND preserves the set!!
//   On k_c=1: (z00, z10) in {(+-4, +-4), (+-4, +-8), ...} -> multiplying BOTH by (-1)^{y0.c} preserves the set!!
//   AND changing p00 -> p00 ^ L(c) ONLY changes p00 mod RM(1,5)? WAIT NO!!
//   When z00(c) in {0, +-4} (L=0 half!), multiplying z00(c) by (-1)^{y0.c} does NOT change p00(c) = (z00(c)/4) mod 2 AT ALL!!
//   BECAUSE +4 == -4 (mod 8)!!
//   OH!! GOOD CATCH!! THANK GOD WE CHECKED THAT!!
//   When L=0 (z == 0 mod 4), p(c) = (z(c)/4) mod 2 is INVARIANT under v(y) -> +-v(y^y0)!!
//   SO WE MUST TEST ALL 65,536 WORDS p0 in RM(2, 5), NOT JUST 1,024!!
//   (Wait: 65,536 words is STILL tiny on 8 threads, AND even better: on d_c=0/2, p0(c)=0 forces z0(c)=0,
//    AND on any 32-pt half with d_c=2 points, p0(c)=0 is FORCED at every m0 point, AND
//    remember z0(c) = 4*p0(c) + 8*q0(c) mod 16 and z1(c) = (-1)^{q6}*z0(c) forces deg(p0 * q6) <= 3 on d_c=0!!
//    Let's test ALL 65,536 p0 in RM(2,5) directly — zero shortcuts, 100% exhaustive!!)
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <thread>
#include <unordered_map>
#include <vector>

static int q6[64];
static inline void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static inline void fwht32(std::array<int, 32>& a) {
    for (int st = 1; st < 32; st *= 2)
        for (int i = 0; i < 32; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}

// Check ALL 65,536 p0 in RM(2,5) on one 32-pt L=0 half (is_H=0 => H^c for (v00,v10); is_H=1 => H for (v01,v11))!
// Allowed (z0, z1) pairs at point i (c = 2*i + is_H) given q = q6[c], d_c (0,1,2), k_c (0,1), and p0_i = (z0/4)&1:
//   Let's derive EVERY case directly from V_hat(c, w0, w1) so there is ZERO chance of a sign/formula mistake!
//   For L=0 half: z0 = (X0 + X1)/2, z1 = (X0 - X1)/2 where:
//     If is_H == 0: (X0, X1) = (A_c, B_c) where A_c = (V00+V01)/2, B_c = (V10+V11)/2.
//     If is_H == 1: (X0, X1) = (C_c, D_c) where C_c = (V00-V01)/2, D_c = (V10-V11)/2.
//   Notice the rules on (X0, X1) are IDENTICAL for is_H==0 and is_H==1 once we fix L=0 on that half!
//   Let's compute the exact valid (z0, z1) table by brute-forcing all (V00,V01,V10,V11) for each (q, dc, kc)!
static std::vector<std::pair<int8_t, int8_t>> valid_pairs[2][3][2][2]; // [q][dc][kc][p0]

static void init_tables() {
    for (int c = 0; c < 64; ++c)
        q6[c] = ((c & 1) & ((c >> 1) & 1)) ^ (((c >> 2) & 1) & ((c >> 3) & 1)) ^ (((c >> 4) & 1) & ((c >> 5) & 1));
    int Zvals[3] = {-8, 0, 8}, Fvals[4] = {-12, -4, 4, 12};
    for (int q = 0; q < 2; ++q) {
        std::vector<int> w0_opts = (q == 0) ? std::vector<int>{-8, 0, 8} : std::vector<int>{-12, -4, 4, 12};
        std::vector<int> w1_opts = (q == 0) ? std::vector<int>{-12, -4, 4, 12} : std::vector<int>{-8, 0, 8};
        for (int v00 : w0_opts) for (int v01 : w0_opts) for (int v10 : w1_opts) for (int v11 : w1_opts) {
            int A = (v00 + v01) / 2, C = (v00 - v01) / 2;
            int B = (v10 + v11) / 2, D = (v10 - v11) / 2;
            int dc = (q == 0) ? ((v00 == 0) + (v01 == 0)) : ((v10 == 0) + (v11 == 0));
            int kc = (q == 0) ? ((std::abs(v10) == 4) + (std::abs(v11) == 4)) : ((std::abs(v00) == 4) + (std::abs(v01) == 4));
            if (kc > 1) continue;
            // For L=0 half on (A, B): z0 = (A+B)/2, z1 = (A-B)/2 must BOTH be 0 mod 4!
            if (((A + B) & 7) != 0 || ((A - B) & 7) != 0) continue;
            int z0 = (A + B) / 2, z1 = (A - B) / 2;
            int p0 = ((z0 >> 2) & 1);
            auto pr = std::make_pair((int8_t)z0, (int8_t)z1);
            auto& vec = valid_pairs[q][dc][kc][p0];
            if (std::find(vec.begin(), vec.end(), pr) == vec.end()) vec.push_back(pr);
        }
    }
    (void)Zvals; (void)Fvals;
    // Sanity check: verify (C, D) produces the EXACT same valid_pairs table when L=0 on (C,D)!
    for (int q = 0; q < 2; ++q) {
        std::vector<int> w0_opts = (q == 0) ? std::vector<int>{-8, 0, 8} : std::vector<int>{-12, -4, 4, 12};
        std::vector<int> w1_opts = (q == 0) ? std::vector<int>{-12, -4, 4, 12} : std::vector<int>{-8, 0, 8};
        std::vector<std::pair<int8_t, int8_t>> check_tbl[3][2][2];
        for (int v00 : w0_opts) for (int v01 : w0_opts) for (int v10 : w1_opts) for (int v11 : w1_opts) {
            int C = (v00 - v01) / 2, D = (v10 - v11) / 2;
            int dc = (q == 0) ? ((v00 == 0) + (v01 == 0)) : ((v10 == 0) + (v11 == 0));
            int kc = (q == 0) ? ((std::abs(v10) == 4) + (std::abs(v11) == 4)) : ((std::abs(v00) == 4) + (std::abs(v01) == 4));
            if (kc > 1) continue;
            if (((C + D) & 7) != 0 || ((C - D) & 7) != 0) continue;
            int z0 = (C + D) / 2, z1 = (C - D) / 2, p0 = (z0 >> 2) & 1;
            auto pr = std::make_pair((int8_t)z0, (int8_t)z1);
            auto& vec = check_tbl[dc][kc][p0];
            if (std::find(vec.begin(), vec.end(), pr) == vec.end()) vec.push_back(pr);
        }
        for (int dc = 0; dc < 3; ++dc) for (int kc = 0; kc < 2; ++kc) for (int p0 = 0; p0 < 2; ++p0) {
            auto a = valid_pairs[q][dc][kc][p0], b = check_tbl[dc][kc][p0];
            std::sort(a.begin(), a.end()); std::sort(b.begin(), b.end());
            if (a != b) { std::cerr << "MISMATCH AB vs CD!\n"; std::exit(1); }
        }
    }
    std::cout << "[OK] valid_pairs table verified identical for (A,B) and (C,D)!\n";
}

// Fast 8+8 quarter-join checking if ANY (z0, z1) exists with s0 = WHT_5^{-1}(z0) in [-2,2]^32 AND s1 = WHT_5^{-1}(z1) in [-2,2]^32!
struct Q8 { std::array<int8_t, 8> b0, b1; };
static void enum_q8_pair(int start, int j, std::array<int, 8>& z0, std::array<int, 8>& z1,
                         const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                         std::unordered_map<uint16_t, std::vector<Q8>>& out) {
    if (j == 8) {
        auto u0 = z0, u1 = z1; fwht8(u0); fwht8(u1);
        uint8_t p0 = 0, p1 = 0; std::array<int8_t, 8> b0, b1;
        for (int y = 0; y < 8; ++y) {
            if ((u0[y] & 7) || (u1[y] & 7)) return;
            int q0 = u0[y] >> 3, q1 = u1[y] >> 3;
            if (std::abs(q0) > 8 || std::abs(q1) > 8) return;
            b0[y] = (int8_t)q0; b1[y] = (int8_t)q1;
            if (q0 & 1) p0 |= (uint8_t(1) << y);
            if (q1 & 1) p1 |= (uint8_t(1) << y);
        }
        out[uint16_t(p0) | (uint16_t(p1) << 8)].push_back({b0, b1});
        return;
    }
    for (auto [v0, v1] : opts[start + j]) {
        z0[j] = v0; z1[j] = v1;
        enum_q8_pair(start, j + 1, z0, z1, opts, out);
    }
}

struct H16 { std::array<int8_t, 16> u0, u1; };
static void enum_h16_pair(int start, const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                          std::unordered_map<uint32_t, std::vector<H16>>& out) {
    std::unordered_map<uint16_t, std::vector<Q8>> q0, q1;
    std::array<int, 8> t0{}, t1{};
    enum_q8_pair(start, 0, t0, t1, opts, q0); if (q0.empty()) return;
    enum_q8_pair(start + 8, 0, t0, t1, opts, q1); if (q1.empty()) return;
    for (const auto& [p16, v0] : q0) {
        auto it = q1.find(p16); if (it == q1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            std::array<int8_t, 16> u0, u1; uint16_t par0 = 0, par1 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a.b0[y]) + std::abs(b.b0[y]) > 8 || std::abs(a.b1[y]) + std::abs(b.b1[y]) > 8) { ok = false; break; }
                int s0 = (a.b0[y] + b.b0[y]) >> 1, d0 = (a.b0[y] - b.b0[y]) >> 1;
                int s1 = (a.b1[y] + b.b1[y]) >> 1, d1 = (a.b1[y] - b.b1[y]) >> 1;
                u0[y] = (int8_t)s0; u0[8+y] = (int8_t)d0; u1[y] = (int8_t)s1; u1[8+y] = (int8_t)d1;
                if (s0 & 1) par0 |= (uint16_t(1) << y); if (d0 & 1) par0 |= (uint16_t(1) << (8 + y));
                if (s1 & 1) par1 |= (uint16_t(1) << y); if (d1 & 1) par1 |= (uint16_t(1) << (8 + y));
            }
            if (ok) out[uint32_t(par0) | (uint32_t(par1) << 16)].push_back({u0, u1});
        }
    }
}

static bool has_valid_pair(const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts) {
    std::unordered_map<uint32_t, std::vector<H16>> g0, g1;
    enum_h16_pair(0, opts, g0); if (g0.empty()) return false;
    enum_h16_pair(16, opts, g1); if (g1.empty()) return false;
    for (const auto& [par32, v0] : g0) {
        auto it = g1.find(par32); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u0[y]) + std::abs(b.u0[y]) > 4 || std::abs(a.u1[y]) + std::abs(b.u1[y]) > 4) { ok = false; break; }
            }
            if (ok) return true;
        }
    }
    return false;
}

static void check_orbit(const std::string& label, uint64_t u_mask, uint64_t m0_mask, uint64_t k1_mask,
                        const std::vector<uint32_t>& rm25) {
    auto t0 = std::chrono::steady_clock::now();
    for (int is_H : {0, 1}) {
        int dc[32], kc[32], qv[32];
        for (int i = 0; i < 32; ++i) {
            int c = 2 * i + is_H;
            qv[i] = q6[c];
            dc[i] = ((u_mask >> c) & 1) + 2 * ((m0_mask >> c) & 1);
            kc[i] = (k1_mask >> c) & 1;
        }
        std::atomic<int> surv{0}, next_p{0};
        std::vector<std::thread> ths;
        for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&]() {
            while (true) {
                int pi = next_p.fetch_add(1); if (pi >= 65536) break;
                uint32_t p0 = rm25[pi];
                std::array<std::vector<std::pair<int8_t, int8_t>>, 32> opts;
                bool ok = true;
                for (int i = 0; i < 32; ++i) {
                    opts[i] = valid_pairs[qv[i]][dc[i]][kc[i]][(p0 >> i) & 1];
                    if (opts[i].empty()) { ok = false; break; }
                }
                if (ok && has_valid_pair(opts)) surv.fetch_add(1);
            }
        });
        for (auto& th : ths) th.join();
        std::cout << "  " << label << " [" << (is_H ? "H (v01,v11)" : "H^c (v00,v10)") << "]: "
                  << surv.load() << " / 65536 p0 survive\n" << std::flush;
    }
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "    (checked both halves in " << dt << "s)\n" << std::flush;
}

int main() {
    init_tables();
    uint32_t mons5[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0; for (int x = 0; x < 32; ++x) if ((x & m) == m) mask |= (1u << x);
        mons5[mk++] = mask;
    }
    std::vector<uint32_t> rm25(65536, 0);
    for (int s = 1; s < 65536; ++s) rm25[s] = rm25[s ^ (1 << __builtin_ctz(s))] ^ mons5[__builtin_ctz(s)];

    struct Orb { std::string name; uint64_t u, m0, k1; };
    std::vector<Orb> orbs = {
        {"wt16_orb0(6Z,10F)",   0xfaaa500050005000ULL, 0ULL, 0ULL},
        {"wt16_orb1(10Z,6F)",   0xaafa005000500050ULL, 0ULL, 0ULL},
        {"wt12_orb0(m0=2)",     0x0aaaa000a000a000ULL, 0x5ULL, 0ULL},
        {"wt12_orb1(m0=1,k1=1)",0x0aaaa000a000a000ULL, 0x2ULL, 0x8ULL},
        {"wt12_orb2(m0=1,k1=1)",0x0aaaa000a000a000ULL, 0x8ULL, 0x2ULL},
        {"wt12_orb3(m0=2)",     0x0aaaa000a000a000ULL, 0x5000ULL, 0ULL},
        {"wt12_orb4(m0=1,k1=1)",0x0555500050005000ULL, 0x1ULL, 0x4ULL},
        {"wt12_orb5(m0=2)",     0x0555500050005000ULL, 0xaULL, 0ULL},
        {"wt12_orb6(m0=1,k1=1)",0x5505005000500050ULL, 0x1ULL, 0x4ULL},
        {"wt12_orb7(m0=2)",     0x5505005000500050ULL, 0xaULL, 0ULL},
        {"wt12_orb8(m0=1,k1=1)",0x5505005000500050ULL, 0x1000ULL, 0x4000ULL},
    };
    for (const auto& o : orbs) check_orbit(o.name, o.u, o.m0, o.k1, rm25);
    return 0;
}
