// COMPLETE 100% EXACT SOLVER for Case II-B4 (k1=4, |M|=4, |K2|=0, L00=0) of (t=100, r=6, |Z|=128)!
// All 10 exact Stab(P)-orbits of isotropic 2-planes K1 relative to P = {0, 1, 2, 3}!
// Step 1: Exact 22-bit deg456(A/8) == 0 pins p00 in RM(2,6) to <= 256 candidates per orbit!
// Step 2: Exact 32+32 pair join on (z00, z10) (max 2 options per point!) filters p00 to ONLY surviving (v00, v10)!
// Step 3: Exact 22-bit deg456(C) == 0 pins p01 mod RM(1,6) to <= 2 candidates per surviving p00!
// Step 4: Exact 32+32 pair join on (z01, z11) (coupled with wt(v00)+wt(v10)+wt(v01)+wt(v11) == 100)!
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include <vector>

static int q6[64];
static uint64_t mons6[22], qmon[15];

static inline void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static uint32_t deg456_bits6(uint64_t f) {
    uint8_t a[64]; for (int i = 0; i < 64; ++i) a[i] = (f >> i) & 1;
    for (int b = 0; b < 6; ++b) for (int i = 0; i < 64; ++i) if (i & (1 << b)) a[i] ^= a[i ^ (1 << b)];
    uint32_t out = 0; int k = 0;
    for (int i = 0; i < 64; ++i) if (__builtin_popcount(i) >= 4) { if (a[i]) out |= (1u << k); k++; }
    return out;
}
static bool base_syndrome6(const std::array<int, 64>& Abase, uint32_t& out_syn) {
    out_syn = 0; int k = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) >= 4) {
        int s = 0; for (int c = 0; c < 64; ++c) if ((c & ~m) == 0) s += Abase[c];
        if (s & 7) return false;
        if (s & 8) out_syn |= (1u << k);
        k++;
    }
    return true;
}

static std::vector<std::pair<int8_t, int8_t>> opts00[2][2][2][2];    // [q][inP][inK1][p00]
static std::vector<std::pair<int8_t, int8_t>> opts01[2][2][2][2][2]; // [q][inP][inK1][p00][p01]
static int A16_tbl[2][2][2][2]; // [q][inP][inK1][p00] (-1 if invalid)
static int C16_tbl[2][2][2][2][2]; // [q][inP][inK1][p00][p01] (-1 if invalid)

static void init_all() {
    for (int c = 0; c < 64; ++c)
        q6[c] = ((c & 1) & ((c >> 1) & 1)) ^ (((c >> 2) & 1) & ((c >> 3) & 1)) ^ (((c >> 4) & 1) & ((c >> 5) & 1));
    int mk = 0, qk = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) <= 2) {
        uint64_t mask = 0; for (int c = 0; c < 64; ++c) if ((c & m) == m) mask |= (1ULL << c);
        mons6[mk++] = mask;
        if (__builtin_popcount(m) == 2) qmon[qk++] = mask;
    }
    for (int q = 0; q < 2; ++q) for (int p = 0; p < 2; ++p) for (int k = 0; k < 2; ++k) for (int p0 = 0; p0 < 2; ++p0) {
        A16_tbl[q][p][k][p0] = -1;
        for (int p1 = 0; p1 < 2; ++p1) C16_tbl[q][p][k][p0][p1] = -1;
    }
    for (int q = 0; q < 2; ++q) {
        std::vector<int> w0s = (q == 0) ? std::vector<int>{-8, 0, 8} : std::vector<int>{-12, -4, 4, 12};
        std::vector<int> w1s = (q == 0) ? std::vector<int>{-12, -4, 4, 12} : std::vector<int>{-8, 0, 8};
        for (int v00 : w0s) for (int v01 : w0s) for (int v10 : w1s) for (int v11 : w1s) {
            int dc = (q == 0) ? ((v00 == 0) + (v01 == 0)) : ((v10 == 0) + (v11 == 0));
            int kc = (q == 0) ? ((std::abs(v10) == 4) + (std::abs(v11) == 4)) : ((std::abs(v00) == 4) + (std::abs(v01) == 4));
            if ((dc != 0 && dc != 2) || (kc != 0 && kc != 1)) continue;
            int inP = dc / 2, inK = kc;
            int A = (v00 + v01) / 2, C = (v00 - v01) / 2, B = (v10 + v11) / 2, D = (v10 - v11) / 2;
            int z00 = (A + B) / 2, z10 = (A - B) / 2, z01 = (C + D) / 2, z11 = (C - D) / 2;
            if ((z00 & 3) != 0 || (z10 & 3) != 0) continue;
            int p0 = (z00 >> 2) & 1, p1 = ((z01 - 2) >> 2) & 1;
            int a16 = ((A % 16) + 16) % 16, c16 = ((C % 16) + 16) % 16;
            if (A16_tbl[q][inP][inK][p0] >= 0 && A16_tbl[q][inP][inK][p0] != a16) { std::cerr << "A16 NONUNIQUE!\n"; std::exit(1); }
            A16_tbl[q][inP][inK][p0] = a16;
            if (C16_tbl[q][inP][inK][p0][p1] >= 0 && C16_tbl[q][inP][inK][p0][p1] != c16) { std::cerr << "C16 NONUNIQUE!\n"; std::exit(1); }
            C16_tbl[q][inP][inK][p0][p1] = c16;
            auto pr0 = std::make_pair((int8_t)z00, (int8_t)z10);
            auto& v0 = opts00[q][inP][inK][p0];
            if (std::find(v0.begin(), v0.end(), pr0) == v0.end()) v0.push_back(pr0);
            auto pr1 = std::make_pair((int8_t)z01, (int8_t)z11);
            auto& v1 = opts01[q][inP][inK][p0][p1];
            if (std::find(v1.begin(), v1.end(), pr1) == v1.end()) v1.push_back(pr1);
        }
    }
    int m0 = 0, m1 = 0;
    for (int q=0;q<2;++q) for (int p=0;p<2;++p) for (int k=0;k<2;++k) for (int p0=0;p0<2;++p0) {
        m0 = std::max(m0, (int)opts00[q][p][k][p0].size());
        for (int p1=0;p1<2;++p1) m1 = std::max(m1, (int)opts01[q][p][k][p0][p1].size());
    }
    std::cout << "[OK] II-B4 tables verified! max opts00=" << m0 << ", max opts01=" << m1 << "\n";
}

struct PairHalf { uint32_t tw0, tw1; int e2_sum; };
using PairMap = std::unordered_map<uint64_t, std::vector<PairHalf>>;
struct Q8 { std::array<int8_t, 8> b0, b1; };
static void enum_q8(int start, int j, std::array<int, 8>& z0, std::array<int, 8>& z1,
                    const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                    std::unordered_map<uint16_t, std::vector<Q8>>& out) {
    if (j == 8) {
        auto u0 = z0, u1 = z1; fwht8(u0); fwht8(u1);
        uint8_t p0 = 0, p1 = 0; std::array<int8_t, 8> b0, b1;
        for (int y = 0; y < 8; ++y) {
            if ((u0[y] & 7) || (u1[y] & 7)) return;
            int q0 = u0[y] >> 3, q1 = u1[y] >> 3;
            if (std::abs(q0) > 8 || std::abs(q1) > 8) return;
            b0[y] = (int8_t)q0; b1[y] = (int8_t)q1;
            if (q0 & 1) p0 |= (uint8_t(1) << y); if (q1 & 1) p1 |= (uint8_t(1) << y);
        }
        out[uint16_t(p0) | (uint16_t(p1) << 8)].push_back({b0, b1});
        return;
    }
    for (auto [v0, v1] : opts[start + j]) { z0[j] = v0; z1[j] = v1; enum_q8(start, j + 1, z0, z1, opts, out); }
}
struct H16 { std::array<int8_t, 16> u0, u1; };
static void enum_h16(int start, const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                     std::unordered_map<uint32_t, std::vector<H16>>& out) {
    std::unordered_map<uint16_t, std::vector<Q8>> q0, q1; std::array<int, 8> t0{}, t1{};
    enum_q8(start, 0, t0, t1, opts, q0); if (q0.empty()) return;
    enum_q8(start + 8, 0, t0, t1, opts, q1); if (q1.empty()) return;
    for (const auto& [p16, v0] : q0) {
        auto it = q1.find(p16); if (it == q1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            std::array<int8_t, 16> u0, u1; uint16_t par0 = 0, par1 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a.b0[y]) + std::abs(b.b0[y]) > 8 || std::abs(a.b1[y]) + std::abs(b.b1[y]) > 8) { ok = false; break; }
                int s0 = (a.b0[y] + b.b0[y]) >> 1, d0 = (a.b0[y] - b.b0[y]) >> 1;
                int s1 = (a.b1[y] + b.b1[y]) >> 1, d1 = (a.b1[y] - b.b1[y]) >> 1;
                u0[y] = (int8_t)s0; u0[8+y] = (int8_t)d0; u1[y] = (int8_t)s1; u1[8+y] = (int8_t)d1;
                if (s0 & 1) par0 |= (uint16_t(1) << y); if (d0 & 1) par0 |= (uint16_t(1) << (8 + y));
                if (s1 & 1) par1 |= (uint16_t(1) << y); if (d1 & 1) par1 |= (uint16_t(1) << (8 + y));
            }
            if (ok) out[uint32_t(par0) | (uint32_t(par1) << 16)].push_back({u0, u1});
        }
    }
}
static int min_pair_wt_64(const std::array<std::vector<std::pair<int8_t, int8_t>>, 64>& opts64) {
    auto do_half = [&](int offset, const PairMap* filter, PairMap& out) {
        std::array<std::vector<std::pair<int8_t, int8_t>>, 32> o32;
        for (int i = 0; i < 32; ++i) o32[i] = opts64[offset + i];
        std::unordered_map<uint32_t, std::vector<H16>> g0, g1;
        enum_h16(0, o32, g0); if (g0.empty()) return;
        enum_h16(16, o32, g1); if (g1.empty()) return;
        for (const auto& [par32, v0] : g0) {
            auto it = g1.find(par32); if (it == g1.end()) continue;
            for (const auto& a : v0) for (const auto& b : it->second) {
                uint32_t p0 = 0, p1 = 0, tw0 = 0, tw1 = 0; int e2 = 0; bool ok = true;
                for (int y = 0; y < 16; ++y) {
                    if (std::abs(a.u0[y]) + std::abs(b.u0[y]) > 4 || std::abs(a.u1[y]) + std::abs(b.u1[y]) > 4) { ok = false; break; }
                    int x0a = (a.u0[y] + b.u0[y]) >> 1, x0b = (a.u0[y] - b.u0[y]) >> 1;
                    int x1a = (a.u1[y] + b.u1[y]) >> 1, x1b = (a.u1[y] - b.u1[y]) >> 1;
                    e2 += x0a*x0a + x0b*x0b + x1a*x1a + x1b*x1b;
                    if (x0a & 1) p0 |= (1u << y); if (x0b & 1) p0 |= (1u << (16 + y));
                    if (x1a & 1) p1 |= (1u << y); if (x1b & 1) p1 |= (1u << (16 + y));
                    if (std::abs(x0a) == 2) tw0 |= (1u << y); if (std::abs(x0b) == 2) tw0 |= (1u << (16 + y));
                    if (std::abs(x1a) == 2) tw1 |= (1u << y); if (std::abs(x1b) == 2) tw1 |= (1u << (16 + y));
                }
                if (!ok) continue;
                uint64_t pk = (uint64_t(p0) << 32) | uint64_t(p1);
                if (filter && !filter->count(pk)) continue;
                auto& vec = out[pk];
                bool f = false;
                for (auto& e : vec) if (e.tw0 == tw0 && e.tw1 == tw1) { e.e2_sum = std::min(e.e2_sum, e2); f = true; break; }
                if (!f) vec.push_back({tw0, tw1, e2});
            }
        }
    };
    PairMap m0, m1;
    do_half(0, nullptr, m0); if (m0.empty()) return 999;
    do_half(32, &m0, m1); if (m1.empty()) return 999;
    int best = 999;
    for (const auto& [pk, v1] : m1) {
        const auto& v0 = m0.at(pk);
        for (const auto& a : v0) for (const auto& b : v1)
            if ((a.tw0 & b.tw0) == 0 && (a.tw1 & b.tw1) == 0)
                best = std::min(best, (a.e2_sum + b.e2_sum) / 2);
    }
    return best;
}

static void solve_K1_orbit(int oid, uint64_t K1) {
    auto t0 = std::chrono::steady_clock::now();
    uint64_t P = 0xFULL;
    uint64_t Z6_mask = 0; for (int c = 0; c < 64; ++c) if (q6[c] == 0) Z6_mask |= (1ULL << c);
    // Step 1: Find ALL p00 in RM(2,6) satisfying:
    //   - p00 == 0 on P \ K1, p00 == 1 on P cap K1!
    //   - deg456(K1 ^ (Z6_mask & p00)) == 0!
    uint64_t must0 = P & ~K1, must1 = P & K1;
    uint32_t k1_syn = deg456_bits6(K1);
    uint32_t basA[22]; for (int b = 0; b < 22; ++b) basA[b] = deg456_bits6(Z6_mask & mons6[b]);
    std::vector<uint64_t> cand_p00;
    uint32_t cs = 0; uint64_t cp = 0;
    for (uint32_t s = 0; s < (1u << 22); ++s) {
        if (s > 0) { int b = __builtin_ctz(s); cs ^= basA[b]; cp ^= mons6[b]; }
        if ((cp & must0) != 0 || (cp & must1) != must1) continue;
        if (cs == k1_syn) cand_p00.push_back(cp);
    }

    // Step 2: Test EVERY cand_p00 with exact 32+32 pair join on (z00, z10)!
    int surv_p00 = 0;
    long long tot_full_hits = 0;
    for (uint64_t p00 : cand_p00) {
        std::array<std::vector<std::pair<int8_t, int8_t>>, 64> o00;
        bool ok = true;
        for (int c = 0; c < 64; ++c) {
            o00[c] = opts00[q6[c]][(P >> c) & 1][(K1 >> c) & 1][(p00 >> c) & 1];
            if (o00[c].empty()) { ok = false; break; }
        }
        if (!ok) continue;
        int w00 = min_pair_wt_64(o00);
        if (w00 >= 999) continue;
        surv_p00++;
        // Step 3: For this surviving p00, compute C(p00, p01) mod 16 -> find ALL matching p01 mod RM(1,6) (32,768)!
        std::array<int, 64> Cbase{};
        uint64_t M01 = 0;
        for (int c = 0; c < 64; ++c) {
            int q = q6[c], inP = (P >> c) & 1, inK = (K1 >> c) & 1, p0 = (p00 >> c) & 1;
            int c0 = C16_tbl[q][inP][inK][p0][0], c1 = C16_tbl[q][inP][inK][p0][1];
            Cbase[c] = c0;
            if (((c1 - c0 + 16) % 16) == 8) M01 |= (1ULL << c);
            else if (c1 != c0) { std::cerr << "UNEXPECTED C16 DIFF!\n"; std::exit(1); }
        }
        uint32_t c_syn = 0;
        if (!base_syndrome6(Cbase, c_syn)) continue;
        uint32_t basC[15]; for (int b = 0; b < 15; ++b) basC[b] = deg456_bits6(M01 & qmon[b]);
        uint32_t csc = 0; uint64_t cp01 = 0;
        for (int s = 0; s < 32768; ++s) {
            if (s > 0) { int b = __builtin_ctz(s); csc ^= basC[b]; cp01 ^= qmon[b]; }
            if (csc != c_syn) continue;
            // Step 4: Exact 32+32 pair join on (z01, z11)!
            std::array<std::vector<std::pair<int8_t, int8_t>>, 64> o01;
            for (int c = 0; c < 64; ++c)
                o01[c] = opts01[q6[c]][(P >> c) & 1][(K1 >> c) & 1][(p00 >> c) & 1][(cp01 >> c) & 1];
            int w01 = min_pair_wt_64(o01);
            if (w01 < 999 && w00 + w01 <= 100) {
                tot_full_hits++;
                std::cout << "    [HIT!] orb#" << oid << " w00=" << w00 << " w01=" << w01 << "\n" << std::flush;
            }
        }
    }
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "  orb#" << oid << " (K1=0x" << std::hex << K1 << std::dec << "): cand_p00=" << cand_p00.size()
              << " surv_v00v10=" << surv_p00 << " FULL_HITS=" << tot_full_hits << " [" << dt << "s]\n" << std::flush;
}

int main() {
    init_all();
    uint64_t K1_orbs[10] = {
        0x1100110ULL, 0x30030ULL, 0x330ULL, 0x2100210ULL, 0x2200110ULL,
        0x80040210ULL, 0x110011ULL, 0x8421ULL, 0x220011ULL, 0x33ULL
    };
    for (int i = 0; i < 10; ++i) solve_K1_orbit(i, K1_orbs[i]);
    return 0;
}
