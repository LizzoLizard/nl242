// ULTRA-FAST 100% EXACT SOLVER for wt16_orb0 and wt16_orb1 of Branch I (L00=1_H, t=100, r=6, |Z|=128)!
// Uses:
//   1. Exact 64x normalization: translating (v00,v10,v01,v11) by (0, y') and flipping sign (-1)^s
//      shifts p00|_H by ANY L in RM(1,5) while fixing p00|_{H^c} and p01|_H => WLOG p00|_H == p00|_{H^c}!!
//   2. Exact s_A syndrome tracking on H^c cap U: m0 records the EXACT 22-bit deg456 syndrome of
//      ((z00+z10 - 4)/8)&1 on H^c cap U, so L1 only queries the EXACT matching osyn!!
//   3. Pre-filter po in RM(2,5) to only those surviving L0-half on H for (v01, v11) (16,384 / 65,536)!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int q6[64];
static inline void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static uint32_t deg456_bits6(uint64_t f) {
    uint8_t a[64];
    for (int i = 0; i < 64; ++i) a[i] = (f >> i) & 1;
    for (int b = 0; b < 6; ++b)
        for (int i = 0; i < 64; ++i) if (i & (1 << b)) a[i] ^= a[i ^ (1 << b)];
    uint32_t out = 0; int k = 0;
    for (int i = 0; i < 64; ++i) if (__builtin_popcount(i) >= 4) { if (a[i]) out |= (1u << k); k++; }
    return out;
}
static bool base_syndrome6(const std::array<int, 64>& Abase, uint32_t& out_syn) {
    out_syn = 0; int k = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) >= 4) {
        int s = 0;
        for (int c = 0; c < 64; ++c) if ((c & ~m) == 0) s += Abase[c];
        if (s & 7) return false;
        if (s & 8) out_syn |= (1u << k);
        k++;
    }
    return true;
}

static std::vector<std::pair<int8_t, int8_t>> opts_L0[2][3][2];    // [q][dc][p_self]
static std::vector<std::pair<int8_t, int8_t>> opts_L1[2][3][2][2]; // [q][dc][p_self][p_other]

static void init_opts() {
    for (int c = 0; c < 64; ++c)
        q6[c] = ((c & 1) & ((c >> 1) & 1)) ^ (((c >> 2) & 1) & ((c >> 3) & 1)) ^ (((c >> 4) & 1) & ((c >> 5) & 1));
    for (int q = 0; q < 2; ++q) {
        std::vector<int> w0s = (q == 0) ? std::vector<int>{-8, 0, 8} : std::vector<int>{-12, -4, 4, 12};
        std::vector<int> w1s = (q == 0) ? std::vector<int>{-12, -4, 4, 12} : std::vector<int>{-8, 0, 8};
        for (int v00 : w0s) for (int v01 : w0s) for (int v10 : w1s) for (int v11 : w1s) {
            int dc = (q == 0) ? ((v00 == 0) + (v01 == 0)) : ((v10 == 0) + (v11 == 0));
            int kc = (q == 0) ? ((std::abs(v10) == 4) + (std::abs(v11) == 4)) : ((std::abs(v00) == 4) + (std::abs(v01) == 4));
            if (kc != 0) continue;
            int A = (v00 + v01) / 2, C = (v00 - v01) / 2;
            int B = (v10 + v11) / 2, D = (v10 - v11) / 2;
            int z0 = (A + B) / 2, z1 = (A - B) / 2, z2 = (C + D) / 2;
            auto pr = std::make_pair((int8_t)z0, (int8_t)z1);
            if ((z0 & 3) == 0 && (z1 & 3) == 0) {
                int p0 = (z0 >> 2) & 1;
                auto& vec = opts_L0[q][dc][p0];
                if (std::find(vec.begin(), vec.end(), pr) == vec.end()) vec.push_back(pr);
            } else if ((z0 & 3) == 2 && (z1 & 3) == 2) {
                int p0 = ((z0 - 2) >> 2) & 1, po = (z2 >> 2) & 1;
                auto& vec = opts_L1[q][dc][p0][po];
                if (std::find(vec.begin(), vec.end(), pr) == vec.end()) vec.push_back(pr);
            }
        }
    }
}

struct PairHalf { uint32_t tw0, tw1; int e2_sum; };
using PairMap = std::unordered_map<uint64_t, std::vector<PairHalf>>;

// L0 collector WITH exact s_A bitmask on the 8 points of H^c cap U!
struct Q8S { std::array<int8_t, 8> b0, b1; uint8_t sA; };
static void enum_q8_sA(int start, int j, std::array<int, 8>& z0, std::array<int, 8>& z1, uint8_t sA,
                       const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                       const int bit_of_i[32],
                       std::unordered_map<uint16_t, std::vector<Q8S>>& out) {
    if (j == 8) {
        auto u0 = z0, u1 = z1; fwht8(u0); fwht8(u1);
        uint8_t p0 = 0, p1 = 0; std::array<int8_t, 8> b0, b1;
        for (int y = 0; y < 8; ++y) {
            if ((u0[y] & 7) || (u1[y] & 7)) return;
            int q0 = u0[y] >> 3, q1 = u1[y] >> 3;
            if (std::abs(q0) > 8 || std::abs(q1) > 8) return;
            b0[y] = (int8_t)q0; b1[y] = (int8_t)q1;
            if (q0 & 1) p0 |= (uint8_t(1) << y);
            if (q1 & 1) p1 |= (uint8_t(1) << y);
        }
        out[uint16_t(p0) | (uint16_t(p1) << 8)].push_back({b0, b1, sA});
        return;
    }
    int idx = start + j; int bi = bit_of_i[idx];
    for (auto [v0, v1] : opts[idx]) {
        z0[j] = v0; z1[j] = v1;
        uint8_t ns = sA;
        if (bi >= 0) {
            int A = v0 + v1; // +-4 or +-12 => ((A - 4) >> 3) & 1!
            if ((((A - 4) % 16) + 16) % 16 == 8) ns |= (uint8_t(1) << bi);
        }
        enum_q8_sA(start, j + 1, z0, z1, ns, opts, bit_of_i, out);
    }
}
struct H16S { std::array<int8_t, 16> u0, u1; uint8_t sA; };
static void enum_h16_sA(int start, const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                        const int bit_of_i[32], std::unordered_map<uint32_t, std::vector<H16S>>& out) {
    std::unordered_map<uint16_t, std::vector<Q8S>> q0, q1;
    std::array<int, 8> t0{}, t1{};
    enum_q8_sA(start, 0, t0, t1, 0, opts, bit_of_i, q0); if (q0.empty()) return;
    enum_q8_sA(start + 8, 0, t0, t1, 0, opts, bit_of_i, q1); if (q1.empty()) return;
    for (const auto& [p16, v0] : q0) {
        auto it = q1.find(p16); if (it == q1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            std::array<int8_t, 16> u0, u1; uint16_t par0 = 0, par1 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a.b0[y]) + std::abs(b.b0[y]) > 8 || std::abs(a.b1[y]) + std::abs(b.b1[y]) > 8) { ok = false; break; }
                int s0 = (a.b0[y] + b.b0[y]) >> 1, d0 = (a.b0[y] - b.b0[y]) >> 1;
                int s1 = (a.b1[y] + b.b1[y]) >> 1, d1 = (a.b1[y] - b.b1[y]) >> 1;
                u0[y] = (int8_t)s0; u0[8+y] = (int8_t)d0; u1[y] = (int8_t)s1; u1[8+y] = (int8_t)d1;
                if (s0 & 1) par0 |= (uint16_t(1) << y); if (d0 & 1) par0 |= (uint16_t(1) << (8 + y));
                if (s1 & 1) par1 |= (uint16_t(1) << y); if (d1 & 1) par1 |= (uint16_t(1) << (8 + y));
            }
            if (ok) out[uint32_t(par0) | (uint32_t(par1) << 16)].push_back({u0, u1, uint8_t(a.sA | b.sA)});
        }
    }
}
static void collect_L0_by_syn(const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                              const int bit_of_i[32], const uint32_t syn_of_sA[256],
                              std::unordered_map<uint32_t, PairMap>& out_by_syn) {
    out_by_syn.clear();
    std::unordered_map<uint32_t, std::vector<H16S>> g0, g1;
    enum_h16_sA(0, opts, bit_of_i, g0); if (g0.empty()) return;
    enum_h16_sA(16, opts, bit_of_i, g1); if (g1.empty()) return;
    for (const auto& [par32, v0] : g0) {
        auto it = g1.find(par32); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p0 = 0, p1 = 0, tw0 = 0, tw1 = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u0[y]) + std::abs(b.u0[y]) > 4 || std::abs(a.u1[y]) + std::abs(b.u1[y]) > 4) { ok = false; break; }
                int x0a = (a.u0[y] + b.u0[y]) >> 1, x0b = (a.u0[y] - b.u0[y]) >> 1;
                int x1a = (a.u1[y] + b.u1[y]) >> 1, x1b = (a.u1[y] - b.u1[y]) >> 1;
                e2 += x0a*x0a + x0b*x0b + x1a*x1a + x1b*x1b;
                if (x0a & 1) p0 |= (1u << y); if (x0b & 1) p0 |= (1u << (16 + y));
                if (x1a & 1) p1 |= (1u << y); if (x1b & 1) p1 |= (1u << (16 + y));
                if (std::abs(x0a) == 2) tw0 |= (1u << y); if (std::abs(x0b) == 2) tw0 |= (1u << (16 + y));
                if (std::abs(x1a) == 2) tw1 |= (1u << y); if (std::abs(x1b) == 2) tw1 |= (1u << (16 + y));
            }
            if (!ok) continue;
            uint32_t syn = syn_of_sA[a.sA | b.sA];
            uint64_t pk = (uint64_t(p0) << 32) | uint64_t(p1);
            auto& vec = out_by_syn[syn][pk];
            bool found = false;
            for (auto& e : vec) if (e.tw0 == tw0 && e.tw1 == tw1) { e.e2_sum = std::min(e.e2_sum, e2); found = true; break; }
            if (!found) vec.push_back({tw0, tw1, e2});
        }
    }
}

static bool has_L0_any(const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts) {
    int dummy[32]; for (int i = 0; i < 32; ++i) dummy[i] = -1;
    std::unordered_map<uint32_t, std::vector<H16S>> g0, g1;
    enum_h16_sA(0, opts, dummy, g0); if (g0.empty()) return false;
    enum_h16_sA(16, opts, dummy, g1); if (g1.empty()) return false;
    for (const auto& [par32, v0] : g0) {
        auto it = g1.find(par32); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            bool ok = true;
            for (int y = 0; y < 16; ++y)
                if (std::abs(a.u0[y]) + std::abs(b.u0[y]) > 4 || std::abs(a.u1[y]) + std::abs(b.u1[y]) > 4) { ok = false; break; }
            if (ok) return true;
        }
    }
    return false;
}

static void collect_L1_filtered(const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                                const PairMap& filter, PairMap& out) {
    out.clear();
    int dummy[32]; for (int i = 0; i < 32; ++i) dummy[i] = -1;
    std::unordered_map<uint32_t, std::vector<H16S>> g0, g1;
    enum_h16_sA(0, opts, dummy, g0); if (g0.empty()) return;
    enum_h16_sA(16, opts, dummy, g1); if (g1.empty()) return;
    for (const auto& [par32, v0] : g0) {
        auto it = g1.find(par32); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p0 = 0, p1 = 0, tw0 = 0, tw1 = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u0[y]) + std::abs(b.u0[y]) > 4 || std::abs(a.u1[y]) + std::abs(b.u1[y]) > 4) { ok = false; break; }
                int x0a = (a.u0[y] + b.u0[y]) >> 1, x0b = (a.u0[y] - b.u0[y]) >> 1;
                int x1a = (a.u1[y] + b.u1[y]) >> 1, x1b = (a.u1[y] - b.u1[y]) >> 1;
                e2 += x0a*x0a + x0b*x0b + x1a*x1a + x1b*x1b;
                if (x0a & 1) p0 |= (1u << y); if (x0b & 1) p0 |= (1u << (16 + y));
                if (x1a & 1) p1 |= (1u << y); if (x1b & 1) p1 |= (1u << (16 + y));
                if (std::abs(x0a) == 2) tw0 |= (1u << y); if (std::abs(x0b) == 2) tw0 |= (1u << (16 + y));
                if (std::abs(x1a) == 2) tw1 |= (1u << y); if (std::abs(x1b) == 2) tw1 |= (1u << (16 + y));
            }
            if (!ok) continue;
            uint64_t pk = (uint64_t(p0) << 32) | uint64_t(p1);
            if (!filter.count(pk)) continue;
            auto& vec = out[pk];
            bool found = false;
            for (auto& e : vec) if (e.tw0 == tw0 && e.tw1 == tw1) { e.e2_sum = std::min(e.e2_sum, e2); found = true; break; }
            if (!found) vec.push_back({tw0, tw1, e2});
        }
    }
}

static void solve_wt16(const std::string& name, uint64_t u_mask, const std::vector<uint32_t>& rm25) {
    auto t0 = std::chrono::steady_clock::now();
    std::array<int, 64> Abase{};
    uint64_t M_self = 0, M_other = 0;
    int bit_of_i[32]; for (int i = 0; i < 32; ++i) bit_of_i[i] = -1;
    std::vector<int> free8_pts;
    for (int c = 0; c < 64; ++c) {
        int q = q6[c], dc = (u_mask >> c) & 1;
        if ((c & 1) == 0) { // H^c = L0
            if (dc == 0) { if (q == 0) M_self |= (1ULL << c); }
            else { Abase[c] = 4; bit_of_i[c >> 1] = (int)free8_pts.size(); free8_pts.push_back(c); }
        } else { // H = L1
            if (dc == 0) { Abase[c] = (q == 0) ? 8 : 12; M_other |= (1ULL << c); if (q == 1) M_self |= (1ULL << c); }
            else { Abase[c] = (q == 0) ? 4 : 0; if (q == 0) M_self |= (1ULL << c); }
        }
    }
    uint32_t base_syn = 0;
    if (!base_syndrome6(Abase, base_syn)) { std::cout << name << ": DEAD mod 8!\n"; return; }
    uint32_t syn_of_sA[256];
    for (int sm = 0; sm < 256; ++sm) {
        uint64_t fm = 0;
        for (int j = 0; j < 8; ++j) if ((sm >> j) & 1) fm |= (1ULL << free8_pts[j]);
        syn_of_sA[sm] = deg456_bits6(fm);
    }

    // 1. Pre-filter po in RM(2,5) to those valid on H (L0 for (v01, v11))!
    std::vector<uint8_t> po_ok(65536, 0);
    {
        std::atomic<int> pi{0};
        std::vector<std::thread> ths;
        for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&]() {
            while (true) {
                int idx = pi.fetch_add(1); if (idx >= 65536) break;
                uint32_t po = rm25[idx];
                std::array<std::vector<std::pair<int8_t, int8_t>>, 32> oH;
                for (int i = 0; i < 32; ++i) {
                    int c = 2 * i + 1, dc = (u_mask >> c) & 1;
                    oH[i] = opts_L0[q6[c]][dc][(po >> i) & 1];
                }
                if (has_L0_any(oH)) po_ok[idx] = 1;
            }
        });
        for (auto& th : ths) th.join();
    }
    std::unordered_map<uint32_t, std::vector<uint32_t>> other_by_syn;
    int n_po_ok = 0;
    for (int idx = 0; idx < 65536; ++idx) {
        if (!po_ok[idx]) continue;
        n_po_ok++;
        uint32_t p5 = rm25[idx];
        uint64_t emb = 0;
        for (int i = 0; i < 32; ++i) if ((p5 >> i) & 1) emb |= (1ULL << (2 * i + 1));
        other_by_syn[deg456_bits6(M_other & emb)].push_back(p5);
    }

    // 2. Test ALL 65,536 normalized p_self (p_self|_H == p_self|_{H^c} = p5 in RM(2,5))!
    std::atomic<int> pi{0};
    std::atomic<long long> L0_pass{0}, tot_syns{0}, tot_po_checks{0}, full_joins{0};
    std::atomic<int> min_wpair{999};
    std::vector<std::thread> ths;
    for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&]() {
        while (true) {
            int idx = pi.fetch_add(1); if (idx >= 65536) break;
            uint32_t p5 = rm25[idx];
            std::array<std::vector<std::pair<int8_t, int8_t>>, 32> o0;
            for (int i = 0; i < 32; ++i) {
                int c = 2 * i, dc = (u_mask >> c) & 1;
                o0[i] = opts_L0[q6[c]][dc][(p5 >> i) & 1];
            }
            std::unordered_map<uint32_t, PairMap> by_syn;
            collect_L0_by_syn(o0, bit_of_i, syn_of_sA, by_syn);
            if (by_syn.empty()) continue;
            L0_pass.fetch_add(1);
            uint64_t p_full = 0;
            for (int i = 0; i < 32; ++i) if ((p5 >> i) & 1) p_full |= (1ULL << (2 * i)) | (1ULL << (2 * i + 1));
            uint32_t self_syn = deg456_bits6(M_self & p_full);
            for (const auto& [sA_syn, m0] : by_syn) {
                tot_syns.fetch_add(1);
                uint32_t need_osyn = self_syn ^ base_syn ^ sA_syn;
                auto ito = other_by_syn.find(need_osyn);
                if (ito == other_by_syn.end()) continue;
                for (uint32_t po : ito->second) {
                    tot_po_checks.fetch_add(1);
                    std::array<std::vector<std::pair<int8_t, int8_t>>, 32> o1;
                    for (int i = 0; i < 32; ++i) {
                        int c = 2 * i + 1, dc = (u_mask >> c) & 1;
                        o1[i] = opts_L1[q6[c]][dc][(p5 >> i) & 1][(po >> i) & 1];
                    }
                    PairMap m1; collect_L1_filtered(o1, m0, m1);
                    for (const auto& [pk, v1] : m1) {
                        const auto& v0 = m0.at(pk);
                        for (const auto& a : v0) for (const auto& b : v1) {
                            if ((a.tw0 & b.tw0) || (a.tw1 & b.tw1)) continue;
                            int w = (a.e2_sum + b.e2_sum) / 2;
                            full_joins.fetch_add(1);
                            int prev = min_wpair.load();
                            while (w < prev && !min_wpair.compare_exchange_weak(prev, w)) {}
                        }
                    }
                }
            }
        }
    });
    for (auto& th : ths) th.join();
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << ">>> RESULT " << name << " in " << dt << "s: valid_po=" << n_po_ok
              << " |other_syns|=" << other_by_syn.size()
              << " L0_pass=" << L0_pass.load() << " syns=" << tot_syns.load()
              << " po_checks=" << tot_po_checks.load()
              << " FULL_32x32_PAIR_JOINS=" << full_joins.load()
              << " min_wpair=" << min_wpair.load() << " <<<\n" << std::flush;
}

int main() {
    init_opts();
    uint32_t mons5[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0; for (int x = 0; x < 32; ++x) if ((x & m) == m) mask |= (1u << x);
        mons5[mk++] = mask;
    }
    std::vector<uint32_t> rm25(65536, 0);
    for (int s = 1; s < 65536; ++s) rm25[s] = rm25[s ^ (1 << __builtin_ctz(s))] ^ mons5[__builtin_ctz(s)];

    solve_wt16("wt16_orb0(6Z,10F)", 0xfaaa500050005000ULL, rm25);
    solve_wt16("wt16_orb1(10Z,6F)", 0xaafa005000500050ULL, rm25);
    return 0;
}
