// ULTRA-FAST 100% EXACT K-COSET SOLVER for ALL remaining II-B2 (|M|=6, k2=1, p=0) cases on 0x0025!
// Only 2 tight (n_diff = 16/16 => X(c') = +1 at ALL 16 cosets!) cases remain:
//   Case A (k_in=0, d1=0, d2=1, B=22, wt=(40,60)): 6 cosets with m=1, 10 with m=0; ONE x=0 pt has d2=1 (z11=-6*s1)!
//   Case B (k_in=0, d1=1, d2=0, B=23, wt=(42,58)): 6 cosets with m=1, 1 with d1=1 (x=-1 in z01, z11=+2*s1), 9 with m=0!
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include <vector>

static int q6[64];
static uint64_t qmon[15];

static inline void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static void init() {
    for (int c = 0; c < 64; ++c)
        q6[c] = ((c & 1) & ((c >> 1) & 1)) ^ (((c >> 2) & 1) & ((c >> 3) & 1)) ^ (((c >> 4) & 1) & ((c >> 5) & 1));
    int k = 0;
    for (int i = 0; i < 6; ++i)
        for (int j = i + 1; j < 6; ++j) {
            uint64_t m = 0;
            for (int c = 0; c < 64; ++c) if (((c >> i) & 1) && ((c >> j) & 1)) m |= (1ULL << c);
            qmon[k++] = m;
        }
}
static uint64_t pmask(int s) {
    uint64_t m = 0; for (int k = 0; k < 15; ++k) if ((s >> k) & 1) m ^= qmon[k]; return m;
}
static std::array<int, 64> align_rad_low2(uint64_t p01) {
    int B[6] = {}; int p0 = p01 & 1;
    for (int i = 0; i < 6; ++i)
        for (int j = 0; j < 6; ++j)
            if (p0 ^ ((p01 >> (1<<i)) & 1) ^ ((p01 >> (1<<j)) & 1) ^ ((p01 >> ((1<<i)^(1<<j))) & 1))
                B[i] |= (1 << j);
    std::vector<int> rad;
    for (int x = 1; x < 64; ++x) {
        bool ok = true; for (int i = 0; i < 6; ++i) if (__builtin_parity(B[i] & x)) { ok = false; break; }
        if (ok) rad.push_back(x);
    }
    int bas[6]; bas[0] = rad[0]; bas[1] = rad[1]; int nb = 2;
    for (int v = 1; v < 64 && nb < 6; ++v) {
        bool in_sp = false;
        for (int m = 0; m < (1 << nb); ++m) {
            int s = 0; for (int k = 0; k < nb; ++k) if ((m >> k) & 1) s ^= bas[k];
            if (s == v) { in_sp = true; break; }
        }
        if (!in_sp) bas[nb++] = v;
    }
    std::array<int, 64> perm{};
    for (int x = 0; x < 64; ++x) {
        int c = 0; for (int k = 0; k < 6; ++k) if ((x >> k) & 1) c ^= bas[k];
        perm[x] = c;
    }
    return perm;
}

// Type codes per point:
//   0: (2, 10)   [x=0]
//   1: (10, 2)   [x=+1]
//   2: (-6, -6)  [x=-1, m=1]
//   3: (2, -6)   [x=0, d2=1]
//   4: (-6, 2)   [x=-1, d1=1]
struct COpt { uint8_t t[4]; uint8_t m, k; };
static std::vector<COpt> make_coset_opts(bool is_caseA) {
    std::vector<COpt> out;
    // Normal m=0: (1,0,0,0) -> 4 opts
    for (int i = 0; i < 4; ++i) { COpt o{{0,0,0,0}, 0, 0}; o.t[i] = 1; out.push_back(o); }
    // Normal m=1: (-1,1,1,0) -> 12 opts
    for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) if (i != j) {
        COpt o{{1,1,1,1}, 1, 0}; o.t[i] = 2; o.t[j] = 0; out.push_back(o);
    }
    if (is_caseA) {
        // One x=0 replaced by type 3 (2, -6), k=1!
        // From m=0 (1,0,0,0): pick j != i -> 12 opts
        for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) if (i != j) {
            COpt o{{0,0,0,0}, 0, 1}; o.t[i] = 1; o.t[j] = 3; out.push_back(o);
        }
        // From m=1 (-1,1,1,0): replace the 0 by type 3 -> 12 opts
        for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) if (i != j) {
            COpt o{{1,1,1,1}, 1, 1}; o.t[i] = 2; o.t[j] = 3; out.push_back(o);
        }
    } else {
        // Case B: one x=-1 replaced by type 4 (-6, 2), k=1, m=0!
        // From (-1,1,1,0): replace -1 by type 4 -> 12 opts
        for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) if (i != j) {
            COpt o{{1,1,1,1}, 0, 1}; o.t[i] = 4; o.t[j] = 0; out.push_back(o);
        }
    }
    return out;
}

static void solve_case(const std::string& label, bool is_caseA) {
    auto t0 = std::chrono::steady_clock::now();
    uint64_t p01 = pmask(0x0025);
    auto perm = align_rad_low2(p01);
    int s0[64], s1[64];
    for (int x = 0; x < 64; ++x) {
        int c = perm[x], p0 = (p01 >> c) & 1, p1 = 1 ^ q6[c] ^ p0;
        s0[x] = p0 ? -1 : 1; s1[x] = p1 ? -1 : 1;
    }
    auto copts = make_coset_opts(is_caseA);
    static const int z0_v[5] = {2, 10, -6, 2, -6};
    static const int z1_v[5] = {10, 2, -6, -6, 2};

    struct Q8 { std::array<int8_t, 8> b0, b1; uint8_t m, k; };
    auto do_q8 = [&](int start, std::unordered_map<uint16_t, std::vector<Q8>>& out) {
        for (const auto& o0 : copts) for (const auto& o1 : copts) {
            if (o0.k + o1.k > 1) continue;
            std::array<int, 8> z0, z1;
            for (int u = 0; u < 4; ++u) {
                int c0 = start + u, c1 = start + 4 + u;
                z0[u] = z0_v[o0.t[u]] * s0[c0]; z1[u] = z1_v[o0.t[u]] * s1[c0];
                z0[4+u] = z0_v[o1.t[u]] * s0[c1]; z1[4+u] = z1_v[o1.t[u]] * s1[c1];
            }
            fwht8(z0); fwht8(z1);
            uint8_t p0 = 0, p1 = 0; std::array<int8_t, 8> b0, b1; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if ((z0[y] & 7) || (z1[y] & 7)) { ok = false; break; }
                int q0 = z0[y] >> 3, q1 = z1[y] >> 3;
                if (std::abs(q0) > 8 || std::abs(q1) > 8) { ok = false; break; }
                b0[y] = (int8_t)q0; b1[y] = (int8_t)q1;
                if (q0 & 1) p0 |= (uint8_t(1) << y); if (q1 & 1) p1 |= (uint8_t(1) << y);
            }
            if (ok) out[uint16_t(p0) | (uint16_t(p1) << 8)].push_back({b0, b1, uint8_t(o0.m+o1.m), uint8_t(o0.k+o1.k)});
        }
    };
    struct H16 { std::array<int8_t, 16> u0, u1; uint8_t m, k; };
    auto do_h16 = [&](int start, std::unordered_map<uint32_t, std::vector<H16>>& out) {
        std::unordered_map<uint16_t, std::vector<Q8>> q0, q1;
        do_q8(start, q0); do_q8(start + 8, q1);
        for (const auto& [p16, v0] : q0) {
            auto it = q1.find(p16); if (it == q1.end()) continue;
            for (const auto& a : v0) for (const auto& b : it->second) {
                if (a.k + b.k > 1 || a.m + b.m > 6) continue;
                std::array<int8_t, 16> u0, u1; uint16_t par0 = 0, par1 = 0; bool ok = true;
                for (int y = 0; y < 8; ++y) {
                    if (std::abs(a.b0[y]) + std::abs(b.b0[y]) > 8 || std::abs(a.b1[y]) + std::abs(b.b1[y]) > 8) { ok = false; break; }
                    int x0 = (a.b0[y] + b.b0[y]) >> 1, d0 = (a.b0[y] - b.b0[y]) >> 1;
                    int x1 = (a.b1[y] + b.b1[y]) >> 1, d1 = (a.b1[y] - b.b1[y]) >> 1;
                    u0[y] = (int8_t)x0; u0[8+y] = (int8_t)d0; u1[y] = (int8_t)x1; u1[8+y] = (int8_t)d1;
                    if (x0 & 1) par0 |= (uint16_t(1) << y); if (d0 & 1) par0 |= (uint16_t(1) << (8 + y));
                    if (x1 & 1) par1 |= (uint16_t(1) << y); if (d1 & 1) par1 |= (uint16_t(1) << (8 + y));
                }
                if (ok) out[uint32_t(par0) | (uint32_t(par1) << 16)].push_back({u0, u1, uint8_t(a.m+b.m), uint8_t(a.k+b.k)});
            }
        }
    };
    struct Half32 { uint32_t tw0, tw1; uint8_t m, k; };
    auto do_h32 = [&](int start, std::unordered_map<uint64_t, std::vector<Half32>>& out) {
        std::unordered_map<uint32_t, std::vector<H16>> g0, g1;
        do_h16(start, g0); do_h16(start + 16, g1);
        for (const auto& [par32, v0] : g0) {
            auto it = g1.find(par32); if (it == g1.end()) continue;
            for (const auto& a : v0) for (const auto& b : it->second) {
                if (a.k + b.k > 1 || a.m + b.m > 6) continue;
                uint32_t p0 = 0, p1 = 0, tw0 = 0, tw1 = 0; bool ok = true;
                for (int y = 0; y < 16; ++y) {
                    if (std::abs(a.u0[y]) + std::abs(b.u0[y]) > 4 || std::abs(a.u1[y]) + std::abs(b.u1[y]) > 4) { ok = false; break; }
                    int x0a = (a.u0[y] + b.u0[y]) >> 1, x0b = (a.u0[y] - b.u0[y]) >> 1;
                    int x1a = (a.u1[y] + b.u1[y]) >> 1, x1b = (a.u1[y] - b.u1[y]) >> 1;
                    if (x0a & 1) p0 |= (1u << y); if (x0b & 1) p0 |= (1u << (16 + y));
                    if (x1a & 1) p1 |= (1u << y); if (x1b & 1) p1 |= (1u << (16 + y));
                    if (std::abs(x0a) == 2) tw0 |= (1u << y); if (std::abs(x0b) == 2) tw0 |= (1u << (16 + y));
                    if (std::abs(x1a) == 2) tw1 |= (1u << y); if (std::abs(x1b) == 2) tw1 |= (1u << (16 + y));
                }
                if (ok) out[(uint64_t(p0) << 32) | uint64_t(p1)].push_back({tw0, tw1, uint8_t(a.m+b.m), uint8_t(a.k+b.k)});
            }
        }
    };
    std::unordered_map<uint64_t, std::vector<Half32>> h0, h1;
    do_h32(0, h0); do_h32(32, h1);
    long long hits = 0;
    for (const auto& [pk, v0] : h0) {
        auto it = h1.find(pk); if (it == h1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            if (a.m + b.m != 6 || a.k + b.k != 1) continue;
            if ((a.tw0 & b.tw0) || (a.tw1 & b.tw1)) continue;
            hits++;
        }
    }
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << ">>> RESULT " << label << " in " << dt << "s: HITS = " << hits << " <<<\n" << std::flush;
}

int main() {
    init();
    solve_case("II-B2 0x0025 Case A (d2=1, B=22, wt=40,60)", true);
    solve_case("II-B2 0x0025 Case B (d1=1, B=23, wt=42,58)", false);
    return 0;
}
