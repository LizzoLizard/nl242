// Exact autocorrelation mod-512 check on ALL 416 weight<=16 words of 1_H * q_6 + RM(2,6)
// for Branch I (L_{00} = 1_H) of (t = 100, r = 6, |Z| = 128, |D| = 16)!
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <unordered_map>
#include <vector>

static int q6[64];
static void fwht64(std::array<int, 64>& a) {
    for (int st = 1; st < 64; st *= 2)
        for (int i = 0; i < 64; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}

// Check if there exist signings sZ on U (all +-1) and sF on K (all +-2, or 0 if k_c!=1)
// such that WHT(sZ*1_U + 2*sF*1_K) == 0 (mod 8) AND WHT((-1)^q6 * (sZ*1_U - 2*sF*1_K)) == 0 (mod 8)!
// Equivalently:
//   Let hZ(c) = sZ(c)*1_{U cap Z6}(c) + 2*sF(c)*1_{K cap F6}(c)
//   Let hF(c) = sZ(c)*1_{U cap F6}(c) + 2*sF(c)*1_{K cap Z6}(c)  (WAIT! Check sign!)
//   Wait: h_+ = sZ 1_{U cap Z} + sZ 1_{U cap F} + 2 sF 1_{K cap Z} + 2 sF 1_{K cap F}
//         h_- = sZ 1_{U cap Z} - sZ 1_{U cap F} - 2 sF 1_{K cap Z} + 2 sF 1_{K cap F}
//   Notice: (h_+ + h_-)/2 = sZ 1_{U cap Z} + 2 sF 1_{K cap F}  (MUST be 0 mod 4 everywhere!)
//           (h_+ - h_-)/2 = sZ 1_{U cap F} + 2 sF 1_{K cap Z}  (MUST be 0 mod 4 everywhere!)
//   AND their (w / 4) mod 2 bitmasks MUST MATCH!
static long long count_signings(uint64_t u_mask, const std::vector<int>& K_pts) {
    std::vector<int> uZ, uF, kZ, kF;
    for (int c = 0; c < 64; ++c) if ((u_mask >> c) & 1) { if (q6[c] == 0) uZ.push_back(c); else uF.push_back(c); }
    for (int c : K_pts) { if (q6[c] == 0) kZ.push_back(c); else kF.push_back(c); }
    auto build_side = [&](const std::vector<int>& u_pts, const std::vector<int>& k_pts) {
        std::unordered_map<uint64_t, long long> mp;
        int nu = (int)u_pts.size(), nk = (int)k_pts.size();
        for (int km = 0; km < (1 << nk); ++km) {
            std::array<int, 64> base{};
            for (int j = 0; j < nk; ++j) base[k_pts[j]] += ((km >> j) & 1) ? -2 : 2;
            for (int um = 0; um < (1 << nu); ++um) {
                auto v = base;
                for (int i = 0; i < nu; ++i) v[u_pts[i]] += ((um >> i) & 1) ? -1 : 1;
                fwht64(v);
                uint64_t pat = 0; bool ok = true;
                for (int y = 0; y < 64; ++y) {
                    if (v[y] & 3) { ok = false; break; }
                    if ((v[y] >> 2) & 1) pat |= (1ULL << y);
                }
                if (ok) mp[pat]++;
            }
        }
        return mp;
    };
    auto m1 = build_side(uZ, kF); if (m1.empty()) return 0;
    auto m2 = build_side(uF, kZ); if (m2.empty()) return 0;
    long long tot = 0;
    for (const auto& [pat, c1] : m1) {
        auto it = m2.find(pat); if (it != m2.end()) tot += c1 * it->second;
    }
    return tot;
}

int main() {
    for (int c = 0; c < 64; ++c)
        q6[c] = ((c & 1) & ((c >> 1) & 1)) ^ (((c >> 2) & 1) & ((c >> 3) & 1)) ^ (((c >> 4) & 1) & ((c >> 5) & 1));
    uint32_t mons5[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0; for (int x = 0; x < 32; ++x) if ((x & m) == m) mask |= (1u << x);
        mons5[mk++] = mask;
    }
    std::vector<uint32_t> rm25(65536, 0);
    for (int s = 1; s < 65536; ++s) rm25[s] = rm25[s ^ (1 << __builtin_ctz(s))] ^ mons5[__builtin_ctz(s)];
    std::vector<uint32_t> lmons;
    for (int i = 0; i < 16; ++i) { int w = __builtin_popcount(mons5[i]); if (w == 16 || w == 32) lmons.push_back(mons5[i]); }
    std::vector<uint32_t> lin5(64, 0);
    for (int s = 1; s < 64; ++s) lin5[s] = lin5[s ^ (1 << __builtin_ctz(s))] ^ lmons[__builtin_ctz(s)];
    uint32_t q6_H = 0; for (int x = 0; x < 32; ++x) if (q6[(x << 1) | 1]) q6_H |= (1u << x);

    std::vector<uint64_t> w12, w16;
    for (uint32_t g0 : rm25) {
        int c0 = __builtin_popcount(g0); if (c0 > 16) continue;
        uint32_t b1 = q6_H ^ g0;
        for (uint32_t L : lin5) {
            uint32_t u1 = b1 ^ L; int c1 = __builtin_popcount(u1);
            if (c0 + c1 != 12 && c0 + c1 != 16) continue;
            uint64_t u = 0;
            for (int x = 0; x < 32; ++x) {
                if ((g0 >> x) & 1) u |= (1ULL << (2 * x));
                if ((u1 >> x) & 1) u |= (1ULL << (2 * x + 1));
            }
            if (c0 + c1 == 12) w12.push_back(u); else w16.push_back(u);
        }
    }

    int surv16_0010 = 0, surv16_all = 0;
    for (uint64_t u : w16) {
        std::array<int, 64> v0{}, v1{};
        for (int c = 0; c < 64; ++c) { v0[c] = (u >> c) & 1; v1[c] = (q6[c] ? -1 : 1) * v0[c]; }
        fwht64(v0); fwht64(v1);
        bool ok = true;
        for (int y = 0; y < 64; ++y) {
            if (y && (v0[y] & 7)) { ok = false; break; }
            if ((v1[y] & 7) != 4) { ok = false; break; }
        }
        if (!ok) continue;
        surv16_0010++;
        if (count_signings(u, {}) > 0) surv16_all++;
    }
    std::cout << "wt-16: pass (00,10)=" << surv16_0010 << ", pass ALL 4 mod-512=" << surv16_all << "\n";

    int surv12_0010 = 0, surv12_all = 0;
    std::map<std::tuple<int, int, int>, int> cls12;
    for (uint64_t u : w12) {
        std::array<int, 64> v0{}, v1{};
        for (int c = 0; c < 64; ++c) { v0[c] = (u >> c) & 1; v1[c] = (q6[c] ? -1 : 1) * v0[c]; }
        fwht64(v0); fwht64(v1);
        for (int c1 = 0; c1 < 64; ++c1) {
            int s1 = q6[c1] ? -1 : 1;
            for (int t1 = 0; t1 < 2; ++t1) {
                if (t1 == 0 && ((u >> c1) & 1)) continue;
                int d1_1 = (t1 == 0) ? 2 * s1 : -2 * s1;
                for (int c2 = c1; c2 < 64; ++c2) {
                    int s2 = q6[c2] ? -1 : 1;
                    for (int t2 = 0; t2 < 2; ++t2) {
                        if (c2 == c1 && t2 < t1) continue;
                        if (t2 == 0 && ((u >> c2) & 1)) continue;
                        if (c2 == c1 && t1 == 0 && t2 == 0) continue;
                        int d2_1 = (t2 == 0) ? 2 * s2 : -2 * s2;
                        bool ok = true;
                        for (int y = 0; y < 64; ++y) {
                            int p1 = __builtin_parity(y & c1) ? -1 : 1;
                            int p2 = __builtin_parity(y & c2) ? -1 : 1;
                            if (y && ((v0[y] + 2*p1 + 2*p2) & 7) != 0) { ok = false; break; }
                            if (((v1[y] + d1_1*p1 + d2_1*p2) & 7) != 4) { ok = false; break; }
                        }
                        if (!ok) continue;
                        surv12_0010++;
                        std::vector<int> K;
                        if (c1 == c2 && t1 == 1 && t2 == 1) { /* k2=1 => k1=0! */ }
                        else {
                            if (t1 == 1) K.push_back(c1);
                            if (t2 == 1) K.push_back(c2);
                        }
                        long long ns = count_signings(u, K);
                        if (ns > 0) {
                            surv12_all++;
                            int m0 = (t1 == 0) + (t2 == 0);
                            int k1 = (int)K.size();
                            int k2 = (c1 == c2 && t1 == 1 && t2 == 1) ? 1 : 0;
                            cls12[{m0, k1, k2}]++;
                        }
                    }
                }
            }
        }
    }
    std::cout << "wt-12: pass (00,10)=" << surv12_0010 << ", pass ALL 4 mod-512=" << surv12_all << "\n";
    for (const auto& [k, v] : cls12)
        std::cout << "  (m0=" << std::get<0>(k) << ", k1=" << std::get<1>(k) << ", k2=" << std::get<2>(k) << "): " << v << "\n";
    return 0;
}
