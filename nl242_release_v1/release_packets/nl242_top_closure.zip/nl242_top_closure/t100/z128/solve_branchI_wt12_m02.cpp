// COMPLETE EXACT SOLVER for ALL 4 wt-12 (m0=2, k1=0) orbits of Branch I (L00=1_H, t=100, r=6, |Z|=128)!
// Step 1: Enumerate ALL (p_self in RM(2,6), p_other|_{L1} in RM(2,5)) passing 22-bit 6-var deg456(A) == 0!
//         Notice: shifting v_self(y) -> +-v_self(y ^ y0) preserves p_self|_{L0} AND shifts p_self|_{L1} by ANY affine L in RM(1,5)!
//         Wait: let's check ALL 2,048 p_self without even modding by RM(1,5) — only 2,048!
//         Actually, even simpler: each (p_self, p_other|_{L1}) uniquely fixes (z00, z10) options to <= 2 per point on ALL 64 pts!
//         WAIT: check! For fixed (p00, p01|_H), we can immediately run exact 32+32 half-join on (z00, z10) SIMULTANEOUSLY!
//         Even better: FIRST check the L=0 half (H^c for orb0,3; H for orb5,7) for p_self — remember ONLY 512 p_self|_{L0} survive!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <thread>
#include <unordered_map>
#include <vector>

static int q6[64];
static inline void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static uint32_t deg456_bits6(uint64_t f) {
    uint8_t a[64];
    for (int i = 0; i < 64; ++i) a[i] = (f >> i) & 1;
    for (int b = 0; b < 6; ++b)
        for (int i = 0; i < 64; ++i) if (i & (1 << b)) a[i] ^= a[i ^ (1 << b)];
    uint32_t out = 0; int k = 0;
    for (int i = 0; i < 64; ++i) if (__builtin_popcount(i) >= 4) { if (a[i]) out |= (1u << k); k++; }
    return out;
}
static bool base_syndrome6(const std::array<int, 64>& Abase, uint32_t& out_syn) {
    out_syn = 0; int k = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) >= 4) {
        int s = 0;
        for (int c = 0; c < 64; ++c) if ((c & ~m) == 0) s += Abase[c];
        if (s & 7) return false;
        if (s & 8) out_syn |= (1u << k);
        k++;
    }
    return true;
}

// Valid (z0, z1) pairs on L=0 half (given q, dc, p_self) AND on L=1 half (given q, dc, p_self, p_other) for kc=0!
static std::vector<std::pair<int8_t, int8_t>> opts_L0[2][3][2];    // [q][dc][p_self]
static std::vector<std::pair<int8_t, int8_t>> opts_L1[2][3][2][2]; // [q][dc][p_self][p_other]

static void init_opts() {
    for (int c = 0; c < 64; ++c)
        q6[c] = ((c & 1) & ((c >> 1) & 1)) ^ (((c >> 2) & 1) & ((c >> 3) & 1)) ^ (((c >> 4) & 1) & ((c >> 5) & 1));
    for (int q = 0; q < 2; ++q) {
        std::vector<int> w0s = (q == 0) ? std::vector<int>{-8, 0, 8} : std::vector<int>{-12, -4, 4, 12};
        std::vector<int> w1s = (q == 0) ? std::vector<int>{-12, -4, 4, 12} : std::vector<int>{-8, 0, 8};
        for (int v00 : w0s) for (int v01 : w0s) for (int v10 : w1s) for (int v11 : w1s) {
            int dc = (q == 0) ? ((v00 == 0) + (v01 == 0)) : ((v10 == 0) + (v11 == 0));
            int kc = (q == 0) ? ((std::abs(v10) == 4) + (std::abs(v11) == 4)) : ((std::abs(v00) == 4) + (std::abs(v01) == 4));
            if (kc != 0) continue;
            int A = (v00 + v01) / 2, C = (v00 - v01) / 2;
            int B = (v10 + v11) / 2, D = (v10 - v11) / 2;
            int z0 = (A + B) / 2, z1 = (A - B) / 2, z2 = (C + D) / 2;
            auto pr = std::make_pair((int8_t)z0, (int8_t)z1);
            if ((z0 & 3) == 0 && (z1 & 3) == 0) {
                int p0 = (z0 >> 2) & 1;
                auto& vec = opts_L0[q][dc][p0];
                if (std::find(vec.begin(), vec.end(), pr) == vec.end()) vec.push_back(pr);
            } else if ((z0 & 3) == 2 && (z1 & 3) == 2) {
                int p0 = ((z0 - 2) >> 2) & 1;
                int po = (z2 >> 2) & 1;
                auto& vec = opts_L1[q][dc][p0][po];
                if (std::find(vec.begin(), vec.end(), pr) == vec.end()) vec.push_back(pr);
            }
        }
    }
    // Check max option sizes!
    int mx0 = 0, mx1 = 0;
    for (int q = 0; q < 2; ++q) for (int d = 0; d < 3; ++d) for (int p0 = 0; p0 < 2; ++p0) {
        mx0 = std::max(mx0, (int)opts_L0[q][d][p0].size());
        for (int po = 0; po < 2; ++po) mx1 = std::max(mx1, (int)opts_L1[q][d][p0][po].size());
    }
    std::cout << "[OK] opts_L0 max=" << mx0 << ", opts_L1 max=" << mx1 << "\n";
}

// Exact 32-pt half collection for a PAIR (z0, z1) simultaneously!
// Returns map keyed by (p32_0, p32_1) -> vector of (tw0, tw1, min_e2_sum)
struct PairHalf { uint32_t tw0, tw1; int e2_sum; };
using PairMap = std::unordered_map<uint64_t, std::vector<PairHalf>>;

struct Q8 { std::array<int8_t, 8> b0, b1; };
static void enum_q8(int start, int j, std::array<int, 8>& z0, std::array<int, 8>& z1,
                    const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                    std::unordered_map<uint16_t, std::vector<Q8>>& out) {
    if (j == 8) {
        auto u0 = z0, u1 = z1; fwht8(u0); fwht8(u1);
        uint8_t p0 = 0, p1 = 0; std::array<int8_t, 8> b0, b1;
        for (int y = 0; y < 8; ++y) {
            if ((u0[y] & 7) || (u1[y] & 7)) return;
            int q0 = u0[y] >> 3, q1 = u1[y] >> 3;
            if (std::abs(q0) > 8 || std::abs(q1) > 8) return;
            b0[y] = (int8_t)q0; b1[y] = (int8_t)q1;
            if (q0 & 1) p0 |= (uint8_t(1) << y);
            if (q1 & 1) p1 |= (uint8_t(1) << y);
        }
        out[uint16_t(p0) | (uint16_t(p1) << 8)].push_back({b0, b1});
        return;
    }
    for (auto [v0, v1] : opts[start + j]) { z0[j] = v0; z1[j] = v1; enum_q8(start, j + 1, z0, z1, opts, out); }
}
struct H16 { std::array<int8_t, 16> u0, u1; };
static void enum_h16(int start, const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                     std::unordered_map<uint32_t, std::vector<H16>>& out) {
    std::unordered_map<uint16_t, std::vector<Q8>> q0, q1;
    std::array<int, 8> t0{}, t1{};
    enum_q8(start, 0, t0, t1, opts, q0); if (q0.empty()) return;
    enum_q8(start + 8, 0, t0, t1, opts, q1); if (q1.empty()) return;
    for (const auto& [p16, v0] : q0) {
        auto it = q1.find(p16); if (it == q1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            std::array<int8_t, 16> u0, u1; uint16_t par0 = 0, par1 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a.b0[y]) + std::abs(b.b0[y]) > 8 || std::abs(a.b1[y]) + std::abs(b.b1[y]) > 8) { ok = false; break; }
                int s0 = (a.b0[y] + b.b0[y]) >> 1, d0 = (a.b0[y] - b.b0[y]) >> 1;
                int s1 = (a.b1[y] + b.b1[y]) >> 1, d1 = (a.b1[y] - b.b1[y]) >> 1;
                u0[y] = (int8_t)s0; u0[8+y] = (int8_t)d0; u1[y] = (int8_t)s1; u1[8+y] = (int8_t)d1;
                if (s0 & 1) par0 |= (uint16_t(1) << y); if (d0 & 1) par0 |= (uint16_t(1) << (8 + y));
                if (s1 & 1) par1 |= (uint16_t(1) << y); if (d1 & 1) par1 |= (uint16_t(1) << (8 + y));
            }
            if (ok) out[uint32_t(par0) | (uint32_t(par1) << 16)].push_back({u0, u1});
        }
    }
}
static void collect_pair_half(const std::array<std::vector<std::pair<int8_t, int8_t>>, 32>& opts,
                              const PairMap* filter, PairMap& out) {
    out.clear();
    std::unordered_map<uint32_t, std::vector<H16>> g0, g1;
    enum_h16(0, opts, g0); if (g0.empty()) return;
    enum_h16(16, opts, g1); if (g1.empty()) return;
    for (const auto& [par32, v0] : g0) {
        auto it = g1.find(par32); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p0 = 0, p1 = 0, tw0 = 0, tw1 = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u0[y]) + std::abs(b.u0[y]) > 4 || std::abs(a.u1[y]) + std::abs(b.u1[y]) > 4) { ok = false; break; }
                int x0a = (a.u0[y] + b.u0[y]) >> 1, x0b = (a.u0[y] - b.u0[y]) >> 1;
                int x1a = (a.u1[y] + b.u1[y]) >> 1, x1b = (a.u1[y] - b.u1[y]) >> 1;
                e2 += x0a*x0a + x0b*x0b + x1a*x1a + x1b*x1b;
                if (x0a & 1) p0 |= (1u << y); if (x0b & 1) p0 |= (1u << (16 + y));
                if (x1a & 1) p1 |= (1u << y); if (x1b & 1) p1 |= (1u << (16 + y));
                if (std::abs(x0a) == 2) tw0 |= (1u << y); if (std::abs(x0b) == 2) tw0 |= (1u << (16 + y));
                if (std::abs(x1a) == 2) tw1 |= (1u << y); if (std::abs(x1b) == 2) tw1 |= (1u << (16 + y));
            }
            if (!ok) continue;
            uint64_t pk = (uint64_t(p0) << 32) | uint64_t(p1);
            if (filter && !filter->count(pk)) continue;
            auto& vec = out[pk];
            // Dedup by (tw0, tw1) keeping min e2!
            bool found = false;
            for (auto& e : vec) if (e.tw0 == tw0 && e.tw1 == tw1) { e.e2_sum = std::min(e.e2_sum, e2); found = true; break; }
            if (!found) vec.push_back({tw0, tw1, e2});
        }
    }
}

int main() {
    auto t0 = std::chrono::steady_clock::now();
    init_opts();
    uint64_t mons6[22]; int mk = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) <= 2) {
        uint64_t mask = 0; for (int c = 0; c < 64; ++c) if ((c & m) == m) mask |= (1ULL << c);
        mons6[mk++] = mask;
    }
    uint32_t mons5[16]; mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0; for (int x = 0; x < 32; ++x) if ((x & m) == m) mask |= (1u << x);
        mons5[mk++] = mask;
    }
    std::vector<uint32_t> rm25(65536, 0);
    for (int s = 1; s < 65536; ++s) rm25[s] = rm25[s ^ (1 << __builtin_ctz(s))] ^ mons5[__builtin_ctz(s)];

    struct Job { std::string name; uint64_t u, m0; int L1_bit; };
    std::vector<Job> jobs = {
        {"wt12_orb0(m0=2)", 0x0aaaa000a000a000ULL, 0x5ULL, 1},
        {"wt12_orb3(m0=2)", 0x0aaaa000a000a000ULL, 0x5000ULL, 1},
        {"wt12_orb5(m0=2)", 0x0555500050005000ULL, 0xaULL, 0},
        {"wt12_orb7(m0=2)", 0x5505005000500050ULL, 0xaULL, 0},
    };

    for (const auto& jb : jobs) {
        int L1 = jb.L1_bit, L0 = 1 - L1;
        std::array<int, 64> Abase{};
        uint64_t M_self = 0, M_other = 0, self_zero_req = 0, other_zero_req = 0;
        for (int c = 0; c < 64; ++c) {
            int q = q6[c], dc = ((jb.u >> c) & 1) + 2 * ((jb.m0 >> c) & 1);
            if ((c & 1) == L0) {
                if (dc == 0) { if (q == 0) M_self |= (1ULL << c); }
                else if (dc == 2) self_zero_req |= (1ULL << c);
            } else {
                if (dc == 0) { Abase[c] = (q == 0) ? 8 : 12; M_other |= (1ULL << c); if (q == 1) M_self |= (1ULL << c); }
                else if (dc == 1) { Abase[c] = (q == 0) ? 4 : 0; if (q == 0) M_self |= (1ULL << c); }
                else { other_zero_req |= (1ULL << c); Abase[c] = (q == 0) ? 0 : 4; if (q == 1) M_self |= (1ULL << c); }
            }
        }
        uint32_t tgt22 = 0;
        base_syndrome6(Abase, tgt22);

        std::unordered_map<uint32_t, std::vector<uint32_t>> other_by_syn;
        for (uint32_t p5 : rm25) {
            uint64_t emb = 0;
            for (int i = 0; i < 32; ++i) if ((p5 >> i) & 1) emb |= (1ULL << (2 * i + L1));
            if (emb & other_zero_req) continue;
            other_by_syn[deg456_bits6(M_other & emb)].push_back(p5);
        }

        // Collect all 2,048 matching p_self, grouped by p_self|_{L0}!!
        uint32_t bas[22];
        for (int b = 0; b < 22; ++b) bas[b] = deg456_bits6(M_self & mons6[b]);
        struct CandP { uint64_t p_self; uint32_t p0_L0, p0_L1, syn_other; };
        std::unordered_map<uint32_t, std::vector<CandP>> by_L0;
        uint32_t cur_syn = 0; uint64_t cur_p = 0;
        for (uint32_t s = 0; s < (1u << 22); ++s) {
            if (s > 0) { int b = __builtin_ctz(s); cur_syn ^= bas[b]; cur_p ^= mons6[b]; }
            if (cur_p & self_zero_req) continue;
            uint32_t need = cur_syn ^ tgt22;
            if (!other_by_syn.count(need)) continue;
            uint32_t pL0 = 0, pL1 = 0;
            for (int i = 0; i < 32; ++i) {
                if ((cur_p >> (2*i + L0)) & 1) pL0 |= (1u << i);
                if ((cur_p >> (2*i + L1)) & 1) pL1 |= (1u << i);
            }
            by_L0[pL0].push_back({cur_p, pL0, pL1, need});
        }
        std::cout << jb.name << ": distinct p_self|_{L0} = " << by_L0.size() << "\n" << std::flush;

        // Test EVERY (p_self, p_other|_{L1}) with exact 32+32 half-join on (z0, z1)!
        std::vector<uint32_t> L0_keys;
        for (const auto& [k, _] : by_L0) L0_keys.push_back(k);
        std::atomic<size_t> ki{0};
        std::atomic<long long> L0_pass{0}, full_joins{0};
        std::atomic<int> min_wpair{999};
        std::vector<std::thread> ths;
        for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&]() {
            while (true) {
                size_t idx = ki.fetch_add(1); if (idx >= L0_keys.size()) break;
                uint32_t pL0 = L0_keys[idx];
                std::array<std::vector<std::pair<int8_t, int8_t>>, 32> o0;
                bool ok = true;
                for (int i = 0; i < 32; ++i) {
                    int c = 2 * i + L0, dc = ((jb.u >> c) & 1) + 2 * ((jb.m0 >> c) & 1);
                    o0[i] = opts_L0[q6[c]][dc][(pL0 >> i) & 1];
                    if (o0[i].empty()) { ok = false; break; }
                }
                if (!ok) continue;
                PairMap m0; collect_pair_half(o0, nullptr, m0);
                if (m0.empty()) continue;
                L0_pass.fetch_add(1);
                for (const auto& cp : by_L0.at(pL0)) {
                    for (uint32_t po : other_by_syn.at(cp.syn_other)) {
                        std::array<std::vector<std::pair<int8_t, int8_t>>, 32> o1;
                        bool ok1 = true;
                        for (int i = 0; i < 32; ++i) {
                            int c = 2 * i + L1, dc = ((jb.u >> c) & 1) + 2 * ((jb.m0 >> c) & 1);
                            o1[i] = opts_L1[q6[c]][dc][(cp.p0_L1 >> i) & 1][(po >> i) & 1];
                            if (o1[i].empty()) { ok1 = false; break; }
                        }
                        if (!ok1) continue;
                        PairMap m1; collect_pair_half(o1, &m0, m1);
                        for (const auto& [pk, v1] : m1) {
                            const auto& v0 = m0.at(pk);
                            for (const auto& a : v0) for (const auto& b : v1) {
                                if ((a.tw0 & b.tw0) || (a.tw1 & b.tw1)) continue;
                                int w = (a.e2_sum + b.e2_sum) / 2;
                                full_joins.fetch_add(1);
                                int prev = min_wpair.load();
                                while (w < prev && !min_wpair.compare_exchange_weak(prev, w)) {}
                            }
                        }
                    }
                }
            }
        });
        for (auto& th : ths) th.join();
        std::cout << "  >>> " << jb.name << ": L0_pass=" << L0_pass.load()
                  << " FULL_32x32_PAIR_JOINS=" << full_joins.load()
                  << " min_wpair=" << min_wpair.load() << " <<<\n" << std::flush;
    }
    std::cout << "DONE in " << std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count() << "s\n";
    return 0;
}
