# Balanced 9-Variable `NL = 242` Top-Down Closure Packet (`t ≥ 100`, plus `t = 84`)

This self-contained verification bundle collects all proof narratives, exact integer/rational verifiers, positive controls, and exact orbit/certificate data closing the **top half** of the balanced 9-variable `NL = 242` Boolean function impossibility proof:

- **`t = 100`** (`r = 6, |Z| ∈ {112, 128, 144}` and `r = 8, |Z| ∈ {120, 136}`; `r ≤ 4` has 0 open systems)
- **`t = 102`** (`r = 6, |Z| ∈ {112, 128, 144}` and `r = 8, |Z| ∈ {120, 136}`)
- **`t ≥ 104`** (`t = 104, 106, 110, 112, 118+`, mod-7 range lemma, plus `t = 84`)

Together with the bottom-up high-block closure packets (`t ≤ 98`, culminating in `nl242_t98_closure.zip`), this completes the proof that **no balanced 9-variable Boolean function has nonlinearity `NL = 242`** (`NL_bal(9) = 240`).

All source paths in this packet are strictly relative and portable (zero hardcoded machine paths).

**Computer-assisted.** Most cases here are closed by exhaustive computer checks. The correctness of this packet therefore includes the correctness of its code, which is why every verifier ships as source. All `t = 100` rank-6 structural reductions are written out in full in the companion note `t100.tex` and summarized with the complete audit record in `proofs/PROOF_t100_RANK6.md`.

---

## Directory Structure

```text
nl242_top_closure/
├── README.md                  # This file
├── SHA256SUMS                 # SHA-256 manifest of all 104 payload files in this bundle
├── verify_quick.sh            # Fast end-to-end exact rational/integer + rank-6 audit replay
├── proofs/                    # Proof writeups (PROOF_t100_CLOSED.md, PROOF_t100_RANK6.md, PROOF_t102_CLOSED.md, ...)
├── t100/
│   ├── r8/                    # (t=100, r=8, |Z|=120): exact rational proofs + zero-LP exact y_Z verifiers
│   ├── z128/                  # (t=100, r=6, |Z|=128): 11 exact C++ verifiers (incl. verify_z128_reductions.cpp)
│   └── z112/                  # (t=100, r=6, |Z|=112): master verify_z112_all45_exact.cpp, check_small_masks.cpp, 13 legacy scripts + shapes/
├── t102/
│   ├── verify_t102_r8_closed.cpp
│   ├── verify_t102_z128_closed.py
│   └── z112/                  # (t=102, r=6, |Z|=112): 24 exact C++ verifiers + real_V_t102_orb1.txt
└── t104_plus/                 # Exact verifiers + JSON Farkas certificates for t=84, 104, 106, 110, 112, 118+
```

---

## Requirements

- C++17 / C++20 compiler (`g++` or `clang++` with `-pthread`)
- Python 3.9+ with `numpy` and `scipy` (used only to generate candidate dual rays before verification in **exact arbitrary-precision `fractions.Fraction` / Python `int` arithmetic**; `verify_t110_closed.py`, `verify_t112_closed.py`, `verify_t102_z128_closed.py`, `verify_t84_closed.py`, and all C++ verifiers use zero floating-point arithmetic).

---

## Quick Verification (`~1–2 min`)

Run from the root of this extracted bundle:

```sh
shasum -a 256 -c SHA256SUMS
bash verify_quick.sh
```

`verify_quick.sh` checks:
1. **`t = 100, r = 8` exact rational foundations & positive controls:**
   - `verify_h64_w_ge_6_exact.py`: proves `H_64 w >= 6` (`0` valid 2-sets, exact `Fraction` dual `min n_8^(1) >= 8` on both `Stab(e_7)` orbits of `5,376` valid 4-sets).
   - `verify_delsarte_farkas_exact.py`: verifies all `11/11` Signed `(Q^*, v)`-Weighted Delsarte Farkas certificates in exact `Fraction` arithmetic + `QR(17)` feasibility positive control.
   - `verify_qr17_t100_standalone.cpp`: `QR(17)` `t = 102` positive control + `t = 100` exact closure across all `53,550` XOR-0 `S_8` 4-subsets (`REAL_V = 0`).
   - `audit_n14_n16_exact.cpp`: individual exact integer dual verification of all `32/32` (`n_0 = 14`) and `4,124/4,124` (`n_0 = 16`) RREF reps (`min_margin >= +160`).
   - `test_sym_nonempty.cpp`: non-empty `sym = 0` vs `sym ∈ {1, 2, 3}` exact match across all 5 nonzero `v`-orbit reps of `H_56 w = 2`.
   - `audit_n18_n20_exact_orbits.cpp` + `certify_exact_o8_orbs_L1.py`: explicit 256-point verified `O^-(8,2)` isomorphism reduction (`5` orbits at `n_0 = 18`, `342` orbits at `n_0 = 20`) + exact rational `L_1 + L_∞` dual certification of all `347/347` orbits + `QR(17)` positive control (`6,528.00 = 64 * 102`).
2. **`t = 100, r = 6` audited reductions & complete all-45 `(h, p)` closure:**
   - `t100/z128/verify_z128_reductions.cpp` (`~0.2s`): verifies all 288 local group laws, regenerates all 11 Branch I orbits under `G_lit`, verifies all 2,604 affine 4-flats of Branch II-A, checks the Branch II-B Gram identity and `Sp(6,2)` orbits `0x0025`/`0x0028`/`0x02b4` across all 32,768 quadratic forms, confirms 0 arithmetic solutions for II-B2 and II-B3 under the Zero-Set Rank Bound, and regenerates all 10 Branch II-B4 isotropic-plane orbits (`5,040/5,040`).
   - `t100/z112/check_small_masks.cpp` (`~8s`): exhaustively excludes `9 <= k <= 15` at `t ∈ {94, 96, 98, 100}` (`0` survivors), proving `h = 32 - k <= 16`.
   - `t100/z112/verify_z112_all45_exact.cpp` (`~25s`): passes 7 mandatory positive controls (`PC1`–`PC7`), scans all 45 `(h, p)` pairs (`302` level hits `-> 175` dead by exact `2*` `check_v0` `+ 16` dead by `H_5 m_2` `-> 111` live), and kills all `111/111` live cases (`0` survivors), closing three bugs/omissions caught in the earlier `t100/z112/` scripts.
3. **`t = 102` & `t ≥ 104` pure-integer verifiers:**
   - `t102/verify_t102_r8_closed.cpp` (`~23s`, full `t = 102, r = 8` closure from scratch)
   - `t102/verify_t102_z128_closed.py`
   - `t104_plus/verify_t84_closed.py`, `verify_t106_closed.py`, `verify_t110_closed.py`, `verify_t112_closed.py`

---

## Full Heavy Re-Enumeration Commands for `(t = 100, r = 8)`

Run inside `t100/r8/`:

```sh
# 1. Regenerate all exact Stab hyperplane & v-orbit tables from scratch (~10s):
g++ -O3 -std=c++17 exact_H_orbits.cpp -o /tmp/exact_H_orbits && /tmp/exact_H_orbits
g++ -O3 -std=c++17 compute_v_orbits.cpp -o /tmp/compute_v_orbits && /tmp/compute_v_orbits
g++ -O3 -std=c++17 compute_v_orbits_H64_w6.cpp -o /tmp/compute_v_orbits_H64_w6 && /tmp/compute_v_orbits_H64_w6

# 2. n_0 = 26 (n_8 = 0, v = 0) exact code-by-code closure (~55s total):
g++ -O3 -std=c++17 -pthread solve_n26_v0_turbo.cpp -o /tmp/solve_n26_v0_turbo && /tmp/solve_n26_v0_turbo
g++ -O3 -std=c++17 -pthread exact_H64_w8_and_n26_d8.cpp -o /tmp/exact_H64_w8_and_n26_d8 && /tmp/exact_H64_w8_and_n26_d8

# 3. n_0 = 22 (n_8 = 2, v != 0) exact O^-(8,2)-reduced 36-pair + y_Z closure (~102s total):
g++ -O3 -std=c++17 -pthread solve_n22_o8_exact.cpp -o /tmp/solve_n22_o8_exact && /tmp/solve_n22_o8_exact

# 4. n_0 = 24 (n_8 = 1, Q(v) = 1) exact code-by-code y_Z closure (~19 min on 8 threads):
g++ -O3 -std=c++17 -pthread solve_n24_exact.cpp -o /tmp/solve_n24_exact && /tmp/solve_n24_exact
```

All `(t = 100, r = 6)` verifiers in `t100/z128/` and `t100/z112/` and `(t = 102, r = 6, |Z| = 112)` verifiers in `t102/z112/` compile cleanly with `g++ -O3 -std=c++17 -pthread <file>.cpp` and run directly inside their respective directories.
