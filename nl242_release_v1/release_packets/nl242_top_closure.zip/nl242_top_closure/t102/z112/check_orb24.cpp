#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static uint64_t Zmask = 0, Fmask = 0;
static int perm64[63][64];

static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
        if (Q64[x] == 0) Zmask |= (1ULL << x);
        else Fmask |= (1ULL << x);
    }
    for (int v = 1; v < 64; ++v) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        for (int x = 0; x < 64; ++x)
            perm64[v - 1][x] = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
    }
}
static inline uint64_t apply_p64(uint64_t w, const int* p) {
    uint64_t out = 0;
    while (w) { int i = __builtin_ctzll(w); out |= (1ULL << p[i]); w &= w - 1; }
    return out;
}
static inline void fwht16(std::array<int, 16>& a) {
    for (int step = 1; step < 16; step *= 2)
        for (int i = 0; i < 16; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}

using Slice = std::array<int, 16>;
using Opts64 = std::array<std::vector<int>, 64>;

struct SliceM { Slice u; uint64_t e8; };
static void enum16_m(const int idx[16], int j, Slice& z, uint64_t e8, const Opts64& opts,
                     std::map<uint16_t, std::vector<SliceM>>& out) {
    if (j < 16) {
        int c = idx[j];
        for (int v : opts[c]) {
            z[j] = v;
            enum16_m(idx, j + 1, z, (std::abs(v) == 2) ? (e8 | (1ULL << c)) : e8, opts, out);
        }
        return;
    }
    Slice u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 3) return;
        int q = u[y] >> 2;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back({u, e8});
}

struct PairM { uint16_t par = 0, s2 = 0, d2 = 0; uint64_t e8 = 0; };
static inline bool make_pairM(const SliceM& a, const SliceM& b, PairM& p) {
    p.par = p.s2 = p.d2 = 0; p.e8 = a.e8 | b.e8;
    for (int y = 0; y < 16; ++y) {
        int s = (a.u[y] + b.u[y]) >> 1, d = (a.u[y] - b.u[y]) >> 1;
        if (std::abs(s) > 2 || std::abs(d) > 2) return false;
        if (s & 1) p.par |= (uint16_t(1) << y);
        if (std::abs(s) == 2) p.s2 |= (uint16_t(1) << y);
        if (std::abs(d) == 2) p.d2 |= (uint16_t(1) << y);
    }
    return true;
}

static std::set<uint64_t> collect_e8(Opts64 opts) {
    std::set<uint64_t> res;
    std::array<int, 7> pivots{};
    for (int c = 0; c < 64; ++c) {
        auto& ent = opts[c];
        if (std::find(ent.begin(), ent.end(), 0) != ent.end() || ent.size() <= 1) continue;
        int col = 64 | c;
        for (int i = 6; i >= 0; --i) if ((col >> i) & 1) {
            if (pivots[i]) col ^= pivots[i];
            else {
                pivots[i] = col;
                ent.erase(std::remove_if(ent.begin(), ent.end(), [](int v){ return v < 0; }), ent.end());
                break;
            }
        }
    }
    long long best_cost = (1LL << 60); int b0 = 5, b1 = 4;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        long long prod[4] = {1, 1, 1, 1};
        for (int c = 0; c < 64; ++c) prod[(((c>>i)&1)<<1)|((c>>j)&1)] *= (long long)opts[c].size();
        if (prod[0]+prod[1]+prod[2]+prod[3] < best_cost) { best_cost = prod[0]+prod[1]+prod[2]+prod[3]; b0 = i; b1 = j; }
    }
    int rem[4], rk = 0;
    for (int b = 0; b < 6; ++b) if (b != b0 && b != b1) rem[rk++] = b;
    int sl[4][16];
    for (int q = 0; q < 4; ++q)
        for (int r = 0; r < 16; ++r) {
            int c = (((q >> 1) & 1) << b0) | ((q & 1) << b1);
            for (int j = 0; j < 4; ++j) if ((r >> j) & 1) c |= (1 << rem[j]);
            sl[q][r] = c;
        }
    std::array<std::map<uint16_t, std::vector<SliceM>>, 4> grp;
    for (int q = 0; q < 4; ++q) {
        Slice f{}; enum16_m(sl[q], 0, f, 0ULL, opts, grp[q]);
        if (grp[q].empty()) return {};
    }
    int min_q = 0;
    for (int q = 1; q < 4; ++q) if (grp[q].size() < grp[min_q].size()) min_q = q;
    for (const auto& [k, _] : grp[min_q]) {
        std::array<const std::vector<SliceM>*, 4> g{};
        bool ok = true;
        for (int q = 0; q < 4; ++q) {
            auto it = grp[q].find(k);
            if (it == grp[q].end()) { ok = false; break; }
            g[q] = &it->second;
        }
        if (!ok) continue;
        std::array<int, 4> ord{0, 1, 2, 3};
        std::sort(ord.begin(), ord.end(), [&](int a, int b){ return g[a]->size() < g[b]->size(); });
        std::unordered_map<uint16_t, std::vector<PairM>> idx;
        for (const auto& a : *g[ord[0]]) for (const auto& b : *g[ord[3]]) {
            PairM p; if (make_pairM(a, b, p)) idx[p.par].push_back(p);
        }
        if (idx.empty()) continue;
        for (const auto& c : *g[ord[1]]) for (const auto& d : *g[ord[2]]) {
            PairM q; if (!make_pairM(c, d, q)) continue;
            auto it = idx.find(q.par); if (it == idx.end()) continue;
            for (const auto& p : it->second)
                if (!(p.s2 & q.s2) && !(p.d2 & q.d2)) res.insert(p.e8 | q.e8);
        }
    }
    return res;
}

static Opts64 make_opts(uint64_t p, uint64_t uZ) {
    Opts64 o;
    for (int c = 0; c < 64; ++c) {
        int pc = (p >> c) & 1;
        if (Q64[c] == 1) o[c] = pc ? std::vector<int>{-3, 3} : std::vector<int>{0};
        else if ((uZ >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
        else o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 0, 2};
    }
    return o;
}

int main() {
    init_Q();
    uint64_t mons[22]; int mk = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) <= 2) {
        uint64_t mask = 0;
        for (int c = 0; c < 64; ++c) if ((c & m) == m) mask |= (1ULL << c);
        mons[mk++] = mask;
    }
    std::unordered_set<uint64_t> seenZ;
    std::vector<uint64_t> reps;
    uint64_t cur = 0;
    for (uint32_t s = 1; s < (1u << 22); ++s) {
        cur ^= mons[__builtin_ctz(s)];
        uint64_t uZ = cur & Zmask;
        int wZ = __builtin_popcountll(uZ);
        if (wZ < 4 || wZ > 14) continue;
        int xr = 0; uint64_t tmp = uZ;
        while (tmp) { xr ^= __builtin_ctzll(tmp); tmp &= tmp - 1; }
        if (xr != 0) continue;
        if (seenZ.count(uZ)) continue;
        std::vector<uint64_t> bfs{uZ}; seenZ.insert(uZ);
        for (size_t qi = 0; qi < bfs.size(); ++qi)
            for (int g = 0; g < 63; ++g) {
                uint64_t nxt = apply_p64(bfs[qi], perm64[g]);
                if (seenZ.insert(nxt).second) bfs.push_back(nxt);
            }
        reps.push_back(cur);
    }
    uint64_t u = reps[24], uZ = u & Zmask, pool = Zmask & ~uZ;
    std::cout << "orb=24: wZ=" << __builtin_popcountll(uZ) << " wF=" << __builtin_popcountll(u & Fmask)
              << " |pool|=" << __builtin_popcountll(pool) << "\n";
    auto e0 = collect_e8(make_opts(u, uZ));
    auto e1 = collect_e8(make_opts(u ^ Fmask, uZ));
    std::cout << "|e0|=" << e0.size() << " |e1|=" << e1.size() << "\n";
    for (auto m : e0) std::cout << "  e0 mask=" << std::hex << m << std::dec << " wt=" << __builtin_popcountll(m) << "\n";
    for (auto m : e1) std::cout << "  e1 mask=" << std::hex << m << std::dec << " wt=" << __builtin_popcountll(m) << "\n";
    // Check disjoint pairs (m0, m1) and check remaining weight in pool!
    int joins = 0;
    for (auto m0 : e0) for (auto m1 : e1) {
        if (m0 & m1) continue;
        uint64_t rem = pool & ~(m0 | m1);
        int rw = __builtin_popcountll(rem);
        // Need e2, e3 disjoint subsets of rem with |e2| + |e3| = 17 - |m0| - |m1| (leaving m4 = 3 zeros in rem!)
        // Wait: for p2 = p3 = 0, a valid slice v_2 has z_2(c) = +-8 on e2, 0 elsewhere!
        // Since z_2(c)/8 in {-1, 0, +1} on e2 and 0 elsewhere, its WHT is 8*v_2 in {-8, 0, +8} => e2 MUST BE AN AFFINE FLAT OR UNION OF FLATS!
        // In fact, wait: z_2(c) = +-8 on e2, 0 elsewhere => 64*v_2(y) = 8*sum_{c in e2} (+-1)*(-1)^<c,y> => |e2| = m(v_2) MUST BE 0, 1, 2, 4, 8, ...?
        // Actually any ternary v_2 with WHT in {-8, 0, +8}: Parseval says sum_{c in e2} 64 = 64 * m(v_2) => m(v_2) = |e2|!
        // And v_2(y) in {-1, 0, +1} with |WHT(v_2)| in {0, 8} => e2 can ONLY have size 0, 1 (impossible: WHT +-1), 4 (no, WHT +-2/4), 8? Wait: 64/8=8, so |e2| in {0, 8, 16, 24, ...} or wait: 8 | sum_{y} v_2(y) => m(v_2) = |e2| >= 8 (or 0)!!
        // Wait: |e2| = 0 OR |e2| >= 8!! Let's check what rw and 17 - |m0| - |m1| are!
        std::cout << "  disjoint pair: |m0|=" << __builtin_popcountll(m0) << " |m1|=" << __builtin_popcountll(m1)
                  << " need |e2|+|e3|=" << (17 - __builtin_popcountll(m0) - __builtin_popcountll(m1))
                  << " from |rem|=" << rw << "\n";
        joins++;
    }
    std::cout << "Total disjoint (e0, e1) pairs: " << joins << "\n";
    return 0;
}
