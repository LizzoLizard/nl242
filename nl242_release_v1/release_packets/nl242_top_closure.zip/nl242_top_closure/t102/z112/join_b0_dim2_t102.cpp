// Test EXACT 4-cell (E_8, phase) join on beta=0, dim(U)=2, extra==0 (n_8 == d) at t=102 (|Z|=112)!
// Orbit-reduces e under Stab(U) so the 12,170 matches collapse dramatically, and prints ANY join immediately!
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <iostream>
#include <map>
#include <mutex>
#include <set>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static uint64_t Zmask = 0, Fmask = 0;
static int perm64[63][64];

static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
        if (Q64[x] == 0) Zmask |= (1ULL << x);
        else Fmask |= (1ULL << x);
    }
    for (int v = 1; v < 64; ++v) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        for (int x = 0; x < 64; ++x)
            perm64[v - 1][x] = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
    }
}
static inline uint64_t apply_p64(uint64_t w, const int* p) {
    uint64_t out = 0;
    while (w) { int i = __builtin_ctzll(w); out |= (1ULL << p[i]); w &= w - 1; }
    return out;
}
static inline int xor_mask(uint64_t m) {
    int xr = 0; while (m) { xr ^= __builtin_ctzll(m); m &= m - 1; } return xr;
}
static inline void fwht16(std::array<int, 16>& a) {
    for (int step = 1; step < 16; step *= 2)
        for (int i = 0; i < 16; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}
struct PhaseReducer {
    uint64_t pivs[64]{}; uint64_t mask = 0;
    void init(uint64_t m) {
        mask = m;
        for (int b = 0; b < 64; ++b) pivs[b] = 0;
        for (int k = 0; k < 7; ++k) {
            uint64_t w = 0;
            for (int c = 0; c < 64; ++c) if (k == 6 || ((c >> k) & 1)) w |= (1ULL << c);
            w &= mask;
            while (w) {
                int b = 63 - __builtin_clzll(w);
                if (!pivs[b]) { pivs[b] = w; break; }
                w ^= pivs[b];
            }
        }
    }
    uint64_t reduce(uint64_t w) const {
        w &= mask;
        for (int b = 63; b >= 0; --b) if (pivs[b] && ((w >> b) & 1)) w ^= pivs[b];
        return w;
    }
};

using Slice = std::array<int, 16>;
using Opts64 = std::array<std::vector<int>, 64>;
struct SliceS { Slice u; uint64_t e8, sg; };

static void enum_slice_S(const int idx[16], int j, Slice& z, uint64_t e8, uint64_t sg,
                         const Opts64& opts, uint64_t pool, uint64_t pmask,
                         std::map<uint16_t, std::vector<SliceS>>& out) {
    if (j < 16) {
        int c = idx[j];
        for (int v : opts[c]) {
            z[j] = v;
            uint64_t ne = (((pool >> c) & 1) && std::abs(v) == 2) ? (e8 | (1ULL << c)) : e8;
            uint64_t ns = (((pmask >> c) & 1) && v < 0) ? (sg | (1ULL << c)) : sg;
            enum_slice_S(idx, j + 1, z, ne, ns, opts, pool, pmask, out);
        }
        return;
    }
    Slice u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 3) return;
        int q = u[y] >> 2;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back({u, e8, sg});
}
struct PairS { uint16_t par = 0, s2 = 0, d2 = 0; uint64_t e8 = 0, sg = 0; };
static inline bool make_pairS(const SliceS& a, const SliceS& b, PairS& p) {
    p.par = p.s2 = p.d2 = 0; p.e8 = a.e8 | b.e8; p.sg = a.sg | b.sg;
    for (int y = 0; y < 16; ++y) {
        int s = (a.u[y] + b.u[y]) >> 1, d = (a.u[y] - b.u[y]) >> 1;
        if (std::abs(s) > 2 || std::abs(d) > 2) return false;
        if (s & 1) p.par |= (uint16_t(1) << y);
        if (std::abs(s) == 2) p.s2 |= (uint16_t(1) << y);
        if (std::abs(d) == 2) p.d2 |= (uint16_t(1) << y);
    }
    return true;
}
static int min_row_energy(const Opts64& o) {
    int s = 0;
    for (int c = 0; c < 64; ++c) { int m = 99; for (int v : o[c]) m = std::min(m, v * v); s += m; }
    return s;
}
static std::vector<std::pair<uint64_t, uint64_t>> collect_sigs_b0(Opts64 opts, uint64_t pool, const PhaseReducer& red) {
    std::set<std::pair<uint64_t, uint64_t>> res;
    if (min_row_energy(opts) > 256) return {};
    std::array<int, 7> pivots{};
    for (int c = 0; c < 64; ++c) {
        auto& ent = opts[c];
        if (std::find(ent.begin(), ent.end(), 0) != ent.end() || ent.size() <= 1) continue;
        int col = 64 | c;
        for (int i = 6; i >= 0; --i) if ((col >> i) & 1) {
            if (pivots[i]) col ^= pivots[i];
            else {
                pivots[i] = col;
                ent.erase(std::remove_if(ent.begin(), ent.end(), [](int v){ return v < 0; }), ent.end());
                break;
            }
        }
    }
    long long best_cost = (1LL << 60); int b0 = 5, b1 = 4;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        long long prod[4] = {1, 1, 1, 1};
        for (int c = 0; c < 64; ++c) prod[(((c>>i)&1)<<1)|((c>>j)&1)] *= (long long)opts[c].size();
        if (prod[0]+prod[1]+prod[2]+prod[3] < best_cost) { best_cost = prod[0]+prod[1]+prod[2]+prod[3]; b0 = i; b1 = j; }
    }
    int rem[4], rk = 0;
    for (int b = 0; b < 6; ++b) if (b != b0 && b != b1) rem[rk++] = b;
    int sl[4][16];
    for (int q = 0; q < 4; ++q)
        for (int r = 0; r < 16; ++r) {
            int c = (((q >> 1) & 1) << b0) | ((q & 1) << b1);
            for (int j = 0; j < 4; ++j) if ((r >> j) & 1) c |= (1 << rem[j]);
            sl[q][r] = c;
        }
    std::array<std::map<uint16_t, std::vector<SliceS>>, 4> grp;
    for (int q = 0; q < 4; ++q) {
        Slice f{}; enum_slice_S(sl[q], 0, f, 0ULL, 0ULL, opts, pool, red.mask, grp[q]);
        if (grp[q].empty()) return {};
    }
    int min_q = 0;
    for (int q = 1; q < 4; ++q) if (grp[q].size() < grp[min_q].size()) min_q = q;
    for (const auto& [k, _] : grp[min_q]) {
        std::array<const std::vector<SliceS>*, 4> g{};
        bool ok = true;
        for (int q = 0; q < 4; ++q) {
            auto it = grp[q].find(k);
            if (it == grp[q].end()) { ok = false; break; }
            g[q] = &it->second;
        }
        if (!ok) continue;
        std::array<int, 4> ord{0, 1, 2, 3};
        std::sort(ord.begin(), ord.end(), [&](int a, int b){ return g[a]->size() < g[b]->size(); });
        std::unordered_map<uint16_t, std::vector<PairS>> idx;
        for (const auto& a : *g[ord[0]]) for (const auto& b : *g[ord[3]]) {
            PairS p; if (make_pairS(a, b, p)) idx[p.par].push_back(p);
        }
        if (idx.empty()) continue;
        for (const auto& c : *g[ord[1]]) for (const auto& d : *g[ord[2]]) {
            PairS q; if (!make_pairS(c, d, q)) continue;
            auto it = idx.find(q.par); if (it == idx.end()) continue;
            for (const auto& p : it->second)
                if (!(p.s2 & q.s2) && !(p.d2 & q.d2))
                    res.insert({p.e8 | q.e8, red.reduce(p.sg | q.sg)});
        }
    }
    return {res.begin(), res.end()};
}

static std::mutex log_mu;

int main() {
    init_Q();
    std::vector<int> fpts;
    for (int c = 0; c < 64; ++c) if (Q64[c] == 1) fpts.push_back(c);
    int f_idx[64]; std::fill(f_idx, f_idx + 64, -1);
    for (int j = 0; j < 36; ++j) f_idx[fpts[j]] = j;

    uint64_t mons[22]; int mk = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) <= 2) {
        uint64_t mask = 0;
        for (int c = 0; c < 64; ++c) if ((c & m) == m) mask |= (1ULL << c);
        mons[mk++] = mask;
    }
    uint64_t rref[21]{}, rref_full[21]{}; int piv_col[21]{}; int rank = 0; bool is_piv[36]{};
    for (int k = 0; k < 22; ++k) {
        uint64_t row = 0;
        for (int j = 0; j < 36; ++j) if ((mons[k] >> fpts[j]) & 1) row |= (1ULL << j);
        uint64_t full = mons[k];
        for (int r = 0; r < rank; ++r) if ((row >> piv_col[r]) & 1) { row ^= rref[r]; full ^= rref_full[r]; }
        if (row) {
            int pc = __builtin_ctzll(row);
            for (int r = 0; r < rank; ++r) if ((rref[r] >> pc) & 1) { rref[r] ^= row; rref_full[r] ^= full; }
            rref[rank] = row; rref_full[rank] = full; piv_col[rank] = pc; is_piv[pc] = true; rank++;
        }
    }
    int free_cols[15], frk = 0;
    for (int j = 0; j < 36; ++j) if (!is_piv[j]) free_cols[frk++] = j;
    uint16_t Hcol[36]{};
    for (int k = 0; k < 15; ++k) Hcol[free_cols[k]] = (uint16_t(1) << k);
    for (int r = 0; r < 21; ++r) {
        uint16_t col = 0;
        for (int k = 0; k < 15; ++k) if ((rref[r] >> free_cols[k]) & 1) col |= (uint16_t(1) << k);
        Hcol[piv_col[r]] = col;
    }
    auto synF = [&](uint64_t w) {
        uint16_t s = 0; uint64_t t = w & Fmask;
        while (t) { int c = __builtin_ctzll(t); s ^= Hcol[f_idx[c]]; t &= t - 1; }
        return s;
    };
    auto liftF = [&](uint64_t wF, uint64_t& out) {
        uint64_t ans = 0;
        for (int r = 0; r < 21; ++r)
            if ((wF >> fpts[piv_col[r]]) & 1) ans ^= rref_full[r];
        if ((ans & Fmask) != wF) return false;
        out = ans;
        return true;
    };

    std::vector<std::pair<uint32_t, uint64_t>> L_vec[9];
    std::unordered_map<uint32_t, std::vector<uint64_t>> R_map[9];
    auto gen_half = [&](int off, bool is_right) {
        auto rec = [&](auto& self, int idx, int k, uint32_t key, uint64_t mask) -> void {
            if (is_right) R_map[k][key].push_back(mask);
            else L_vec[k].push_back({key, mask});
            if (k == 8) return;
            for (int i = idx; i < 18; ++i) {
                int j = off + i;
                uint32_t dkey = (static_cast<uint32_t>(Hcol[j]) << 6) | static_cast<uint32_t>(fpts[j]);
                self(self, i + 1, k + 1, key ^ dkey, mask | (1ULL << fpts[j]));
            }
        };
        rec(rec, 0, 0, 0u, 0ULL);
    };
    gen_half(0, false); gen_half(18, true);

    std::unordered_map<uint32_t, std::vector<uint64_t>> direct_err[5];
    for (int d = 0; d <= 4; ++d)
        for (int kL = 0; kL <= d; ++kL)
            for (auto [k1, m1] : L_vec[kL])
                for (const auto& [k2, v2] : R_map[d - kL])
                    for (uint64_t m2 : v2) direct_err[d][k1 ^ k2].push_back(m1 | m2);

    auto find_errors = [&](int d, uint32_t target_key) -> std::vector<uint64_t> {
        if (d <= 4) {
            auto it = direct_err[d].find(target_key);
            return (it == direct_err[d].end()) ? std::vector<uint64_t>{} : it->second;
        }
        std::vector<uint64_t> out;
        for (int kL = 0; kL <= d; ++kL)
            for (auto [k1, m1] : L_vec[kL]) {
                auto it = R_map[d - kL].find(target_key ^ k1);
                if (it != R_map[d - kL].end())
                    for (uint64_t m2 : it->second) out.push_back(m1 | m2);
            }
        return out;
    };

    std::vector<uint64_t> byW[15];
    std::unordered_set<uint64_t> seenZ;
    uint64_t cur = 0;
    for (uint32_t s = 1; s < (1u << 22); ++s) {
        cur ^= mons[__builtin_ctz(s)];
        uint64_t z = cur & Zmask;
        int wz = __builtin_popcountll(z);
        if (wz >= 4 && wz <= 12 && seenZ.insert(z).second) byW[wz].push_back(cur);
    }
    std::vector<std::pair<int, uint64_t>> repsA;
    for (int wa : {4, 6, 8}) {
        std::unordered_set<uint64_t> vis;
        for (uint64_t u : byW[wa]) {
            uint64_t a = u & Zmask;
            if (vis.count(a)) continue;
            repsA.push_back({wa, u});
            std::vector<uint64_t> bfs{a}; vis.insert(a);
            for (size_t qi = 0; qi < bfs.size(); ++qi)
                for (int g = 0; g < 63; ++g) {
                    uint64_t n = apply_p64(bfs[qi], perm64[g]);
                    if (vis.insert(n).second) bfs.push_back(n);
                }
        }
    }

    // Orbit-reduce e under transvection stab of U = {a, b, a^b}!
    struct Match { int m2, d; uint64_t u, v, e; };
    std::vector<Match> matches;
    for (auto [wa, u] : repsA) {
        uint64_t a = u & Zmask;
        std::vector<int> stab;
        for (int g = 0; g < 63; ++g) if (apply_p64(a, perm64[g]) == a) stab.push_back(g);
        std::unordered_set<uint64_t> vis;
        for (int wb = wa; wb <= (28 - wa) / 2; wb += 2) {
            for (uint64_t v : byW[wb]) {
                uint64_t b = v & Zmask;
                if (b == a) continue;
                int wab = __builtin_popcountll(a ^ b);
                if (wab < wb) continue;
                uint64_t d2m = a | b;
                int m2 = __builtin_popcountll(d2m);
                if (m2 > 14) continue;
                uint64_t can = std::min(b, a ^ b);
                if (vis.count(can)) continue;
                std::vector<uint64_t> bfs{can}; vis.insert(can);
                for (size_t qi = 0; qi < bfs.size(); ++qi)
                    for (int g : stab) {
                        uint64_t n = apply_p64(bfs[qi], perm64[g]);
                        uint64_t nc = std::min(n, a ^ n);
                        if (vis.insert(nc).second) bfs.push_back(nc);
                    }
                // Stabilizer of unordered U = {a, b, a^b} inside the 63 transvections:
                std::vector<int> stabU;
                std::array<uint64_t, 3> Uset{a, b, a ^ b};
                std::sort(Uset.begin(), Uset.end());
                for (int g = 0; g < 63; ++g) {
                    std::array<uint64_t, 3> ng{apply_p64(a, perm64[g]), apply_p64(b, perm64[g]), apply_p64(a^b, perm64[g])};
                    std::sort(ng.begin(), ng.end());
                    if (ng == Uset) stabU.push_back(g);
                }
                uint32_t key = (static_cast<uint32_t>(synF(u & v)) << 6) | static_cast<uint32_t>(xor_mask(d2m));
                for (int d = (14 - m2) & 1; d <= 14 - m2; d += 2) {
                    if (d == 0) continue; // n_8 == 0 ALREADY CLOSED!
                    auto errs = find_errors(d, key);
                    std::unordered_set<uint64_t> visE;
                    for (uint64_t e : errs) {
                        if (visE.count(e)) continue;
                        matches.push_back({m2, d, u, v, e});
                        std::vector<uint64_t> ebfs{e}; visE.insert(e);
                        for (size_t qi = 0; qi < ebfs.size(); ++qi)
                            for (int g : stabU) {
                                uint64_t ne = apply_p64(ebfs[qi], perm64[g]);
                                if (visE.insert(ne).second) ebfs.push_back(ne);
                            }
                    }
                }
            }
        }
    }
    std::cout << "Orbit-reduced (U, e) matches (d >= 1): " << matches.size() << "\n" << std::flush;

    // Run EXACT 4-cell (E_8, phase) join on ALL matches for extra == 0 (n_8 == d)!
    std::atomic<size_t> ni{0};
    std::atomic<int> total_joins{0};
    std::vector<std::thread> ths;
    for (int ti = 0; ti < 8; ++ti) {
        ths.emplace_back([&]() {
            while (true) {
                size_t idx = ni.fetch_add(1);
                if (idx >= matches.size()) break;
                const auto& mt = matches[idx];
                int m4 = (14 - mt.m2 - mt.d) / 2;
                uint64_t p0_base = 0;
                if (!liftF(((mt.u & mt.v) ^ mt.e) & Fmask, p0_base)) continue;
                uint64_t d2m = (mt.u | mt.v) & Zmask;
                for (uint64_t p0 : {p0_base, p0_base ^ Zmask}) {
                    uint64_t ps[4] = {p0, p0 ^ mt.u, p0 ^ mt.v, p0 ^ mt.u ^ mt.v ^ Fmask};
                    uint64_t pool = (Zmask & ~d2m) & ~p0;
                    uint64_t pmask = mt.e | ((Zmask & ~d2m) & p0);
                    PhaseReducer red; red.init(pmask);
                    uint64_t tgt_ph = red.reduce(pmask);
                    int target_wt = __builtin_popcountll(pool) - m4;
                    if (target_wt < 0) continue;

                    std::vector<std::pair<uint64_t, uint64_t>> sigs[4];
                    bool ok = true;
                    for (int x = 0; x < 4; ++x) {
                        Opts64 o;
                        for (int c = 0; c < 64; ++c) {
                            int pc = (ps[x] >> c) & 1;
                            if (Q64[c] == 1) {
                                if ((mt.e >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 2};
                                else o[c] = pc ? std::vector<int>{-3, 3} : std::vector<int>{0};
                            } else {
                                if ((d2m >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
                                else o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 0, 2};
                            }
                        }
                        sigs[x] = collect_sigs_b0(o, pool, red);
                        if (sigs[x].empty()) { ok = false; break; }
                    }
                    if (!ok) continue;

                    // Join (sigs[0], sigs[1]) and (sigs[2], sigs[3])!
                    std::unordered_map<uint64_t, std::unordered_set<uint64_t>> p01;
                    for (auto [e0, ph0] : sigs[0]) for (auto [e1, ph1] : sigs[1])
                        if ((e0 & e1) == 0) p01[e0 | e1].insert(ph0 ^ ph1);
                    if (p01.empty()) continue;

                    bool joined = false;
                    for (auto [e2, ph2] : sigs[2]) {
                        for (auto [e3, ph3] : sigs[3]) {
                            if (e2 & e3) continue;
                            uint64_t e23 = e2 | e3;
                            uint64_t ph_need = tgt_ph ^ ph2 ^ ph3;
                            int rem_wt = target_wt - __builtin_popcountll(e23);
                            if (rem_wt < 0) continue;
                            if (m4 == 0) {
                                auto it = p01.find(pool ^ e23);
                                if (it != p01.end() && it->second.count(ph_need)) { joined = true; break; }
                            } else {
                                for (const auto& [e01, phs] : p01) {
                                    if ((e01 & e23) == 0 && __builtin_popcountll(e01) == rem_wt && phs.count(ph_need)) {
                                        joined = true; break;
                                    }
                                }
                                if (joined) break;
                            }
                        }
                        if (joined) break;
                    }
                    if (joined) {
                        int jn = total_joins.fetch_add(1) + 1;
                        if (jn <= 20) {
                            std::lock_guard<std::mutex> lk(log_mu);
                            std::cout << "  !!! REAL LOW-BLOCK JOIN #" << jn << " !!! m2=" << mt.m2
                                      << " d=" << mt.d << " m4=" << m4
                                      << " p0=" << std::hex << p0 << " u=" << mt.u << " v=" << mt.v
                                      << " e=" << mt.e << std::dec << "\n" << std::flush;
                        }
                    }
                }
            }
        });
    }
    for (auto& th : ths) th.join();
    std::cout << "DONE beta=0, dim(U)=2, extra==0: TOTAL JOINS = " << total_joins.load() << "\n" << std::flush;
    return 0;
}
