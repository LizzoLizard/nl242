// Exhaustive 4-cell solver for ALL of (1d): beta=0, dim(U)=1, w=0, n_8 in {2, 4, 6, 8, 10} at t=102 (|Z|=112)!
// Covers BOTH p_2 = p_3 = 0 AND p_2 = p_3 = 1_Z, ALL m_2 <= 14 - n_8 with XOR(uZ) == 0,
// and ALL (n_2, n_4) with 2*n_2 + 4*n_4 = n_8!
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <iostream>
#include <map>
#include <mutex>
#include <set>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static uint64_t Zmask = 0, Fmask = 0;
static int perm64[63][64];

static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
        if (Q64[x] == 0) Zmask |= (1ULL << x);
        else Fmask |= (1ULL << x);
    }
    for (int v = 1; v < 64; ++v) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        for (int x = 0; x < 64; ++x)
            perm64[v - 1][x] = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
    }
}
using Perm = std::array<int, 64>;
static inline uint64_t apply_p64(uint64_t w, const int* p) {
    uint64_t out = 0;
    while (w) { int i = __builtin_ctzll(w); out |= (1ULL << p[i]); w &= w - 1; }
    return out;
}
static Perm compose(const Perm& a, const Perm& b) {
    Perm c; for (int i = 0; i < 64; ++i) c[i] = a[b[i]]; return c;
}
static Perm invert_p(const Perm& a) {
    Perm b; for (int i = 0; i < 64; ++i) b[a[i]] = i; return b;
}
// Schreier stabilizer of obj (if orbit size <= 10000; otherwise direct transvection stabilizer)
static std::vector<Perm> get_stab(uint64_t obj) {
    Perm id; for (int i = 0; i < 64; ++i) id[i] = i;
    std::unordered_map<uint64_t, Perm> to_obj;
    std::vector<uint64_t> bfs{obj};
    to_obj[obj] = id;
    std::vector<Perm> gens;
    std::set<Perm> seen;
    for (size_t qi = 0; qi < bfs.size(); ++qi) {
        if (bfs.size() > 8000) {
            // Fallback to direct transvection stabilizer (still 100% sound subgroup!)
            gens.clear();
            for (int g = 0; g < 63; ++g)
                if (apply_p64(obj, perm64[g]) == obj) {
                    Perm gp; for (int i = 0; i < 64; ++i) gp[i] = perm64[g][i];
                    gens.push_back(gp);
                }
            return gens;
        }
        uint64_t cur = bfs[qi]; Perm tcur = to_obj[cur];
        for (int g = 0; g < 63; ++g) {
            uint64_t nxt = apply_p64(cur, perm64[g]);
            Perm gp; for (int i = 0; i < 64; ++i) gp[i] = perm64[g][i];
            Perm tnxt = compose(gp, tcur);
            auto it = to_obj.find(nxt);
            if (it == to_obj.end()) { to_obj[nxt] = tnxt; bfs.push_back(nxt); }
            else {
                Perm s = compose(invert_p(it->second), tnxt);
                if (s != id && seen.insert(s).second && gens.size() < 40) gens.push_back(s);
            }
        }
    }
    return gens;
}
static inline int xor_mask(uint64_t m) {
    int xr = 0; while (m) { xr ^= __builtin_ctzll(m); m &= m - 1; } return xr;
}
static inline void fwht16(std::array<int, 16>& a) {
    for (int step = 1; step < 16; step *= 2)
        for (int i = 0; i < 16; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}
struct PhaseReducer {
    uint64_t pivs[64]{}; uint64_t mask = 0;
    void init(uint64_t m) {
        mask = m;
        for (int b = 0; b < 64; ++b) pivs[b] = 0;
        for (int k = 0; k < 7; ++k) {
            uint64_t w = 0;
            for (int c = 0; c < 64; ++c) if (k == 6 || ((c >> k) & 1)) w |= (1ULL << c);
            w &= mask;
            while (w) {
                int b = 63 - __builtin_clzll(w);
                if (!pivs[b]) { pivs[b] = w; break; }
                w ^= pivs[b];
            }
        }
    }
    uint64_t reduce(uint64_t w) const {
        w &= mask;
        for (int b = 63; b >= 0; --b) if (pivs[b] && ((w >> b) & 1)) w ^= pivs[b];
        return w;
    }
};

using Slice = std::array<int, 16>;
using Opts64 = std::array<std::vector<int>, 64>;
struct SliceS { Slice u; uint64_t e8, sg; };

static void enum_slice_b0(const int idx[16], int j, Slice& z, const Opts64& opts,
                          std::map<uint16_t, std::vector<Slice>>& out) {
    if (j < 16) {
        for (int v : opts[idx[j]]) { z[j] = v; enum_slice_b0(idx, j + 1, z, opts, out); }
        return;
    }
    Slice u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 3) return;
        int q = u[y] >> 2;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back(u);
}
struct Pair { uint16_t par = 0, s2 = 0, d2 = 0; };
static inline bool make_pair(const Slice& a, const Slice& b, Pair& p) {
    p.par = p.s2 = p.d2 = 0;
    for (int y = 0; y < 16; ++y) {
        int s = (a[y] + b[y]) >> 1, d = (a[y] - b[y]) >> 1;
        if (std::abs(s) > 2 || std::abs(d) > 2) return false;
        if (s & 1) p.par |= (uint16_t(1) << y);
        if (std::abs(s) == 2) p.s2 |= (uint16_t(1) << y);
        if (std::abs(d) == 2) p.d2 |= (uint16_t(1) << y);
    }
    return true;
}
static int min_row_energy(const Opts64& o) {
    int s = 0;
    for (int c = 0; c < 64; ++c) { int m = 99; for (int v : o[c]) m = std::min(m, v * v); s += m; }
    return s;
}
static bool row_exists_b0(Opts64 opts) {
    if (min_row_energy(opts) > 256) return false;
    std::array<int, 7> pivots{};
    for (int c = 0; c < 64; ++c) {
        auto& ent = opts[c];
        if (std::find(ent.begin(), ent.end(), 0) != ent.end() || ent.size() <= 1) continue;
        int col = 64 | c;
        for (int i = 6; i >= 0; --i) if ((col >> i) & 1) {
            if (pivots[i]) col ^= pivots[i];
            else {
                pivots[i] = col;
                ent.erase(std::remove_if(ent.begin(), ent.end(), [](int v){ return v < 0; }), ent.end());
                break;
            }
        }
    }
    long long best_cost = (1LL << 60); int b0 = 5, b1 = 4;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        long long prod[4] = {1, 1, 1, 1};
        for (int c = 0; c < 64; ++c) prod[(((c>>i)&1)<<1)|((c>>j)&1)] *= (long long)opts[c].size();
        if (prod[0]+prod[1]+prod[2]+prod[3] < best_cost) { best_cost = prod[0]+prod[1]+prod[2]+prod[3]; b0 = i; b1 = j; }
    }
    int rem[4], rk = 0;
    for (int b = 0; b < 6; ++b) if (b != b0 && b != b1) rem[rk++] = b;
    int sl[4][16];
    for (int q = 0; q < 4; ++q)
        for (int r = 0; r < 16; ++r) {
            int c = (((q >> 1) & 1) << b0) | ((q & 1) << b1);
            for (int j = 0; j < 4; ++j) if ((r >> j) & 1) c |= (1 << rem[j]);
            sl[q][r] = c;
        }
    std::array<std::map<uint16_t, std::vector<Slice>>, 4> grp;
    for (int q = 0; q < 4; ++q) {
        Slice f{}; enum_slice_b0(sl[q], 0, f, opts, grp[q]);
        if (grp[q].empty()) return false;
    }
    int min_q = 0;
    for (int q = 1; q < 4; ++q) if (grp[q].size() < grp[min_q].size()) min_q = q;
    for (const auto& [k, _] : grp[min_q]) {
        std::array<const std::vector<Slice>*, 4> g{};
        bool ok = true;
        for (int q = 0; q < 4; ++q) {
            auto it = grp[q].find(k);
            if (it == grp[q].end()) { ok = false; break; }
            g[q] = &it->second;
        }
        if (!ok) continue;
        std::array<int, 4> ord{0, 1, 2, 3};
        std::sort(ord.begin(), ord.end(), [&](int a, int b){ return g[a]->size() < g[b]->size(); });
        std::unordered_map<uint16_t, std::vector<Pair>> idx;
        for (const auto& a : *g[ord[0]]) for (const auto& b : *g[ord[3]]) {
            Pair p; if (make_pair(a, b, p)) idx[p.par].push_back(p);
        }
        if (idx.empty()) continue;
        for (const auto& c : *g[ord[1]]) for (const auto& d : *g[ord[2]]) {
            Pair q; if (!make_pair(c, d, q)) continue;
            auto it = idx.find(q.par); if (it == idx.end()) continue;
            for (const auto& p : it->second)
                if (!(p.s2 & q.s2) && !(p.d2 & q.d2)) return true;
        }
    }
    return false;
}

static void enum_slice_S(const int idx[16], int j, Slice& z, uint64_t e8, uint64_t sg,
                         const Opts64& opts, uint64_t pool, uint64_t pmask,
                         std::map<uint16_t, std::vector<SliceS>>& out) {
    if (j < 16) {
        int c = idx[j];
        for (int v : opts[c]) {
            z[j] = v;
            uint64_t ne = (((pool >> c) & 1) && std::abs(v) == 2) ? (e8 | (1ULL << c)) : e8;
            uint64_t ns = (((pmask >> c) & 1) && v < 0) ? (sg | (1ULL << c)) : sg;
            enum_slice_S(idx, j + 1, z, ne, ns, opts, pool, pmask, out);
        }
        return;
    }
    Slice u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 3) return;
        int q = u[y] >> 2;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back({u, e8, sg});
}
struct PairS { uint16_t par = 0, s2 = 0, d2 = 0; uint64_t e8 = 0, sg = 0; };
static inline bool make_pairS(const SliceS& a, const SliceS& b, PairS& p) {
    p.par = p.s2 = p.d2 = 0; p.e8 = a.e8 | b.e8; p.sg = a.sg | b.sg;
    for (int y = 0; y < 16; ++y) {
        int s = (a.u[y] + b.u[y]) >> 1, d = (a.u[y] - b.u[y]) >> 1;
        if (std::abs(s) > 2 || std::abs(d) > 2) return false;
        if (s & 1) p.par |= (uint16_t(1) << y);
        if (std::abs(s) == 2) p.s2 |= (uint16_t(1) << y);
        if (std::abs(d) == 2) p.d2 |= (uint16_t(1) << y);
    }
    return true;
}
static std::vector<std::pair<uint64_t, uint64_t>> collect_sigs_b0(Opts64 opts, uint64_t pool, const PhaseReducer& red) {
    std::set<std::pair<uint64_t, uint64_t>> res;
    if (min_row_energy(opts) > 256) return {};
    std::array<int, 7> pivots{};
    for (int c = 0; c < 64; ++c) {
        auto& ent = opts[c];
        if (std::find(ent.begin(), ent.end(), 0) != ent.end() || ent.size() <= 1) continue;
        int col = 64 | c;
        for (int i = 6; i >= 0; --i) if ((col >> i) & 1) {
            if (pivots[i]) col ^= pivots[i];
            else {
                pivots[i] = col;
                ent.erase(std::remove_if(ent.begin(), ent.end(), [](int v){ return v < 0; }), ent.end());
                break;
            }
        }
    }
    long long best_cost = (1LL << 60); int b0 = 5, b1 = 4;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        long long prod[4] = {1, 1, 1, 1};
        for (int c = 0; c < 64; ++c) prod[(((c>>i)&1)<<1)|((c>>j)&1)] *= (long long)opts[c].size();
        if (prod[0]+prod[1]+prod[2]+prod[3] < best_cost) { best_cost = prod[0]+prod[1]+prod[2]+prod[3]; b0 = i; b1 = j; }
    }
    int rem[4], rk = 0;
    for (int b = 0; b < 6; ++b) if (b != b0 && b != b1) rem[rk++] = b;
    int sl[4][16];
    for (int q = 0; q < 4; ++q)
        for (int r = 0; r < 16; ++r) {
            int c = (((q >> 1) & 1) << b0) | ((q & 1) << b1);
            for (int j = 0; j < 4; ++j) if ((r >> j) & 1) c |= (1 << rem[j]);
            sl[q][r] = c;
        }
    std::array<std::map<uint16_t, std::vector<SliceS>>, 4> grp;
    for (int q = 0; q < 4; ++q) {
        Slice f{}; enum_slice_S(sl[q], 0, f, 0ULL, 0ULL, opts, pool, red.mask, grp[q]);
        if (grp[q].empty()) return {};
    }
    int min_q = 0;
    for (int q = 1; q < 4; ++q) if (grp[q].size() < grp[min_q].size()) min_q = q;
    for (const auto& [k, _] : grp[min_q]) {
        std::array<const std::vector<SliceS>*, 4> g{};
        bool ok = true;
        for (int q = 0; q < 4; ++q) {
            auto it = grp[q].find(k);
            if (it == grp[q].end()) { ok = false; break; }
            g[q] = &it->second;
        }
        if (!ok) continue;
        std::array<int, 4> ord{0, 1, 2, 3};
        std::sort(ord.begin(), ord.end(), [&](int a, int b){ return g[a]->size() < g[b]->size(); });
        std::unordered_map<uint16_t, std::vector<PairS>> idx;
        for (const auto& a : *g[ord[0]]) for (const auto& b : *g[ord[3]]) {
            PairS p; if (make_pairS(a, b, p)) idx[p.par].push_back(p);
        }
        if (idx.empty()) continue;
        for (const auto& c : *g[ord[1]]) for (const auto& d : *g[ord[2]]) {
            PairS q; if (!make_pairS(c, d, q)) continue;
            auto it = idx.find(q.par); if (it == idx.end()) continue;
            for (const auto& p : it->second)
                if (!(p.s2 & q.s2) && !(p.d2 & q.d2))
                    res.insert({p.e8 | q.e8, red.reduce(p.sg | q.sg)});
        }
    }
    return {res.begin(), res.end()};
}

static Opts64 make_row_b0(uint64_t p, uint64_t d2m, uint64_t k2m, uint64_t k4m) {
    Opts64 o;
    for (int c = 0; c < 64; ++c) {
        int pc = (p >> c) & 1;
        if (Q64[c] == 1) {
            if ((k2m >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 0, 2};
            else if ((k4m >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
            else o[c] = pc ? std::vector<int>{-3, 3} : std::vector<int>{0};
        } else {
            if ((d2m >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
            else o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 0, 2};
        }
    }
    return o;
}

static bool valid_pure8(uint64_t T) {
    int sz = __builtin_popcountll(T);
    if (sz == 0) return true;
    if (sz < 8 || (sz & 1)) return false;
    Opts64 o;
    for (int c = 0; c < 64; ++c) o[c] = ((T >> c) & 1) ? std::vector<int>{-2, 2} : std::vector<int>{0};
    return row_exists_b0(o);
}

static std::mutex log_mu;
struct Task1d { uint64_t u, k2m, k4m; int n8, m2, m4; bool check_p2_Z; };

static int run_task(const Task1d& t) {
    uint64_t uZ = t.u & Zmask;
    int hits = 0;

    // Case A: p_2 = p_3 = 0 (p_0 = u, p_1 = u ^ Fmask)!
    {
        uint64_t p0 = t.u, p1 = t.u ^ Fmask;
        // Put higher F-weight first for instant prune!
        if (__builtin_popcountll(p1 & Fmask) > __builtin_popcountll(p0 & Fmask)) std::swap(p0, p1);
        auto r0 = make_row_b0(p0, uZ, t.k2m, t.k4m);
        if (row_exists_b0(r0)) {
            auto r1 = make_row_b0(p1, uZ, t.k2m, t.k4m);
            if (row_exists_b0(r1)) {
                uint64_t zpool = Zmask & ~uZ;
                uint64_t pool = zpool | t.k2m;
                PhaseReducer red; red.init(0ULL);
                auto s0 = collect_sigs_b0(r0, pool, red);
                auto s1 = collect_sigs_b0(r1, pool, red);
                for (auto [e0, _0] : s0) {
                    for (auto [e1, _1] : s1) {
                        if (e0 & e1) continue;
                        uint64_t rem = pool ^ (e0 | e1);
                        int rsz = __builtin_popcountll(rem) - t.m4;
                        if (rsz < 0 || (rsz > 0 && rsz < 8) || (rsz & 1)) continue;
                        uint64_t remZ = rem & zpool;
                        if (__builtin_popcountll(remZ) < t.m4) continue;
                        if (rsz >= 16) {
                            std::lock_guard<std::mutex> lk(log_mu);
                            std::cout << "  [ALERT rsz>=16] n8=" << t.n8 << " m2=" << t.m2 << " m4=" << t.m4
                                      << " rsz=" << rsz << " |e0|=" << __builtin_popcountll(e0)
                                      << " |e1|=" << __builtin_popcountll(e1) << "\n" << std::flush;
                            hits++;
                            goto done_A;
                        }
                        // Choose m4 zeros inside remZ and check valid_pure8(rem ^ zeros)!
                        std::vector<int> zbits;
                        uint64_t tmp = remZ;
                        while (tmp) { zbits.push_back(__builtin_ctzll(tmp)); tmp &= tmp - 1; }
                        auto recZ = [&](auto& self, int idx, int need, uint64_t cur_rem) -> bool {
                            if (need == 0) return valid_pure8(cur_rem);
                            if (idx + need > (int)zbits.size()) return false;
                            if (self(self, idx + 1, need - 1, cur_rem ^ (1ULL << zbits[idx]))) return true;
                            return self(self, idx + 1, need, cur_rem);
                        };
                        if (recZ(recZ, 0, t.m4, rem)) {
                            std::lock_guard<std::mutex> lk(log_mu);
                            std::cout << "  !!! HIT p2=0 !!! n8=" << t.n8 << " m2=" << t.m2 << " m4=" << t.m4
                                      << " rsz=" << rsz << "\n" << std::flush;
                            hits++;
                            goto done_A;
                        }
                    }
                }
            }
        }
    }
    done_A:;

    // Case B: p_2 = p_3 = 1_Z (ONLY when m_4 == 0 and |k2m| >= 2!)
    if (t.check_p2_Z && t.m4 == 0 && __builtin_popcountll(t.k2m) >= 2) {
        uint64_t p2 = Zmask, p0 = t.u ^ Zmask, p1 = p0 ^ Fmask;
        if (__builtin_popcountll(p1 & Fmask) > __builtin_popcountll(p0 & Fmask)) std::swap(p0, p1);
        auto r0 = make_row_b0(p0, uZ, t.k2m, t.k4m);
        if (row_exists_b0(r0)) {
            auto r1 = make_row_b0(p1, uZ, t.k2m, t.k4m);
            if (row_exists_b0(r1)) {
                uint64_t pool = t.k2m;
                uint64_t pmask = Zmask & ~uZ;
                PhaseReducer red; red.init(pmask);
                uint64_t tgt_ph = red.reduce(pmask);
                auto s2 = collect_sigs_b0(make_row_b0(p2, uZ, t.k2m, t.k4m), pool, red);
                if (!s2.empty()) {
                    auto s0 = collect_sigs_b0(r0, pool, red);
                    auto s1 = collect_sigs_b0(r1, pool, red);
                    std::unordered_map<uint64_t, std::unordered_set<uint64_t>> pair2;
                    for (size_t i = 0; i < s2.size(); ++i)
                        for (size_t j = i; j < s2.size(); ++j)
                            if ((s2[i].first & s2[j].first) == 0)
                                pair2[s2[i].first | s2[j].first].insert(s2[i].second ^ s2[j].second);
                    for (auto [e0, ph0] : s0) for (auto [e1, ph1] : s1) {
                        if (e0 & e1) continue;
                        auto it = pair2.find(pool ^ (e0 | e1));
                        if (it != pair2.end() && it->second.count(tgt_ph ^ ph0 ^ ph1)) {
                            std::lock_guard<std::mutex> lk(log_mu);
                            std::cout << "  !!! HIT p2=1_Z !!! n8=" << t.n8 << " m2=" << t.m2 << "\n" << std::flush;
                            hits++;
                            goto done_B;
                        }
                    }
                }
            }
        }
    }
    done_B:;
    return hits;
}

int main() {
    init_Q();
    uint64_t mons[22]; int mk = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) <= 2) {
        uint64_t mask = 0;
        for (int c = 0; c < 64; ++c) if ((c & m) == m) mask |= (1ULL << c);
        mons[mk++] = mask;
    }
    std::vector<uint64_t> u_orbs[13];
    std::unordered_set<uint64_t> seenZ;
    uint64_t cur = 0;
    for (uint32_t s = 1; s < (1u << 22); ++s) {
        cur ^= mons[__builtin_ctz(s)];
        uint64_t uZ = cur & Zmask;
        int wz = __builtin_popcountll(uZ);
        if (wz < 4 || wz > 12 || (wz & 1)) continue;
        if (xor_mask(uZ) != 0 || seenZ.count(uZ)) continue;
        u_orbs[wz].push_back(cur);
        std::vector<uint64_t> bfs{uZ}; seenZ.insert(uZ);
        for (size_t qi = 0; qi < bfs.size(); ++qi)
            for (int g = 0; g < 63; ++g) {
                uint64_t n = apply_p64(bfs[qi], perm64[g]);
                if (seenZ.insert(n).second) bfs.push_back(n);
            }
    }
    for (int wz = 4; wz <= 12; wz += 2)
        std::cout << "m2=" << wz << " (XOR=0): " << u_orbs[wz].size() << " Aut(Q)-orbits\n";
    std::cout << std::flush;

    std::vector<int> fpts;
    for (int c = 0; c < 64; ++c) if (Q64[c] == 1) fpts.push_back(c);

    // Helper: orbit-reduce k-subsets of fpts under st (for small k <= 5)!
    // Build incrementally by layer: orbits of size k -> extend by 1 point -> orbit-reduce!
    // WAY faster than C(36, 5) = 376,992!
    auto build_subset_orbs = [&](const std::vector<Perm>& st, int max_k) {
        std::vector<std::vector<uint64_t>> layers(max_k + 1);
        layers[0] = {0ULL};
        for (int k = 1; k <= max_k; ++k) {
            std::unordered_set<uint64_t> vis;
            for (uint64_t base : layers[k - 1]) {
                for (int c : fpts) {
                    if ((base >> c) & 1) continue;
                    uint64_t m = base | (1ULL << c);
                    if (vis.count(m)) continue;
                    layers[k].push_back(m);
                    std::vector<uint64_t> bfs{m}; vis.insert(m);
                    for (size_t qi = 0; qi < bfs.size(); ++qi)
                        for (const auto& g : st) {
                            uint64_t n = apply_p64(bfs[qi], g.data());
                            if (vis.insert(n).second) bfs.push_back(n);
                        }
                }
            }
        }
        return layers;
    };

    // For each n8 in {2, 4, 6, 8, 10}, build all tasks and run in 8 threads!
    for (int n8 : {2, 4, 6, 8, 10}) {
        std::vector<Task1d> tasks;
        for (int m2 = 4; m2 <= 14 - n8; m2 += 2) {
            int m4 = (14 - n8 - m2) / 2;
            for (uint64_t u : u_orbs[m2]) {
                auto st = get_stab(u & Zmask);
                auto layers = build_subset_orbs(st, n8 / 2);
                // Enumerate all (n2, n4) with 2*n2 + 4*n4 = n8:
                // Choose k4m from layers[n4], then choose k2m disjoint from k4m!
                // Wait: for n4 == 0, k2m is just layers[n2]!
                // For n4 >= 1, pick k4m from layers[n4], get stabilizer of k4m in st (or iterate all orbits of pairs (k4m, k2m))!
                for (int n4 = 0; 4 * n4 <= n8; ++n4) {
                    int n2 = (n8 - 4 * n4) / 2;
                    if (n4 == 0) {
                        for (uint64_t k2m : layers[n2])
                            tasks.push_back({u, k2m, 0ULL, n8, m2, m4, true});
                    } else if (n2 == 0) {
                        for (uint64_t k4m : layers[n4])
                            tasks.push_back({u, 0ULL, k4m, n8, m2, m4, false});
                    } else {
                        // Orbit-reduce (k4m, k2m) incrementally starting from k4m in layers[n4]!
                        for (uint64_t k4m : layers[n4]) {
                            // Stabilizer of k4m inside st (using direct subset of st? No, Schreier inside st!)
                            std::vector<Perm> st4;
                            {
                                Perm id; for (int i = 0; i < 64; ++i) id[i] = i;
                                std::unordered_map<uint64_t, Perm> to_o;
                                std::vector<uint64_t> bfs{k4m}; to_o[k4m] = id;
                                std::set<Perm> sg;
                                for (size_t qi = 0; qi < bfs.size(); ++qi) {
                                    uint64_t c0 = bfs[qi]; Perm tc = to_o[c0];
                                    for (const auto& gp : st) {
                                        uint64_t nx = apply_p64(c0, gp.data());
                                        Perm tn = compose(gp, tc);
                                        auto it = to_o.find(nx);
                                        if (it == to_o.end()) { to_o[nx] = tn; bfs.push_back(nx); }
                                        else {
                                            Perm s = compose(invert_p(it->second), tn);
                                            if (s != id && sg.insert(s).second && st4.size() < 40) st4.push_back(s);
                                        }
                                    }
                                }
                            }
                            // Build n2-subsets disjoint from k4m under st4!
                            std::vector<uint64_t> cur_k2 = {0ULL};
                            for (int kk = 1; kk <= n2; ++kk) {
                                std::vector<uint64_t> nxt_k2;
                                std::unordered_set<uint64_t> vis;
                                for (uint64_t b : cur_k2) {
                                    for (int c : fpts) {
                                        if (((b | k4m) >> c) & 1) continue;
                                        uint64_t m = b | (1ULL << c);
                                        if (vis.count(m)) continue;
                                        nxt_k2.push_back(m);
                                        std::vector<uint64_t> bfs{m}; vis.insert(m);
                                        for (size_t qi = 0; qi < bfs.size(); ++qi)
                                            for (const auto& g : st4) {
                                                uint64_t nx = apply_p64(bfs[qi], g.data());
                                                if (vis.insert(nx).second) bfs.push_back(nx);
                                            }
                                    }
                                }
                                cur_k2 = std::move(nxt_k2);
                            }
                            for (uint64_t k2m : cur_k2)
                                tasks.push_back({u, k2m, k4m, n8, m2, m4, true});
                        }
                    }
                }
            }
        }
        std::atomic<size_t> next_i{0};
        std::atomic<int> total_hits{0};
        std::vector<std::thread> ths;
        for (int ti = 0; ti < 8; ++ti) {
            ths.emplace_back([&]() {
                while (true) {
                    size_t idx = next_i.fetch_add(1);
                    if (idx >= tasks.size()) break;
                    total_hits.fetch_add(run_task(tasks[idx]));
                }
            });
        }
        for (auto& th : ths) th.join();
        std::cout << "DONE (1d) w=0, n8=" << n8 << ": tasks=" << tasks.size() << " hits=" << total_hits.load() << "\n" << std::flush;
    }
    return 0;
}
