// Exact 8-thread solver for ALL (remR == 2, rad_xor != 0) orbits of beta = 1_H at t = 102:
//   - Case II  (H_0): ALL 224 orbits!
//   - Case III (H_1): ALL 894 orbits!
// Because rad_xor != 0 and R_H is even <= 2: R_H == 2 and e_{Hc} == 0 is 100% FORCED,
// and R|_H MUST be 1 at two distinct points {a, b} subset H with a ^ b == rad_xor (16 pairs)!
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <iostream>
#include <map>
#include <mutex>
#include <set>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
    }
}
static inline void fwht16(std::array<int, 16>& a) {
    for (int step = 1; step < 16; step *= 2)
        for (int i = 0; i < 16; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}
static uint8_t rad5_of(uint32_t p) {
    uint8_t B[5] = {};
    int p0 = p & 1;
    for (int i = 0; i < 5; ++i) {
        int pi = (p >> (1 << i)) & 1;
        for (int j = 0; j < 5; ++j) {
            int pj = (p >> (1 << j)) & 1;
            int pij = (p >> ((1 << i) ^ (1 << j))) & 1;
            if (p0 ^ pi ^ pj ^ pij) B[i] |= (1u << j);
        }
    }
    int kcnt = 0, last = 0;
    for (int x = 0; x < 32; ++x) {
        bool ok = true;
        for (int i = 0; i < 5; ++i)
            if (__builtin_parity(B[i] & x)) { ok = false; break; }
        if (ok) { kcnt++; last = x; }
    }
    return (kcnt == 2) ? (uint8_t)last : 0;
}
static inline int xor5_mask(uint32_t m) {
    int r = 0;
    while (m) { int i = __builtin_ctz(m); r ^= i; m &= m - 1; }
    return r;
}

using Perm32 = std::array<uint8_t, 32>;
static inline uint32_t app32(uint32_t m, const Perm32& g) {
    uint32_t out = 0;
    while (m) { int i = __builtin_ctz(m); out |= (1u << g[i]); m &= m - 1; }
    return out;
}
struct PermHash {
    size_t operator()(const Perm32& p) const {
        uint64_t h = 1469598103934665603ULL;
        for (int i = 0; i < 32; ++i) { h ^= p[i]; h *= 1099511628211ULL; }
        return (size_t)h;
    }
};
static std::vector<Perm32> build_stabH(int is_H1) {
    int Hc[32];
    for (int i = 0; i < 32; ++i) Hc[i] = 2 * i + (1 - is_H1);
    std::vector<Perm32> gens;
    for (int v = 2; v < 64; v += 2) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        Perm32 g{};
        for (int i = 0; i < 32; ++i) {
            int x = Hc[i];
            int y = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
            g[i] = (uint8_t)(y >> 1);
        }
        gens.push_back(g);
    }
    Perm32 id{}; for (int i = 0; i < 32; ++i) id[i] = (uint8_t)i;
    std::unordered_set<Perm32, PermHash> vis; vis.reserve(40000);
    std::vector<Perm32> grp{id}; vis.insert(id);
    for (size_t qi = 0; qi < grp.size(); ++qi) {
        const auto cur = grp[qi];
        for (const auto& g : gens) {
            Perm32 nx{};
            for (int i = 0; i < 32; ++i) nx[i] = g[cur[i]];
            if (vis.insert(nx).second) grp.push_back(nx);
        }
    }
    return grp;
}

struct PhaseReducer {
    uint64_t pivs[64]{};
    uint64_t mask = 0;
    void init(uint64_t m) {
        mask = m;
        for (int b = 0; b < 64; ++b) pivs[b] = 0;
        for (int k = 0; k < 7; ++k) {
            uint64_t w = 0;
            for (int c = 0; c < 64; ++c)
                if (k == 6 || ((c >> k) & 1)) w |= (1ULL << c);
            w &= mask;
            while (w) {
                int b = 63 - __builtin_clzll(w);
                if (!pivs[b]) { pivs[b] = w; break; }
                w ^= pivs[b];
            }
        }
    }
    uint64_t reduce(uint64_t w) const {
        w &= mask;
        for (int b = 63; b >= 0; --b)
            if (pivs[b] && ((w >> b) & 1)) w ^= pivs[b];
        return w;
    }
};

using Opts32 = std::array<std::vector<int>, 32>;
using HalfMap = std::unordered_map<uint32_t, std::map<uint32_t, int>>;

static void enum_slice16(int start, int j, std::array<int, 16>& z, const Opts32& opts,
                         std::map<uint16_t, std::vector<std::array<int, 16>>>& out) {
    if (j < 16) {
        for (int v : opts[start + j]) { z[j] = v; enum_slice16(start, j + 1, z, opts, out); }
        return;
    }
    auto u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 15) return;
        int q = u[y] >> 4;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back(u);
}

static void collect_half_minE(const Opts32& opts, HalfMap& by_par, long long& count) {
    by_par.clear(); count = 0;
    std::map<uint16_t, std::vector<std::array<int, 16>>> g0, g1;
    std::array<int, 16> tmp{};
    enum_slice16(0, 0, tmp, opts, g0);
    if (g0.empty()) return;
    enum_slice16(16, 0, tmp, opts, g1);
    if (g1.empty()) return;
    for (auto& [par, v0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a[y]) + std::abs(b[y]) > 4) { ok = false; break; }
                int x0 = (a[y] + b[y]) >> 1, x1 = (a[y] - b[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (uint32_t(1) << y);
                if (x1 & 1) p32 |= (uint32_t(1) << (16 + y));
                if (std::abs(x0) == 2) tw |= (uint32_t(1) << y);
                if (std::abs(x1) == 2) tw |= (uint32_t(1) << (16 + y));
            }
            if (ok) {
                auto& mp = by_par[p32];
                auto it2 = mp.find(tw);
                if (it2 == mp.end() || e2 < it2->second) mp[tw] = e2;
                count++;
            }
        }
    }
}

static int min_join_m(const HalfMap& mt, const HalfMap& ms) {
    int best = 999;
    const HalfMap* sm = &mt; const HalfMap* bg = &ms;
    if (ms.size() < mt.size()) std::swap(sm, bg);
    for (const auto& [p32, tm] : *sm) {
        auto it = bg->find(p32); if (it == bg->end()) continue;
        for (const auto& [tw1, e1] : tm)
            for (const auto& [tw2, e2] : it->second)
                if ((tw1 & tw2) == 0) {
                    int m = (e1 + e2) / 2;
                    if (m < best) best = m;
                }
    }
    return best;
}

struct Slice16S { std::array<int, 16> u; uint16_t m68, sgn; };
static void enum_slice16_S(int start, int j, std::array<int, 16>& z, uint16_t m68, uint16_t sg,
                           const Opts32& opts, uint32_t track_mask,
                           std::map<uint16_t, std::vector<Slice16S>>& out) {
    if (j < 16) {
        int idx = start + j; bool tr = (track_mask >> idx) & 1;
        for (int v : opts[idx]) {
            z[j] = v;
            uint16_t nm = m68 | ((tr && (std::abs(v) == 6 || std::abs(v) == 8)) ? (uint16_t(1) << j) : 0);
            uint16_t ns = sg | ((v < 0) ? (uint16_t(1) << j) : 0);
            enum_slice16_S(start, j + 1, z, nm, ns, opts, track_mask, out);
        }
        return;
    }
    auto u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 15) return;
        int q = u[y] >> 4;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back({u, m68, sg});
}

struct HalfEntryS { uint32_t tw, m68, sgn; int e2; };
static void collect_half_S(const Opts32& opts, uint32_t track_mask,
                           std::unordered_map<uint32_t, std::vector<HalfEntryS>>& out) {
    out.clear();
    std::map<uint16_t, std::vector<Slice16S>> g0, g1;
    std::array<int, 16> tmp{};
    enum_slice16_S(0, 0, tmp, 0, 0, opts, track_mask, g0);
    if (g0.empty()) return;
    enum_slice16_S(16, 0, tmp, 0, 0, opts, track_mask, g1);
    if (g1.empty()) return;
    for (auto& [par, v0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (uint32_t(1) << y);
                if (x1 & 1) p32 |= (uint32_t(1) << (16 + y));
                if (std::abs(x0) == 2) tw |= (uint32_t(1) << y);
                if (std::abs(x1) == 2) tw |= (uint32_t(1) << (16 + y));
            }
            if (ok) {
                uint32_t m68 = uint32_t(a.m68) | (uint32_t(b.m68) << 16);
                uint32_t sg = uint32_t(a.sgn) | (uint32_t(b.sgn) << 16);
                out[p32].push_back({tw, m68, sg, e2});
            }
        }
    }
}

static inline uint64_t interleave_H(uint32_t h_bits, uint32_t hc_bits, int is_H1) {
    uint64_t out = 0;
    for (int i = 0; i < 32; ++i) {
        if ((h_bits >> i) & 1) out |= (1ULL << (2 * i + is_H1));
        if ((hc_bits >> i) & 1) out |= (1ULL << (2 * i + (1 - is_H1)));
    }
    return out;
}

static long long opt_cost(const Opts32& o) {
    long long p0 = 1, p1 = 1;
    for (int i = 0; i < 16; ++i) p0 *= (long long)o[i].size();
    for (int i = 16; i < 32; ++i) p1 *= (long long)o[i].size();
    return p0 + p1;
}

static void solve_case(const std::string& name, int is_H1, int R_max,
                       const std::vector<uint32_t>& all_q,
                       const std::unordered_map<uint32_t, uint8_t>& rad_map) {
    int H_pts[32], Hc_pts[32];
    uint32_t mHZ = 0, mHF = 0, mHcZ = 0, mHcF = 0;
    for (int i = 0; i < 32; ++i) {
        H_pts[i] = 2 * i + is_H1;
        Hc_pts[i] = 2 * i + (1 - is_H1);
        if (Q64[H_pts[i]] == 0) mHZ |= (1u << i); else mHF |= (1u << i);
        if (Q64[Hc_pts[i]] == 0) mHcZ |= (1u << i); else mHcF |= (1u << i);
    }
    auto grp = build_stabH(is_H1);
    std::unordered_map<uint32_t, std::vector<uint32_t>> byZ, byF;
    for (uint32_t q : all_q) {
        byZ[q & mHcZ].push_back(q);
        byF[q & mHcF].push_back(q);
    }
    std::vector<uint32_t> all_smallZ, z1_reps;
    for (const auto& [z, _] : byZ)
        if (z != 0 && __builtin_popcount(z) <= R_max - 2) all_smallZ.push_back(z);
    std::sort(all_smallZ.begin(), all_smallZ.end());
    {
        std::unordered_set<uint32_t> visZ;
        for (uint32_t z : all_smallZ) {
            if (visZ.count(z)) continue;
            z1_reps.push_back(z);
            for (const auto& g : grp) visZ.insert(app32(z, g));
        }
    }
    std::vector<std::vector<uint32_t>> U_reps;
    U_reps.push_back({});
    for (uint32_t z1 : z1_reps) U_reps.push_back({z1});
    {
        std::set<std::vector<uint32_t>> seenU2;
        int max_m2 = R_max - 2;
        int max_min_w = (2 * max_m2) / 3;
        for (uint32_t z1 : z1_reps) {
            int w1 = __builtin_popcount(z1);
            if (w1 > max_min_w) continue;
            std::vector<Perm32> stab1;
            for (const auto& g : grp) if (app32(z1, g) == z1) stab1.push_back(g);
            std::unordered_set<uint32_t> vis2;
            for (uint32_t z2 : all_smallZ) {
                if (z2 == z1 || vis2.count(z2)) continue;
                if (__builtin_popcount(z2) < w1) continue;
                uint32_t z3 = z1 ^ z2;
                if (__builtin_popcount(z3) < w1 || __builtin_popcount(z1 | z2) > max_m2) continue;
                for (const auto& g : stab1) { vis2.insert(app32(z2, g)); vis2.insert(app32(z3, g)); }
                std::vector<uint32_t> U{z1, z2, z3}; std::sort(U.begin(), U.end());
                if (seenU2.count(U)) continue;
                U_reps.push_back(U);
                for (const auto& g : grp) {
                    std::vector<uint32_t> nx{app32(U[0], g), app32(U[1], g), app32(U[2], g)};
                    std::sort(nx.begin(), nx.end()); seenU2.insert(nx);
                }
            }
        }
    }
    std::vector<uint32_t> f_errs[9];
    {
        std::vector<int> fbits;
        for (int i = 0; i < 32; ++i) if ((mHcF >> i) & 1) fbits.push_back(i);
        int nf = (int)fbits.size();
        auto dfs = [&](auto& self, int idx, int w, uint32_t mask) -> void {
            f_errs[w].push_back(mask);
            if (w == R_max - 2) return;
            for (int i = idx; i < nf; ++i) self(self, i + 1, w + 1, mask | (1u << fbits[i]));
        };
        dfs(dfs, 0, 0, 0);
    }

    struct Task {
        std::array<uint32_t, 4> t;
        uint32_t u_union, oddF_mask;
        uint8_t rad_xor;
    };
    std::vector<Task> tasks;
    for (const auto& U : U_reps) {
        int dim = (U.size() == 0) ? 0 : (U.size() == 1 ? 1 : 2);
        uint32_t u_union = 0;
        for (uint32_t z : U) u_union |= z;
        int m2Z = __builtin_popcount(u_union);
        int xZ = xor5_mask(u_union);
        int need_oddF = R_max - 2 - m2Z; // remR == 2!
        if (need_oddF < 0) continue;

        std::vector<Perm32> stabU;
        for (const auto& g : grp) {
            bool ok = true;
            if (dim == 1) ok = (app32(U[0], g) == U[0]);
            else if (dim == 2) {
                uint32_t a0 = app32(U[0], g), a1 = app32(U[1], g);
                ok = ((a0 == U[0] || a0 == U[1] || a0 == U[2]) &&
                      (a1 == U[0] || a1 == U[1] || a1 == U[2]));
            }
            if (ok) stabU.push_back(g);
        }

        uint32_t z1 = (dim >= 1) ? U[0] : 0;
        uint32_t z2 = (dim >= 2) ? U[1] : 0;
        const auto& L1 = byZ[z1];
        const auto& L2 = byZ[z2];

        std::set<std::array<uint32_t, 4>> local_tuples;
        for (uint32_t a : L1) for (uint32_t b : L2) {
            uint32_t prodF = (a & b) & mHcF;
            for (uint32_t e : f_errs[need_oddF]) {
                int xHc = xZ ^ xor5_mask(e);
                int need_rad = 1 ^ xHc;
                if (need_rad == 0) continue; // ONLY rad_xor != 0!
                auto it = byF.find(prodF ^ e);
                if (it == byF.end()) continue;
                for (uint32_t p0 : it->second) {
                    uint32_t p1 = p0 ^ a, p2 = p0 ^ b, p3 = p0 ^ a ^ b ^ mHcF;
                    int rx = rad_map.at(p0) ^ rad_map.at(p1) ^ rad_map.at(p2) ^ rad_map.at(p3);
                    if (rx != need_rad) continue;
                    std::array<uint32_t, 4> t{p0, p1, p2, p3};
                    std::sort(t.begin(), t.end());
                    local_tuples.insert(t);
                }
            }
        }
        std::set<std::array<uint32_t, 4>> visT;
        for (const auto& t : local_tuples) {
            if (visT.count(t)) continue;
            for (const auto& g : stabU) {
                std::array<uint32_t, 4> nx{app32(t[0], g), app32(t[1], g), app32(t[2], g), app32(t[3], g)};
                std::sort(nx.begin(), nx.end());
                visT.insert(nx);
            }
            uint32_t a = t[1] ^ t[0], b = t[2] ^ t[0];
            uint32_t oddF_mask = (t[0] ^ (a & b)) & mHcF;
            uint8_t rx = rad_map.at(t[0]) ^ rad_map.at(t[1]) ^ rad_map.at(t[2]) ^ rad_map.at(t[3]);
            tasks.push_back({t, u_union, oddF_mask, rx});
        }
    }

    std::cout << "\n=== " << name << " (remR==2, rad_nz==1): solving ALL " << tasks.size() << " orbits ===\n" << std::flush;

    std::atomic<size_t> next_i{0};
    std::atomic<long long> n_hc_empty{0}, n_pairs_tested{0}, n_pairs_join{0}, n_joins_102{0}, n_joins_any{0};
    std::mutex mu;

    auto make_opt_s = [&](uint32_t p, uint32_t u_union, uint32_t oddF_mask) {
        Opts32 os;
        for (int i = 0; i < 32; ++i) {
            int pi = (p >> i) & 1;
            if (Q64[Hc_pts[i]] == 1) {
                if ((oddF_mask >> i) & 1) os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 8};
                else os[i] = pi ? std::vector<int>{-12, 12} : std::vector<int>{0};
            } else {
                if (pi) os[i] = {-4, 4};
                else if ((u_union >> i) & 1) os[i] = {0};
                else os[i] = {-8, 0, 8};
            }
        }
        return os;
    };

    auto make_opt_t_base = [&](uint32_t p) {
        Opts32 ot;
        for (int i = 0; i < 32; ++i) {
            int pi = (p >> i) & 1;
            if (Q64[H_pts[i]] == 1) ot[i] = pi ? std::vector<int>{6} : std::vector<int>{-6};
            else ot[i] = pi ? std::vector<int>{-2, 6} : std::vector<int>{-6, 2};
        }
        return ot;
    };

    auto set_val_H = [&](Opts32& ot, uint32_t p, int idx, int abs_v) {
        int pi = (p >> idx) & 1;
        if (abs_v == 2) ot[idx] = pi ? std::vector<int>{-2} : std::vector<int>{2};
        else if (abs_v == 10) ot[idx] = pi ? std::vector<int>{-10} : std::vector<int>{10};
        else ot[idx] = pi ? std::vector<int>{6} : std::vector<int>{-6};
    };

    auto worker = [&]() {
        while (true) {
            size_t ti = next_i.fetch_add(1);
            if (ti >= tasks.size()) break;
            const auto& tk = tasks[ti];

            // Build opt_s for all 4 slices, sort by opt_cost so empty slices abort BEFORE heavy ones!
            Opts32 os[4];
            std::array<int, 4> kord{0, 1, 2, 3};
            for (int k = 0; k < 4; ++k) os[k] = make_opt_s(tk.t[k], tk.u_union, tk.oddF_mask);
            std::sort(kord.begin(), kord.end(), [&](int a, int b){ return opt_cost(os[a]) < opt_cost(os[b]); });

            HalfMap ms[4];
            bool hc_ok = true;
            for (int k : kord) {
                long long cs = 0;
                collect_half_minE(os[k], ms[k], cs);
                if (cs == 0) { hc_ok = false; break; }
            }
            if (!hc_ok) { n_hc_empty.fetch_add(1); continue; }

            // Lazy-initialized full msS (HalfEntryS) for 4-cell join (computed ONLY if some pair passes min_m <= 102!)
            uint32_t Z1 = mHcZ & tk.t[0] & tk.t[1] & tk.t[2] & tk.t[3];
            uint32_t Z0 = mHcZ & ~(tk.t[0] | tk.t[1] | tk.t[2] | tk.t[3]);
            bool msS_ready = false;
            std::unordered_map<uint32_t, std::vector<HalfEntryS>> msS[4];
            auto ensure_msS = [&]() {
                if (msS_ready) return;
                for (int k = 0; k < 4; ++k) collect_half_S(os[k], Z0, msS[k]);
                msS_ready = true;
            };

            auto run_exact_join = [&](const std::array<Opts32, 4>& ot4, uint32_t tgt_e6, uint32_t d3_mask) {
                n_pairs_join.fetch_add(1);
                ensure_msS();
                uint64_t phase64 = interleave_H(0xFFFFFFFFu, Z1 | tk.oddF_mask, is_H1);
                PhaseReducer red; red.init(phase64);
                // sgn_xor == 0 at d3_mask (d_c = 3 on H cap Z), 1 everywhere else in phase64!
                uint64_t raw_tgt = phase64 ^ interleave_H(d3_mask, 0, is_H1);
                uint64_t tgt_sgn = red.reduce(raw_tgt);

                struct Sig {
                    uint32_t e6, e8; int m; uint64_t sgn;
                    bool operator<(const Sig& o) const {
                        if (e6 != o.e6) return e6 < o.e6;
                        if (e8 != o.e8) return e8 < o.e8;
                        if (m != o.m) return m < o.m;
                        return sgn < o.sgn;
                    }
                    bool operator==(const Sig& o) const {
                        return e6 == o.e6 && e8 == o.e8 && m == o.m && sgn == o.sgn;
                    }
                };
                std::array<std::vector<Sig>, 4> sigs;
                for (int k = 0; k < 4; ++k) {
                    std::unordered_map<uint32_t, std::vector<HalfEntryS>> mtS;
                    collect_half_S(ot4[k], mHZ, mtS);
                    for (const auto& [p32, vt] : mtS) {
                        auto its = msS[k].find(p32); if (its == msS[k].end()) continue;
                        for (const auto& et : vt) for (const auto& es : its->second) {
                            if (et.tw & es.tw) continue;
                            int m = (et.e2 + es.e2) / 2;
                            if (m > 64) continue;
                            uint64_t sg = red.reduce(interleave_H(et.sgn, es.sgn, is_H1));
                            sigs[k].push_back({et.m68, es.m68, m, sg});
                        }
                    }
                    std::sort(sigs[k].begin(), sigs[k].end());
                    sigs[k].erase(std::unique(sigs[k].begin(), sigs[k].end()), sigs[k].end());
                    if (sigs[k].empty()) return;
                }
                std::array<int, 4> ord{0, 1, 2, 3};
                std::sort(ord.begin(), ord.end(), [&](int a, int b){ return sigs[a].size() < sigs[b].size(); });
                struct Key {
                    uint32_t e6, e8; uint64_t sgn;
                    bool operator<(const Key& o) const {
                        if (e6 != o.e6) return e6 < o.e6;
                        if (e8 != o.e8) return e8 < o.e8;
                        return sgn < o.sgn;
                    }
                };
                std::map<Key, std::array<uint64_t, 2>> lmap;
                for (const auto& a : sigs[ord[0]]) for (const auto& b : sigs[ord[3]]) {
                    if ((a.e6 & b.e6) || (a.e8 & b.e8)) continue;
                    int m = a.m + b.m; if (m > 102) continue;
                    auto& bm = lmap[{a.e6 | b.e6, a.e8 | b.e8, a.sgn ^ b.sgn}];
                    bm[m >> 6] |= (1ULL << (m & 63));
                }
                for (const auto& c : sigs[ord[1]]) for (const auto& d : sigs[ord[2]]) {
                    if ((c.e6 & d.e6) || (c.e8 & d.e8)) continue;
                    int m = c.m + d.m; if (m > 102) continue;
                    auto it = lmap.find({tgt_e6 ^ (c.e6 | d.e6), Z0 ^ (c.e8 | d.e8), tgt_sgn ^ (c.sgn ^ d.sgn)});
                    if (it != lmap.end()) {
                        n_joins_any.fetch_add(1);
                        int rem = 102 - m;
                        if (it->second[rem >> 6] & (1ULL << (rem & 63))) {
                            n_joins_102.fetch_add(1);
                            std::lock_guard<std::mutex> lk(mu);
                            std::cout << "  [HIT!] task=" << ti << " m2Z=" << __builtin_popcount(tk.u_union)
                                      << " oddF=" << __builtin_popcount(tk.oddF_mask)
                                      << " rad=" << (int)tk.rad_xor << "\n" << std::flush;
                        }
                    }
                }
            };

            // Loop over ALL 16 pairs {a, b} with a < b and a ^ b == rad_xor!
            for (int a = 0; a < 32; ++a) {
                int b = a ^ tk.rad_xor;
                if (b < a) continue;
                n_pairs_tested.fetch_add(1);
                bool aF = (Q64[H_pts[a]] == 1);
                bool bF = (Q64[H_pts[b]] == 1);

                if (!aF && !bF) {
                    // Type ZZ: d_a = d_b = 3
                    int sum_min = 0;
                    std::array<Opts32, 4> ot4;
                    bool ok = true;
                    for (int k = 0; k < 4; ++k) {
                        ot4[k] = make_opt_t_base(tk.t[k]);
                        set_val_H(ot4[k], tk.t[k], a, 2);
                        set_val_H(ot4[k], tk.t[k], b, 2);
                        HalfMap mt; long long ct = 0;
                        collect_half_minE(ot4[k], mt, ct);
                        int m = ct ? min_join_m(mt, ms[k]) : 999;
                        if (m >= 999) { ok = false; break; }
                        sum_min += m;
                        if (sum_min > 102) { ok = false; break; }
                    }
                    if (ok) {
                        uint32_t d3 = (1u << a) | (1u << b);
                        run_exact_join(ot4, mHZ ^ d3, d3);
                    }
                } else if (aF != bF) {
                    // Type ZF
                    int iz = aF ? b : a;
                    int iF = aF ? a : b;
                    int m2[4], m10[4];
                    std::array<Opts32, 4> ot2, ot10;
                    for (int k = 0; k < 4; ++k) {
                        ot2[k] = make_opt_t_base(tk.t[k]);
                        set_val_H(ot2[k], tk.t[k], iz, 2);
                        set_val_H(ot2[k], tk.t[k], iF, 2);
                        HalfMap mt; long long ct = 0;
                        collect_half_minE(ot2[k], mt, ct);
                        m2[k] = ct ? min_join_m(mt, ms[k]) : 999;

                        ot10[k] = ot2[k];
                        set_val_H(ot10[k], tk.t[k], iF, 10);
                        collect_half_minE(ot10[k], mt, ct);
                        m10[k] = ct ? min_join_m(mt, ms[k]) : 999;
                    }
                    for (int j = 0; j < 4; ++j) {
                        int s = m10[j];
                        for (int k = 0; k < 4; ++k) if (k != j) s += m2[k];
                        if (s <= 102) {
                            std::array<Opts32, 4> ot4 = ot2;
                            ot4[j] = ot10[j];
                            uint32_t d3 = (1u << iz);
                            run_exact_join(ot4, mHZ ^ d3, d3);
                        }
                    }
                } else {
                    // Type FF: k_a = k_b = 1
                    int mm[4][4];
                    Opts32 ots[4][4];
                    for (int k = 0; k < 4; ++k) {
                        for (int mask = 0; mask < 4; ++mask) {
                            ots[k][mask] = make_opt_t_base(tk.t[k]);
                            set_val_H(ots[k][mask], tk.t[k], a, (mask & 1) ? 10 : 2);
                            set_val_H(ots[k][mask], tk.t[k], b, (mask & 2) ? 10 : 2);
                            HalfMap mt; long long ct = 0;
                            collect_half_minE(ots[k][mask], mt, ct);
                            mm[k][mask] = ct ? min_join_m(mt, ms[k]) : 999;
                        }
                    }
                    for (int ja = 0; ja < 4; ++ja) for (int jb = 0; jb < 4; ++jb) {
                        int s = 0;
                        for (int k = 0; k < 4; ++k) {
                            int mask = ((k == ja) ? 1 : 0) | ((k == jb) ? 2 : 0);
                            s += mm[k][mask];
                        }
                        if (s <= 102) {
                            std::array<Opts32, 4> ot4;
                            for (int k = 0; k < 4; ++k) {
                                int mask = ((k == ja) ? 1 : 0) | ((k == jb) ? 2 : 0);
                                ot4[k] = ots[k][mask];
                            }
                            run_exact_join(ot4, mHZ, 0);
                        }
                    }
                }
            }
        }
    };

    std::vector<std::thread> ths;
    for (int i = 0; i < 8; ++i) ths.emplace_back(worker);
    for (auto& th : ths) th.join();

    std::cout << "  RESULT " << name << " (remR==2, rad_nz==1): total=" << tasks.size()
              << " hc_empty=" << n_hc_empty.load()
              << " pairs_tested=" << n_pairs_tested.load()
              << " pairs_join=" << n_pairs_join.load()
              << " joins_any=" << n_joins_any.load()
              << " JOINS_102=" << n_joins_102.load() << "\n" << std::flush;
}

int main() {
    init_Q();
    uint32_t mons[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0;
        for (int i = 0; i < 32; ++i) if ((i & m) == m) mask |= (1u << i);
        mons[mk++] = mask;
    }
    std::vector<uint32_t> all_q(65536, 0);
    for (int s = 1; s < 65536; ++s) all_q[s] = all_q[s - 1] ^ mons[__builtin_ctz(s)];
    std::unordered_map<uint32_t, uint8_t> rad_map;
    rad_map.reserve(100000);
    for (uint32_t p : all_q) rad_map[p] = rad5_of(p);

    solve_case("Case II (H_0)", 0, 6, all_q, rad_map);
    solve_case("Case III (H_1)", 1, 8, all_q, rad_map);
    return 0;
}
