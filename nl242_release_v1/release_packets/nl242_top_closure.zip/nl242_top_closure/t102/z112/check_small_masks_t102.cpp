// Small-mask geometry check at t = 102, rank 6, for 9 <= k <= 11.
// PROOF_t102_CLOSED.md uses k = 10 only (B is even at rank 6, and B >= 9 by the
// affine-span argument). B >= 12 is excluded by the mod-3 cell bound instead;
// at k = 12 this geometric filter alone leaves survivors, so the loop stops at 11.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <stdexcept>

namespace {
using Table = std::array<int, 256>;
constexpr std::array<int, 1> targets{102};

int weight(int x) { return __builtin_popcount(static_cast<unsigned>(x)); }
int parity(int x) { return weight(x) % 2; }

void walsh(int* values, int size) {
    for (int h=1; h<size; h*=2)
        for (int b=0; b<size; b+=2*h)
            for (int i=b; i<b+h; ++i) {
                int a=values[i], c=values[i+h];
                values[i]=a+c;
                values[i+h]=a-c;
            }
}

int binary_rank(std::array<int, 8> rows) {
    std::array<int, 8> basis{};
    int rank=0;
    for (int row : rows) {
        for (int j=7; j>=0; --j) {
            if (!(row & (1<<j))) continue;
            if (basis[j]) row ^= basis[j];
            else { basis[j]=row; ++rank; break; }
        }
    }
    return rank;
}

struct Search {
    int k, extras, patterns;
    std::array<int, 6> columns{};
    std::array<int, 64> subset_xor{};
    std::array<unsigned, 257> targets_by_zeros{};
    std::uint64_t geometries=0, eligible_signs=0;
    std::array<std::uint64_t, 1> survivors{};

    explicit Search(int count) : k(count), extras(k-9), patterns(1<<extras) {
        for (unsigned i=0; i<targets.size(); ++i) {
            int t=targets[i];
            if (k%2) {
                targets_by_zeros[(3*t-208)/2-k] |= 1U<<i;
            } else {
                int h=2*t-168-k;
                for (int p=0; 2*p<=h; ++p)
                    targets_by_zeros[t+64-2*h+3*p] |= 1U<<i;
            }
        }
    }

    void rank_six(int sign_mask, int zeros, unsigned candidates) {
        Table signed_sum{}, zero_mask{};
        for (int i=0; i<9; ++i) signed_sum[(1<<i)>>1]=1;
        for (int i=0; i<extras; ++i) signed_sum[columns[i]>>1]=(sign_mask & (1<<i)) ? -1 : 1;
        walsh(signed_sum.data(),256);

        std::array<std::array<int, 2>, 256> slice_xor{}, slice_count{};
        int total_xor=0;
        for (int x=0; x<256; ++x) {
            if (signed_sum[x]%3) continue;
            zero_mask[x]=1;
            total_xor ^= x;
            for (int u=1; u<256; ++u) {
                int bit=parity(x&u);
                slice_xor[u][bit] ^= x;
                ++slice_count[u][bit];
            }
        }
        walsh(zero_mask.data(),256);
        if (zero_mask[0]!=zeros) throw std::logic_error("zero-count mismatch");
        std::array<int, 8> gram{};
        for (int j=0; j<8; ++j) gram[j]=slice_xor[1<<j][1];
        for (unsigned i=0; i<targets.size(); ++i) {
            if (!(candidates & (1U<<i))) continue;
            int t=targets[i], h=2*t-168-k;
            int aligned=(zeros-(t+64-2*h))/3;
            if (!aligned && (total_xor || binary_rank(gram)!=6)) continue;
            int required=64-h+aligned;
            for (int u=1; u<256; ++u) for (int v=u+1; v<256; ++v) {
                int w=u^v;
                if (w<v) continue;
                for (int a=0; a<2; ++a) for (int b=0; b<2; ++b) {
                    int size4=zeros+(1-2*a)*zero_mask[u]+(1-2*b)*zero_mask[v]
                                    +(1-2*(a^b))*zero_mask[w];
                    if (size4!=4*required) continue;
                    if (slice_xor[u][a^1] || slice_xor[v][b^1] || slice_xor[w][a^b^1]) continue;
                    if ((slice_count[u][a^1] | slice_count[v][b^1] | slice_count[w][a^b^1]) & 1) continue;
                    ++survivors[i];
                }
            }
        }
    }

    void inspect() {
        constexpr int powers[]{1,-3,9,-27,81,-243,729,-2187};
        ++geometries;
        std::array<int, 64> sums{};
        for (int y=0; y<patterns; ++y) {
            int dep_weight=weight(y)+weight(subset_xor[y]);
            sums[y]=powers[dep_weight/2];
        }
        walsh(sums.data(),patterns);
        int scale=1<<(k-1);
        for (int s=0; s<patterns; ++s) {
            int numerator=256*(scale+((k%2) ? -sums[s] : sums[s]));
            if (numerator%(3*scale)) throw std::logic_error("nonintegral zero count");
            int zeros=numerator/(3*scale);
            unsigned candidates=targets_by_zeros.at(zeros);
            if (!candidates) continue;
            ++eligible_signs;
            if (k%2) {
                for (unsigned i=0; i<targets.size(); ++i) if (candidates & (1U<<i)) ++survivors[i];
            } else rank_six(s,zeros,candidates);
        }
    }

    void generate(int n, int last, const std::array<int, 9>& prefix) {
        if (n==extras) { inspect(); return; }
        std::array<int, 9> earlier{};
        for (int i=0; i<9; ++i) for (int j=0; j<i; ++j)
            if (prefix[i]==prefix[j]) earlier[i] |= 1<<j;
        for (int col=last+1; col<512; ++col) {
            if (!parity(col) || weight(col)<3) continue;
            bool canonical=true;
            for (int bits=col; bits && canonical; bits &= bits-1)
                canonical=!(earlier[__builtin_ctz(static_cast<unsigned>(bits))] & ~col);
            if (!canonical) continue;
            auto next=prefix;
            for (int i=0; i<9; ++i) next[i]=2*prefix[i]+((col>>i)&1);
            for (int y=0; y<(1<<n); ++y) subset_xor[y+(1<<n)]=subset_xor[y]^col;
            columns[n]=col;
            generate(n+1,col,next);
        }
    }
};
}

int main() {
    for (int k=9; k<=11; ++k) {
        Search s(k);
        s.generate(0,0,{});
        std::cout << "k=" << k << " geometries=" << s.geometries
                  << " zero-count matches=" << s.eligible_signs << " survivors";
        for (auto n : s.survivors) std::cout << ' ' << n;
        std::cout << std::endl;
        if (std::any_of(s.survivors.begin(),s.survivors.end(),[](auto n){return n!=0;})) return 1;
    }
}
