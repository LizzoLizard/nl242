// Parallel bit-sliced Mod-3 Coupled Cell Bound check for cell 1 (|S|=54, wt=10) at f=7 (B=12)
// across ALL unique shift-canonical wt=10 cell support masks of H0_orb#1!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <set>
#include <thread>
#include <unordered_map>
#include <vector>

static int Q64[64], sig0[64];
static void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static void fwht64(std::array<int, 64>& a) {
    for (int st = 1; st < 64; st *= 2)
        for (int i = 0; i < 64; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static void init() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
    }
    std::array<int, 64> q; for (int c = 0; c < 64; ++c) q[c] = Q64[c] ? -1 : 1;
    fwht64(q); for (int y = 0; y < 64; ++y) sig0[y] = q[y] / 8;
}
struct PhaseReducer {
    uint64_t pivs[64]{}; uint64_t mask = 0;
    void init(uint64_t m) {
        mask = m; for (int b = 0; b < 64; ++b) pivs[b] = 0;
        for (int k = 0; k < 7; ++k) {
            uint64_t w = 0;
            for (int c = 0; c < 64; ++c) if (k == 6 || ((c >> k) & 1)) w |= (1ULL << c);
            w &= mask;
            while (w) { int b = 63 - __builtin_clzll(w); if (!pivs[b]) { pivs[b] = w; break; } w ^= pivs[b]; }
        }
    }
    uint64_t reduce(uint64_t w) const {
        w &= mask; for (int b = 63; b >= 0; --b) if (pivs[b] && ((w >> b) & 1)) w ^= pivs[b]; return w;
    }
};
using Opts32 = std::array<std::vector<int>, 32>;
static inline uint64_t interleave_H0(uint32_t h_bits, uint32_t hc_bits) {
    uint64_t out = 0;
    for (int i = 0; i < 32; ++i) {
        if ((h_bits >> i) & 1) out |= (1ULL << (2 * i));
        if ((hc_bits >> i) & 1) out |= (1ULL << (2 * i + 1));
    }
    return out;
}
struct FullHalf { std::array<int8_t, 32> z; uint32_t p32, tw, m68, sgn; int e2; };
static void enum_full_half(const Opts32& opts, uint32_t track_mask,
                           std::unordered_map<uint32_t, std::vector<FullHalf>>& out) {
    out.clear();
    struct Q8 { std::array<int8_t, 8> b, z; uint8_t m68, sgn; };
    auto do_q8 = [&](int start, std::array<std::vector<Q8>, 256>& qout) {
        std::array<int, 8> z{};
        auto dfs = [&](auto& self, int j, uint8_t m68, uint8_t sg) -> void {
            if (j == 8) {
                auto u = z; fwht8(u);
                uint8_t par = 0; std::array<int8_t, 8> b, z8;
                for (int y = 0; y < 8; ++y) {
                    if (u[y] & 7) return;
                    int q = u[y] >> 3; if (std::abs(q) > 8) return;
                    b[y] = (int8_t)q; z8[y] = (int8_t)z[y]; if (q & 1) par |= (uint8_t(1) << y);
                }
                qout[par].push_back({b, z8, m68, sg}); return;
            }
            int idx = start + j; bool tr = (track_mask >> idx) & 1;
            for (int v : opts[idx]) {
                z[j] = v;
                uint8_t nm = m68 | ((tr && (std::abs(v) == 6 || std::abs(v) == 8)) ? (uint8_t(1) << j) : 0);
                uint8_t ns = sg | ((v < 0) ? (uint8_t(1) << j) : 0);
                self(self, j + 1, nm, ns);
            }
        };
        dfs(dfs, 0, 0, 0);
    };
    struct H16 { std::array<int8_t, 16> u, z; uint16_t m68, sgn; };
    auto do_h16 = [&](int start, std::unordered_map<uint16_t, std::vector<H16>>& hout) {
        std::array<std::vector<Q8>, 256> q0, q1; do_q8(start, q0); do_q8(start + 8, q1);
        for (int p8 = 0; p8 < 256; ++p8) {
            if (q0[p8].empty() || q1[p8].empty()) continue;
            for (const auto& a : q0[p8]) for (const auto& b : q1[p8]) {
                std::array<int8_t, 16> u, z16; uint16_t p16 = 0; bool ok = true;
                for (int y = 0; y < 8; ++y) {
                    if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                    int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                    u[y] = (int8_t)s; u[8+y] = (int8_t)d; z16[y] = a.z[y]; z16[8+y] = b.z[y];
                    if (s & 1) p16 |= (uint16_t(1) << y); if (d & 1) p16 |= (uint16_t(1) << (8 + y));
                }
                if (ok) hout[p16].push_back({u, z16, uint16_t(a.m68|(b.m68<<8)), uint16_t(a.sgn|(b.sgn<<8))});
            }
        }
    };
    std::unordered_map<uint16_t, std::vector<H16>> g0, g1;
    do_h16(0, g0); do_h16(16, g1);
    for (const auto& [par, v0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (1u << y); if (x1 & 1) p32 |= (1u << (16 + y));
                if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
            }
            if (ok) {
                std::array<int8_t, 32> z32; for (int i = 0; i < 16; ++i) { z32[i] = a.z[i]; z32[16+i] = b.z[i]; }
                out[p32].push_back({z32, p32, tw, uint32_t(a.m68)|(uint32_t(b.m68)<<16), uint32_t(a.sgn)|(uint32_t(b.sgn)<<16), e2});
            }
        }
    }
}
static uint64_t canon_shift64(uint64_t m) {
    uint64_t best = m;
    for (int s = 1; s < 64; ++s) {
        uint64_t nm = 0, t = m;
        while (t) { int y = __builtin_ctzll(t); nm |= (1ULL << (y ^ s)); t &= t - 1; }
        if (nm < best) best = nm;
    }
    return best;
}

static bool kill_cell_f7_parallel(uint64_t vmask, int target_f) {
    std::vector<int> S_pts, V_pts;
    for (int y = 0; y < 64; ++y) {
        if ((vmask >> y) & 1) V_pts.push_back(y); else S_pts.push_back(y);
    }
    int nS = (int)S_pts.size();
    int B_target = nS - 28 - 2 * target_f;
    uint64_t b1 = 0, b2 = 0;
    for (int c = 0; c < 64; ++c) {
        int s = 0; for (int y : V_pts) s += sig0[y] * (__builtin_parity(y & c) ? -1 : 1);
        s = ((s % 3) + 3) % 3;
        if (s == 1) b1 |= (1ULL << c); else if (s == 2) b2 |= (1ULL << c);
    }
    uint64_t d1[64], d2[64];
    for (int i = 0; i < nS; ++i) {
        int y = S_pts[i]; uint64_t m1 = 0, m2 = 0;
        for (int c = 0; c < 64; ++c) {
            int v = -sig0[y] * (__builtin_parity(y & c) ? -1 : 1);
            if (v == 1) m1 |= (1ULL << c); else m2 |= (1ULL << c);
        }
        d1[i] = m1; d2[i] = m2;
    }
    std::atomic<bool> found{false};
    std::atomic<int> next_i0{0};
    std::vector<std::thread> ths;
    for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&]() {
        auto dfs = [&](auto& self, int idx, int rem, uint64_t a1, uint64_t a2) -> void {
            if (found.load(std::memory_order_relaxed)) return;
            if (rem == 0) {
                if (__builtin_popcountll(a1 | a2) <= B_target) found.store(true, std::memory_order_relaxed);
                return;
            }
            if (rem == 1) {
                uint64_t a0 = ~(a1 | a2);
                for (int i = idx; i < nS; ++i) {
                    // Wait: n1 | n2 = (a0 & (d1|d2)) | (a2 & d2) | (a1 & d1) = a0 | (a1 & d1) | (a2 & d2)!!
                    // Because d1 | d2 = ~0ULL (every entry of d is +-1 mod 3!)!
                    // Check: n1 | n2 = (a0 & d1) | (a2 & d2) | (a1 & d1) | (a0 & d2)
                    //                = a0 | (a1 & d1) | (a2 & d2)
                    //                = ~((a1 & d2) | (a2 & d1))!!
                    // So wt_3 == 64 - popcount((a1 & d2[i]) | (a2 & d1[i]))!!
                    // ONE popcount + 3 bitwise ops per leaf!!
                    int zeros = __builtin_popcountll((a1 & d2[i]) | (a2 & d1[i]));
                    if (64 - zeros <= B_target) { found.store(true, std::memory_order_relaxed); return; }
                }
                return;
            }
            uint64_t a0 = ~(a1 | a2);
            int lim = nS - rem;
            for (int i = idx; i <= lim; ++i) {
                uint64_t n1 = (a0 & d1[i]) | (a2 & d2[i]);
                uint64_t n2 = (a1 & d1[i]) | (a0 & d2[i]);
                self(self, i + 1, rem - 1, n1, n2);
            }
        };
        uint64_t b0 = ~(b1 | b2);
        while (!found.load(std::memory_order_relaxed)) {
            int i0 = next_i0.fetch_add(1);
            if (i0 > nS - target_f) break;
            uint64_t n1 = (b0 & d1[i0]) | (b2 & d2[i0]);
            uint64_t n2 = (b1 & d1[i0]) | (b0 & d2[i0]);
            dfs(dfs, i0 + 1, target_f - 1, n1, n2);
        }
    });
    for (auto& th : ths) th.join();
    return !found.load();
}

int main() {
    auto t0 = std::chrono::steady_clock::now();
    init();
    uint32_t mHZ = 0, mHcZ = 0;
    for (int i = 0; i < 32; ++i) {
        if (Q64[2*i] == 0) mHZ |= (1u << i);
        if (Q64[2*i+1] == 0) mHcZ |= (1u << i);
    }
    std::array<uint32_t, 4> t = {0u, 0u, 0xf0fu, 0xc03f3030u};
    uint32_t track_s = 0x3fc0c080u, m4 = mHcZ & ~track_s;
    std::unordered_map<uint32_t, std::vector<FullHalf>> ms[4];
    for (int k = 0; k < 4; ++k) {
        Opts32 os;
        for (int i = 0; i < 32; ++i) {
            int pi = (t[k] >> i) & 1;
            if (Q64[2*i+1] == 1) os[i] = pi ? std::vector<int>{-12, 12} : std::vector<int>{0};
            else os[i] = ((m4 >> i) & 1) ? std::vector<int>{0} : std::vector<int>{-8, 0, 8};
        }
        enum_full_half(os, track_s, ms[k]);
    }
    uint32_t quads[8] = {0x9000000au, 0x04020802u, 0x01080208u, 0x05000060u,
                         0x80204020u, 0x10402040u, 0x00600a00u, 0x000a6000u};
    uint64_t phase64 = interleave_H0(0xFFFFFFFFu, 0);
    PhaseReducer red; red.init(phase64);
    uint64_t tgt_red = red.reduce(phase64);
    std::set<uint64_t> wt10_masks;
    for (uint32_t qmask : quads) {
        std::array<uint32_t, 4> m2F = {0, qmask, qmask, qmask}, m10F = {qmask, 0, 0, 0};
        struct Row { std::array<int8_t, 64> z; uint32_t e6, e8; int m; uint64_t sr, sred; };
        std::array<std::vector<Row>, 4> rows;
        for (int k = 0; k < 4; ++k) {
            Opts32 ot;
            for (int i = 0; i < 32; ++i) {
                int pi = (t[k] >> i) & 1;
                if (Q64[2*i] == 0) ot[i] = pi ? std::vector<int>{-2, 6} : std::vector<int>{-6, 2};
                else {
                    if ((m2F[k] >> i) & 1) ot[i] = pi ? std::vector<int>{-2} : std::vector<int>{2};
                    else if ((m10F[k] >> i) & 1) ot[i] = pi ? std::vector<int>{-10} : std::vector<int>{10};
                    else ot[i] = pi ? std::vector<int>{6} : std::vector<int>{-6};
                }
            }
            std::unordered_map<uint32_t, std::vector<FullHalf>> mt;
            enum_full_half(ot, mHZ, mt);
            for (const auto& [p32, vt] : mt) {
                auto its = ms[k].find(p32); if (its == ms[k].end()) continue;
                for (const auto& et : vt) for (const auto& es : its->second) {
                    if (et.tw & es.tw) continue;
                    int m = (et.e2 + es.e2) / 2; if (m > 64) continue;
                    std::array<int8_t, 64> z64;
                    for (int i = 0; i < 32; ++i) { z64[2*i] = et.z[i]; z64[2*i+1] = es.z[i]; }
                    uint64_t sr = interleave_H0(et.sgn, es.sgn);
                    rows[k].push_back({z64, et.m68, es.m68, m, sr, red.reduce(sr)});
                }
            }
        }
        std::unordered_map<uint64_t, std::vector<std::pair<int,int>>> lmap;
        for (size_t i = 0; i < rows[0].size(); ++i) for (size_t j = 0; j < rows[3].size(); ++j) {
            const auto &a = rows[0][i], &b = rows[3][j];
            if ((a.e6 & b.e6) || (a.e8 & b.e8)) continue;
            int m = a.m + b.m; if (m > 102) continue;
            lmap[(uint64_t(a.e8 | b.e8) << 8) | uint64_t(m)].push_back({(int)i, (int)j});
        }
        for (size_t i = 0; i < rows[1].size(); ++i) for (size_t j = 0; j < rows[2].size(); ++j) {
            const auto &c = rows[1][i], &d = rows[2][j];
            if ((c.e6 & d.e6) || (c.e8 & d.e8)) continue;
            int m = c.m + d.m; if (m > 102) continue;
            uint32_t e8r = c.e8 | d.e8;
            if ((e8r & track_s) != e8r) continue;
            auto it = lmap.find((uint64_t(track_s ^ e8r) << 8) | uint64_t(102 - m));
            if (it == lmap.end()) continue;
            uint32_t re6 = c.e6 | d.e6;
            for (auto [ia, ib] : it->second) {
                const auto &a = rows[0][ia], &b = rows[3][ib];
                if ((a.e6 | b.e6) & re6) continue;
                if ((a.e6 | b.e6 | re6) != mHZ) continue;
                if ((a.sred ^ b.sred ^ c.sred ^ d.sred) != tgt_red) continue;
                uint64_t diff = a.sr ^ b.sr ^ c.sr ^ d.sr ^ phase64;
                int s0 = diff & 1, lin = 0;
                for (int bit = 0; bit < 5; ++bit) if (((diff >> (2*(1<<bit))) & 1) ^ s0) lin |= (1<<bit);
                for (int u0f = 0; u0f < 2; ++u0f) {
                    bool ok = true;
                    for (int c6 = 0; c6 < 64 && ok; ++c6) {
                        int fl = (s0 ^ (__builtin_parity(lin & (c6>>1)) & 1) ^ ((c6&1)?u0f:0)) ? -1 : 1;
                        int z0 = a.z[c6]*fl, z1 = c.z[c6], z2 = d.z[c6], z3 = b.z[c6];
                        int Vs[4] = {z0+z1+z2+z3, z0-z1+z2-z3, z0+z1-z2-z3, z0-z1-z2+z3};
                        for (int v : Vs) {
                            if (Q64[c6] == 0) { if (v != 0 && std::abs(v) != 8) { ok = false; break; } }
                            else { if (std::abs(v) != 4 && std::abs(v) != 12) { ok = false; break; } }
                        }
                    }
                    if (!ok) continue;
                    std::array<int, 64> tmp;
                    for (int c6 = 0; c6 < 64; ++c6) tmp[c6] = c.z[c6];
                    fwht64(tmp);
                    uint64_t vm = 0; for (int y = 0; y < 64; ++y) if (tmp[y] != 0) vm |= (1ULL << y);
                    if (__builtin_popcountll(vm) == 10) wt10_masks.insert(canon_shift64(vm));
                    for (int c6 = 0; c6 < 64; ++c6) {
                        int fl = (s0 ^ (__builtin_parity(lin & (c6>>1)) & 1) ^ ((c6&1)?u0f:0)) ? -1 : 1;
                        tmp[c6] = a.z[c6] * fl;
                    }
                    fwht64(tmp);
                    vm = 0; for (int y = 0; y < 64; ++y) if (tmp[y] != 0) vm |= (1ULL << y);
                    if (__builtin_popcountll(vm) == 10) wt10_masks.insert(canon_shift64(vm));
                }
            }
        }
    }
    std::cout << "Unique shift-canonical wt=10 masks = " << wt10_masks.size() << "\n" << std::flush;
    int killed = 0;
    for (uint64_t vm : wt10_masks) {
        auto t1 = std::chrono::steady_clock::now();
        bool d = kill_cell_f7_parallel(vm, 7);
        double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t1).count();
        std::cout << "  mask=" << std::hex << vm << std::dec << " f=7 (B=12): " << (d ? "KILLED!" : "SURVIVED!") << " [" << dt << "s]\n" << std::flush;
        if (d) killed++;
    }
    std::cout << "DONE in " << std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count()
              << "s: KILLED " << killed << " / " << wt10_masks.size() << "\n" << std::flush;
    return 0;
}
