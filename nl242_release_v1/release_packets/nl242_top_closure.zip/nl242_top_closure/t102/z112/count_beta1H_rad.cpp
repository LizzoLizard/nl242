#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
    }
}

static uint8_t rad5_of(uint32_t p) {
    uint8_t B[5] = {};
    int p0 = p & 1;
    for (int i = 0; i < 5; ++i) {
        int pi = (p >> (1 << i)) & 1;
        for (int j = 0; j < 5; ++j) {
            int pj = (p >> (1 << j)) & 1;
            int pij = (p >> ((1 << i) ^ (1 << j))) & 1;
            if (p0 ^ pi ^ pj ^ pij) B[i] |= (1u << j);
        }
    }
    int kcnt = 0, last = 0;
    for (int x = 0; x < 32; ++x) {
        bool ok = true;
        for (int i = 0; i < 5; ++i)
            if (__builtin_parity(B[i] & x)) { ok = false; break; }
        if (ok) { kcnt++; last = x; }
    }
    return (kcnt == 2) ? (uint8_t)last : 0;
}

static inline int xor5_mask(uint32_t m) {
    int r = 0;
    while (m) { int i = __builtin_ctz(m); r ^= i; m &= m - 1; }
    return r;
}

static void analyze(const std::string& name, int is_H1, int R_max,
                    const std::vector<uint32_t>& all_q,
                    const std::unordered_map<uint32_t, uint8_t>& rad_map) {
    int Hc[32];
    uint32_t mZ = 0, mF = 0;
    for (int i = 0; i < 32; ++i) {
        Hc[i] = 2 * i + (1 - is_H1);
        if (Q64[Hc[i]] == 0) mZ |= (1u << i);
        else mF |= (1u << i);
    }
    std::vector<std::array<int, 32>> gens;
    for (int v = 2; v < 64; v += 2) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        std::array<int, 32> g{};
        for (int i = 0; i < 32; ++i) {
            int x = Hc[i];
            int y = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
            g[i] = y >> 1;
        }
        gens.push_back(g);
    }
    auto app32 = [&](uint32_t m, const std::array<int, 32>& g) {
        uint32_t out = 0;
        while (m) { int i = __builtin_ctz(m); out |= (1u << g[i]); m &= m - 1; }
        return out;
    };

    // Group all_q by Z-restriction and F-restriction
    std::unordered_map<uint32_t, std::vector<uint32_t>> byZ, byF;
    for (uint32_t q : all_q) {
        byZ[q & mZ].push_back(q);
        byF[q & mF].push_back(q);
    }
    // Check kernel on Z and kernel on F
    std::cout << "\n=== " << name << " (|Z|=" << __builtin_popcount(mZ)
              << ", |F|=" << __builtin_popcount(mF) << ", R_max=" << R_max << ") ===\n";
    std::cout << "  |kerZ|=" << byZ[0].size() << ", |kerF|=" << byF[0].size() << "\n";

    // Wait: every unordered 4-tuple {p0,p1,p2,p3} with p0^p1^p2^p3 = mF has:
    //   U_Z = {0, a_Z, b_Z, a_Z^b_Z} where a_Z = (p1^p0)&mZ, b_Z = (p2^p0)&mZ.
    //   Let m2Z = |a_Z | b_Z| <= R_max!
    //   First enumerate ALL Stab(H)-orbits of subspaces U_Z = span(a_Z, b_Z) with |a_Z | b_Z| <= R_max!
    //   Notice: for a FIXED U_Z:
    //     dim=0: U_Z = {0} (1 orbit)
    //     dim=1: U_Z = {0, z} with wt(z) <= R_max (even, >0)
    //     dim=2: U_Z = {0, z1, z2, z1^z2} with |z1|z2| <= R_max (note wt(z1), wt(z2), wt(z1^z2) all <= R_max!)
    std::vector<uint32_t> smallZ;
    for (const auto& [z, _] : byZ)
        if (z != 0 && __builtin_popcount(z) <= R_max) smallZ.push_back(z);
    std::sort(smallZ.begin(), smallZ.end());

    // Build all U_Z subspaces (canonical sorted tuple of nonzero elements) up to Stab(H)
    std::set<std::vector<uint32_t>> seenU;
    std::vector<std::vector<uint32_t>> U_reps;
    auto add_U = [&](std::vector<uint32_t> U) {
        std::sort(U.begin(), U.end());
        if (seenU.count(U)) return;
        U_reps.push_back(U);
        std::vector<std::vector<uint32_t>> bfs{U}; seenU.insert(U);
        for (size_t qi = 0; qi < bfs.size(); ++qi)
            for (const auto& g : gens) {
                std::vector<uint32_t> nx(bfs[qi].size());
                for (size_t j = 0; j < nx.size(); ++j) nx[j] = app32(bfs[qi][j], g);
                std::sort(nx.begin(), nx.end());
                if (seenU.insert(nx).second) bfs.push_back(nx);
            }
    };
    add_U({}); // dim 0
    for (uint32_t z1 : smallZ) add_U({z1}); // dim 1
    for (size_t i = 0; i < smallZ.size(); ++i)
        for (size_t j = i + 1; j < smallZ.size(); ++j) {
            uint32_t z1 = smallZ[i], z2 = smallZ[j], z3 = z1 ^ z2;
            if (z3 <= z2) continue;
            if (__builtin_popcount(z1 | z2) <= R_max) add_U({z1, z2, z3});
        }
    std::cout << "  Total Stab(H)-orbits of U_Z (m2Z <= " << R_max << "): " << U_reps.size() << "\n";

    // Now for EACH U_Z orbit rep, compute Stab(U_Z) and enumerate ALL valid unordered 4-tuples {p0,p1,p2,p3}
    // up to Stab(U_Z)!
    // Wait: let's track counts by (dimU, m2Z, oddF, rad_xor == 0 vs != 0)!
    std::map<std::tuple<int, int, int, int>, long long> raw_cnt, orb_cnt;
    long long total_raw = 0, total_orbs = 0;

    // Precompute F-words with weight <= R_max? Even better:
    // For fixed (a, b) lifting (z1, z2):
    //   p0^p1^p2^p3 = mF => p1=p0^a, p2=p0^b, p3=p0^a^b^mF.
    //   oddF = wt_F(p0 ^ (a & b)) <= R_max - m2Z!
    //   Wait: how many q in all_q have wt_F(q ^ (a & b)) <= max_oddF?
    //   Better: iterate ALL e subset mF with wt(e) <= max_oddF AND (m2Z + wt(e)) % 2 == 0!
    //   Wait: in Case II (|F|=20, max_oddF=6), C(20,0)+C(20,2)+C(20,4)+C(20,6) = 1+190+4845+38760 = 43,796 (and only ~1/32 hit byF, i.e., ~1,370!!).
    //   In Case III (|F|=16, max_oddF=8), even faster: C(16,0..8 even) = 1+120+1820+8008+12870 = 22,819!
    //   WAIT A SECOND! For fixed (a, b), `a` and `b` ONLY vary over `byZ[z1]` and `byZ[z2]`:
    //     - In Case III: |byZ[z]| = 2!! So only 2*2 = 4 pairs (a, b) per U_Z!!
    //     - In Case II: |byZ[z]| = 32! So up to 32*32 = 1024 pairs (a, b) — STILL tiny!!
    //   EVEN BETTER: if we store all_q as a vector and check `popcount((q ^ prod) & mF) <= max_oddF`,
    //   NO! Iterating `byF` directly takes 32,768 steps, OR enumerating `e` of wt <= max_oddF and checking `byF.find((prod ^ e) & mF)`!
    //   Actually, in Case II, |byF| = 32,768, and 1024 * 32,768 = 33M ops total per U_Z (Wait: we can orbit-reduce (a, b) FIRST under Stab(U_Z)!!).
    //   Let's build Stab(U_Z) or just generate the full group Stab(H)? Wait: |Stab(H)| = 2^4 * |Sp(4,2)| = 16 * 720 = 11,520? Wait: check |Stab(H)|!
    //   Let's compute |Stab(H)|! Actually `|Aut(Q)| = |O^-(6,2)| = 51,840`, and `51,840 / 63`? Wait: `51,840 * 2` or `51,840`?
    //   Wait: `O^-(6,2)` has order `51,840`. Wait: `51,840 / 63` is NOT an integer! `63` is # of hyperplanes in `AGL(6,2)`?
    //   Recall `Aut(Q)` includes translations? NO, translations don't preserve `Q` unless in radical, wait: our 63 transvections generate `O^-(6,2)` (`51,840`)? No, `2^5 * ...`? Let's just print the orbit sizes of `U_Z` and use BFS with `gens`!

    // For fast orbit-reduction of 4-tuples: we only need `Stab(U_Z)`? Even easier:
    // For each U_Z rep, collect all valid 4-tuples `{p0,p1,p2,p3}` (passing parity + rad law!),
    // then orbit-reduce the 4-tuples using `gens` (or keep a global `seen_tuple` set? Wait: global `seen_tuple` would BFS across all `U_Z` in the orbit, which might be large, OR we can compute `Stab(U_Z)` once!).
    // Wait: how big is `Stab(H)`? Let's check: `65,536` elements split into `74` orbits, average orbit size ~`885`, max orbit size ~`2880` -> `|Stab(H)|` is probably `5760` or `2880` or `11520` or `23040`!
    // Wait: `63` hyperplanes of each type: `|O^-(6,2)|`? Wait: `Q` has 28 zeros and 36 ones in `F_2^6` (which is affine, 64 pts!).
    // `Sp(6, 2)` has order `1,451,520`, `O^-(6, 2)` has order `51,840`, and `51,840` DOES divide `1,451,520` (`28`), wait: `1,451,520 / 63 = 23,040`? Wait: `63` affine hyperplanes of type `(16,16)`: `51,840` doesn't divide by `63`, wait `63 = 2^6 - 1` -> `Aut(Q)` in `AGL(6, 2)` is `Sp(6, 2)`!!
    // Because EVERY linear symplectic map `A in Sp(6, 2)` changes `Q` by a linear functional `L`, which is cancelled by a UNIQUE translation `x -> x + v`!
    // So `|Aut(Q)| = |Sp(6, 2)| = 1,451,520`!!
    // And `|Stab(H)| = 1,451,520 / 63 = 23,040`!!
    // Let's check: `23,040` is small enough? Even better: we don't need to enumerate `23,040` elements; for each `U_Z` rep, let's FIRST count raw tuples `{p0,p1,p2,p3}` passing the 6-bit Mod-16 Radical Law!

    // Precompute F-patterns of weight <= R_max
    std::vector<uint32_t> f_errs[9];
    {
        std::vector<int> fbits;
        for (int i = 0; i < 32; ++i) if ((mF >> i) & 1) fbits.push_back(i);
        int nf = (int)fbits.size();
        auto dfs = [&](auto& self, int idx, int w, uint32_t mask) -> void {
            f_errs[w].push_back(mask);
            if (w == R_max) return;
            for (int i = idx; i < nf; ++i) self(self, i + 1, w + 1, mask | (1u << fbits[i]));
        };
        dfs(dfs, 0, 0, 0);
    }

    for (const auto& U : U_reps) {
        int dim = (U.size() == 0) ? 0 : (U.size() == 1 ? 1 : 2);
        uint32_t u_union = 0;
        for (uint32_t z : U) u_union |= z;
        int m2Z = __builtin_popcount(u_union);
        int xZ = xor5_mask(u_union);
        int max_oddF = R_max - m2Z;

        uint32_t z1 = (dim >= 1) ? U[0] : 0;
        uint32_t z2 = (dim >= 2) ? U[1] : 0;
        const auto& L1 = byZ[z1];
        const auto& L2 = byZ[z2];

        // Deduplicate valid 4-tuples for this U_Z rep
        std::set<std::array<uint32_t, 4>> local_tuples;
        for (uint32_t a : L1) {
            for (uint32_t b : L2) {
                uint32_t prodF = (a & b) & mF;
                for (int w = (m2Z & 1); w <= max_oddF; w += 2) {
                    for (uint32_t e : f_errs[w]) {
                        auto it = byF.find(prodF ^ e);
                        if (it == byF.end()) continue;
                        int xHc = xZ ^ xor5_mask(e);
                        for (uint32_t p0 : it->second) {
                            uint32_t p1 = p0 ^ a;
                            uint32_t p2 = p0 ^ b;
                            uint32_t p3 = p0 ^ a ^ b ^ mF;
                            int rad_xor = rad_map.at(p0) ^ rad_map.at(p1) ^ rad_map.at(p2) ^ rad_map.at(p3);
                            if (xHc != (1 ^ rad_xor)) continue;
                            std::array<uint32_t, 4> t{p0, p1, p2, p3};
                            std::sort(t.begin(), t.end());
                            local_tuples.insert(t);
                        }
                    }
                }
            }
        }
        for (const auto& t : local_tuples) {
            int rad_xor = rad_map.at(t[0]) ^ rad_map.at(t[1]) ^ rad_map.at(t[2]) ^ rad_map.at(t[3]);
            // Compute oddF directly from t
            uint32_t a = t[1] ^ t[0], b = t[2] ^ t[0];
            int oddF = __builtin_popcount((t[0] ^ (a & b)) & mF);
            raw_cnt[{dim, m2Z, oddF, rad_xor != 0}]++;
            total_raw++;
        }
    }
    std::cout << "  Total raw tuples (across U_Z reps, passing 6-bit Mod-16 Rad Law): " << total_raw << "\n";
    for (const auto& [k, v] : raw_cnt) {
        auto [dim, m2Z, oddF, rnz] = k;
        std::cout << "    dim=" << dim << " m2Z=" << m2Z << " oddF=" << oddF
                  << " remR=" << (R_max - m2Z - oddF) << " rad_nz=" << rnz << ": " << v << "\n";
    }
}

int main() {
    init_Q();
    uint32_t mons[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0;
        for (int i = 0; i < 32; ++i) if ((i & m) == m) mask |= (1u << i);
        mons[mk++] = mask;
    }
    std::vector<uint32_t> all_q(65536, 0);
    for (int s = 1; s < 65536; ++s) all_q[s] = all_q[s - 1] ^ mons[__builtin_ctz(s)];

    // Verify Mod-16 Radical theorem algebraically across ALL 65,536 words of RM(2, 5)!
    std::unordered_map<uint32_t, uint8_t> rad_map;
    rad_map.reserve(100000);
    uint32_t hyp_mask[32] = {};
    for (int a = 1; a < 32; ++a)
        for (int c = 0; c < 32; ++c)
            if (__builtin_parity(a & c)) hyp_mask[a] |= (1u << c);
    for (uint32_t p : all_q) {
        if (__builtin_popcount(p) % 4 != 0) {
            std::cerr << "FAIL: wt(p) not div by 4!\n"; return 1;
        }
        uint8_t r = rad5_of(p);
        for (int a = 1; a < 32; ++a) {
            int w = __builtin_popcount(p & hyp_mask[a]);
            if ((w & 1) || (((w >> 1) & 1) != (__builtin_parity(a & r) & 1))) {
                std::cerr << "FAIL: rad5 theorem failed for p=" << p << " a=" << a << "\n"; return 1;
            }
        }
        rad_map[p] = r;
    }
    std::cout << "[VERIFIED] Mod-16 Radical Law holds for ALL 65,536 words of RM(2, 5)!\n";

    analyze("Case II (H_0)", 0, 6, all_q, rad_map);
    analyze("Case III (H_1)", 1, 8, all_q, rad_map);
    return 0;
}
