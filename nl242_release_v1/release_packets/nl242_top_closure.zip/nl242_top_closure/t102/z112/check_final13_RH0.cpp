// Audit rad_xor on all 13 remR in {6, 8} orbits and solve RH = 0 (2*eHc = remR) whenever rad_xor == 0!
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <set>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static inline void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
    }
}
static uint8_t rad5_of(uint32_t p) {
    uint8_t B[5] = {}; int p0 = p & 1;
    for (int i = 0; i < 5; ++i) {
        int pi = (p >> (1 << i)) & 1;
        for (int j = 0; j < 5; ++j) {
            int pj = (p >> (1 << j)) & 1, pij = (p >> ((1 << i) ^ (1 << j))) & 1;
            if (p0 ^ pi ^ pj ^ pij) B[i] |= (1u << j);
        }
    }
    int kcnt = 0, last = 0;
    for (int x = 0; x < 32; ++x) {
        bool ok = true;
        for (int i = 0; i < 5; ++i) if (__builtin_parity(B[i] & x)) { ok = false; break; }
        if (ok) { kcnt++; last = x; }
    }
    return (kcnt == 2) ? (uint8_t)last : 0;
}
static inline int xor5_mask(uint32_t m) {
    int r = 0; while (m) { int i = __builtin_ctz(m); r ^= i; m &= m - 1; } return r;
}
using Perm32 = std::array<uint8_t, 32>;
static inline uint32_t app32(uint32_t m, const Perm32& g) {
    uint32_t out = 0; while (m) { int i = __builtin_ctz(m); out |= (1u << g[i]); m &= m - 1; } return out;
}
struct PermHash {
    size_t operator()(const Perm32& p) const {
        uint64_t h = 1469598103934665603ULL;
        for (int i = 0; i < 32; ++i) { h ^= p[i]; h *= 1099511628211ULL; }
        return (size_t)h;
    }
};
static std::vector<Perm32> build_stabH(int is_H1) {
    std::vector<Perm32> gens;
    for (int v = 2; v < 64; v += 2) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        Perm32 g{};
        for (int i = 0; i < 32; ++i) {
            int x = 2 * i + (1 - is_H1);
            int y = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
            g[i] = (uint8_t)(y >> 1);
        }
        gens.push_back(g);
    }
    Perm32 id{}; for (int i = 0; i < 32; ++i) id[i] = (uint8_t)i;
    std::unordered_set<Perm32, PermHash> vis; vis.reserve(40000);
    std::vector<Perm32> grp{id}; vis.insert(id);
    for (size_t qi = 0; qi < grp.size(); ++qi) {
        const auto cur = grp[qi];
        for (const auto& g : gens) {
            Perm32 nx{}; for (int i = 0; i < 32; ++i) nx[i] = g[cur[i]];
            if (vis.insert(nx).second) grp.push_back(nx);
        }
    }
    return grp;
}
using Opts32 = std::array<std::vector<int>, 32>;
using HalfMap = std::unordered_map<uint32_t, std::map<uint32_t, int>>;
static inline uint16_t compute_q16(const std::array<int8_t, 16>& u) {
    uint16_t q = 0; for (int y = 0; y < 16; ++y) if ((u[y] >> 1) & 1) q |= (uint16_t(1) << y); return q;
}
struct Slice8 { std::array<int8_t, 8> b; };
static void enum_q8(int start, int j, std::array<int, 8>& z, const Opts32& opts, std::array<std::vector<Slice8>, 256>& out) {
    if (j == 8) {
        auto u = z; fwht8(u); uint8_t par = 0; std::array<int8_t, 8> b;
        for (int y = 0; y < 8; ++y) {
            if (u[y] & 7) return;
            int q = u[y] >> 3; if (std::abs(q) > 8) return;
            b[y] = (int8_t)q; if (q & 1) par |= (uint8_t(1) << y);
        }
        out[par].push_back({b}); return;
    }
    for (int v : opts[start + j]) { z[j] = v; enum_q8(start, j + 1, z, opts, out); }
}
struct Slice16 { std::array<int8_t, 16> u; uint16_t q16; };
static void collect_minE(const Opts32& opts, HalfMap& out) {
    out.clear();
    auto do16 = [&](int start, std::unordered_map<uint16_t, std::vector<Slice16>>& h) {
        std::array<std::vector<Slice8>, 256> q0, q1; std::array<int, 8> tmp{};
        enum_q8(start, 0, tmp, opts, q0); enum_q8(start + 8, 0, tmp, opts, q1);
        for (int p8 = 0; p8 < 256; ++p8) for (const auto& a : q0[p8]) for (const auto& b : q1[p8]) {
            std::array<int8_t, 16> u; uint16_t p16 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                u[y] = (int8_t)s; u[8 + y] = (int8_t)d;
                if (s & 1) p16 |= (uint16_t(1) << y); if (d & 1) p16 |= (uint16_t(1) << (8 + y));
            }
            if (ok) h[p16].push_back({u, compute_q16(u)});
        }
    };
    std::unordered_map<uint16_t, std::vector<Slice16>> g0, g1;
    do16(0, g0); if (g0.empty()) return;
    do16(16, g1); if (g1.empty()) return;
    for (const auto& [par, v0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (1u << y); if (x1 & 1) p32 |= (1u << (16 + y));
                if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
            }
            if (ok) { auto& mp = out[p32]; auto it2 = mp.find(tw); if (it2 == mp.end() || e2 < it2->second) mp[tw] = e2; }
        }
    }
}
static int min_join_m(const HalfMap& mt, const HalfMap& ms) {
    int best = 999;
    const HalfMap *sm = &mt, *bg = &ms;
    if (ms.size() < mt.size()) std::swap(sm, bg);
    for (const auto& [p32, tm] : *sm) {
        auto it = bg->find(p32); if (it == bg->end()) continue;
        for (const auto& [tw1, e1] : tm)
            for (const auto& [tw2, e2] : it->second)
                if ((tw1 & tw2) == 0) best = std::min(best, (e1 + e2) / 2);
    }
    return best;
}

struct HcCfg { uint32_t m4, k3, k2, k4; };
static std::vector<HcCfg> enum_Hc_orbits(int two_eHc, uint32_t Z0, uint32_t oddF, uint32_t evenF,
                                         const std::vector<Perm32>& stabT) {
    std::vector<int> z0b, ofb, efb;
    for (int i = 0; i < 32; ++i) {
        if ((Z0 >> i) & 1) z0b.push_back(i);
        if ((oddF >> i) & 1) ofb.push_back(i);
        if ((evenF >> i) & 1) efb.push_back(i);
    }
    struct Item { int type, pos, cost; };
    std::vector<Item> items;
    for (int p : z0b) items.push_back({0, p, 2});
    for (int p : ofb) items.push_back({1, p, 2});
    for (int p : efb) items.push_back({2, p, 2});
    std::vector<HcCfg> raw;
    auto dfs = [&](auto& self, size_t idx, int rem, uint32_t m4, uint32_t k3, uint32_t k2, uint32_t k4) -> void {
        if (rem == 0) { raw.push_back({m4, k3, k2, k4}); return; }
        for (size_t i = idx; i < items.size(); ++i) {
            const auto& it = items[i];
            if (it.cost <= rem) {
                uint32_t bit = 1u << it.pos;
                if (it.type == 0) self(self, i + 1, rem - 2, m4 | bit, k3, k2, k4);
                else if (it.type == 1) self(self, i + 1, rem - 2, m4, k3 | bit, k2, k4);
                else {
                    self(self, i + 1, rem - 2, m4, k3, k2 | bit, k4);
                    if (rem >= 4) self(self, i + 1, rem - 4, m4, k3, k2, k4 | bit);
                }
            }
        }
    };
    dfs(dfs, 0, two_eHc, 0, 0, 0, 0);
    std::set<std::tuple<uint32_t, uint32_t, uint32_t, uint32_t>> vis;
    std::vector<HcCfg> reps;
    for (const auto& c : raw) {
        auto key = std::make_tuple(c.m4, c.k3, c.k2, c.k4);
        if (vis.count(key)) continue;
        reps.push_back(c);
        for (const auto& g : stabT)
            vis.insert({app32(c.m4, g), app32(c.k3, g), app32(c.k2, g), app32(c.k4, g)});
    }
    return reps;
}

int main() {
    init_Q();
    uint32_t mons[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0;
        for (int i = 0; i < 32; ++i) if ((i & m) == m) mask |= (1u << i);
        mons[mk++] = mask;
    }
    std::vector<uint32_t> all_q(65536, 0);
    for (int s = 1; s < 65536; ++s) all_q[s] = all_q[s - 1] ^ mons[__builtin_ctz(s)];
    std::unordered_map<uint32_t, uint8_t> rad_map;
    for (uint32_t p : all_q) rad_map[p] = rad5_of(p);

    for (int is_H1 : {0, 1}) {
        int R_max = is_H1 ? 8 : 6;
        int H_pts[32], Hc_pts[32];
        uint32_t mHcZ = 0, mHcF = 0;
        for (int i = 0; i < 32; ++i) {
            H_pts[i] = 2 * i + is_H1; Hc_pts[i] = 2 * i + (1 - is_H1);
            if (Q64[Hc_pts[i]] == 0) mHcZ |= (1u << i); else mHcF |= (1u << i);
        }
        auto grp = build_stabH(is_H1);
        std::unordered_map<uint32_t, std::vector<uint32_t>> byZ, byF;
        for (uint32_t q : all_q) { byZ[q & mHcZ].push_back(q); byF[q & mHcF].push_back(q); }
        std::vector<std::vector<uint32_t>> U_reps{{}};
        if (R_max == 8) {
            std::unordered_set<uint32_t> visZ;
            for (const auto& [z, _] : byZ)
                if (z != 0 && __builtin_popcount(z) == 2 && !visZ.count(z)) {
                    U_reps.push_back({z});
                    for (const auto& g : grp) visZ.insert(app32(z, g));
                }
        }
        std::vector<uint32_t> f_errs[3];
        std::vector<int> fbits;
        for (int i = 0; i < 32; ++i) if ((mHcF >> i) & 1) fbits.push_back(i);
        f_errs[0].push_back(0);
        for (size_t i = 0; i < fbits.size(); ++i)
            for (size_t j = i + 1; j < fbits.size(); ++j)
                f_errs[2].push_back((1u << fbits[i]) | (1u << fbits[j]));

        int oid = 0;
        for (const auto& U : U_reps) {
            int dim = (int)U.size();
            uint32_t u_union = dim ? U[0] : 0;
            int m2Z = __builtin_popcount(u_union), xZ = xor5_mask(u_union);
            std::vector<Perm32> stabU;
            for (const auto& g : grp) if (dim == 0 || app32(U[0], g) == U[0]) stabU.push_back(g);
            std::set<std::array<uint32_t, 4>> local_tuples;
            for (uint32_t a : byZ[u_union]) for (uint32_t b : byZ[0]) {
                uint32_t prodF = (a & b) & mHcF;
                for (int w = 0; w <= (R_max - 6 - m2Z); w += 2) {
                    for (uint32_t e : f_errs[w]) {
                        int need_rad = 1 ^ xZ ^ xor5_mask(e);
                        auto it = byF.find(prodF ^ e); if (it == byF.end()) continue;
                        for (uint32_t p0 : it->second) {
                            uint32_t p1 = p0 ^ a, p2 = p0 ^ b, p3 = p0 ^ a ^ b ^ mHcF;
                            if ((rad_map.at(p0)^rad_map.at(p1)^rad_map.at(p2)^rad_map.at(p3)) != need_rad) continue;
                            std::array<uint32_t, 4> t{p0, p1, p2, p3}; std::sort(t.begin(), t.end());
                            local_tuples.insert(t);
                        }
                    }
                }
            }
            std::set<std::array<uint32_t, 4>> visT;
            for (const auto& t : local_tuples) {
                if (visT.count(t)) continue;
                std::vector<Perm32> stabT;
                for (const auto& g : stabU) {
                    std::array<uint32_t, 4> nx{app32(t[0], g), app32(t[1], g), app32(t[2], g), app32(t[3], g)};
                    std::sort(nx.begin(), nx.end()); visT.insert(nx);
                    if (nx == t) stabT.push_back(g);
                }
                uint32_t a = t[1] ^ t[0], b = t[2] ^ t[0];
                uint32_t oddF = (t[0] ^ (a & b)) & mHcF;
                uint32_t Z0 = mHcZ & ~(t[0] | t[1] | t[2] | t[3]);
                uint32_t evenF = mHcF & ~oddF;
                int remR = R_max - m2Z - __builtin_popcount(oddF);
                uint8_t rx = rad_map.at(t[0]) ^ rad_map.at(t[1]) ^ rad_map.at(t[2]) ^ rad_map.at(t[3]);
                std::cout << (is_H1 ? "H1" : "H0") << "_orb#" << oid << " remR=" << remR
                          << " rad_xor=" << (int)rx << " |StabT|=" << stabT.size() << "\n";
                if (rx == 0) {
                    auto cfgs = enum_Hc_orbits(remR, Z0, oddF, evenF, stabT);
                    std::cout << "  -> rad_xor==0! Testing " << cfgs.size() << " RH=0 Hc-orbits!\n" << std::flush;
                    // Build H_RH0 HalfMaps once per slice (only 1 option on H^F, 2 on H^Z)!
                    HalfMap mt[4];
                    for (int k = 0; k < 4; ++k) {
                        Opts32 ot;
                        for (int i = 0; i < 32; ++i) {
                            int pi = (t[k] >> i) & 1;
                            if (Q64[H_pts[i]] == 0) ot[i] = pi ? std::vector<int>{-2, 6} : std::vector<int>{-6, 2};
                            else ot[i] = pi ? std::vector<int>{6} : std::vector<int>{-6};
                        }
                        collect_minE(ot, mt[k]);
                    }
                    int surv = 0;
                    for (const auto& c : cfgs) {
                        int sum_m = 0; bool ok = true;
                        for (int k = 0; k < 4; ++k) {
                            Opts32 os;
                            for (int i = 0; i < 32; ++i) {
                                int pi = (t[k] >> i) & 1;
                                if (Q64[Hc_pts[i]] == 1) {
                                    if ((oddF >> i) & 1) {
                                        if ((c.k3 >> i) & 1) os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{0};
                                        else os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 8};
                                    } else if ((c.k2 >> i) & 1) os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 0, 8};
                                    else if ((c.k4 >> i) & 1) os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{0};
                                    else os[i] = pi ? std::vector<int>{-12, 12} : std::vector<int>{0};
                                } else {
                                    if (pi) os[i] = {-4, 4};
                                    else if (((u_union | c.m4) >> i) & 1) os[i] = {0};
                                    else os[i] = {-8, 0, 8};
                                }
                            }
                            HalfMap ms; collect_minE(os, ms);
                            int mk_m = min_join_m(mt[k], ms);
                            if (mk_m >= 999) { ok = false; break; }
                            sum_m += mk_m;
                            if (sum_m > 102) { ok = false; break; }
                        }
                        if (ok) surv++;
                    }
                    std::cout << "  -> RH=0 survivors (sum_min_m <= 102): " << surv << " / " << cfgs.size() << "\n" << std::flush;
                }
                oid++;
            }
        }
    }
    return 0;
}
