// ULTRA-FAST q16-filtered exact solver for:
//   - Case II  (H_0): remR == 4 (R_H in {0, 2}, 26 orbs) + dump 7 remR == 6 orbs
//   - Case III (H_1): remR == 2, rad==0 (60 orbs) + remR == 4 (R_H in {0, 2}, 58 orbs) + dump 4 remR==6 & 2 remR==8 orbs
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <mutex>
#include <set>
#include <stdexcept>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
    }
}
static inline void fwht8(std::array<int, 8>& a) {
    for (int step = 1; step < 8; step *= 2)
        for (int i = 0; i < 8; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}
static uint8_t rad5_of(uint32_t p) {
    uint8_t B[5] = {};
    int p0 = p & 1;
    for (int i = 0; i < 5; ++i) {
        int pi = (p >> (1 << i)) & 1;
        for (int j = 0; j < 5; ++j) {
            int pj = (p >> (1 << j)) & 1;
            int pij = (p >> ((1 << i) ^ (1 << j))) & 1;
            if (p0 ^ pi ^ pj ^ pij) B[i] |= (1u << j);
        }
    }
    int kcnt = 0, last = 0;
    for (int x = 0; x < 32; ++x) {
        bool ok = true;
        for (int i = 0; i < 5; ++i)
            if (__builtin_parity(B[i] & x)) { ok = false; break; }
        if (ok) { kcnt++; last = x; }
    }
    return (kcnt == 2) ? (uint8_t)last : 0;
}
static inline int xor5_mask(uint32_t m) {
    int r = 0;
    while (m) { int i = __builtin_ctz(m); r ^= i; m &= m - 1; }
    return r;
}

using Perm32 = std::array<uint8_t, 32>;
static inline uint32_t app32(uint32_t m, const Perm32& g) {
    uint32_t out = 0;
    while (m) { int i = __builtin_ctz(m); out |= (1u << g[i]); m &= m - 1; }
    return out;
}
struct PermHash {
    size_t operator()(const Perm32& p) const {
        uint64_t h = 1469598103934665603ULL;
        for (int i = 0; i < 32; ++i) { h ^= p[i]; h *= 1099511628211ULL; }
        return (size_t)h;
    }
};
static std::vector<Perm32> build_stabH(int is_H1) {
    std::vector<Perm32> gens;
    for (int v = 2; v < 64; v += 2) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        Perm32 g{};
        for (int i = 0; i < 32; ++i) {
            int x = 2 * i + (1 - is_H1);
            int y = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
            g[i] = (uint8_t)(y >> 1);
        }
        gens.push_back(g);
    }
    Perm32 id{}; for (int i = 0; i < 32; ++i) id[i] = (uint8_t)i;
    std::unordered_set<Perm32, PermHash> vis; vis.reserve(40000);
    std::vector<Perm32> grp{id}; vis.insert(id);
    for (size_t qi = 0; qi < grp.size(); ++qi) {
        const auto cur = grp[qi];
        for (const auto& g : gens) {
            Perm32 nx{};
            for (int i = 0; i < 32; ++i) nx[i] = g[cur[i]];
            if (vis.insert(nx).second) grp.push_back(nx);
        }
    }
    return grp;
}

struct PhaseReducer {
    uint64_t pivs[64]{};
    uint64_t mask = 0;
    void init(uint64_t m) {
        mask = m;
        for (int b = 0; b < 64; ++b) pivs[b] = 0;
        for (int k = 0; k < 7; ++k) {
            uint64_t w = 0;
            for (int c = 0; c < 64; ++c)
                if (k == 6 || ((c >> k) & 1)) w |= (1ULL << c);
            w &= mask;
            while (w) {
                int b = 63 - __builtin_clzll(w);
                if (!pivs[b]) { pivs[b] = w; break; }
                w ^= pivs[b];
            }
        }
    }
    uint64_t reduce(uint64_t w) const {
        w &= mask;
        for (int b = 63; b >= 0; --b)
            if (pivs[b] && ((w >> b) & 1)) w ^= pivs[b];
        return w;
    }
};

using Opts32 = std::array<std::vector<int>, 32>;
using HalfMap = std::unordered_map<uint32_t, std::map<uint32_t, int>>;

static inline uint64_t interleave_H(uint32_t h_bits, uint32_t hc_bits, int is_H1) {
    uint64_t out = 0;
    for (int i = 0; i < 32; ++i) {
        if ((h_bits >> i) & 1) out |= (1ULL << (2 * i + is_H1));
        if ((hc_bits >> i) & 1) out |= (1ULL << (2 * i + (1 - is_H1)));
    }
    return out;
}
static inline uint16_t compute_q16(const std::array<int8_t, 16>& u) {
    uint16_t q = 0;
    for (int y = 0; y < 16; ++y)
        if ((u[y] >> 1) & 1) q |= (uint16_t(1) << y);
    return q;
}
static long long opt_cost(const Opts32& o) {
    long long p0 = 1, p1 = 1;
    for (int i = 0; i < 16; ++i) p0 *= (long long)o[i].size();
    for (int i = 16; i < 32; ++i) p1 *= (long long)o[i].size();
    return p0 + p1;
}

// ---------- Fast 8x8 HalfMap + q16-filtered min_m against known mt! ----------
struct U16Q { std::array<int8_t, 16> u; uint16_t q16; };
struct HalfByQ {
    std::vector<U16Q> all;
    std::unordered_map<uint16_t, std::vector<uint32_t>> by_q;
};

static void enum_slice8_plain(int start, int j, std::array<int, 8>& z, const Opts32& opts,
                              std::array<std::vector<std::array<int8_t, 8>>, 256>& out) {
    if (j < 8) {
        for (int v : opts[start + j]) { z[j] = v; enum_slice8_plain(start, j + 1, z, opts, out); }
        return;
    }
    auto u = z; fwht8(u);
    uint8_t par = 0; std::array<int8_t, 8> b;
    for (int y = 0; y < 8; ++y) {
        if (u[y] & 7) return;
        int q = u[y] >> 3; if (std::abs(q) > 8) return;
        b[y] = (int8_t)q; if (q & 1) par |= (uint8_t(1) << y);
    }
    out[par].push_back(b);
}

static void enum_slice16_by_par(int start, const Opts32& opts,
                                const std::unordered_map<uint16_t, std::vector<uint16_t>>* allowed_par,
                                std::unordered_map<uint16_t, HalfByQ>& out) {
    std::array<std::vector<std::array<int8_t, 8>>, 256> q0, q1;
    std::array<int, 8> tmp{};
    enum_slice8_plain(start, 0, tmp, opts, q0);
    enum_slice8_plain(start + 8, 0, tmp, opts, q1);
    for (int par8 = 0; par8 < 256; ++par8) {
        if (q0[par8].empty() || q1[par8].empty()) continue;
        for (const auto& a : q0[par8]) for (const auto& b : q1[par8]) {
            std::array<int8_t, 16> u; uint16_t par16 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a[y]) + std::abs(b[y]) > 8) { ok = false; break; }
                int s = (a[y] + b[y]) >> 1, d = (a[y] - b[y]) >> 1;
                u[y] = (int8_t)s; u[8 + y] = (int8_t)d;
                if (s & 1) par16 |= (uint16_t(1) << y);
                if (d & 1) par16 |= (uint16_t(1) << (8 + y));
            }
            if (!ok) continue;
            if (allowed_par && !allowed_par->count(par16)) continue;
            uint16_t q16 = compute_q16(u);
            auto& hb = out[par16];
            uint32_t id = (uint32_t)hb.all.size();
            hb.all.push_back({u, q16});
            hb.by_q[q16].push_back(id);
        }
    }
}

struct HalfFilter {
    HalfMap mp;
    std::unordered_map<uint16_t, std::vector<uint16_t>> p32low_by_par;
};

static void build_half_filter(const Opts32& opts, HalfFilter& out) {
    out.mp.clear(); out.p32low_by_par.clear();
    std::unordered_map<uint16_t, HalfByQ> g0, g1;
    enum_slice16_by_par(0, opts, nullptr, g0);
    if (g0.empty()) return;
    enum_slice16_by_par(16, opts, nullptr, g1);
    if (g1.empty()) return;
    for (const auto& [par, h0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : h0.all) for (const auto& b : it->second.all) {
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (uint32_t(1) << y);
                if (x1 & 1) p32 |= (uint32_t(1) << (16 + y));
                if (std::abs(x0) == 2) tw |= (uint32_t(1) << y);
                if (std::abs(x1) == 2) tw |= (uint32_t(1) << (16 + y));
            }
            if (ok) {
                auto& m2 = out.mp[p32];
                auto it2 = m2.find(tw);
                if (it2 == m2.end() || e2 < it2->second) m2[tw] = e2;
            }
        }
    }
    for (const auto& [p32, _] : out.mp) {
        uint16_t lo = (uint16_t)(p32 & 0xFFFFu), hi = (uint16_t)(p32 >> 16);
        out.p32low_by_par[lo ^ hi].push_back(lo);
    }
}

// Compute exact min_m matching `os` against known `mt` using q16 lookup (100x faster than full collect_half_minE!!)!
static int min_m_against_filter(const Opts32& os, const HalfFilter& mt) {
    if (mt.mp.empty()) return 999;
    std::unordered_map<uint16_t, HalfByQ> g0, g1;
    enum_slice16_by_par(0, os, &mt.p32low_by_par, g0);
    if (g0.empty()) return 999;
    enum_slice16_by_par(16, os, &mt.p32low_by_par, g1);
    if (g1.empty()) return 999;
    int best = 999;
    for (const auto& [par16, p32_lows] : mt.p32low_by_par) {
        auto it0 = g0.find(par16); if (it0 == g0.end()) continue;
        auto it1 = g1.find(par16); if (it1 == g1.end()) continue;
        const auto& H0 = it0->second; const auto& H1 = it1->second;
        size_t n0 = H0.all.size(), n1 = H1.all.size(), np = p32_lows.size();
        auto check_pair = [&](const U16Q& a, const U16Q& b, const std::map<uint32_t, int>& m_mt) {
            uint32_t tw = 0; int e2 = 0;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) return;
                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (std::abs(x0) == 2) tw |= (1u << y);
                if (std::abs(x1) == 2) tw |= (1u << (16 + y));
            }
            for (const auto& [tw_t, et] : m_mt)
                if ((tw & tw_t) == 0) {
                    int m = (et + e2) / 2;
                    if (m < best) best = m;
                }
        };
        if (n0 * n1 <= std::min(n0, n1) * np * 2) {
            for (const auto& a : H0.all) for (const auto& b : H1.all) {
                uint16_t lo = a.q16 ^ b.q16 ^ par16;
                uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                auto itm = mt.mp.find(p32); if (itm == mt.mp.end()) continue;
                check_pair(a, b, itm->second);
            }
        } else if (n0 <= n1) {
            for (const auto& a : H0.all) {
                uint16_t base = a.q16 ^ par16;
                for (uint16_t lo : p32_lows) {
                    auto itq = H1.by_q.find(base ^ lo); if (itq == H1.by_q.end()) continue;
                    uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                    const auto& m_mt = mt.mp.at(p32);
                    for (uint32_t id1 : itq->second) check_pair(a, H1.all[id1], m_mt);
                }
            }
        } else {
            for (const auto& b : H1.all) {
                uint16_t base = b.q16 ^ par16;
                for (uint16_t lo : p32_lows) {
                    auto itq = H0.by_q.find(base ^ lo); if (itq == H0.by_q.end()) continue;
                    uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                    const auto& m_mt = mt.mp.at(p32);
                    for (uint32_t id0 : itq->second) check_pair(H0.all[id0], b, m_mt);
                }
            }
        }
    }
    return best;
}

// Collect HalfMap of `os` filtered ONLY to `allowed_p32` (union of all p32 keys across CachedRH2!!)!
static void collect_Hc_filtered(const Opts32& os, const HalfFilter& union_mt, HalfMap& out_ms) {
    out_ms.clear();
    if (union_mt.mp.empty()) return;
    std::unordered_map<uint16_t, HalfByQ> g0, g1;
    enum_slice16_by_par(0, os, &union_mt.p32low_by_par, g0);
    if (g0.empty()) return;
    enum_slice16_by_par(16, os, &union_mt.p32low_by_par, g1);
    if (g1.empty()) return;
    for (const auto& [par16, p32_lows] : union_mt.p32low_by_par) {
        auto it0 = g0.find(par16); if (it0 == g0.end()) continue;
        auto it1 = g1.find(par16); if (it1 == g1.end()) continue;
        const auto& H0 = it0->second; const auto& H1 = it1->second;
        size_t n0 = H0.all.size(), n1 = H1.all.size(), np = p32_lows.size();
        auto rec = [&](const U16Q& a, const U16Q& b, uint32_t p32) {
            uint32_t tw = 0; int e2 = 0;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) return;
                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (std::abs(x0) == 2) tw |= (1u << y);
                if (std::abs(x1) == 2) tw |= (1u << (16 + y));
            }
            auto& m2 = out_ms[p32];
            auto it2 = m2.find(tw);
            if (it2 == m2.end() || e2 < it2->second) m2[tw] = e2;
        };
        if (n0 * n1 <= std::min(n0, n1) * np * 2) {
            for (const auto& a : H0.all) for (const auto& b : H1.all) {
                uint16_t lo = a.q16 ^ b.q16 ^ par16;
                uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                if (!union_mt.mp.count(p32)) continue;
                rec(a, b, p32);
            }
        } else if (n0 <= n1) {
            for (const auto& a : H0.all) {
                uint16_t base = a.q16 ^ par16;
                for (uint16_t lo : p32_lows) {
                    auto itq = H1.by_q.find(base ^ lo); if (itq == H1.by_q.end()) continue;
                    uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                    for (uint32_t id1 : itq->second) rec(a, H1.all[id1], p32);
                }
            }
        } else {
            for (const auto& b : H1.all) {
                uint16_t base = b.q16 ^ par16;
                for (uint16_t lo : p32_lows) {
                    auto itq = H0.by_q.find(base ^ lo); if (itq == H0.by_q.end()) continue;
                    uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                    for (uint32_t id0 : itq->second) rec(H0.all[id0], b, p32);
                }
            }
        }
    }
}

static int min_join_m(const HalfMap& mt, const HalfMap& ms) {
    int best = 999;
    const HalfMap* sm = &mt; const HalfMap* bg = &ms;
    if (ms.size() < mt.size()) std::swap(sm, bg);
    for (const auto& [p32, tm] : *sm) {
        auto it = bg->find(p32); if (it == bg->end()) continue;
        for (const auto& [tw1, e1] : tm)
            for (const auto& [tw2, e2] : it->second)
                if ((tw1 & tw2) == 0) {
                    int m = (e1 + e2) / 2;
                    if (m < best) best = m;
                }
    }
    return best;
}

// ---------- Exact S-collect (8x8 + q16 filtered against mt!) for 4-cell join ----------
struct Slice8S { std::array<int8_t, 8> b; uint8_t m68, sgn; };
static void enum_slice8_S(int start, int j, std::array<int, 8>& z, uint8_t m68, uint8_t sg,
                          const Opts32& opts, uint32_t track_mask,
                          std::array<std::vector<Slice8S>, 256>& out) {
    if (j < 8) {
        int idx = start + j; bool tr = (track_mask >> idx) & 1;
        for (int v : opts[idx]) {
            z[j] = v;
            uint8_t nm = m68 | ((tr && (std::abs(v) == 6 || std::abs(v) == 8)) ? (uint8_t(1) << j) : 0);
            uint8_t ns = sg | ((v < 0) ? (uint8_t(1) << j) : 0);
            enum_slice8_S(start, j + 1, z, nm, ns, opts, track_mask, out);
        }
        return;
    }
    auto u = z; fwht8(u);
    uint8_t par = 0; std::array<int8_t, 8> b;
    for (int y = 0; y < 8; ++y) {
        if (u[y] & 7) return;
        int q = u[y] >> 3; if (std::abs(q) > 8) return;
        b[y] = (int8_t)q; if (q & 1) par |= (uint8_t(1) << y);
    }
    out[par].push_back({b, m68, sg});
}

struct Slice16S { std::array<int8_t, 16> u; uint16_t m68, sgn, q16; };
struct HalfByQS {
    std::vector<Slice16S> all;
    std::unordered_map<uint16_t, std::vector<uint32_t>> by_q;
};
static void enum_slice16_S_by_par(int start, const Opts32& opts, uint32_t track_mask,
                                  const std::unordered_map<uint16_t, std::vector<uint16_t>>* allowed_par,
                                  std::unordered_map<uint16_t, HalfByQS>& out) {
    std::array<std::vector<Slice8S>, 256> q0, q1;
    std::array<int, 8> tmp{};
    enum_slice8_S(start, 0, tmp, 0, 0, opts, track_mask, q0);
    enum_slice8_S(start + 8, 0, tmp, 0, 0, opts, track_mask, q1);
    for (int par8 = 0; par8 < 256; ++par8) {
        if (q0[par8].empty() || q1[par8].empty()) continue;
        for (const auto& a : q0[par8]) for (const auto& b : q1[par8]) {
            std::array<int8_t, 16> u; uint16_t par16 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                u[y] = (int8_t)s; u[8 + y] = (int8_t)d;
                if (s & 1) par16 |= (uint16_t(1) << y);
                if (d & 1) par16 |= (uint16_t(1) << (8 + y));
            }
            if (!ok) continue;
            if (allowed_par && !allowed_par->count(par16)) continue;
            uint16_t q16 = compute_q16(u);
            auto& hb = out[par16];
            uint32_t id = (uint32_t)hb.all.size();
            hb.all.push_back({u, uint16_t(a.m68 | (b.m68 << 8)), uint16_t(a.sgn | (b.sgn << 8)), q16});
            hb.by_q[q16].push_back(id);
        }
    }
}

struct HalfEntryS { uint32_t tw, m68, sgn; int e2; };
static void collect_half_S_full(const Opts32& opts, uint32_t track_mask,
                                std::unordered_map<uint32_t, std::vector<HalfEntryS>>& out,
                                std::unordered_map<uint16_t, std::vector<uint16_t>>& p32low_by_par) {
    out.clear(); p32low_by_par.clear();
    std::unordered_map<uint16_t, HalfByQS> g0, g1;
    enum_slice16_S_by_par(0, opts, track_mask, nullptr, g0);
    if (g0.empty()) return;
    enum_slice16_S_by_par(16, opts, track_mask, nullptr, g1);
    if (g1.empty()) return;
    for (const auto& [par, h0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : h0.all) for (const auto& b : it->second.all) {
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (uint32_t(1) << y);
                if (x1 & 1) p32 |= (uint32_t(1) << (16 + y));
                if (std::abs(x0) == 2) tw |= (uint32_t(1) << y);
                if (std::abs(x1) == 2) tw |= (uint32_t(1) << (16 + y));
            }
            if (ok) out[p32].push_back({tw, uint32_t(a.m68) | (uint32_t(b.m68) << 16),
                                        uint32_t(a.sgn) | (uint32_t(b.sgn) << 16), e2});
        }
    }
    for (const auto& [p32, _] : out) {
        uint16_t lo = (uint16_t)(p32 & 0xFFFFu), hi = (uint16_t)(p32 >> 16);
        p32low_by_par[lo ^ hi].push_back(lo);
    }
}

struct Ctx {
    int is_H1, R_max;
    int H_pts[32], Hc_pts[32];
    uint32_t mHZ = 0, mHF = 0, mHcZ = 0, mHcF = 0;
    void init(int h1, int rm) {
        is_H1 = h1; R_max = rm; mHZ = mHF = mHcZ = mHcF = 0;
        for (int i = 0; i < 32; ++i) {
            H_pts[i] = 2 * i + is_H1; Hc_pts[i] = 2 * i + (1 - is_H1);
            if (Q64[H_pts[i]] == 0) mHZ |= (1u << i); else mHF |= (1u << i);
            if (Q64[Hc_pts[i]] == 0) mHcZ |= (1u << i); else mHcF |= (1u << i);
        }
    }
    Opts32 make_opt_s(uint32_t p, uint32_t u_union, uint32_t oddF,
                      uint32_t m4, uint32_t k3, uint32_t k2, uint32_t k4) const {
        Opts32 os;
        for (int i = 0; i < 32; ++i) {
            int pi = (p >> i) & 1;
            if (Q64[Hc_pts[i]] == 1) {
                if ((oddF >> i) & 1) {
                    if ((k3 >> i) & 1) os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{0};
                    else os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 8};
                } else {
                    if ((k4 >> i) & 1) os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{0};
                    else if ((k2 >> i) & 1) os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 0, 8};
                    else os[i] = pi ? std::vector<int>{-12, 12} : std::vector<int>{0};
                }
            } else {
                if (pi) os[i] = {-4, 4};
                else if (((u_union | m4) >> i) & 1) os[i] = {0};
                else os[i] = {-8, 0, 8};
            }
        }
        return os;
    }
    Opts32 make_opt_t_base(uint32_t p) const {
        Opts32 ot;
        for (int i = 0; i < 32; ++i) {
            int pi = (p >> i) & 1;
            if (Q64[H_pts[i]] == 1) ot[i] = pi ? std::vector<int>{6} : std::vector<int>{-6};
            else ot[i] = pi ? std::vector<int>{-2, 6} : std::vector<int>{-6, 2};
        }
        return ot;
    }
    void set_val_H(Opts32& ot, uint32_t p, int idx, int abs_v) const {
        int pi = (p >> idx) & 1;
        if (abs_v == 2) ot[idx] = pi ? std::vector<int>{-2} : std::vector<int>{2};
        else if (abs_v == 10) ot[idx] = pi ? std::vector<int>{-10} : std::vector<int>{10};
        else ot[idx] = pi ? std::vector<int>{6} : std::vector<int>{-6};
    }

    long long run_exact_join(const std::array<Opts32, 4>& ot4, const std::array<Opts32, 4>& os4,
                             uint32_t tgt_e6, uint32_t d3_H, uint32_t k3_H,
                             uint32_t Z1, uint32_t Z0_act, uint32_t k1_act, uint32_t k2_Hc) const {
        uint32_t track_s = Z0_act | k2_Hc;
        uint64_t phase64 = interleave_H(0xFFFFFFFFu, Z1 | k1_act, is_H1);
        PhaseReducer red; red.init(phase64);
        uint64_t tgt_sgn = red.reduce(phase64 ^ interleave_H(d3_H | k3_H, 0, is_H1));
        struct Sig {
            uint32_t e6, e8; int m; uint64_t sgn;
            bool operator<(const Sig& o) const {
                if (e6 != o.e6) return e6 < o.e6;
                if (e8 != o.e8) return e8 < o.e8;
                if (m != o.m) return m < o.m;
                return sgn < o.sgn;
            }
            bool operator==(const Sig& o) const {
                return e6 == o.e6 && e8 == o.e8 && m == o.m && sgn == o.sgn;
            }
        };
        std::array<std::vector<Sig>, 4> sigs;
        for (int k = 0; k < 4; ++k) {
            std::unordered_map<uint32_t, std::vector<HalfEntryS>> mtS;
            std::unordered_map<uint16_t, std::vector<uint16_t>> p32low_by_par;
            collect_half_S_full(ot4[k], mHZ, mtS, p32low_by_par);
            if (mtS.empty()) return 0;

            std::unordered_map<uint16_t, HalfByQS> g0, g1;
            enum_slice16_S_by_par(0, os4[k], track_s, &p32low_by_par, g0);
            if (g0.empty()) return 0;
            enum_slice16_S_by_par(16, os4[k], track_s, &p32low_by_par, g1);
            if (g1.empty()) return 0;

            auto emit = [&](const Slice16S& a, const Slice16S& b, uint32_t p32, const std::vector<HalfEntryS>& vt) {
                uint32_t tw = 0; int e2 = 0;
                for (int y = 0; y < 16; ++y) {
                    if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) return;
                    int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                    e2 += x0*x0 + x1*x1;
                    if (std::abs(x0) == 2) tw |= (1u << y);
                    if (std::abs(x1) == 2) tw |= (1u << (16 + y));
                }
                uint32_t e8 = uint32_t(a.m68) | (uint32_t(b.m68) << 16);
                uint32_t sgS = uint32_t(a.sgn) | (uint32_t(b.sgn) << 16);
                for (const auto& et : vt) {
                    if (tw & et.tw) continue;
                    int m = (et.e2 + e2) / 2;
                    if (m > 64) continue;
                    sigs[k].push_back({et.m68, e8, m, red.reduce(interleave_H(et.sgn, sgS, is_H1))});
                }
            };
            for (const auto& [par16, p32_lows] : p32low_by_par) {
                auto it0 = g0.find(par16); if (it0 == g0.end()) continue;
                auto it1 = g1.find(par16); if (it1 == g1.end()) continue;
                const auto& H0 = it0->second; const auto& H1 = it1->second;
                size_t n0 = H0.all.size(), n1 = H1.all.size(), np = p32_lows.size();
                if (n0 * n1 <= std::min(n0, n1) * np * 2) {
                    for (const auto& a : H0.all) for (const auto& b : H1.all) {
                        uint16_t lo = a.q16 ^ b.q16 ^ par16;
                        uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                        auto itm = mtS.find(p32); if (itm == mtS.end()) continue;
                        emit(a, b, p32, itm->second);
                    }
                } else if (n0 <= n1) {
                    for (const auto& a : H0.all) {
                        uint16_t base = a.q16 ^ par16;
                        for (uint16_t lo : p32_lows) {
                            auto itq = H1.by_q.find(base ^ lo); if (itq == H1.by_q.end()) continue;
                            uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                            const auto& vt = mtS.at(p32);
                            for (uint32_t id1 : itq->second) emit(a, H1.all[id1], p32, vt);
                        }
                    }
                } else {
                    for (const auto& b : H1.all) {
                        uint16_t base = b.q16 ^ par16;
                        for (uint16_t lo : p32_lows) {
                            auto itq = H0.by_q.find(base ^ lo); if (itq == H0.by_q.end()) continue;
                            uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                            const auto& vt = mtS.at(p32);
                            for (uint32_t id0 : itq->second) emit(H0.all[id0], b, p32, vt);
                        }
                    }
                }
            }
            std::sort(sigs[k].begin(), sigs[k].end());
            sigs[k].erase(std::unique(sigs[k].begin(), sigs[k].end()), sigs[k].end());
            if (sigs[k].empty()) return 0;
        }
        std::array<int, 4> ord{0, 1, 2, 3};
        std::sort(ord.begin(), ord.end(), [&](int a, int b){ return sigs[a].size() < sigs[b].size(); });
        struct Key {
            uint32_t e6, e8; uint64_t sgn;
            bool operator<(const Key& o) const {
                if (e6 != o.e6) return e6 < o.e6;
                if (e8 != o.e8) return e8 < o.e8;
                return sgn < o.sgn;
            }
        };
        std::map<Key, std::array<uint64_t, 2>> lmap;
        for (const auto& a : sigs[ord[0]]) for (const auto& b : sigs[ord[3]]) {
            if ((a.e6 & b.e6) || (a.e8 & b.e8)) continue;
            int m = a.m + b.m; if (m > 102) continue;
            auto& bm = lmap[{a.e6 | b.e6, a.e8 | b.e8, a.sgn ^ b.sgn}];
            bm[m >> 6] |= (1ULL << (m & 63));
        }
        long long hits = 0;
        for (const auto& c : sigs[ord[1]]) for (const auto& d : sigs[ord[2]]) {
            if ((c.e6 & d.e6) || (c.e8 & d.e8)) continue;
            int m = c.m + d.m; if (m > 102) continue;
            auto it = lmap.find({tgt_e6 ^ (c.e6 | d.e6), track_s ^ (c.e8 | d.e8), tgt_sgn ^ (c.sgn ^ d.sgn)});
            if (it != lmap.end()) {
                int rem = 102 - m;
                if (it->second[rem >> 6] & (1ULL << (rem & 63))) hits++;
            }
        }
        return hits;
    }
};

struct CachedRH2 {
    uint8_t rad_xor;
    std::array<HalfFilter, 4> union_mt; // union of ALL p32 keys across all R_H==2 mt maps!
    std::array<Opts32, 4> ot_clean;
    std::array<HalfMap, 4> mt_clean;
    std::vector<int> f_pts;
    std::vector<std::array<Opts32, 4>> ot_f2;
    std::vector<std::array<HalfMap, 4>> mt_f2;
    struct PairData {
        int type, a, b;
        std::array<Opts32, 4> ot0, ot1, ot2, ot3;
        std::array<HalfMap, 4> mt0, mt1, mt2, mt3;
    };
    std::vector<PairData> pairs;

    void add_to_union(int k, const HalfMap& hm) {
        for (const auto& [p32, _] : hm) union_mt[k].mp[p32][0] = 0;
    }
    void finalize_union() {
        for (int k = 0; k < 4; ++k)
            for (const auto& [p32, _] : union_mt[k].mp) {
                uint16_t lo = (uint16_t)(p32 & 0xFFFFu), hi = (uint16_t)(p32 >> 16);
                union_mt[k].p32low_by_par[lo ^ hi].push_back(lo);
            }
    }
    void build(const Ctx& ctx, const std::array<uint32_t, 4>& t, uint8_t rx) {
        rad_xor = rx;
        if (rx == 0) {
            for (int k = 0; k < 4; ++k) {
                ot_clean[k] = ctx.make_opt_t_base(t[k]);
                HalfFilter hf; build_half_filter(ot_clean[k], hf);
                mt_clean[k] = std::move(hf.mp);
                add_to_union(k, mt_clean[k]);
            }
            for (int i = 0; i < 32; ++i) {
                if (!((ctx.mHF >> i) & 1)) continue;
                f_pts.push_back(i);
                std::array<Opts32, 4> o2; std::array<HalfMap, 4> m2;
                for (int k = 0; k < 4; ++k) {
                    o2[k] = ot_clean[k]; ctx.set_val_H(o2[k], t[k], i, 2);
                    HalfFilter hf; build_half_filter(o2[k], hf);
                    m2[k] = std::move(hf.mp);
                    add_to_union(k, m2[k]);
                }
                ot_f2.push_back(std::move(o2)); mt_f2.push_back(std::move(m2));
            }
        } else {
            for (int a = 0; a < 32; ++a) {
                int b = a ^ rx; if (b < a) continue;
                bool aF = (Q64[ctx.H_pts[a]] == 1), bF = (Q64[ctx.H_pts[b]] == 1);
                PairData pd;
                if (!aF && !bF) {
                    pd.type = 0; pd.a = a; pd.b = b;
                    for (int k = 0; k < 4; ++k) {
                        pd.ot0[k] = ctx.make_opt_t_base(t[k]);
                        ctx.set_val_H(pd.ot0[k], t[k], a, 2); ctx.set_val_H(pd.ot0[k], t[k], b, 2);
                        HalfFilter hf; build_half_filter(pd.ot0[k], hf);
                        pd.mt0[k] = std::move(hf.mp); add_to_union(k, pd.mt0[k]);
                    }
                } else if (aF != bF) {
                    pd.type = 1; pd.a = aF ? b : a; pd.b = aF ? a : b;
                    for (int k = 0; k < 4; ++k) {
                        pd.ot0[k] = ctx.make_opt_t_base(t[k]);
                        ctx.set_val_H(pd.ot0[k], t[k], pd.a, 2); ctx.set_val_H(pd.ot0[k], t[k], pd.b, 2);
                        HalfFilter hf; build_half_filter(pd.ot0[k], hf);
                        pd.mt0[k] = std::move(hf.mp); add_to_union(k, pd.mt0[k]);
                        pd.ot1[k] = pd.ot0[k]; ctx.set_val_H(pd.ot1[k], t[k], pd.b, 10);
                        build_half_filter(pd.ot1[k], hf);
                        pd.mt1[k] = std::move(hf.mp); add_to_union(k, pd.mt1[k]);
                    }
                } else {
                    pd.type = 2; pd.a = a; pd.b = b;
                    for (int k = 0; k < 4; ++k) {
                        Opts32* ots[4] = {&pd.ot0[k], &pd.ot1[k], &pd.ot2[k], &pd.ot3[k]};
                        HalfMap* mts[4] = {&pd.mt0[k], &pd.mt1[k], &pd.mt2[k], &pd.mt3[k]};
                        for (int mk = 0; mk < 4; ++mk) {
                            *ots[mk] = ctx.make_opt_t_base(t[k]);
                            ctx.set_val_H(*ots[mk], t[k], a, (mk & 1) ? 10 : 2);
                            ctx.set_val_H(*ots[mk], t[k], b, (mk & 2) ? 10 : 2);
                            HalfFilter hf; build_half_filter(*ots[mk], hf);
                            *mts[mk] = std::move(hf.mp); add_to_union(k, *mts[mk]);
                        }
                    }
                }
                pairs.push_back(std::move(pd));
            }
        }
        finalize_union();
    }
    long long test_Hc(const Ctx& ctx, const std::array<Opts32, 4>& os4,
                      uint32_t Z1, uint32_t Z0_act, uint32_t k1_act, uint32_t k2_Hc) const {
        std::array<HalfMap, 4> ms4;
        std::array<int, 4> ko{0, 1, 2, 3};
        std::sort(ko.begin(), ko.end(), [&](int a, int b){ return opt_cost(os4[a]) < opt_cost(os4[b]); });
        for (int k : ko) {
            collect_Hc_filtered(os4[k], union_mt[k], ms4[k]);
            if (ms4[k].empty()) return 0;
        }
        long long hits = 0;
        if (rad_xor == 0) {
            int mc[4];
            for (int k = 0; k < 4; ++k) mc[k] = mt_clean[k].empty() ? 999 : min_join_m(mt_clean[k], ms4[k]);
            for (size_t pi = 0; pi < f_pts.size(); ++pi) {
                int m2[4];
                for (int k = 0; k < 4; ++k) m2[k] = mt_f2[pi][k].empty() ? 999 : min_join_m(mt_f2[pi][k], ms4[k]);
                for (int a = 0; a < 4; ++a) for (int b = a + 1; b < 4; ++b) {
                    int s = 0;
                    for (int k = 0; k < 4; ++k) s += (k == a || k == b) ? m2[k] : mc[k];
                    if (s <= 102) {
                        std::array<Opts32, 4> ot4 = ot_clean;
                        ot4[a] = ot_f2[pi][a]; ot4[b] = ot_f2[pi][b];
                        hits += ctx.run_exact_join(ot4, os4, ctx.mHZ, 0, 0, Z1, Z0_act, k1_act, k2_Hc);
                    }
                }
            }
        } else {
            for (const auto& pd : pairs) {
                if (pd.type == 0) {
                    int s = 0; bool ok = true;
                    for (int k = 0; k < 4; ++k) {
                        int m = pd.mt0[k].empty() ? 999 : min_join_m(pd.mt0[k], ms4[k]);
                        if (m >= 999 || (s += m) > 102) { ok = false; break; }
                    }
                    if (ok) {
                        uint32_t d3 = (1u << pd.a) | (1u << pd.b);
                        hits += ctx.run_exact_join(pd.ot0, os4, ctx.mHZ ^ d3, d3, 0, Z1, Z0_act, k1_act, k2_Hc);
                    }
                } else if (pd.type == 1) {
                    int m2[4], m10[4];
                    for (int k = 0; k < 4; ++k) {
                        m2[k] = pd.mt0[k].empty() ? 999 : min_join_m(pd.mt0[k], ms4[k]);
                        m10[k] = pd.mt1[k].empty() ? 999 : min_join_m(pd.mt1[k], ms4[k]);
                    }
                    for (int j = 0; j < 4; ++j) {
                        int s = m10[j]; for (int k = 0; k < 4; ++k) if (k != j) s += m2[k];
                        if (s <= 102) {
                            std::array<Opts32, 4> ot4 = pd.ot0; ot4[j] = pd.ot1[j];
                            uint32_t d3 = (1u << pd.a);
                            hits += ctx.run_exact_join(ot4, os4, ctx.mHZ ^ d3, d3, 0, Z1, Z0_act, k1_act, k2_Hc);
                        }
                    }
                } else {
                    int mm[4][4];
                    for (int k = 0; k < 4; ++k) {
                        const HalfMap* mts[4] = {&pd.mt0[k], &pd.mt1[k], &pd.mt2[k], &pd.mt3[k]};
                        for (int mk = 0; mk < 4; ++mk) mm[k][mk] = mts[mk]->empty() ? 999 : min_join_m(*mts[mk], ms4[k]);
                    }
                    for (int ja = 0; ja < 4; ++ja) for (int jb = 0; jb < 4; ++jb) {
                        int s = 0;
                        for (int k = 0; k < 4; ++k) s += mm[k][((k==ja)?1:0)|((k==jb)?2:0)];
                        if (s <= 102) {
                            std::array<Opts32, 4> ot4;
                            for (int k = 0; k < 4; ++k) {
                                int mk = ((k==ja)?1:0)|((k==jb)?2:0);
                                ot4[k] = (mk==0)?pd.ot0[k]:((mk==1)?pd.ot1[k]:((mk==2)?pd.ot2[k]:pd.ot3[k]));
                            }
                            hits += ctx.run_exact_join(ot4, os4, ctx.mHZ, 0, 0, Z1, Z0_act, k1_act, k2_Hc);
                        }
                    }
                }
            }
        }
        return hits;
    }
};

static void run_case(const std::string& name, int is_H1, int R_max, bool do_r2z0,
                     const std::vector<uint32_t>& all_q,
                     const std::unordered_map<uint32_t, uint8_t>& rad_map) {
    auto t_start = std::chrono::steady_clock::now();
    Ctx ctx; ctx.init(is_H1, R_max);
    auto grp = build_stabH(is_H1);
    std::unordered_map<uint32_t, std::vector<uint32_t>> byZ, byF;
    for (uint32_t q : all_q) { byZ[q & ctx.mHcZ].push_back(q); byF[q & ctx.mHcF].push_back(q); }

    int max_m2 = R_max - 2;
    std::vector<uint32_t> all_smallZ, z1_reps;
    for (const auto& [z, _] : byZ)
        if (z != 0 && __builtin_popcount(z) <= max_m2) all_smallZ.push_back(z);
    std::sort(all_smallZ.begin(), all_smallZ.end());
    {
        std::unordered_set<uint32_t> visZ;
        for (uint32_t z : all_smallZ) {
            if (visZ.count(z)) continue;
            z1_reps.push_back(z);
            for (const auto& g : grp) visZ.insert(app32(z, g));
        }
    }
    std::vector<std::vector<uint32_t>> U_reps;
    U_reps.push_back({});
    for (uint32_t z1 : z1_reps) U_reps.push_back({z1});
    {
        std::set<std::vector<uint32_t>> seenU2;
        int max_min_w = (2 * max_m2) / 3;
        for (uint32_t z1 : z1_reps) {
            int w1 = __builtin_popcount(z1); if (w1 > max_min_w) continue;
            std::vector<Perm32> stab1;
            for (const auto& g : grp) if (app32(z1, g) == z1) stab1.push_back(g);
            std::unordered_set<uint32_t> vis2;
            for (uint32_t z2 : all_smallZ) {
                if (z2 == z1 || vis2.count(z2)) continue;
                if (__builtin_popcount(z2) < w1) continue;
                uint32_t z3 = z1 ^ z2;
                if (__builtin_popcount(z3) < w1 || __builtin_popcount(z1 | z2) > max_m2) continue;
                for (const auto& g : stab1) { vis2.insert(app32(z2, g)); vis2.insert(app32(z3, g)); }
                std::vector<uint32_t> U{z1, z2, z3}; std::sort(U.begin(), U.end());
                if (seenU2.count(U)) continue;
                U_reps.push_back(U);
                for (const auto& g : grp) {
                    std::vector<uint32_t> nx{app32(U[0], g), app32(U[1], g), app32(U[2], g)};
                    std::sort(nx.begin(), nx.end()); seenU2.insert(nx);
                }
            }
        }
    }
    std::vector<uint32_t> f_errs[9];
    {
        std::vector<int> fbits;
        for (int i = 0; i < 32; ++i) if ((ctx.mHcF >> i) & 1) fbits.push_back(i);
        auto dfs = [&](auto& self, int idx, int w, uint32_t mask) -> void {
            f_errs[w].push_back(mask);
            if (w == max_m2) return;
            for (int i = idx; i < (int)fbits.size(); ++i) self(self, i + 1, w + 1, mask | (1u << fbits[i]));
        };
        dfs(dfs, 0, 0, 0);
    }

    struct Task { std::array<uint32_t, 4> t; uint32_t u_union, oddF; uint8_t rad_xor; int remR; };
    std::vector<Task> t_r2z0, t_r4, t_r6, t_r8;
    for (const auto& U : U_reps) {
        int dim = (U.size() == 0) ? 0 : (U.size() == 1 ? 1 : 2);
        uint32_t u_union = 0; for (uint32_t z : U) u_union |= z;
        int m2Z = __builtin_popcount(u_union), xZ = xor5_mask(u_union);
        std::vector<Perm32> stabU;
        for (const auto& g : grp) {
            bool ok = true;
            if (dim == 1) ok = (app32(U[0], g) == U[0]);
            else if (dim == 2) {
                uint32_t a0 = app32(U[0], g), a1 = app32(U[1], g);
                ok = ((a0 == U[0] || a0 == U[1] || a0 == U[2]) && (a1 == U[0] || a1 == U[1] || a1 == U[2]));
            }
            if (ok) stabU.push_back(g);
        }
        uint32_t z1 = (dim >= 1) ? U[0] : 0, z2 = (dim >= 2) ? U[1] : 0;
        const auto& L1 = byZ[z1]; const auto& L2 = byZ[z2];
        std::set<std::array<uint32_t, 4>> local_tuples;
        for (uint32_t a : L1) for (uint32_t b : L2) {
            uint32_t prodF = (a & b) & ctx.mHcF;
            for (int w = (m2Z & 1); w <= max_m2 - m2Z; w += 2) {
                int remR = R_max - m2Z - w;
                for (uint32_t e : f_errs[w]) {
                    int need_rad = 1 ^ xZ ^ xor5_mask(e);
                    if (remR == 2 && need_rad != 0) continue;
                    auto it = byF.find(prodF ^ e);
                    if (it == byF.end()) continue;
                    for (uint32_t p0 : it->second) {
                        uint32_t p1 = p0 ^ a, p2 = p0 ^ b, p3 = p0 ^ a ^ b ^ ctx.mHcF;
                        int rx = rad_map.at(p0) ^ rad_map.at(p1) ^ rad_map.at(p2) ^ rad_map.at(p3);
                        if (rx != need_rad) continue;
                        std::array<uint32_t, 4> t{p0, p1, p2, p3};
                        std::sort(t.begin(), t.end());
                        local_tuples.insert(t);
                    }
                }
            }
        }
        std::set<std::array<uint32_t, 4>> visT;
        for (const auto& t : local_tuples) {
            if (visT.count(t)) continue;
            for (const auto& g : stabU) {
                std::array<uint32_t, 4> nx{app32(t[0], g), app32(t[1], g), app32(t[2], g), app32(t[3], g)};
                std::sort(nx.begin(), nx.end()); visT.insert(nx);
            }
            uint32_t a = t[1] ^ t[0], b = t[2] ^ t[0];
            uint32_t oddF = (t[0] ^ (a & b)) & ctx.mHcF;
            int remR = R_max - m2Z - __builtin_popcount(oddF);
            uint8_t rx = rad_map.at(t[0]) ^ rad_map.at(t[1]) ^ rad_map.at(t[2]) ^ rad_map.at(t[3]);
            Task tk{t, u_union, oddF, rx, remR};
            if (remR == 2) t_r2z0.push_back(tk);
            else if (remR == 4) t_r4.push_back(tk);
            else if (remR == 6) t_r6.push_back(tk);
            else if (remR == 8) t_r8.push_back(tk);
        }
    }
    std::cout << "\n=== " << name << ": r2z0=" << t_r2z0.size() << " r4=" << t_r4.size()
              << " r6=" << t_r6.size() << " r8=" << t_r8.size() << " ===\n" << std::flush;

    // 1. remR == 2, rad == 0
    if (do_r2z0) {
        auto t0 = std::chrono::steady_clock::now();
        std::atomic<size_t> ni{0};
        std::atomic<long long> h0{0}, h2{0};
        std::vector<std::thread> ths;
        for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&]() {
            while (true) {
                size_t idx = ni.fetch_add(1); if (idx >= t_r2z0.size()) break;
                const auto& tk = t_r2z0[idx];
                uint32_t Z1 = ctx.mHcZ & tk.t[0] & tk.t[1] & tk.t[2] & tk.t[3];
                uint32_t Z0 = ctx.mHcZ & ~(tk.t[0] | tk.t[1] | tk.t[2] | tk.t[3]);
                uint32_t evenF = ctx.mHcF & ~tk.oddF;

                std::array<Opts32, 4> ot_c; std::array<HalfFilter, 4> mt_c; bool ht_ok = true;
                for (int k = 0; k < 4; ++k) {
                    ot_c[k] = ctx.make_opt_t_base(tk.t[k]);
                    build_half_filter(ot_c[k], mt_c[k]);
                    if (mt_c[k].mp.empty()) { ht_ok = false; break; }
                }
                if (ht_ok) {
                    for (int i = 0; i < 32; ++i) {
                        uint32_t bit = 1u << i;
                        uint32_t m4 = bit & Z0, k3 = bit & tk.oddF, k2 = bit & evenF;
                        if (!(m4 | k3 | k2)) continue;
                        std::array<Opts32, 4> os4;
                        std::array<int, 4> ko{0, 1, 2, 3};
                        for (int k = 0; k < 4; ++k) os4[k] = ctx.make_opt_s(tk.t[k], tk.u_union, tk.oddF, m4, k3, k2, 0);
                        std::sort(ko.begin(), ko.end(), [&](int a, int b){ return opt_cost(os4[a]) < opt_cost(os4[b]); });
                        int s = 0; bool ok = true;
                        for (int k : ko) {
                            int m = min_m_against_filter(os4[k], mt_c[k]);
                            if (m >= 999 || (s += m) > 102) { ok = false; break; }
                        }
                        if (ok) h0.fetch_add(ctx.run_exact_join(ot_c, os4, ctx.mHZ, 0, 0, Z1, Z0 ^ m4, tk.oddF ^ k3, k2));
                    }
                }
                std::array<Opts32, 4> os4;
                for (int k = 0; k < 4; ++k) os4[k] = ctx.make_opt_s(tk.t[k], tk.u_union, tk.oddF, 0, 0, 0, 0);
                CachedRH2 crh2; crh2.build(ctx, tk.t, 0);
                h2.fetch_add(crh2.test_Hc(ctx, os4, Z1, Z0, tk.oddF, 0));
            }
        });
        for (auto& th : ths) th.join();
        double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        std::cout << "  [DONE] " << name << " (remR==2, rad==0, " << t_r2z0.size()
                  << " orbs) in " << dt << "s: hits_RH0=" << h0.load() << " hits_RH2=" << h2.load() << "\n" << std::flush;
    }

    // 2. remR == 4, R_H in {0, 2}!
    {
        auto t0 = std::chrono::steady_clock::now();
        std::atomic<size_t> ni{0};
        std::atomic<long long> h0{0}, h2{0};
        std::vector<std::thread> ths;
        for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&]() {
            while (true) {
                size_t idx = ni.fetch_add(1); if (idx >= t_r4.size()) break;
                const auto& tk = t_r4[idx];
                uint32_t Z1 = ctx.mHcZ & tk.t[0] & tk.t[1] & tk.t[2] & tk.t[3];
                uint32_t Z0 = ctx.mHcZ & ~(tk.t[0] | tk.t[1] | tk.t[2] | tk.t[3]);
                uint32_t evenF = ctx.mHcF & ~tk.oddF;
                std::vector<int> pos2;
                for (int i = 0; i < 32; ++i) if (((Z0 | tk.oddF | evenF) >> i) & 1) pos2.push_back(i);

                // Split A: RH=0, 2 eHc=4 (only if rad==0!)
                if (tk.rad_xor == 0) {
                    std::array<Opts32, 4> ot_c; std::array<HalfFilter, 4> mt_c; bool ht_ok = true;
                    for (int k = 0; k < 4; ++k) {
                        ot_c[k] = ctx.make_opt_t_base(tk.t[k]);
                        build_half_filter(ot_c[k], mt_c[k]);
                        if (mt_c[k].mp.empty()) { ht_ok = false; break; }
                    }
                    if (ht_ok) {
                        auto test_os4 = [&](uint32_t m4, uint32_t k3, uint32_t k2, uint32_t k4) {
                            std::array<Opts32, 4> os4; std::array<int, 4> ko{0, 1, 2, 3};
                            for (int k = 0; k < 4; ++k) os4[k] = ctx.make_opt_s(tk.t[k], tk.u_union, tk.oddF, m4, k3, k2, k4);
                            std::sort(ko.begin(), ko.end(), [&](int a, int b){ return opt_cost(os4[a]) < opt_cost(os4[b]); });
                            int s = 0;
                            for (int k : ko) {
                                int m = min_m_against_filter(os4[k], mt_c[k]);
                                if (m >= 999 || (s += m) > 102) return;
                            }
                            h0.fetch_add(ctx.run_exact_join(ot_c, os4, ctx.mHZ, 0, 0, Z1, Z0 ^ m4, tk.oddF ^ k3, k2));
                        };
                        for (int i = 0; i < 32; ++i) if ((evenF >> i) & 1) test_os4(0, 0, 0, 1u << i);
                        for (size_t a = 0; a < pos2.size(); ++a) for (size_t b = a + 1; b < pos2.size(); ++b) {
                            uint32_t msk = (1u << pos2[a]) | (1u << pos2[b]);
                            test_os4(msk & Z0, msk & tk.oddF, msk & evenF, 0);
                        }
                    }
                }
                // Split B: RH=2, 2 eHc=2
                CachedRH2 crh2; crh2.build(ctx, tk.t, tk.rad_xor);
                for (int i : pos2) {
                    uint32_t bit = 1u << i;
                    uint32_t m4 = bit & Z0, k3 = bit & tk.oddF, k2 = bit & evenF;
                    std::array<Opts32, 4> os4;
                    for (int k = 0; k < 4; ++k) os4[k] = ctx.make_opt_s(tk.t[k], tk.u_union, tk.oddF, m4, k3, k2, 0);
                    h2.fetch_add(crh2.test_Hc(ctx, os4, Z1, Z0 ^ m4, tk.oddF ^ k3, k2));
                }
            }
        });
        for (auto& th : ths) th.join();
        double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        std::cout << "  [DONE] " << name << " (remR==4, " << t_r4.size()
                  << " orbs) RH=0 & RH=2 in " << dt << "s: hits_RH0=" << h0.load() << " hits_RH2=" << h2.load() << "\n" << std::flush;
    }

    auto dump = [&](const std::string& lbl, const std::vector<Task>& vec) {
        for (size_t idx = 0; idx < vec.size(); ++idx) {
            const auto& tk = vec[idx];
            std::cout << "    " << lbl << "#" << idx << " m2Z=" << __builtin_popcount(tk.u_union)
                      << " oddF=" << __builtin_popcount(tk.oddF) << " rad=" << (int)tk.rad_xor << " wF=(";
            for (int k = 0; k < 4; ++k) std::cout << __builtin_popcount(tk.t[k] & ctx.mHcF) << (k<3?",":"");
            std::cout << ") wZ=(";
            for (int k = 0; k < 4; ++k) std::cout << __builtin_popcount(tk.t[k] & ctx.mHcZ) << (k<3?",":"");
            std::cout << ")\n";
        }
    };
    if (!t_r6.empty()) dump("r6", t_r6);
    if (!t_r8.empty()) dump("r8", t_r8);
    (void)t_start;
    std::cout << std::flush;
}

int main() {
    init_Q();
    uint32_t mons[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0;
        for (int i = 0; i < 32; ++i) if ((i & m) == m) mask |= (1u << i);
        mons[mk++] = mask;
    }
    std::vector<uint32_t> all_q(65536, 0);
    for (int s = 1; s < 65536; ++s) all_q[s] = all_q[s - 1] ^ mons[__builtin_ctz(s)];
    std::unordered_map<uint32_t, uint8_t> rad_map;
    for (uint32_t p : all_q) rad_map[p] = rad5_of(p);

    run_case("Case II (H_0)", 0, 6, false, all_q, rad_map);
    run_case("Case III (H_1)", 1, 8, true, all_q, rad_map);
    return 0;
}
