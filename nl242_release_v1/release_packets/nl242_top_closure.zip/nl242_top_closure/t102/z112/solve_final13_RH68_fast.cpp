// ULTRA-FAST EXACT solver for ALL 13 final R_H in {6, 8} jobs of (t=102, r=6, |Z|=112, beta=1_H)!
// Uses:
//   1. Exact 1-second uncoupled DP prefix/suffix -> max_allowed_m[k][sc][n10] (100% sound pruning!)
//   2. Compact nF-bit (16 or 20 bits) F-mask packing -> exact support-indexed build_pairs (s_a + d1 + 2*d2 <= RH)
//   3. Exact (need22, both2, one2) deduplicated U_R-indexed L x R join (mk_L + d_sub + 2*d_add <= RH)
//   4. Exact 4-slice q16 join (exact_join_fixed_F) on every surviving F-pattern!
//   5. Mandatory POSITIVE CONTROL first: H0_orb#1 (RH=4, m4=0x40) MUST find ALL 8 real quads!
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <mutex>
#include <set>
#include <string>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static inline void fwht8(std::array<int, 8>& a) {
    for (int st = 1; st < 8; st *= 2)
        for (int i = 0; i < 8; i += 2 * st)
            for (int j = i; j < i + st; ++j) { int x = a[j], y = a[j + st]; a[j] = x + y; a[j + st] = x - y; }
}
static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
    }
}
static uint8_t rad5_of(uint32_t p) {
    uint8_t B[5] = {}; int p0 = p & 1;
    for (int i = 0; i < 5; ++i) {
        int pi = (p >> (1 << i)) & 1;
        for (int j = 0; j < 5; ++j) {
            int pj = (p >> (1 << j)) & 1, pij = (p >> ((1 << i) ^ (1 << j))) & 1;
            if (p0 ^ pi ^ pj ^ pij) B[i] |= (1u << j);
        }
    }
    int kcnt = 0, last = 0;
    for (int x = 0; x < 32; ++x) {
        bool ok = true;
        for (int i = 0; i < 5; ++i) if (__builtin_parity(B[i] & x)) { ok = false; break; }
        if (ok) { kcnt++; last = x; }
    }
    return (kcnt == 2) ? (uint8_t)last : 0;
}
static inline int xor5_mask(uint32_t m) {
    int r = 0; while (m) { int i = __builtin_ctz(m); r ^= i; m &= m - 1; } return r;
}
using Perm32 = std::array<uint8_t, 32>;
static inline uint32_t app32(uint32_t m, const Perm32& g) {
    uint32_t out = 0; while (m) { int i = __builtin_ctz(m); out |= (1u << g[i]); m &= m - 1; } return out;
}
struct PermHash {
    size_t operator()(const Perm32& p) const {
        uint64_t h = 1469598103934665603ULL;
        for (int i = 0; i < 32; ++i) { h ^= p[i]; h *= 1099511628211ULL; }
        return (size_t)h;
    }
};
static std::vector<Perm32> build_stabH(int is_H1) {
    std::vector<Perm32> gens;
    for (int v = 2; v < 64; v += 2) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        Perm32 g{};
        for (int i = 0; i < 32; ++i) {
            int x = 2 * i + (1 - is_H1);
            int y = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
            g[i] = (uint8_t)(y >> 1);
        }
        gens.push_back(g);
    }
    Perm32 id{}; for (int i = 0; i < 32; ++i) id[i] = (uint8_t)i;
    std::unordered_set<Perm32, PermHash> vis; vis.reserve(40000);
    std::vector<Perm32> grp{id}; vis.insert(id);
    for (size_t qi = 0; qi < grp.size(); ++qi) {
        const auto cur = grp[qi];
        for (const auto& g : gens) {
            Perm32 nx{}; for (int i = 0; i < 32; ++i) nx[i] = g[cur[i]];
            if (vis.insert(nx).second) grp.push_back(nx);
        }
    }
    return grp;
}
struct PhaseReducer {
    uint64_t pivs[64]{}; uint64_t mask = 0;
    void init(uint64_t m) {
        mask = m; for (int b = 0; b < 64; ++b) pivs[b] = 0;
        for (int k = 0; k < 7; ++k) {
            uint64_t w = 0;
            for (int c = 0; c < 64; ++c) if (k == 6 || ((c >> k) & 1)) w |= (1ULL << c);
            w &= mask;
            while (w) { int b = 63 - __builtin_clzll(w); if (!pivs[b]) { pivs[b] = w; break; } w ^= pivs[b]; }
        }
    }
    uint64_t reduce(uint64_t w) const {
        w &= mask; for (int b = 63; b >= 0; --b) if (pivs[b] && ((w >> b) & 1)) w ^= pivs[b]; return w;
    }
};
using Opts32 = std::array<std::vector<int>, 32>;
using HalfMap = std::unordered_map<uint32_t, std::map<uint32_t, int>>;

static inline uint64_t interleave_H(uint32_t h_bits, uint32_t hc_bits, int is_H1) {
    uint64_t out = 0;
    for (int i = 0; i < 32; ++i) {
        if ((h_bits >> i) & 1) out |= (1ULL << (2 * i + is_H1));
        if ((hc_bits >> i) & 1) out |= (1ULL << (2 * i + (1 - is_H1)));
    }
    return out;
}
static inline uint16_t compute_q16(const std::array<int8_t, 16>& u) {
    uint16_t q = 0; for (int y = 0; y < 16; ++y) if ((u[y] >> 1) & 1) q |= (uint16_t(1) << y); return q;
}

// H^c S-collect + minE
struct Slice8S { std::array<int8_t, 8> b; uint8_t m68, sgn; };
static void enum_slice8_S(int start, int j, std::array<int, 8>& z, uint8_t m68, uint8_t sg,
                          const Opts32& opts, uint32_t track_mask,
                          std::array<std::vector<Slice8S>, 256>& out) {
    if (j < 8) {
        int idx = start + j; bool tr = (track_mask >> idx) & 1;
        for (int v : opts[idx]) {
            z[j] = v;
            uint8_t nm = m68 | ((tr && (std::abs(v) == 6 || std::abs(v) == 8)) ? (uint8_t(1) << j) : 0);
            uint8_t ns = sg | ((v < 0) ? (uint8_t(1) << j) : 0);
            enum_slice8_S(start, j + 1, z, nm, ns, opts, track_mask, out);
        }
        return;
    }
    auto u = z; fwht8(u);
    uint8_t par = 0; std::array<int8_t, 8> b;
    for (int y = 0; y < 8; ++y) {
        if (u[y] & 7) return;
        int q = u[y] >> 3; if (std::abs(q) > 8) return;
        b[y] = (int8_t)q; if (q & 1) par |= (uint8_t(1) << y);
    }
    out[par].push_back({b, m68, sg});
}
struct Slice16S { std::array<int8_t, 16> u; uint16_t m68, sgn, q16; };
static void enum_slice16_S_8x8(int start, const Opts32& opts, uint32_t track_mask,
                               const std::unordered_map<uint16_t, std::vector<uint16_t>>* allowed_par,
                               std::unordered_map<uint16_t, std::vector<Slice16S>>& out) {
    std::array<std::vector<Slice8S>, 256> q0, q1;
    std::array<int, 8> tmp{};
    enum_slice8_S(start, 0, tmp, 0, 0, opts, track_mask, q0);
    enum_slice8_S(start + 8, 0, tmp, 0, 0, opts, track_mask, q1);
    for (int p8 = 0; p8 < 256; ++p8) {
        if (q0[p8].empty() || q1[p8].empty()) continue;
        for (const auto& a : q0[p8]) for (const auto& b : q1[p8]) {
            std::array<int8_t, 16> u; uint16_t p16 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                u[y] = (int8_t)s; u[8 + y] = (int8_t)d;
                if (s & 1) p16 |= (uint16_t(1) << y); if (d & 1) p16 |= (uint16_t(1) << (8 + y));
            }
            if (!ok) continue;
            if (allowed_par && !allowed_par->count(p16)) continue;
            out[p16].push_back({u, uint16_t(a.m68|(b.m68<<8)), uint16_t(a.sgn|(b.sgn<<8)), compute_q16(u)});
        }
    }
}
struct HalfEntryS { uint32_t tw, m68, sgn; int e2; };
struct HcData {
    std::unordered_map<uint32_t, std::vector<HalfEntryS>> by_p32;
    std::unordered_map<uint16_t, std::vector<uint16_t>> p32low_by_par;
    HalfMap minE;
};
static void collect_Hc_S(const Opts32& opts, uint32_t track_mask, HcData& out) {
    out.by_p32.clear(); out.p32low_by_par.clear(); out.minE.clear();
    std::unordered_map<uint16_t, std::vector<Slice16S>> g0, g1;
    enum_slice16_S_8x8(0, opts, track_mask, nullptr, g0); if (g0.empty()) return;
    enum_slice16_S_8x8(16, opts, track_mask, nullptr, g1); if (g1.empty()) return;
    for (const auto& [par, v0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (1u << y); if (x1 & 1) p32 |= (1u << (16 + y));
                if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
            }
            if (ok) {
                out.by_p32[p32].push_back({tw, uint32_t(a.m68)|(uint32_t(b.m68)<<16), uint32_t(a.sgn)|(uint32_t(b.sgn)<<16), e2});
                auto& mp = out.minE[p32];
                auto it2 = mp.find(tw); if (it2 == mp.end() || e2 < it2->second) mp[tw] = e2;
            }
        }
    }
    for (const auto& [p32, _] : out.minE) {
        uint16_t lo = (uint16_t)(p32 & 0xFFFFu), hi = (uint16_t)(p32 >> 16);
        out.p32low_by_par[lo ^ hi].push_back(lo);
    }
}

// H u <= RH with compact F-bit indices AND exact (sc, n10) tracking!
struct HQ8 { std::array<int8_t, 8> b; uint32_t m2c, m10c; int8_t sc, n10, u; };
static void enum_H_q8(int start, int j, int cur_u, int max_u,
                      std::array<int, 8>& z, uint32_t m2c, uint32_t m10c, int sc, int n10,
                      uint32_t p, const int H_pts[32], const int h_to_f[32],
                      std::array<std::vector<HQ8>, 256>& out) {
    if (j == 8) {
        auto u = z; fwht8(u);
        uint8_t par = 0; std::array<int8_t, 8> b;
        for (int y = 0; y < 8; ++y) {
            if (u[y] & 7) return;
            int q = u[y] >> 3; if (std::abs(q) > 8) return;
            b[y] = (int8_t)q; if (q & 1) par |= (uint8_t(1) << y);
        }
        out[par].push_back({b, m2c, m10c, (int8_t)sc, (int8_t)n10, (int8_t)cur_u});
        return;
    }
    int idx = start + j, pi = (p >> idx) & 1;
    if (Q64[H_pts[idx]] == 0) {
        if (pi == 0) {
            z[j] = -6; enum_H_q8(start, j+1, cur_u, max_u, z, m2c, m10c, sc - 1, n10, p, H_pts, h_to_f, out);
            z[j] = 2;  enum_H_q8(start, j+1, cur_u, max_u, z, m2c, m10c, sc,     n10, p, H_pts, h_to_f, out);
        } else {
            z[j] = -2; enum_H_q8(start, j+1, cur_u, max_u, z, m2c, m10c, sc,     n10, p, H_pts, h_to_f, out);
            z[j] = 6;  enum_H_q8(start, j+1, cur_u, max_u, z, m2c, m10c, sc - 1, n10, p, H_pts, h_to_f, out);
        }
    } else {
        uint32_t fbit = 1u << h_to_f[idx];
        if (pi == 0) {
            z[j] = -6; enum_H_q8(start, j+1, cur_u, max_u, z, m2c, m10c, sc, n10, p, H_pts, h_to_f, out);
            if (cur_u < max_u) {
                z[j] = 2;  enum_H_q8(start, j+1, cur_u+1, max_u, z, m2c|fbit, m10c,      sc + 1, n10,     p, H_pts, h_to_f, out);
                z[j] = 10; enum_H_q8(start, j+1, cur_u+1, max_u, z, m2c,      m10c|fbit, sc - 2, n10 + 1, p, H_pts, h_to_f, out);
            }
        } else {
            z[j] = 6;  enum_H_q8(start, j+1, cur_u, max_u, z, m2c, m10c, sc, n10, p, H_pts, h_to_f, out);
            if (cur_u < max_u) {
                z[j] = -2;  enum_H_q8(start, j+1, cur_u+1, max_u, z, m2c|fbit, m10c,      sc + 1, n10,     p, H_pts, h_to_f, out);
                z[j] = -10; enum_H_q8(start, j+1, cur_u+1, max_u, z, m2c,      m10c|fbit, sc - 2, n10 + 1, p, H_pts, h_to_f, out);
            }
        }
    }
}
struct HH16 { std::array<int8_t, 16> u; uint32_t m2c, m10c; int8_t sc, n10; uint16_t q16; };
struct HHalfByU {
    std::vector<HH16> all[9];
    std::unordered_map<uint16_t, std::vector<uint32_t>> by_q[9];
};
static void enum_H_h16(int start, int max_u, uint32_t p, const int H_pts[32], const int h_to_f[32],
                       const std::unordered_map<uint16_t, std::vector<uint16_t>>& allowed_par,
                       std::unordered_map<uint16_t, HHalfByU>& out) {
    std::array<std::vector<HQ8>, 256> q0, q1; std::array<int, 8> tmp{};
    enum_H_q8(start, 0, 0, max_u, tmp, 0, 0, 0, 0, p, H_pts, h_to_f, q0);
    enum_H_q8(start + 8, 0, 0, max_u, tmp, 0, 0, 0, 0, p, H_pts, h_to_f, q1);
    for (int p8 = 0; p8 < 256; ++p8) {
        if (q0[p8].empty() || q1[p8].empty()) continue;
        for (const auto& a : q0[p8]) for (const auto& b : q1[p8]) {
            int uc = a.u + b.u; if (uc > max_u) continue;
            std::array<int8_t, 16> u; uint16_t p16 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                u[y] = (int8_t)s; u[8 + y] = (int8_t)d;
                if (s & 1) p16 |= (uint16_t(1) << y); if (d & 1) p16 |= (uint16_t(1) << (8 + y));
            }
            if (!ok || !allowed_par.count(p16)) continue;
            uint16_t q16 = compute_q16(u);
            auto& hb = out[p16];
            uint32_t id = (uint32_t)hb.all[uc].size();
            hb.all[uc].push_back({u, a.m2c | b.m2c, a.m10c | b.m10c, (int8_t)(a.sc + b.sc), (int8_t)(a.n10 + b.n10), q16});
            hb.by_q[uc][q16].push_back(id);
        }
    }
}

struct SliceHalfTables {
    std::unordered_map<uint16_t, HHalfByU> hg0, hg1;
    std::vector<uint16_t> pars;
};

template <typename Callback>
static void scan_H_joins_parallel(int RH, const SliceHalfTables& st, const HcData& hc, Callback make_thread_cb) {
    std::atomic<size_t> pi{0};
    std::vector<std::thread> ths;
    for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&, ti]() {
        auto cb = make_thread_cb(ti);
        while (true) {
            size_t idx = pi.fetch_add(1); if (idx >= st.pars.size()) break;
            uint16_t par16 = st.pars[idx];
            const auto& p32_lows = hc.p32low_by_par.at(par16);
            const auto& H0 = st.hg0.at(par16); const auto& H1 = st.hg1.at(par16);
            for (int u0 = 0; u0 <= RH; ++u0) {
                if (H0.all[u0].empty()) continue;
                for (int u1 = 0; u1 <= RH - u0; ++u1) {
                    if (H1.all[u1].empty()) continue;
                    size_t n0 = H0.all[u0].size(), n1 = H1.all[u1].size(), np = p32_lows.size();
                    if (n0 * n1 <= std::min(n0, n1) * np * 2) {
                        for (const auto& a : H0.all[u0]) for (const auto& b : H1.all[u1]) {
                            uint16_t lo = a.q16 ^ b.q16 ^ par16;
                            uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                            auto itm = hc.minE.find(p32); if (itm == hc.minE.end()) continue;
                            uint32_t tw = 0; int e2 = 0; bool ok = true;
                            for (int y = 0; y < 16; ++y) {
                                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                                e2 += x0*x0 + x1*x1;
                                if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
                            }
                            if (ok) cb(a, b, tw, e2, itm->second);
                        }
                    } else if (n0 <= n1) {
                        const auto& qm1 = H1.by_q[u1];
                        for (const auto& a : H0.all[u0]) {
                            uint16_t base = a.q16 ^ par16;
                            for (uint16_t lo : p32_lows) {
                                auto itq = qm1.find(base ^ lo); if (itq == qm1.end()) continue;
                                uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                                const auto& mp = hc.minE.at(p32);
                                for (uint32_t id1 : itq->second) {
                                    const auto& b = H1.all[u1][id1];
                                    uint32_t tw = 0; int e2 = 0; bool ok = true;
                                    for (int y = 0; y < 16; ++y) {
                                        if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                                        int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                                        e2 += x0*x0 + x1*x1;
                                        if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
                                    }
                                    if (ok) cb(a, b, tw, e2, mp);
                                }
                            }
                        }
                    } else {
                        const auto& qm0 = H0.by_q[u0];
                        for (const auto& b : H1.all[u1]) {
                            uint16_t base = b.q16 ^ par16;
                            for (uint16_t lo : p32_lows) {
                                auto itq = qm0.find(base ^ lo); if (itq == qm0.end()) continue;
                                uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                                const auto& mp = hc.minE.at(p32);
                                for (uint32_t id0 : itq->second) {
                                    const auto& a = H0.all[u0][id0];
                                    uint32_t tw = 0; int e2 = 0; bool ok = true;
                                    for (int y = 0; y < 16; ++y) {
                                        if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                                        int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                                        e2 += x0*x0 + x1*x1;
                                        if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
                                    }
                                    if (ok) cb(a, b, tw, e2, mp);
                                }
                            }
                        }
                    }
                }
            }
        }
        cb.finish();
    });
    for (auto& th : ths) th.join();
}

static long long exact_join_fixed_F(int is_H1, const int H_pts[32], uint32_t mHZ,
                                    const std::array<uint32_t, 4>& t,
                                    const std::array<uint32_t, 4>& m2F,
                                    const std::array<uint32_t, 4>& m10F,
                                    int d3_cnt, uint8_t need_d3_xor, uint32_t k3_H,
                                    uint32_t Z1, uint32_t track_s, uint32_t k1_act,
                                    const HcData hc[4]) {
    int need_e6_cnt = __builtin_popcount(mHZ) - d3_cnt;
    uint64_t phase64 = interleave_H(0xFFFFFFFFu, Z1 | k1_act, is_H1);
    PhaseReducer red; red.init(phase64);
    struct Sig {
        uint32_t e6, e8; int m; uint64_t sgn;
        bool operator<(const Sig& o) const {
            if (e6 != o.e6) return e6 < o.e6; if (e8 != o.e8) return e8 < o.e8;
            if (m != o.m) return m < o.m; return sgn < o.sgn;
        }
        bool operator==(const Sig& o) const { return e6 == o.e6 && e8 == o.e8 && m == o.m && sgn == o.sgn; }
    };
    std::array<std::vector<Sig>, 4> sigs;
    for (int k = 0; k < 4; ++k) {
        Opts32 ot;
        for (int i = 0; i < 32; ++i) {
            int pi = (t[k] >> i) & 1;
            if (Q64[H_pts[i]] == 0) ot[i] = pi ? std::vector<int>{-2, 6} : std::vector<int>{-6, 2};
            else {
                if ((m2F[k] >> i) & 1) ot[i] = pi ? std::vector<int>{-2} : std::vector<int>{2};
                else if ((m10F[k] >> i) & 1) ot[i] = pi ? std::vector<int>{-10} : std::vector<int>{10};
                else ot[i] = pi ? std::vector<int>{6} : std::vector<int>{-6};
            }
        }
        std::unordered_map<uint16_t, std::vector<Slice16S>> g0, g1;
        enum_slice16_S_8x8(0, ot, mHZ, &hc[k].p32low_by_par, g0); if (g0.empty()) return 0;
        enum_slice16_S_8x8(16, ot, mHZ, &hc[k].p32low_by_par, g1); if (g1.empty()) return 0;
        for (const auto& [par, v0] : g0) {
            auto it1 = g1.find(par); if (it1 == g1.end()) continue;
            for (const auto& a : v0) for (const auto& b : it1->second) {
                uint16_t lo = a.q16 ^ b.q16 ^ par;
                uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par) << 16);
                auto its = hc[k].by_p32.find(p32); if (its == hc[k].by_p32.end()) continue;
                uint32_t tw = 0; int e2 = 0; bool ok = true;
                for (int y = 0; y < 16; ++y) {
                    if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                    int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                    e2 += x0*x0 + x1*x1;
                    if (std::abs(x0) == 2) tw |= (1u << y); if (std::abs(x1) == 2) tw |= (1u << (16 + y));
                }
                if (!ok) continue;
                uint32_t e6 = uint32_t(a.m68) | (uint32_t(b.m68) << 16);
                uint32_t sgH = uint32_t(a.sgn) | (uint32_t(b.sgn) << 16);
                for (const auto& es : its->second) {
                    if (tw & es.tw) continue;
                    int m = (e2 + es.e2) / 2; if (m > 64) continue;
                    sigs[k].push_back({e6, es.m68, m, red.reduce(interleave_H(sgH, es.sgn, is_H1))});
                }
            }
        }
        std::sort(sigs[k].begin(), sigs[k].end());
        sigs[k].erase(std::unique(sigs[k].begin(), sigs[k].end()), sigs[k].end());
        if (sigs[k].empty()) return 0;
    }
    std::array<int, 4> ord{0, 1, 2, 3};
    std::sort(ord.begin(), ord.end(), [&](int a, int b){ return sigs[a].size() < sigs[b].size(); });
    struct LE { uint32_t e6; uint64_t sgn; };
    std::unordered_map<uint64_t, std::vector<LE>> lmap;
    for (const auto& a : sigs[ord[0]]) for (const auto& b : sigs[ord[3]]) {
        if ((a.e6 & b.e6) || (a.e8 & b.e8)) continue;
        int m = a.m + b.m; if (m > 102) continue;
        lmap[(uint64_t(a.e8 | b.e8) << 8) | uint64_t(m)].push_back({a.e6 | b.e6, a.sgn ^ b.sgn});
    }
    long long hits = 0;
    for (const auto& c : sigs[ord[1]]) for (const auto& d : sigs[ord[2]]) {
        if ((c.e6 & d.e6) || (c.e8 & d.e8)) continue;
        int m = c.m + d.m; if (m > 102) continue;
        uint32_t e8r = c.e8 | d.e8;
        if ((e8r & track_s) != e8r) continue;
        auto it = lmap.find((uint64_t(track_s ^ e8r) << 8) | uint64_t(102 - m));
        if (it == lmap.end()) continue;
        uint32_t re6 = c.e6 | d.e6; uint64_t rsgn = c.sgn ^ d.sgn;
        for (const auto& L : it->second) {
            if (L.e6 & re6) continue;
            uint32_t u6 = L.e6 | re6;
            if (__builtin_popcount(u6) != need_e6_cnt) continue;
            uint32_t d3_H = mHZ ^ u6;
            if (xor5_mask(d3_H) != need_d3_xor) continue;
            uint64_t tgt_sgn = red.reduce(phase64 ^ interleave_H(d3_H | k3_H, 0, is_H1));
            if ((L.sgn ^ rsgn) == tgt_sgn) hits++;
        }
    }
    return hits;
}

static inline uint32_t unpack_F(uint32_t cf, const int f_to_h[20]) {
    uint32_t out = 0;
    while (cf) { int j = __builtin_ctz(cf); out |= (1u << f_to_h[j]); cf &= cf - 1; }
    return out;
}

struct PairKey {
    uint32_t n22, b2, o2;
    bool operator==(const PairKey& o) const { return n22 == o.n22 && b2 == o.b2 && o2 == o.o2; }
};
struct PairKeyHash {
    size_t operator()(const PairKey& k) const {
        uint64_t h = (uint64_t(k.n22) << 40) ^ (uint64_t(k.b2) << 20) ^ uint64_t(k.o2);
        h ^= h >> 33; h *= 0xff51afd7ed558ccdULL; h ^= h >> 33; return (size_t)h;
    }
};
struct PairRec { uint32_t m2a, m10a, m2b, m10b; uint8_t m; };
struct PairGroup {
    int min_m = 999;
    std::vector<PairRec> items;
};

static long long solve_one_RH68(const std::string& label, int is_H1, int RH,
                                const std::array<uint32_t, 4>& t, uint32_t u_union, uint32_t oddF,
                                uint8_t rad_xor, uint32_t m4, uint32_t k2) {
    auto t0 = std::chrono::steady_clock::now();
    int H_pts[32], Hc_pts[32], h_to_f[32], f_to_h[20];
    int nF = 0, nHZ = 0;
    uint32_t mHZ = 0, mHcZ = 0, mHcF = 0;
    for (int i = 0; i < 32; ++i) {
        H_pts[i] = 2 * i + is_H1; Hc_pts[i] = 2 * i + (1 - is_H1);
        if (Q64[H_pts[i]] == 0) { mHZ |= (1u << i); h_to_f[i] = -1; nHZ++; }
        else { h_to_f[i] = nF; f_to_h[nF++] = i; }
        if (Q64[Hc_pts[i]] == 0) mHcZ |= (1u << i); else mHcF |= (1u << i);
    }
    uint32_t Z1 = mHcZ & t[0] & t[1] & t[2] & t[3];
    uint32_t Z0 = mHcZ & ~(t[0] | t[1] | t[2] | t[3]);
    uint32_t track_s = (Z0 ^ m4) | k2;

    HcData hc[4];
    for (int k = 0; k < 4; ++k) {
        Opts32 os;
        for (int i = 0; i < 32; ++i) {
            int pi = (t[k] >> i) & 1;
            if (Q64[Hc_pts[i]] == 1) {
                if ((oddF >> i) & 1) os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 8};
                else if ((k2 >> i) & 1) os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 0, 8};
                else os[i] = pi ? std::vector<int>{-12, 12} : std::vector<int>{0};
            } else {
                if (pi) os[i] = {-4, 4};
                else if (((u_union | m4) >> i) & 1) os[i] = {0};
                else os[i] = {-8, 0, 8};
            }
        }
        collect_Hc_S(os, track_s, hc[k]);
        if (hc[k].minE.empty()) {
            std::cout << "  " << label << ": DEAD (hc[" << k << "] empty)\n" << std::flush;
            return 0;
        }
    }

    // Build SliceHalfTables once per distinct slice!
    SliceHalfTables st[4];
    int same_as[4] = {-1, -1, -1, -1};
    for (int k = 0; k < 4; ++k) {
        if (k > 0 && t[k] == t[k-1]) { same_as[k] = (same_as[k-1] >= 0) ? same_as[k-1] : (k-1); continue; }
        enum_H_h16(0, RH, t[k], H_pts, h_to_f, hc[k].p32low_by_par, st[k].hg0);
        enum_H_h16(16, RH, t[k], H_pts, h_to_f, hc[k].p32low_by_par, st[k].hg1);
        for (const auto& [par16, _] : hc[k].p32low_by_par)
            if (st[k].hg0.count(par16) && st[k].hg1.count(par16)) st[k].pars.push_back(par16);
    }

    // PASS 1: Exact uncoupled DP min_m[k][sc+36][n10] -> exact max_allowed_m[k][sc+36][n10]!
    int min_m_dp[4][48][9];
    for (int k = 0; k < 4; ++k) for (int s = 0; s < 48; ++s) for (int n = 0; n <= 8; ++n) min_m_dp[k][s][n] = 999;
    for (int k = 0; k < 4; ++k) {
        if (same_as[k] >= 0) {
            int p = same_as[k];
            for (int s = 0; s < 48; ++s) for (int n = 0; n <= 8; ++n) min_m_dp[k][s][n] = min_m_dp[p][s][n];
            continue;
        }
        std::mutex mu;
        struct Pass1CB {
            int RH; int loc[48][9]; int (*dst)[9]; std::mutex* mu;
            Pass1CB(int rh, int (*d)[9], std::mutex* m) : RH(rh), dst(d), mu(m) {
                for (int s = 0; s < 48; ++s) for (int n = 0; n <= 8; ++n) loc[s][n] = 999;
            }
            void operator()(const HH16& a, const HH16& b, uint32_t tw, int e2, const std::map<uint32_t, int>& mp) {
                int best_es = 999999;
                for (const auto& [tw_s, es] : mp) if ((tw & tw_s) == 0 && es < best_es) best_es = es;
                if (best_es < 999999) {
                    int m = (e2 + best_es) / 2; if (m > 64) return;
                    int sc = a.sc + b.sc, n10 = a.n10 + b.n10;
                    if (sc + 36 >= 0 && sc + 36 < 48 && n10 <= RH)
                        if (m < loc[sc + 36][n10]) loc[sc + 36][n10] = m;
                }
            }
            void finish() {
                std::lock_guard<std::mutex> lk(*mu);
                for (int s = 0; s < 48; ++s) for (int n = 0; n <= 8; ++n) dst[s][n] = std::min(dst[s][n], loc[s][n]);
            }
        };
        scan_H_joins_parallel(RH, st[k], hc[k], [&](int){ return Pass1CB(RH, min_m_dp[k], &mu); });
    }

    int dp_pref[5][200][9], dp_suff[5][200][9];
    for (int k = 0; k <= 4; ++k) for (int s = 0; s < 200; ++s) for (int n = 0; n <= 8; ++n)
        dp_pref[k][s][n] = dp_suff[k][s][n] = 999;
    dp_pref[0][150][0] = 0;
    for (int k = 0; k < 4; ++k)
        for (int s = 0; s < 200; ++s) for (int n = 0; n <= RH; ++n) {
            if (dp_pref[k][s][n] >= 999) continue;
            for (int sc = 0; sc < 48; ++sc) for (int n10 = 0; n10 <= RH - n; ++n10) {
                int m = min_m_dp[k][sc][n10]; if (m >= 999) continue;
                int ns = s + (sc - 36);
                if (ns >= 0 && ns < 200) dp_pref[k+1][ns][n + n10] = std::min(dp_pref[k+1][ns][n + n10], dp_pref[k][s][n] + m);
            }
        }
    dp_suff[4][150][0] = 0;
    for (int k = 3; k >= 0; --k)
        for (int s = 0; s < 200; ++s) for (int n = 0; n <= RH; ++n) {
            if (dp_suff[k+1][s][n] >= 999) continue;
            for (int sc = 0; sc < 48; ++sc) for (int n10 = 0; n10 <= RH - n; ++n10) {
                int m = min_m_dp[k][sc][n10]; if (m >= 999) continue;
                int ns = s + (sc - 36);
                if (ns >= 0 && ns < 200) dp_suff[k][ns][n + n10] = std::min(dp_suff[k][ns][n + n10], dp_suff[k+1][s][n] + m);
            }
        }
    int tgt = RH - nHZ;
    int dp_best = 999;
    for (int n = 0; n <= RH; ++n) dp_best = std::min(dp_best, dp_pref[4][150 + tgt][n]);
    if (dp_best > 102) {
        std::cout << "  " << label << ": DEAD (DP_min=" << dp_best << ") in "
                  << std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count() << "s\n" << std::flush;
        return 0;
    }

    int max_allow[4][48][9];
    for (int k = 0; k < 4; ++k) for (int sc = 0; sc < 48; ++sc) for (int n10 = 0; n10 <= 8; ++n10) {
        int best_other = 999;
        if (min_m_dp[k][sc][n10] < 999) {
            for (int sL = 0; sL < 200; ++sL) {
                int sR = 300 + tgt - (sc - 36) - sL;
                if (sR < 0 || sR >= 200) continue;
                for (int nL = 0; nL <= RH - n10; ++nL) {
                    int wL = dp_pref[k][sL][nL]; if (wL >= 999) continue;
                    for (int nR = 0; nR <= RH - n10 - nL; ++nR) {
                        int wR = dp_suff[k+1][sR][nR]; if (wR < 999 && wL + wR < best_other) best_other = wL + wR;
                    }
                }
            }
        }
        max_allow[k][sc][n10] = (best_other <= 102) ? (102 - best_other) : -1;
    }

    // PASS 2: Collect ONLY (m2c, m10c) -> min_m passing m <= max_allow[k][sc+36][n10]!
    std::unordered_map<uint64_t, int> minm[4];
    int min_all[4] = {999, 999, 999, 999};
    for (int k = 0; k < 4; ++k) {
        // Notice: max_allow[k] can differ between slices even if t[k]==t[k-1] ONLY if same_as differs?
        // Actually if t[k]==t[k-1], dp_pref/dp_suff is symmetric in k and k-1, so max_allow[k] == max_allow[k-1]!
        bool can_copy = (same_as[k] >= 0);
        if (can_copy) {
            int p = same_as[k];
            for (int sc = 0; sc < 48 && can_copy; ++sc)
                for (int n10 = 0; n10 <= RH; ++n10)
                    if (max_allow[k][sc][n10] != max_allow[p][sc][n10]) { can_copy = false; break; }
            if (can_copy) { minm[k] = minm[p]; min_all[k] = min_all[p]; continue; }
        }
        int sk = (same_as[k] >= 0) ? same_as[k] : k;
        std::mutex mu;
        struct Pass2CB {
            int RH; const int (*allow)[9];
            std::unordered_map<uint64_t, int> loc;
            std::unordered_map<uint64_t, int>* dst; std::mutex* mu;
            Pass2CB(int rh, const int (*al)[9], std::unordered_map<uint64_t, int>* d, std::mutex* m)
                : RH(rh), allow(al), dst(d), mu(m) {}
            void operator()(const HH16& a, const HH16& b, uint32_t tw, int e2, const std::map<uint32_t, int>& mp) {
                int sc = a.sc + b.sc, n10 = a.n10 + b.n10;
                if (sc + 36 < 0 || sc + 36 >= 48 || n10 > RH) return;
                int lim = allow[sc + 36][n10];
                if (lim < 0) return;
                int best_es = 999999;
                for (const auto& [tw_s, es] : mp) if ((tw & tw_s) == 0 && es < best_es) best_es = es;
                if (best_es < 999999) {
                    int m = (e2 + best_es) / 2;
                    if (m > lim || m > 64) return;
                    uint64_t key = (uint64_t(a.m2c | b.m2c) << 20) | uint64_t(a.m10c | b.m10c);
                    auto it = loc.find(key); if (it == loc.end() || m < it->second) loc[key] = m;
                }
            }
            void finish() {
                std::lock_guard<std::mutex> lk(*mu);
                for (const auto& [key, m] : loc) {
                    auto it = dst->find(key); if (it == dst->end() || m < it->second) (*dst)[key] = m;
                }
            }
        };
        scan_H_joins_parallel(RH, st[sk], hc[k], [&](int){ return Pass2CB(RH, max_allow[k], &minm[k], &mu); });
        for (const auto& [_, m] : minm[k]) min_all[k] = std::min(min_all[k], m);
    }
    int sum_min = min_all[0] + min_all[1] + min_all[2] + min_all[3];
    if (sum_min > 102) {
        std::cout << "  " << label << ": DEAD (post-DP sum_min=" << sum_min << ")\n" << std::flush;
        return 0;
    }

    struct FItem { uint32_t m2, m10; uint8_t m; };
    std::array<std::unordered_map<uint32_t, std::vector<FItem>>, 4> by_supp;
    std::array<std::unordered_map<uint32_t, int>, 4> min_m_supp;
    std::array<size_t, 4> n_fi{};
    for (int k = 0; k < 4; ++k) {
        int lim = 102 - (sum_min - min_all[k]);
        for (const auto& [key, m] : minm[k]) {
            if (m > lim) continue;
            uint32_t m2 = (uint32_t)(key >> 20), m10 = (uint32_t)(key & 0xFFFFFu);
            uint32_t supp = m2 | m10;
            by_supp[k][supp].push_back({m2, m10, (uint8_t)m});
            auto it = min_m_supp[k].find(supp);
            if (it == min_m_supp[k].end() || m < it->second) min_m_supp[k][supp] = m;
            n_fi[k]++;
        }
        for (auto& [_, v] : by_supp[k])
            std::sort(v.begin(), v.end(), [](const FItem& a, const FItem& b){ return a.m < b.m; });
    }
    double dt_dp = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "  " << label << " (RH=" << RH << ", DP=" << dp_best << "): FItems=("
              << n_fi[0] << "," << n_fi[1] << "," << n_fi[2] << "," << n_fi[3]
              << ") supps=(" << by_supp[0].size() << "," << by_supp[1].size() << "," << by_supp[2].size() << "," << by_supp[3].size()
              << ") [" << dt_dp << "s]\n" << std::flush;

    std::array<int, 4> ord{0, 1, 2, 3};
    std::sort(ord.begin(), ord.end(), [&](int a, int b){ return n_fi[a] < n_fi[b]; });

    // Support-indexed build_pairs: EXACT identity mk = s_a + d1 + 2*d2 <= RH!!
    uint32_t fullF = (1u << nF) - 1u;
    auto build_pairs = [&](int k1, int k2, int max_m) {
        std::unordered_map<PairKey, PairGroup, PairKeyHash> pmap;
        const auto& S1 = by_supp[k1];
        const auto& S2 = by_supp[k2];
        const auto& M2 = min_m_supp[k2];
        for (const auto& [supp_a, va] : S1) {
            int sa = __builtin_popcount(supp_a);
            int min_ma = va[0].m;
            if (min_ma > max_m) continue;
            // Enumerate all D_sub <= supp_a, D_add <= (~supp_a & fullF) with sa + |D_sub| + 2*|D_add| <= RH!
            int a_bits[20], na = 0, c_bits[20], nc = 0;
            for (int b = 0; b < nF; ++b) {
                if ((supp_a >> b) & 1) a_bits[na++] = b; else c_bits[nc++] = b;
            }
            int slack = RH - sa;
            auto try_supp_b = [&](uint32_t supp_b) {
                auto it2 = S2.find(supp_b); if (it2 == S2.end()) return;
                if (min_ma + M2.at(supp_b) > max_m) return;
                uint32_t inter = supp_a & supp_b;
                uint32_t o2 = supp_a ^ supp_b;
                const auto& vb = it2->second;
                for (const auto& a : va) {
                    if (a.m + vb[0].m > max_m) break;
                    if (a.m10 & ~inter) continue;
                    int rem = max_m - a.m;
                    for (const auto& b : vb) {
                        if (b.m > rem) break;
                        if (b.m10 & ~inter) continue;
                        if (a.m10 & b.m10) continue;
                        uint32_t n22 = a.m10 | b.m10;
                        uint32_t b2 = inter & ~n22;
                        auto& grp = pmap[{n22, b2, o2}];
                        int totm = a.m + b.m;
                        if (totm < grp.min_m) grp.min_m = totm;
                        grp.items.push_back({a.m2, a.m10, b.m2, b.m10, (uint8_t)totm});
                    }
                }
            };
            // Recursive enumeration of D_sub (cost 1) then D_add (cost 2)
            auto enum_add = [&](auto& self, int idx, int rem_sl, uint32_t cur_sb) -> void {
                try_supp_b(cur_sb);
                if (rem_sl < 2) return;
                for (int i = idx; i < nc; ++i)
                    self(self, i + 1, rem_sl - 2, cur_sb | (1u << c_bits[i]));
            };
            auto enum_sub = [&](auto& self, int idx, int rem_sl, uint32_t cur_sb) -> void {
                enum_add(enum_add, 0, rem_sl, cur_sb);
                if (rem_sl < 1) return;
                for (int i = idx; i < na; ++i)
                    self(self, i + 1, rem_sl - 1, cur_sb ^ (1u << a_bits[i]));
            };
            enum_sub(enum_sub, 0, slack, supp_a);
        }
        for (auto& [_, grp] : pmap)
            std::sort(grp.items.begin(), grp.items.end(), [](const PairRec& x, const PairRec& y){ return x.m < y.m; });
        return pmap;
    };

    int max_mL = 102 - min_all[ord[1]] - min_all[ord[2]];
    int max_mR = 102 - min_all[ord[0]] - min_all[ord[3]];
    auto Lmap = build_pairs(ord[0], ord[3], max_mL);
    auto Rmap = build_pairs(ord[1], ord[2], max_mR);
    size_t l_items = 0, r_items = 0;
    for (const auto& [_, g] : Lmap) l_items += g.items.size();
    for (const auto& [_, g] : Rmap) r_items += g.items.size();

    // Index Rmap by U_R = n22 | b2 | o2!
    struct RKeyRef { PairKey k; const PairGroup* g; };
    std::unordered_map<uint32_t, std::vector<RKeyRef>> R_by_U;
    std::unordered_map<uint32_t, int> R_min_m_U;
    for (const auto& [rk, rg] : Rmap) {
        uint32_t ur = rk.n22 | rk.b2 | rk.o2;
        R_by_U[ur].push_back({rk, &rg});
        auto it = R_min_m_U.find(ur);
        if (it == R_min_m_U.end() || rg.min_m < it->second) R_min_m_U[ur] = rg.min_m;
    }

    std::vector<std::pair<PairKey, const PairGroup*>> Lvec;
    Lvec.reserve(Lmap.size());
    for (const auto& [lk, lg] : Lmap) Lvec.push_back({lk, &lg});

    struct Cand {
        std::array<uint32_t, 4> m2, m10; // unpacked 32-bit H masks!
        int d3_cnt; uint8_t need_d3_xor; uint32_t k3_H;
        bool operator<(const Cand& o) const { if (m2 != o.m2) return m2 < o.m2; return m10 < o.m10; }
        bool operator==(const Cand& o) const { return m2 == o.m2 && m10 == o.m10; }
    };
    std::vector<Cand> cands;
    std::mutex cmu;
    std::atomic<size_t> li{0};
    std::vector<std::thread> ths;
    for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&]() {
        std::vector<Cand> lc;
        while (true) {
            size_t idx = li.fetch_add(1); if (idx >= Lvec.size()) break;
            const PairKey& a = Lvec[idx].first;
            const PairGroup& ag = *Lvec[idx].second;
            uint32_t ul = a.n22 | a.b2 | a.o2;
            uint32_t la = a.b2 | a.o2;
            int mk_l = __builtin_popcount(a.n22) + __builtin_popcount(a.b2) + 2 * __builtin_popcount(a.o2);
            int slack = RH - mk_l;
            int b_bits[20], nb = 0, c_bits[20], nc = 0;
            for (int bit = 0; bit < nF; ++bit) {
                if ((a.b2 >> bit) & 1) b_bits[nb++] = bit;
                else if (!((ul >> bit) & 1)) c_bits[nc++] = bit;
            }
            auto try_ur = [&](uint32_t ur) {
                auto itu = R_by_U.find(ur); if (itu == R_by_U.end()) return;
                if (ag.min_m + R_min_m_U.at(ur) > 102) return;
                for (const auto& rr : itu->second) {
                    const PairKey& b = rr.k;
                    const PairGroup& bg = *rr.g;
                    if (ag.min_m + bg.min_m > 102) continue;
                    if (a.n22 & b.n22) continue;
                    if ((a.n22 & ~b.b2) || (b.n22 & ~a.b2)) continue;
                    uint32_t rb = b.b2 | b.o2;
                    if ((a.o2 & ~rb) || (b.o2 & ~la)) continue;
                    uint32_t k1 = a.n22 | b.n22;
                    uint32_t k4 = (a.b2 & b.b2) & ~k1;
                    uint32_t k3 = ((a.b2 & b.o2) | (a.o2 & b.b2)) & ~k1;
                    uint32_t k2m = ((a.o2 & b.o2) | (a.b2 & ~rb & ~k1) | (b.b2 & ~la & ~k1)) & ~k1;
                    int sumk = __builtin_popcount(k1) + 2*__builtin_popcount(k2m) + 3*__builtin_popcount(k3) + 4*__builtin_popcount(k4);
                    if (sumk > RH) continue;
                    int d3_cnt = RH - sumk;
                    uint32_t k1_H = unpack_F(k1, f_to_h), k3_H = unpack_F(k3, f_to_h);
                    uint8_t need_d3_xor = rad_xor ^ (uint8_t)xor5_mask(k1_H | k3_H);
                    if (d3_cnt == 0 && need_d3_xor != 0) continue;
                    if (d3_cnt == 1 && !((mHZ >> need_d3_xor) & 1)) continue;
                    if (d3_cnt == 2 && need_d3_xor == 0) continue;
                    for (const auto& il : ag.items) {
                        if (il.m + bg.items[0].m > 102) break;
                        int rem = 102 - il.m;
                        for (const auto& ir : bg.items) {
                            if (ir.m > rem) break;
                            std::array<uint32_t, 4> m2, m10;
                            m2[ord[0]] = unpack_F(il.m2a, f_to_h); m10[ord[0]] = unpack_F(il.m10a, f_to_h);
                            m2[ord[3]] = unpack_F(il.m2b, f_to_h); m10[ord[3]] = unpack_F(il.m10b, f_to_h);
                            m2[ord[1]] = unpack_F(ir.m2a, f_to_h); m10[ord[1]] = unpack_F(ir.m10a, f_to_h);
                            m2[ord[2]] = unpack_F(ir.m2b, f_to_h); m10[ord[2]] = unpack_F(ir.m10b, f_to_h);
                            lc.push_back({m2, m10, d3_cnt, need_d3_xor, k3_H});
                        }
                    }
                }
            };
            auto enum_add = [&](auto& self, int i0, int rsl, uint32_t cur_ur) -> void {
                try_ur(cur_ur);
                if (rsl < 2) return;
                for (int i = i0; i < nc; ++i) self(self, i + 1, rsl - 2, cur_ur | (1u << c_bits[i]));
            };
            auto enum_sub = [&](auto& self, int i0, int rsl, uint32_t cur_ur) -> void {
                enum_add(enum_add, 0, rsl, cur_ur);
                if (rsl < 1) return;
                for (int i = i0; i < nb; ++i) self(self, i + 1, rsl - 1, cur_ur ^ (1u << b_bits[i]));
            };
            enum_sub(enum_sub, 0, slack, ul);
        }
        std::lock_guard<std::mutex> lk(cmu);
        cands.insert(cands.end(), lc.begin(), lc.end());
    });
    for (auto& th : ths) th.join();
    std::sort(cands.begin(), cands.end());
    cands.erase(std::unique(cands.begin(), cands.end()), cands.end());
    double dt_join = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "    Lkeys=" << Lmap.size() << "(" << l_items << ") Rkeys=" << Rmap.size() << "(" << r_items
              << ") -> cands=" << cands.size() << " [" << dt_join << "s]\n" << std::flush;

    std::atomic<size_t> ci{0};
    std::atomic<long long> tot_hits{0};
    ths.clear();
    for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&]() {
        while (true) {
            size_t idx = ci.fetch_add(1); if (idx >= cands.size()) break;
            const auto& c = cands[idx];
            long long h = exact_join_fixed_F(is_H1, H_pts, mHZ, t, c.m2, c.m10, c.d3_cnt, c.need_d3_xor, c.k3_H, Z1, track_s, oddF, hc);
            if (h > 0) {
                tot_hits.fetch_add(h);
                std::lock_guard<std::mutex> lk(cmu);
                std::cout << "    [HIT!!] " << label << " cand#" << idx << " h=" << h
                          << " d3=" << c.d3_cnt << " d3x=" << (int)c.need_d3_xor
                          << " m2=(" << std::hex << c.m2[0] << "," << c.m2[1] << "," << c.m2[2] << "," << c.m2[3]
                          << ") m10=(" << c.m10[0] << "," << c.m10[1] << "," << c.m10[2] << "," << c.m10[3] << ")" << std::dec << "\n" << std::flush;
            }
        }
    });
    for (auto& th : ths) th.join();
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "  >>> RESULT " << label << " in " << dt << "s: cands=" << cands.size()
              << " TOTAL_HITS=" << tot_hits.load() << " <<<\n" << std::flush;
    return tot_hits.load();
}

int main() {
    init_Q();
    uint32_t mons[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0;
        for (int i = 0; i < 32; ++i) if ((i & m) == m) mask |= (1u << i);
        mons[mk++] = mask;
    }
    std::vector<uint32_t> all_q(65536, 0);
    for (int s = 1; s < 65536; ++s) all_q[s] = all_q[s - 1] ^ mons[__builtin_ctz(s)];
    std::unordered_map<uint32_t, uint8_t> rad_map;
    for (uint32_t p : all_q) rad_map[p] = rad5_of(p);

    // 1. MANDATORY POSITIVE CONTROL: H0_orb#1 at RH=4, m4=0x40 (must find ALL 8 real quads, hits > 0!)
    {
        std::array<uint32_t, 4> t_pos = {0u, 0u, 0xf0fu, 0xc03f3030u};
        std::cout << "=== POSITIVE CONTROL (H0_orb#1 RH=4 m4=0x40) ===\n" << std::flush;
        long long hpos = solve_one_RH68("POSCTRL_H0_orb1_RH4_m4", 0, 4, t_pos, 0, 0, 1, 0x40u, 0);
        if (hpos <= 0) { std::cerr << "POSITIVE CONTROL FAILED!\n"; return 1; }
        std::cout << "POSITIVE CONTROL PASSED (hits=" << hpos << ")!\n\n" << std::flush;
    }

    // 2. ALL 13 SURVIVING FINAL JOBS across Case II (H_0) and Case III (H_1)!
    long long grand_hits = 0;
    for (int is_H1 : {0, 1}) {
        int R_max = is_H1 ? 8 : 6;
        uint32_t mHcZ = 0, mHcF = 0;
        for (int i = 0; i < 32; ++i) {
            if (Q64[2 * i + (1 - is_H1)] == 0) mHcZ |= (1u << i); else mHcF |= (1u << i);
        }
        auto grp = build_stabH(is_H1);
        std::unordered_map<uint32_t, std::vector<uint32_t>> byZ, byF;
        for (uint32_t q : all_q) { byZ[q & mHcZ].push_back(q); byF[q & mHcF].push_back(q); }

        std::vector<std::vector<uint32_t>> U_reps;
        U_reps.push_back({});
        if (R_max == 8) {
            std::unordered_set<uint32_t> visZ;
            for (const auto& [z, _] : byZ)
                if (z != 0 && __builtin_popcount(z) == 2 && !visZ.count(z)) {
                    U_reps.push_back({z});
                    for (const auto& g : grp) visZ.insert(app32(z, g));
                }
        }
        std::vector<uint32_t> f_errs[3];
        std::vector<int> fbits;
        for (int i = 0; i < 32; ++i) if ((mHcF >> i) & 1) fbits.push_back(i);
        f_errs[0].push_back(0);
        for (size_t i = 0; i < fbits.size(); ++i)
            for (size_t j = i + 1; j < fbits.size(); ++j)
                f_errs[2].push_back((1u << fbits[i]) | (1u << fbits[j]));

        std::cout << "\n=== " << (is_H1 ? "Case III (H_1)" : "Case II (H_0)") << " FINAL JOBS ===\n" << std::flush;
        int oid = 0;
        for (const auto& U : U_reps) {
            int dim = (int)U.size();
            uint32_t u_union = dim ? U[0] : 0;
            int m2Z = __builtin_popcount(u_union), xZ = xor5_mask(u_union);
            std::vector<Perm32> stabU;
            for (const auto& g : grp) if (dim == 0 || app32(U[0], g) == U[0]) stabU.push_back(g);
            const auto& L1 = byZ[u_union]; const auto& L2 = byZ[0];
            std::set<std::array<uint32_t, 4>> local_tuples;
            for (uint32_t a : L1) for (uint32_t b : L2) {
                uint32_t prodF = (a & b) & mHcF;
                for (int w = 0; w <= (R_max - 6 - m2Z); w += 2) {
                    for (uint32_t e : f_errs[w]) {
                        int need_rad = 1 ^ xZ ^ xor5_mask(e);
                        auto it = byF.find(prodF ^ e); if (it == byF.end()) continue;
                        for (uint32_t p0 : it->second) {
                            uint32_t p1 = p0 ^ a, p2 = p0 ^ b, p3 = p0 ^ a ^ b ^ mHcF;
                            int rx = rad_map.at(p0) ^ rad_map.at(p1) ^ rad_map.at(p2) ^ rad_map.at(p3);
                            if (rx != need_rad) continue;
                            std::array<uint32_t, 4> t{p0, p1, p2, p3};
                            std::sort(t.begin(), t.end());
                            local_tuples.insert(t);
                        }
                    }
                }
            }
            std::set<std::array<uint32_t, 4>> visT;
            for (const auto& t : local_tuples) {
                if (visT.count(t)) continue;
                std::vector<Perm32> stabT;
                for (const auto& g : stabU) {
                    std::array<uint32_t, 4> nx{app32(t[0], g), app32(t[1], g), app32(t[2], g), app32(t[3], g)};
                    std::sort(nx.begin(), nx.end()); visT.insert(nx);
                    if (nx == t) stabT.push_back(g);
                }
                uint32_t a = t[1] ^ t[0], b = t[2] ^ t[0];
                uint32_t oddF = (t[0] ^ (a & b)) & mHcF;
                uint32_t Z0 = mHcZ & ~(t[0] | t[1] | t[2] | t[3]);
                int remR = R_max - m2Z - __builtin_popcount(oddF);
                uint8_t rx = rad_map.at(t[0]) ^ rad_map.at(t[1]) ^ rad_map.at(t[2]) ^ rad_map.at(t[3]);
                std::string pfx = (is_H1 ? "H1_orb#" : "H0_orb#") + std::to_string(oid);
                if (remR == 6) {
                    grand_hits += solve_one_RH68(pfx + "_RH6_eHc0", is_H1, 6, t, u_union, oddF, rx, 0, 0);
                } else {
                    std::set<std::pair<uint32_t, uint32_t>> visH;
                    for (int pos = 0; pos < 32; ++pos) {
                        uint32_t bit = 1u << pos;
                        uint32_t m4 = bit & Z0, k2 = bit & mHcF;
                        if (!(m4 | k2)) continue;
                        if (visH.count({m4, k2})) continue;
                        for (const auto& g : stabT) visH.insert({app32(m4, g), app32(k2, g)});
                        grand_hits += solve_one_RH68(pfx + "_RH6_" + (m4 ? "m4" : "k2"), is_H1, 6, t, u_union, oddF, rx, m4, k2);
                    }
                    grand_hits += solve_one_RH68(pfx + "_RH8_eHc0", is_H1, 8, t, u_union, oddF, rx, 0, 0);
                }
                oid++;
            }
        }
    }
    std::cout << "\n========================================\n"
              << "ALL 16 FINAL R_H IN {6,8} JOBS COMPLETE! GRAND_HITS = " << grand_hits << "\n"
              << "========================================\n" << std::flush;
    return 0;
}
