// Exact 4-cell (E_8, phase) join on ALL survivors of beta=0, dim(U)=1, w in {6,8,10}, n_8 == w!
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static uint64_t Zmask = 0, Fmask = 0;
static int perm64[63][64];

static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
        if (Q64[x] == 0) Zmask |= (1ULL << x);
        else Fmask |= (1ULL << x);
    }
    for (int v = 1; v < 64; ++v) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        for (int x = 0; x < 64; ++x)
            perm64[v - 1][x] = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
    }
}
static inline uint64_t apply_p64(uint64_t w, const int* p) {
    uint64_t out = 0;
    while (w) { int i = __builtin_ctzll(w); out |= (1ULL << p[i]); w &= w - 1; }
    return out;
}
static inline int xor_mask(uint64_t m) {
    int xr = 0;
    while (m) { xr ^= __builtin_ctzll(m); m &= m - 1; }
    return xr;
}
static inline void fwht16(std::array<int, 16>& a) {
    for (int step = 1; step < 16; step *= 2)
        for (int i = 0; i < 16; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}
struct PhaseReducer {
    uint64_t pivs[64]{}; uint64_t mask = 0;
    void init(uint64_t m) {
        mask = m;
        for (int b = 0; b < 64; ++b) pivs[b] = 0;
        for (int k = 0; k < 7; ++k) {
            uint64_t w = 0;
            for (int c = 0; c < 64; ++c) if (k == 6 || ((c >> k) & 1)) w |= (1ULL << c);
            w &= mask;
            while (w) {
                int b = 63 - __builtin_clzll(w);
                if (!pivs[b]) { pivs[b] = w; break; }
                w ^= pivs[b];
            }
        }
    }
    uint64_t reduce(uint64_t w) const {
        w &= mask;
        for (int b = 63; b >= 0; --b) if (pivs[b] && ((w >> b) & 1)) w ^= pivs[b];
        return w;
    }
};

using Slice = std::array<int, 16>;
using Opts64 = std::array<std::vector<int>, 64>;
struct SliceS { Slice u; uint64_t e8, sg; };

static void enum_slice_S(const int idx[16], int j, Slice& z, uint64_t e8, uint64_t sg,
                         const Opts64& opts, uint64_t pool, uint64_t pmask,
                         std::map<uint16_t, std::vector<SliceS>>& out) {
    if (j < 16) {
        int c = idx[j];
        for (int v : opts[c]) {
            z[j] = v;
            uint64_t ne = (((pool >> c) & 1) && std::abs(v) == 2) ? (e8 | (1ULL << c)) : e8;
            uint64_t ns = (((pmask >> c) & 1) && v < 0) ? (sg | (1ULL << c)) : sg;
            enum_slice_S(idx, j + 1, z, ne, ns, opts, pool, pmask, out);
        }
        return;
    }
    Slice u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 3) return;
        int q = u[y] >> 2;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back({u, e8, sg});
}
struct PairS { uint16_t par = 0, s2 = 0, d2 = 0; uint64_t e8 = 0, sg = 0; };
static inline bool make_pairS(const SliceS& a, const SliceS& b, PairS& p) {
    p.par = p.s2 = p.d2 = 0; p.e8 = a.e8 | b.e8; p.sg = a.sg | b.sg;
    for (int y = 0; y < 16; ++y) {
        int s = (a.u[y] + b.u[y]) >> 1, d = (a.u[y] - b.u[y]) >> 1;
        if (std::abs(s) > 2 || std::abs(d) > 2) return false;
        if (s & 1) p.par |= (uint16_t(1) << y);
        if (std::abs(s) == 2) p.s2 |= (uint16_t(1) << y);
        if (std::abs(d) == 2) p.d2 |= (uint16_t(1) << y);
    }
    return true;
}
static int min_row_energy(const Opts64& o) {
    int s = 0;
    for (int c = 0; c < 64; ++c) { int m = 99; for (int v : o[c]) m = std::min(m, v * v); s += m; }
    return s;
}
static std::vector<std::pair<uint64_t, uint64_t>> collect_sigs_b0(Opts64 opts, uint64_t pool, const PhaseReducer& red) {
    std::set<std::pair<uint64_t, uint64_t>> res;
    if (min_row_energy(opts) > 256) return {};
    std::array<int, 7> pivots{};
    for (int c = 0; c < 64; ++c) {
        auto& ent = opts[c];
        if (std::find(ent.begin(), ent.end(), 0) != ent.end() || ent.size() <= 1) continue;
        int col = 64 | c;
        for (int i = 6; i >= 0; --i) if ((col >> i) & 1) {
            if (pivots[i]) col ^= pivots[i];
            else {
                pivots[i] = col;
                ent.erase(std::remove_if(ent.begin(), ent.end(), [](int v){ return v < 0; }), ent.end());
                break;
            }
        }
    }
    long long best_cost = (1LL << 60); int b0 = 5, b1 = 4;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        long long prod[4] = {1, 1, 1, 1};
        for (int c = 0; c < 64; ++c) prod[(((c>>i)&1)<<1)|((c>>j)&1)] *= (long long)opts[c].size();
        if (prod[0]+prod[1]+prod[2]+prod[3] < best_cost) { best_cost = prod[0]+prod[1]+prod[2]+prod[3]; b0 = i; b1 = j; }
    }
    int rem[4], rk = 0;
    for (int b = 0; b < 6; ++b) if (b != b0 && b != b1) rem[rk++] = b;
    int sl[4][16];
    for (int q = 0; q < 4; ++q)
        for (int r = 0; r < 16; ++r) {
            int c = (((q >> 1) & 1) << b0) | ((q & 1) << b1);
            for (int j = 0; j < 4; ++j) if ((r >> j) & 1) c |= (1 << rem[j]);
            sl[q][r] = c;
        }
    std::array<std::map<uint16_t, std::vector<SliceS>>, 4> grp;
    for (int q = 0; q < 4; ++q) {
        Slice f{}; enum_slice_S(sl[q], 0, f, 0ULL, 0ULL, opts, pool, red.mask, grp[q]);
        if (grp[q].empty()) return {};
    }
    int min_q = 0;
    for (int q = 1; q < 4; ++q) if (grp[q].size() < grp[min_q].size()) min_q = q;
    for (const auto& [k, _] : grp[min_q]) {
        std::array<const std::vector<SliceS>*, 4> g{};
        bool ok = true;
        for (int q = 0; q < 4; ++q) {
            auto it = grp[q].find(k);
            if (it == grp[q].end()) { ok = false; break; }
            g[q] = &it->second;
        }
        if (!ok) continue;
        std::array<int, 4> ord{0, 1, 2, 3};
        std::sort(ord.begin(), ord.end(), [&](int a, int b){ return g[a]->size() < g[b]->size(); });
        std::unordered_map<uint16_t, std::vector<PairS>> idx;
        for (const auto& a : *g[ord[0]]) for (const auto& b : *g[ord[3]]) {
            PairS p; if (make_pairS(a, b, p)) idx[p.par].push_back(p);
        }
        if (idx.empty()) continue;
        for (const auto& c : *g[ord[1]]) for (const auto& d : *g[ord[2]]) {
            PairS q; if (!make_pairS(c, d, q)) continue;
            auto it = idx.find(q.par); if (it == idx.end()) continue;
            for (const auto& p : it->second)
                if (!(p.s2 & q.s2) && !(p.d2 & q.d2))
                    res.insert({p.e8 | q.e8, red.reduce(p.sg | q.sg)});
        }
    }
    return {res.begin(), res.end()};
}

static Opts64 make_row_b0(uint64_t p, uint64_t d2m, uint64_t k1m) {
    Opts64 o;
    for (int c = 0; c < 64; ++c) {
        int pc = (p >> c) & 1;
        if (Q64[c] == 1) {
            if ((k1m >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 2};
            else o[c] = pc ? std::vector<int>{-3, 3} : std::vector<int>{0};
        } else {
            if ((d2m >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
            else o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 0, 2};
        }
    }
    return o;
}

int main() {
    init_Q();
    uint64_t mons[22]; int mk = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) <= 2) {
        uint64_t mask = 0;
        for (int c = 0; c < 64; ++c) if ((c & m) == m) mask |= (1ULL << c);
        mons[mk++] = mask;
    }
    std::vector<uint64_t> byF[11], byZ[9];
    std::unordered_set<uint64_t> seenF, seenZ;
    uint64_t cur = 0;
    for (uint32_t s = 1; s < (1u << 22); ++s) {
        cur ^= mons[__builtin_ctz(s)];
        uint64_t f = cur & Fmask, z = cur & Zmask;
        int wf = __builtin_popcountll(f), wz = __builtin_popcountll(z);
        if ((wf == 6 || wf == 8 || wf == 10) && seenF.insert(f).second) byF[wf].push_back(cur);
        if ((wz == 4 || wz == 6 || wz == 8) && seenZ.insert(z).second) byZ[wz].push_back(cur);
    }

    int total_joins = 0;
    for (int w : {6, 8, 10}) {
        std::vector<uint64_t> repsF;
        std::unordered_set<uint64_t> vis;
        for (uint64_t p : byF[w]) {
            uint64_t f = p & Fmask;
            if (vis.count(f)) continue;
            repsF.push_back(p);
            std::vector<uint64_t> bfs{f}; vis.insert(f);
            for (size_t qi = 0; qi < bfs.size(); ++qi)
                for (int g = 0; g < 63; ++g) {
                    uint64_t n = apply_p64(bfs[qi], perm64[g]);
                    if (vis.insert(n).second) bfs.push_back(n);
                }
        }
        for (size_t ri = 0; ri < repsF.size(); ++ri) {
            uint64_t p = repsF[ri], pF = p & Fmask;
            int xpF = xor_mask(pF);
            int max_m2 = 14 - w;
            std::vector<int> stab;
            for (int g = 0; g < 63; ++g) if (apply_p64(pF, perm64[g]) == pF) stab.push_back(g);
            int joins_rep = 0;
            for (int m2 = 4; m2 <= max_m2; m2 += 2) {
                int m4 = (14 - w - m2) / 2;
                std::unordered_set<uint64_t> visU;
                for (uint64_t u : byZ[m2]) {
                    uint64_t uZ = u & Zmask;
                    if (xor_mask(uZ) != xpF || visU.count(uZ)) continue;
                    std::vector<uint64_t> bfs{uZ}; visU.insert(uZ);
                    for (size_t qi = 0; qi < bfs.size(); ++qi)
                        for (int g : stab) {
                            uint64_t n = apply_p64(bfs[qi], perm64[g]);
                            if (visU.insert(n).second) bfs.push_back(n);
                        }
                    for (uint64_t p2 : {p, p ^ Zmask}) {
                        uint64_t p0 = p2 ^ u, p1 = p0 ^ Fmask;
                        uint64_t pool = (Zmask & ~uZ) & ~p2;
                        uint64_t pmask = pF | ((Zmask & ~uZ) & p2);
                        PhaseReducer red; red.init(pmask);
                        uint64_t tgt_ph = red.reduce(pmask);
                        auto s2 = collect_sigs_b0(make_row_b0(p2, uZ, pF), pool, red);
                        if (s2.empty()) continue;
                        auto s0 = collect_sigs_b0(make_row_b0(p0, uZ, pF), pool, red);
                        if (s0.empty()) continue;
                        auto s1 = collect_sigs_b0(make_row_b0(p1, uZ, pF), pool, red);
                        if (s1.empty()) continue;
                        int target_e8_wt = __builtin_popcountll(pool) - m4;
                        if (target_e8_wt < 0) continue;
                        // Index (e2a | e2b, ph2a ^ ph2b) for pairs from s2 x s2 (disjoint e8)!
                        std::unordered_map<uint64_t, std::unordered_set<uint64_t>> pair2;
                        for (size_t i = 0; i < s2.size(); ++i)
                            for (size_t j = i; j < s2.size(); ++j) {
                                if (s2[i].first & s2[j].first) continue;
                                pair2[s2[i].first | s2[j].first].insert(s2[i].second ^ s2[j].second);
                            }
                        if (pair2.empty()) continue;
                        bool found = false;
                        for (auto [e0, ph0] : s0) {
                            for (auto [e1, ph1] : s1) {
                                if (e0 & e1) continue;
                                uint64_t e01 = e0 | e1;
                                uint64_t ph_need = tgt_ph ^ ph0 ^ ph1;
                                int rem_wt = target_e8_wt - __builtin_popcountll(e01);
                                if (rem_wt < 0) continue;
                                // If m4 == 0: e23 MUST equal pool ^ e01!
                                if (m4 == 0) {
                                    auto it = pair2.find(pool ^ e01);
                                    if (it != pair2.end() && it->second.count(ph_need)) { found = true; break; }
                                } else {
                                    for (const auto& [e23, phs] : pair2) {
                                        if ((e23 & e01) == 0 && __builtin_popcountll(e23) == rem_wt && phs.count(ph_need)) {
                                            found = true; break;
                                        }
                                    }
                                    if (found) break;
                                }
                            }
                            if (found) break;
                        }
                        if (found) {
                            joins_rep++; total_joins++;
                            std::cout << "  !!! JOIN FOUND !!! w=" << w << " rep#" << ri << " m2=" << m2 << " m4=" << m4
                                      << " |s0|=" << s0.size() << " |s1|=" << s1.size() << " |s2|=" << s2.size() << "\n" << std::flush;
                        }
                    }
                }
            }
            std::cout << "DONE w=" << w << " rep#" << ri << ": joins=" << joins_rep << "\n" << std::flush;
        }
    }
    std::cout << "ALL w in {6,8,10}, n_8==w DONE: total_joins = " << total_joins << "\n";
    return 0;
}
