// 1,000x faster exhaustive 4-cell (E_8, phase) join for beta=0, dim(U)=1: (1a), (1b), (1c)!
// Uses FULL Schreier stabilizer of pF (336/945 orbit BFS) + row_exists_b0 prefilter + 8 threads!
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <iostream>
#include <map>
#include <set>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static uint64_t Zmask = 0, Fmask = 0;
static int perm64[63][64];

static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
        if (Q64[x] == 0) Zmask |= (1ULL << x);
        else Fmask |= (1ULL << x);
    }
    for (int v = 1; v < 64; ++v) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        for (int x = 0; x < 64; ++x)
            perm64[v - 1][x] = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
    }
}
using Perm = std::array<int, 64>;
static inline uint64_t apply_p64(uint64_t w, const int* p) {
    uint64_t out = 0;
    while (w) { int i = __builtin_ctzll(w); out |= (1ULL << p[i]); w &= w - 1; }
    return out;
}
static Perm compose(const Perm& a, const Perm& b) {
    Perm c; for (int i = 0; i < 64; ++i) c[i] = a[b[i]]; return c;
}
static Perm invert_p(const Perm& a) {
    Perm b; for (int i = 0; i < 64; ++i) b[a[i]] = i; return b;
}
static std::vector<Perm> schreier_stab(uint64_t obj) {
    Perm id; for (int i = 0; i < 64; ++i) id[i] = i;
    std::unordered_map<uint64_t, Perm> to_obj;
    std::vector<uint64_t> bfs{obj};
    to_obj[obj] = id;
    std::vector<Perm> gens;
    std::set<Perm> seen_g;
    for (size_t qi = 0; qi < bfs.size(); ++qi) {
        uint64_t cur = bfs[qi];
        Perm tcur = to_obj[cur];
        for (int g = 0; g < 63; ++g) {
            uint64_t nxt = apply_p64(cur, perm64[g]);
            Perm gp; for (int i = 0; i < 64; ++i) gp[i] = perm64[g][i];
            Perm tnxt = compose(gp, tcur); // maps obj -> nxt
            auto it = to_obj.find(nxt);
            if (it == to_obj.end()) {
                to_obj[nxt] = tnxt;
                bfs.push_back(nxt);
            } else {
                // inv(it->second) * tnxt fixes obj!
                Perm s = compose(invert_p(it->second), tnxt);
                if (s != id && seen_g.insert(s).second) {
                    if (gens.size() < 40) gens.push_back(s);
                }
            }
        }
    }
    return gens;
}
static inline int xor_mask(uint64_t m) {
    int xr = 0; while (m) { xr ^= __builtin_ctzll(m); m &= m - 1; } return xr;
}
static inline void fwht16(std::array<int, 16>& a) {
    for (int step = 1; step < 16; step *= 2)
        for (int i = 0; i < 16; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}
struct PhaseReducer {
    uint64_t pivs[64]{}; uint64_t mask = 0;
    void init(uint64_t m) {
        mask = m;
        for (int b = 0; b < 64; ++b) pivs[b] = 0;
        for (int k = 0; k < 7; ++k) {
            uint64_t w = 0;
            for (int c = 0; c < 64; ++c) if (k == 6 || ((c >> k) & 1)) w |= (1ULL << c);
            w &= mask;
            while (w) {
                int b = 63 - __builtin_clzll(w);
                if (!pivs[b]) { pivs[b] = w; break; }
                w ^= pivs[b];
            }
        }
    }
    uint64_t reduce(uint64_t w) const {
        w &= mask;
        for (int b = 63; b >= 0; --b) if (pivs[b] && ((w >> b) & 1)) w ^= pivs[b];
        return w;
    }
};

using Slice = std::array<int, 16>;
using Opts64 = std::array<std::vector<int>, 64>;
struct SliceS { Slice u; uint64_t e8, sg; };

static void enum_slice_b0(const int idx[16], int j, Slice& z, const Opts64& opts,
                          std::map<uint16_t, std::vector<Slice>>& out) {
    if (j < 16) {
        for (int v : opts[idx[j]]) { z[j] = v; enum_slice_b0(idx, j + 1, z, opts, out); }
        return;
    }
    Slice u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 3) return;
        int q = u[y] >> 2;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back(u);
}
struct Pair { uint16_t par = 0, s2 = 0, d2 = 0; };
static inline bool make_pair(const Slice& a, const Slice& b, Pair& p) {
    p.par = p.s2 = p.d2 = 0;
    for (int y = 0; y < 16; ++y) {
        int s = (a[y] + b[y]) >> 1, d = (a[y] - b[y]) >> 1;
        if (std::abs(s) > 2 || std::abs(d) > 2) return false;
        if (s & 1) p.par |= (uint16_t(1) << y);
        if (std::abs(s) == 2) p.s2 |= (uint16_t(1) << y);
        if (std::abs(d) == 2) p.d2 |= (uint16_t(1) << y);
    }
    return true;
}
static int min_row_energy(const Opts64& o) {
    int s = 0;
    for (int c = 0; c < 64; ++c) { int m = 99; for (int v : o[c]) m = std::min(m, v * v); s += m; }
    return s;
}
static bool row_exists_b0(Opts64 opts) {
    if (min_row_energy(opts) > 256) return false;
    std::array<int, 7> pivots{};
    for (int c = 0; c < 64; ++c) {
        auto& ent = opts[c];
        if (std::find(ent.begin(), ent.end(), 0) != ent.end() || ent.size() <= 1) continue;
        int col = 64 | c;
        for (int i = 6; i >= 0; --i) if ((col >> i) & 1) {
            if (pivots[i]) col ^= pivots[i];
            else {
                pivots[i] = col;
                ent.erase(std::remove_if(ent.begin(), ent.end(), [](int v){ return v < 0; }), ent.end());
                break;
            }
        }
    }
    long long best_cost = (1LL << 60); int b0 = 5, b1 = 4;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        long long prod[4] = {1, 1, 1, 1};
        for (int c = 0; c < 64; ++c) prod[(((c>>i)&1)<<1)|((c>>j)&1)] *= (long long)opts[c].size();
        if (prod[0]+prod[1]+prod[2]+prod[3] < best_cost) { best_cost = prod[0]+prod[1]+prod[2]+prod[3]; b0 = i; b1 = j; }
    }
    int rem[4], rk = 0;
    for (int b = 0; b < 6; ++b) if (b != b0 && b != b1) rem[rk++] = b;
    int sl[4][16];
    for (int q = 0; q < 4; ++q)
        for (int r = 0; r < 16; ++r) {
            int c = (((q >> 1) & 1) << b0) | ((q & 1) << b1);
            for (int j = 0; j < 4; ++j) if ((r >> j) & 1) c |= (1 << rem[j]);
            sl[q][r] = c;
        }
    std::array<std::map<uint16_t, std::vector<Slice>>, 4> grp;
    for (int q = 0; q < 4; ++q) {
        Slice f{}; enum_slice_b0(sl[q], 0, f, opts, grp[q]);
        if (grp[q].empty()) return false;
    }
    int min_q = 0;
    for (int q = 1; q < 4; ++q) if (grp[q].size() < grp[min_q].size()) min_q = q;
    for (const auto& [k, _] : grp[min_q]) {
        std::array<const std::vector<Slice>*, 4> g{};
        bool ok = true;
        for (int q = 0; q < 4; ++q) {
            auto it = grp[q].find(k);
            if (it == grp[q].end()) { ok = false; break; }
            g[q] = &it->second;
        }
        if (!ok) continue;
        std::array<int, 4> ord{0, 1, 2, 3};
        std::sort(ord.begin(), ord.end(), [&](int a, int b){ return g[a]->size() < g[b]->size(); });
        std::unordered_map<uint16_t, std::vector<Pair>> idx;
        for (const auto& a : *g[ord[0]]) for (const auto& b : *g[ord[3]]) {
            Pair p; if (make_pair(a, b, p)) idx[p.par].push_back(p);
        }
        if (idx.empty()) continue;
        for (const auto& c : *g[ord[1]]) for (const auto& d : *g[ord[2]]) {
            Pair q; if (!make_pair(c, d, q)) continue;
            auto it = idx.find(q.par); if (it == idx.end()) continue;
            for (const auto& p : it->second)
                if (!(p.s2 & q.s2) && !(p.d2 & q.d2)) return true;
        }
    }
    return false;
}

static void enum_slice_S(const int idx[16], int j, Slice& z, uint64_t e8, uint64_t sg,
                         const Opts64& opts, uint64_t pool, uint64_t pmask,
                         std::map<uint16_t, std::vector<SliceS>>& out) {
    if (j < 16) {
        int c = idx[j];
        for (int v : opts[c]) {
            z[j] = v;
            uint64_t ne = (((pool >> c) & 1) && std::abs(v) == 2) ? (e8 | (1ULL << c)) : e8;
            uint64_t ns = (((pmask >> c) & 1) && v < 0) ? (sg | (1ULL << c)) : sg;
            enum_slice_S(idx, j + 1, z, ne, ns, opts, pool, pmask, out);
        }
        return;
    }
    Slice u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 3) return;
        int q = u[y] >> 2;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back({u, e8, sg});
}
struct PairS { uint16_t par = 0, s2 = 0, d2 = 0; uint64_t e8 = 0, sg = 0; };
static inline bool make_pairS(const SliceS& a, const SliceS& b, PairS& p) {
    p.par = p.s2 = p.d2 = 0; p.e8 = a.e8 | b.e8; p.sg = a.sg | b.sg;
    for (int y = 0; y < 16; ++y) {
        int s = (a.u[y] + b.u[y]) >> 1, d = (a.u[y] - b.u[y]) >> 1;
        if (std::abs(s) > 2 || std::abs(d) > 2) return false;
        if (s & 1) p.par |= (uint16_t(1) << y);
        if (std::abs(s) == 2) p.s2 |= (uint16_t(1) << y);
        if (std::abs(d) == 2) p.d2 |= (uint16_t(1) << y);
    }
    return true;
}
static std::vector<std::pair<uint64_t, uint64_t>> collect_sigs_b0(Opts64 opts, uint64_t pool, const PhaseReducer& red) {
    std::set<std::pair<uint64_t, uint64_t>> res;
    if (min_row_energy(opts) > 256) return {};
    std::array<int, 7> pivots{};
    for (int c = 0; c < 64; ++c) {
        auto& ent = opts[c];
        if (std::find(ent.begin(), ent.end(), 0) != ent.end() || ent.size() <= 1) continue;
        int col = 64 | c;
        for (int i = 6; i >= 0; --i) if ((col >> i) & 1) {
            if (pivots[i]) col ^= pivots[i];
            else {
                pivots[i] = col;
                ent.erase(std::remove_if(ent.begin(), ent.end(), [](int v){ return v < 0; }), ent.end());
                break;
            }
        }
    }
    long long best_cost = (1LL << 60); int b0 = 5, b1 = 4;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        long long prod[4] = {1, 1, 1, 1};
        for (int c = 0; c < 64; ++c) prod[(((c>>i)&1)<<1)|((c>>j)&1)] *= (long long)opts[c].size();
        if (prod[0]+prod[1]+prod[2]+prod[3] < best_cost) { best_cost = prod[0]+prod[1]+prod[2]+prod[3]; b0 = i; b1 = j; }
    }
    int rem[4], rk = 0;
    for (int b = 0; b < 6; ++b) if (b != b0 && b != b1) rem[rk++] = b;
    int sl[4][16];
    for (int q = 0; q < 4; ++q)
        for (int r = 0; r < 16; ++r) {
            int c = (((q >> 1) & 1) << b0) | ((q & 1) << b1);
            for (int j = 0; j < 4; ++j) if ((r >> j) & 1) c |= (1 << rem[j]);
            sl[q][r] = c;
        }
    std::array<std::map<uint16_t, std::vector<SliceS>>, 4> grp;
    for (int q = 0; q < 4; ++q) {
        Slice f{}; enum_slice_S(sl[q], 0, f, 0ULL, 0ULL, opts, pool, red.mask, grp[q]);
        if (grp[q].empty()) return {};
    }
    int min_q = 0;
    for (int q = 1; q < 4; ++q) if (grp[q].size() < grp[min_q].size()) min_q = q;
    for (const auto& [k, _] : grp[min_q]) {
        std::array<const std::vector<SliceS>*, 4> g{};
        bool ok = true;
        for (int q = 0; q < 4; ++q) {
            auto it = grp[q].find(k);
            if (it == grp[q].end()) { ok = false; break; }
            g[q] = &it->second;
        }
        if (!ok) continue;
        std::array<int, 4> ord{0, 1, 2, 3};
        std::sort(ord.begin(), ord.end(), [&](int a, int b){ return g[a]->size() < g[b]->size(); });
        std::unordered_map<uint16_t, std::vector<PairS>> idx;
        for (const auto& a : *g[ord[0]]) for (const auto& b : *g[ord[3]]) {
            PairS p; if (make_pairS(a, b, p)) idx[p.par].push_back(p);
        }
        if (idx.empty()) continue;
        for (const auto& c : *g[ord[1]]) for (const auto& d : *g[ord[2]]) {
            PairS q; if (!make_pairS(c, d, q)) continue;
            auto it = idx.find(q.par); if (it == idx.end()) continue;
            for (const auto& p : it->second)
                if (!(p.s2 & q.s2) && !(p.d2 & q.d2))
                    res.insert({p.e8 | q.e8, red.reduce(p.sg | q.sg)});
        }
    }
    return {res.begin(), res.end()};
}

static Opts64 make_row_b0(uint64_t p, uint64_t d2m, uint64_t k1m, uint64_t k2m, uint64_t k3m, uint64_t k4m) {
    Opts64 o;
    for (int c = 0; c < 64; ++c) {
        int pc = (p >> c) & 1;
        if (Q64[c] == 1) {
            if ((k1m >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 2};
            else if ((k2m >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 0, 2};
            else if ((k3m >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
            else if ((k4m >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
            else o[c] = pc ? std::vector<int>{-3, 3} : std::vector<int>{0};
        } else {
            if ((d2m >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
            else o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 0, 2};
        }
    }
    return o;
}

struct Task { uint64_t p2, u, k1m, k2m, k3m, k4m; int m4; };

static bool run_task(const Task& t) {
    uint64_t uZ = t.u & Zmask;
    uint64_t p0 = t.p2 ^ t.u, p1 = p0 ^ Fmask;
    auto r0 = make_row_b0(p0, uZ, t.k1m, t.k2m, t.k3m, t.k4m);
    if (!row_exists_b0(r0)) return false;
    auto r1 = make_row_b0(p1, uZ, t.k1m, t.k2m, t.k3m, t.k4m);
    if (!row_exists_b0(r1)) return false;
    auto r2 = make_row_b0(t.p2, uZ, t.k1m, t.k2m, t.k3m, t.k4m);
    if (!row_exists_b0(r2)) return false;

    uint64_t zpool = (Zmask & ~uZ) & ~t.p2;
    uint64_t pool = zpool | t.k2m;
    uint64_t pmask = t.k1m | ((Zmask & ~uZ) & t.p2);
    PhaseReducer red; red.init(pmask);
    uint64_t tgt_ph = red.reduce(pmask);
    auto s2 = collect_sigs_b0(r2, pool, red);
    if (s2.empty()) return false;
    auto s0 = collect_sigs_b0(r0, pool, red);
    if (s0.empty()) return false;
    auto s1 = collect_sigs_b0(r1, pool, red);
    if (s1.empty()) return false;

    int target_e8_wt = __builtin_popcountll(pool) - t.m4;
    if (target_e8_wt < 0) return false;
    std::unordered_map<uint64_t, std::unordered_set<uint64_t>> pair2;
    for (size_t i = 0; i < s2.size(); ++i)
        for (size_t j = i; j < s2.size(); ++j) {
            if (s2[i].first & s2[j].first) continue;
            pair2[s2[i].first | s2[j].first].insert(s2[i].second ^ s2[j].second);
        }
    if (pair2.empty()) return false;
    for (auto [e0, ph0] : s0) {
        for (auto [e1, ph1] : s1) {
            if (e0 & e1) continue;
            uint64_t e01 = e0 | e1;
            uint64_t ph_need = tgt_ph ^ ph0 ^ ph1;
            int rem_wt = target_e8_wt - __builtin_popcountll(e01);
            if (rem_wt < 0) continue;
            if (t.m4 == 0) {
                auto it = pair2.find(pool ^ e01);
                if (it != pair2.end() && it->second.count(ph_need)) return true;
            } else {
                for (const auto& [e23, phs] : pair2) {
                    if ((e23 & e01) != 0) continue;
                    uint64_t all_e = e01 | e23;
                    if ((all_e & t.k2m) != t.k2m) continue;
                    if (__builtin_popcountll(e23) == rem_wt && phs.count(ph_need)) return true;
                }
            }
        }
    }
    return false;
}

static int run_batch(const std::string& label, const std::vector<Task>& tasks) {
    std::atomic<size_t> next_i{0};
    std::atomic<int> joins{0};
    std::vector<std::thread> ths;
    for (int t = 0; t < 8; ++t) {
        ths.emplace_back([&]() {
            while (true) {
                size_t idx = next_i.fetch_add(1);
                if (idx >= tasks.size()) break;
                if (run_task(tasks[idx])) joins.fetch_add(1);
            }
        });
    }
    for (auto& th : ths) th.join();
    std::cout << label << ": tasks=" << tasks.size() << " joins=" << joins.load() << "\n" << std::flush;
    return joins.load();
}

static std::vector<Perm> pair_stab_from(const std::vector<Perm>& stab_pF, uint64_t uZ) {
    Perm id; for (int i = 0; i < 64; ++i) id[i] = i;
    std::unordered_map<uint64_t, Perm> to_obj;
    std::vector<uint64_t> bfs{uZ};
    to_obj[uZ] = id;
    std::vector<Perm> gens;
    std::set<Perm> seen;
    for (size_t qi = 0; qi < bfs.size(); ++qi) {
        uint64_t cur = bfs[qi]; Perm tcur = to_obj[cur];
        for (const auto& gp : stab_pF) {
            uint64_t nxt = apply_p64(cur, gp.data());
            Perm tnxt = compose(gp, tcur);
            auto it = to_obj.find(nxt);
            if (it == to_obj.end()) { to_obj[nxt] = tnxt; bfs.push_back(nxt); }
            else {
                Perm s = compose(invert_p(it->second), tnxt);
                if (s != id && seen.insert(s).second && gens.size() < 40) gens.push_back(s);
            }
        }
    }
    return gens;
}

int main() {
    init_Q();
    uint64_t mons[22]; int mk = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) <= 2) {
        uint64_t mask = 0;
        for (int c = 0; c < 64; ++c) if ((c & m) == m) mask |= (1ULL << c);
        mons[mk++] = mask;
    }
    uint64_t rep6 = 0, rep8 = 0;
    std::vector<uint64_t> byZ[7];
    std::unordered_set<uint64_t> seenZ;
    uint64_t cur = 0;
    for (uint32_t s = 1; s < (1u << 22); ++s) {
        cur ^= mons[__builtin_ctz(s)];
        int wf = __builtin_popcountll(cur & Fmask), wz = __builtin_popcountll(cur & Zmask);
        if (wf == 6 && !rep6) rep6 = cur;
        if (wf == 8 && !rep8) rep8 = cur;
        if ((wz == 4 || wz == 6) && seenZ.insert(cur & Zmask).second) byZ[wz].push_back(cur);
    }

    auto stab6 = schreier_stab(rep6 & Fmask);
    auto stab8 = schreier_stab(rep8 & Fmask);
    std::cout << "Schreier stab gens: w=6 -> " << stab6.size() << ", w=8 -> " << stab8.size() << "\n" << std::flush;

    auto get_u_orbs = [&](uint64_t pF, const std::vector<Perm>& st, int m2) {
        int xpF = xor_mask(pF);
        std::vector<uint64_t> us;
        std::unordered_set<uint64_t> vis;
        for (uint64_t u : byZ[m2]) {
            uint64_t uZ = u & Zmask;
            if (xor_mask(uZ) != xpF || vis.count(uZ)) continue;
            us.push_back(u);
            std::vector<uint64_t> bfs{uZ}; vis.insert(uZ);
            for (size_t qi = 0; qi < bfs.size(); ++qi)
                for (const auto& g : st) {
                    uint64_t n = apply_p64(bfs[qi], g.data());
                    if (vis.insert(n).second) bfs.push_back(n);
                }
        }
        return us;
    };

    auto orb_red = [&](const std::vector<uint64_t>& cands, const std::vector<Perm>& st) {
        std::vector<uint64_t> out;
        std::unordered_set<uint64_t> vis;
        for (uint64_t m : cands) {
            if (vis.count(m)) continue;
            out.push_back(m);
            std::vector<uint64_t> bfs{m}; vis.insert(m);
            for (size_t qi = 0; qi < bfs.size(); ++qi)
                for (const auto& g : st) {
                    uint64_t n = apply_p64(bfs[qi], g.data());
                    if (vis.insert(n).second) bfs.push_back(n);
                }
        }
        return out;
    };

    // (1a) w=8, n8=10
    {
        uint64_t p = rep8, pF = p & Fmask, fComp = Fmask & ~pF;
        auto us = get_u_orbs(pF, stab8, 4);
        std::vector<uint64_t> k3c, k2c;
        for (int c = 0; c < 64; ++c) { if ((pF>>c)&1) k3c.push_back(1ULL<<c); if ((fComp>>c)&1) k2c.push_back(1ULL<<c); }
        std::vector<Task> tasks;
        for (uint64_t u : us) {
            auto st = pair_stab_from(stab8, u & Zmask);
            for (uint64_t p2 : {p, p ^ Zmask}) {
                for (uint64_t m : orb_red(k3c, st)) tasks.push_back({p2, u, pF ^ m, 0, m, 0, 0});
                for (uint64_t m : orb_red(k2c, st)) tasks.push_back({p2, u, pF, m, 0, 0, 0});
            }
        }
        std::cout << "(1a) u_orbs=" << us.size() << " -> ";
        run_batch("(1a) w=8, n8=10", tasks);
    }

    // (1b) w=6, n8=8
    {
        uint64_t p = rep6, pF = p & Fmask, fComp = Fmask & ~pF;
        std::vector<uint64_t> k3c, k2c;
        for (int c = 0; c < 64; ++c) { if ((pF>>c)&1) k3c.push_back(1ULL<<c); if ((fComp>>c)&1) k2c.push_back(1ULL<<c); }
        std::vector<Task> tasks;
        for (int m2 : {4, 6}) {
            int m4 = (14 - 8 - m2) / 2;
            auto us = get_u_orbs(pF, stab6, m2);
            for (uint64_t u : us) {
                auto st = pair_stab_from(stab6, u & Zmask);
                for (uint64_t p2 : {p, p ^ Zmask}) {
                    for (uint64_t m : orb_red(k3c, st)) tasks.push_back({p2, u, pF ^ m, 0, m, 0, m4});
                    for (uint64_t m : orb_red(k2c, st)) tasks.push_back({p2, u, pF, m, 0, 0, m4});
                }
            }
        }
        run_batch("(1b) w=6, n8=8", tasks);
    }

    // (1c) w=6, n8=10
    {
        uint64_t p = rep6, pF = p & Fmask, fComp = Fmask & ~pF;
        std::vector<int> pFpts, fCpts;
        for (int c = 0; c < 64; ++c) { if ((pF>>c)&1) pFpts.push_back(c); if ((fComp>>c)&1) fCpts.push_back(c); }
        std::vector<uint64_t> k3_2, k2_2, k4_1;
        for (size_t i = 0; i < pFpts.size(); ++i)
            for (size_t j = i + 1; j < pFpts.size(); ++j)
                k3_2.push_back((1ULL << pFpts[i]) | (1ULL << pFpts[j]));
        for (size_t i = 0; i < fCpts.size(); ++i) {
            k4_1.push_back(1ULL << fCpts[i]);
            for (size_t j = i + 1; j < fCpts.size(); ++j)
                k2_2.push_back((1ULL << fCpts[i]) | (1ULL << fCpts[j]));
        }
        auto us = get_u_orbs(pF, stab6, 4);
        std::vector<Task> tasks;
        for (uint64_t u : us) {
            auto st = pair_stab_from(stab6, u & Zmask);
            auto k32o = orb_red(k3_2, st), k22o = orb_red(k2_2, st), k41o = orb_red(k4_1, st);
            std::vector<std::pair<uint64_t, uint64_t>> k31_k21;
            std::set<std::pair<uint64_t, uint64_t>> visP;
            for (int a : pFpts) for (int b : fCpts) {
                std::pair<uint64_t, uint64_t> pr{1ULL << a, 1ULL << b};
                if (visP.count(pr)) continue;
                k31_k21.push_back(pr);
                std::vector<std::pair<uint64_t, uint64_t>> bfs{pr}; visP.insert(pr);
                for (size_t qi = 0; qi < bfs.size(); ++qi)
                    for (const auto& g : st) {
                        std::pair<uint64_t, uint64_t> np{apply_p64(bfs[qi].first, g.data()),
                                                         apply_p64(bfs[qi].second, g.data())};
                        if (visP.insert(np).second) bfs.push_back(np);
                    }
            }
            for (uint64_t p2 : {p, p ^ Zmask}) {
                for (uint64_t m : k32o) tasks.push_back({p2, u, pF ^ m, 0, m, 0, 0});
                for (uint64_t m : k22o) tasks.push_back({p2, u, pF, m, 0, 0, 0});
                for (uint64_t m : k41o) tasks.push_back({p2, u, pF, 0, 0, m, 0});
                for (auto [m3, m2] : k31_k21) tasks.push_back({p2, u, pF ^ m3, m2, m3, 0, 0});
            }
        }
        std::cout << "(1c) u_orbs=" << us.size() << " -> ";
        run_batch("(1c) w=6, n8=10", tasks);
    }
    return 0;
}
