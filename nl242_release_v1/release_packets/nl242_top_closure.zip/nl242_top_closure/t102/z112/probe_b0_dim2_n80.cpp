// Exhaustive check of ALL beta = 0, n_8 = 0, dim(U) = 2 at t = 102 (|Z| = 112, |D| = 28)!
// Here m_2 = |a | b| in {6, 8, 10, 12, 14}, XOR(a | b) == 0, AND (u & v)|_F in RM(2,6)|_F (synF(u & v) == 0)!
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static uint64_t Zmask = 0, Fmask = 0;
static int perm64[63][64];

static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
        if (Q64[x] == 0) Zmask |= (1ULL << x);
        else Fmask |= (1ULL << x);
    }
    for (int v = 1; v < 64; ++v) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        for (int x = 0; x < 64; ++x)
            perm64[v - 1][x] = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
    }
}
static inline uint64_t apply_p64(uint64_t w, const int* p) {
    uint64_t out = 0;
    while (w) { int i = __builtin_ctzll(w); out |= (1ULL << p[i]); w &= w - 1; }
    return out;
}
static inline void fwht16(std::array<int, 16>& a) {
    for (int step = 1; step < 16; step *= 2)
        for (int i = 0; i < 16; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}
using Slice = std::array<int, 16>;
using Opts64 = std::array<std::vector<int>, 64>;
using Groups = std::map<uint16_t, std::vector<Slice>>;

static void enum_slice_b0(const int idx[16], int j, Slice& z, const Opts64& opts, Groups& out) {
    if (j < 16) {
        for (int v : opts[idx[j]]) { z[j] = v; enum_slice_b0(idx, j + 1, z, opts, out); }
        return;
    }
    Slice u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 3) return;
        int q = u[y] >> 2;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back(u);
}
struct Pair { uint16_t par = 0, s2 = 0, d2 = 0; };
static inline bool make_pair(const Slice& a, const Slice& b, Pair& p) {
    p.par = p.s2 = p.d2 = 0;
    for (int y = 0; y < 16; ++y) {
        int s = (a[y] + b[y]) >> 1, d = (a[y] - b[y]) >> 1;
        if (std::abs(s) > 2 || std::abs(d) > 2) return false;
        if (s & 1) p.par |= (uint16_t(1) << y);
        if (std::abs(s) == 2) p.s2 |= (uint16_t(1) << y);
        if (std::abs(d) == 2) p.d2 |= (uint16_t(1) << y);
    }
    return true;
}
static int min_row_energy(const Opts64& o) {
    int s = 0;
    for (int c = 0; c < 64; ++c) { int m = 99; for (int v : o[c]) m = std::min(m, v * v); s += m; }
    return s;
}
static bool row_exists_b0(Opts64 opts) {
    if (min_row_energy(opts) > 256) return false;
    std::array<int, 7> pivots{};
    for (int c = 0; c < 64; ++c) {
        auto& ent = opts[c];
        if (std::find(ent.begin(), ent.end(), 0) != ent.end() || ent.size() <= 1) continue;
        int col = 64 | c;
        for (int i = 6; i >= 0; --i) if ((col >> i) & 1) {
            if (pivots[i]) col ^= pivots[i];
            else {
                pivots[i] = col;
                ent.erase(std::remove_if(ent.begin(), ent.end(), [](int v){ return v < 0; }), ent.end());
                break;
            }
        }
    }
    long long best_cost = (1LL << 60); int b0 = 5, b1 = 4;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        long long prod[4] = {1, 1, 1, 1};
        for (int c = 0; c < 64; ++c) prod[(((c>>i)&1)<<1)|((c>>j)&1)] *= (long long)opts[c].size();
        if (prod[0]+prod[1]+prod[2]+prod[3] < best_cost) { best_cost = prod[0]+prod[1]+prod[2]+prod[3]; b0 = i; b1 = j; }
    }
    int rem[4], rk = 0;
    for (int b = 0; b < 6; ++b) if (b != b0 && b != b1) rem[rk++] = b;
    int sl[4][16];
    for (int q = 0; q < 4; ++q)
        for (int r = 0; r < 16; ++r) {
            int c = (((q >> 1) & 1) << b0) | ((q & 1) << b1);
            for (int j = 0; j < 4; ++j) if ((r >> j) & 1) c |= (1 << rem[j]);
            sl[q][r] = c;
        }
    std::array<Groups, 4> grp;
    for (int q = 0; q < 4; ++q) {
        Slice f{}; enum_slice_b0(sl[q], 0, f, opts, grp[q]);
        if (grp[q].empty()) return false;
    }
    int min_q = 0;
    for (int q = 1; q < 4; ++q) if (grp[q].size() < grp[min_q].size()) min_q = q;
    for (const auto& [k, _] : grp[min_q]) {
        std::array<const std::vector<Slice>*, 4> g{};
        bool ok = true;
        for (int q = 0; q < 4; ++q) {
            auto it = grp[q].find(k);
            if (it == grp[q].end()) { ok = false; break; }
            g[q] = &it->second;
        }
        if (!ok) continue;
        std::array<int, 4> ord{0, 1, 2, 3};
        std::sort(ord.begin(), ord.end(), [&](int a, int b){ return g[a]->size() < g[b]->size(); });
        std::unordered_map<uint16_t, std::vector<Pair>> idx;
        for (const auto& a : *g[ord[0]]) for (const auto& b : *g[ord[3]]) {
            Pair p; if (make_pair(a, b, p)) idx[p.par].push_back(p);
        }
        if (idx.empty()) continue;
        for (const auto& c : *g[ord[1]]) for (const auto& d : *g[ord[2]]) {
            Pair q; if (!make_pair(c, d, q)) continue;
            auto it = idx.find(q.par); if (it == idx.end()) continue;
            for (const auto& p : it->second)
                if (!(p.s2 & q.s2) && !(p.d2 & q.d2)) return true;
        }
    }
    return false;
}
static Opts64 make_opts(uint64_t p, uint64_t d2m) {
    Opts64 o;
    for (int c = 0; c < 64; ++c) {
        int pc = (p >> c) & 1;
        if (Q64[c] == 1) o[c] = pc ? std::vector<int>{-3, 3} : std::vector<int>{0};
        else if ((d2m >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
        else o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 0, 2};
    }
    return o;
}

int main() {
    init_Q();
    std::vector<int> fpts;
    for (int c = 0; c < 64; ++c) if (Q64[c] == 1) fpts.push_back(c);
    int f_idx[64]; std::fill(f_idx, f_idx + 64, -1);
    for (int j = 0; j < 36; ++j) f_idx[fpts[j]] = j;

    // Build RM(2,6) parity-check on F_6 (15-bit syndrome!) + full RM(2,6)|_F lookup map!
    uint64_t mons[22]; int mk = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) <= 2) {
        uint64_t mask = 0;
        for (int c = 0; c < 64; ++c) if ((c & m) == m) mask |= (1ULL << c);
        mons[mk++] = mask;
    }
    // Build syndrome Hcol[36] AND liftF map!
    uint64_t rref[21]{}; int piv_col[21]{}; int rank = 0; bool is_piv[36]{};
    uint64_t rref_full[21]{};
    for (int k = 0; k < 22; ++k) {
        uint64_t row = 0;
        for (int j = 0; j < 36; ++j) if ((mons[k] >> fpts[j]) & 1) row |= (1ULL << j);
        uint64_t full = mons[k];
        for (int r = 0; r < rank; ++r) if ((row >> piv_col[r]) & 1) { row ^= rref[r]; full ^= rref_full[r]; }
        if (row) {
            int pc = __builtin_ctzll(row);
            for (int r = 0; r < rank; ++r) if ((rref[r] >> pc) & 1) { rref[r] ^= row; rref_full[r] ^= full; }
            rref[rank] = row; rref_full[rank] = full; piv_col[rank] = pc; is_piv[pc] = true; rank++;
        }
    }
    int free_cols[15], frk = 0;
    for (int j = 0; j < 36; ++j) if (!is_piv[j]) free_cols[frk++] = j;
    uint16_t Hcol[36]{};
    for (int k = 0; k < 15; ++k) Hcol[free_cols[k]] = (uint16_t(1) << k);
    for (int r = 0; r < 21; ++r) {
        uint16_t col = 0;
        for (int k = 0; k < 15; ++k) if ((rref[r] >> free_cols[k]) & 1) col |= (uint16_t(1) << k);
        Hcol[piv_col[r]] = col;
    }
    auto synF = [&](uint64_t w) {
        uint16_t s = 0; uint64_t t = w & Fmask;
        while (t) { int c = __builtin_ctzll(t); s ^= Hcol[f_idx[c]]; t &= t - 1; }
        return s;
    };
    auto liftF = [&](uint64_t wF, uint64_t& out) {
        uint64_t ans = 0;
        for (int r = 0; r < 21; ++r)
            if ((wF >> fpts[piv_col[r]]) & 1) ans ^= rref_full[r];
        if ((ans & Fmask) != wF) return false;
        out = ans;
        return true;
    };

    // Collect RM(2,6) words by weight on Z_6 (4, 6, 8, 10, 12) — remember min(wa, wb, wab) <= floor(2*14/3) = 9 -> wa in {4, 6, 8}!
    // Check: m2 = (wa + wb + wab)/2 <= 14 => wa + wb + wab <= 28 => smallest of (wa, wb, wab) is <= 9, and even => wa in {4, 6, 8}!
    // And wb <= (28 - wa)/2 <= 12 (for wa=4: wb <= 12; wa=6: wb <= 10; wa=8: wb <= 10)!
    std::vector<uint64_t> byW[15];
    std::unordered_set<uint64_t> seen_repZ;
    uint64_t cur = 0;
    for (uint32_t s = 1; s < (1u << 22); ++s) {
        cur ^= mons[__builtin_ctz(s)];
        uint64_t z = cur & Zmask;
        int wz = __builtin_popcountll(z);
        if (wz < 4 || wz > 12) continue;
        // Keep one canonical lift per z (cur with min F-weight or first seen; note swapping cur <-> cur^Fmask just permutes p0,p1,p2,p3!)
        // Wait: (u & v) changes by v on F if we replace u by u ^ Fmask -> v is ALREADY in RM(2,6), so synF(u & v) IS INVARIANT under u -> u^Fmask, v -> v^Fmask!!
        // Wait: check! ((u^F) & v)|_F = (u&v ^ v)|_F -> differs by v|_F in RM(2,6)|_F -> synF is 100% INVARIANT!!
        if (seen_repZ.insert(z).second) byW[wz].push_back(cur);
    }
    // Orbit-reduce wa in {4, 6, 8}!
    std::vector<std::pair<int, uint64_t>> repsA;
    for (int wa : {4, 6, 8}) {
        std::unordered_set<uint64_t> vis;
        for (uint64_t u : byW[wa]) {
            uint64_t a = u & Zmask;
            if (vis.count(a)) continue;
            repsA.push_back({wa, u});
            std::vector<uint64_t> bfs{a}; vis.insert(a);
            for (size_t qi = 0; qi < bfs.size(); ++qi)
                for (int g = 0; g < 63; ++g) {
                    uint64_t n = apply_p64(bfs[qi], perm64[g]);
                    if (vis.insert(n).second) bfs.push_back(n);
                }
        }
    }
    std::cout << "Aut(Q)-orbits for smallest word wa in {4,6,8}: " << repsA.size() << "\n" << std::flush;

    int total_orbs = 0, total_4ok = 0;
    for (auto [wa, u] : repsA) {
        uint64_t a = u & Zmask;
        std::vector<int> stab;
        for (int g = 0; g < 63; ++g) if (apply_p64(a, perm64[g]) == a) stab.push_back(g);
        std::unordered_set<uint64_t> vis;
        for (int wb = wa; wb <= (28 - wa) / 2; wb += 2) {
            for (uint64_t v : byW[wb]) {
                uint64_t b = v & Zmask;
                if (b == a) continue;
                int wab = __builtin_popcountll(a ^ b);
                if (wab < wb) continue;
                uint64_t d2m = a | b;
                int m2 = __builtin_popcountll(d2m);
                if (m2 > 14 || (m2 & 1)) continue; // n_8=0 => m2 = 14 - 2*m4 is EVEN!
                // Check XOR(d2m) == 0!
                int xr = 0; uint64_t tmp = d2m;
                while (tmp) { xr ^= __builtin_ctzll(tmp); tmp &= tmp - 1; }
                if (xr != 0) continue;
                if (synF(u & v) != 0) continue;
                uint64_t can = std::min(b, a ^ b);
                if (vis.count(can)) continue;
                total_orbs++;
                std::vector<uint64_t> bfs{can}; vis.insert(can);
                for (size_t qi = 0; qi < bfs.size(); ++qi)
                    for (int g : stab) {
                        uint64_t n = apply_p64(bfs[qi], perm64[g]);
                        uint64_t nc = std::min(n, a ^ n);
                        if (vis.insert(nc).second) bfs.push_back(nc);
                    }
                // Lift p0_base from (u & v) & Fmask, test BOTH lifts p0_base and p0_base ^ Zmask!
                uint64_t p0_base = 0;
                if (!liftF((u & v) & Fmask, p0_base)) continue;
                for (uint64_t p0 : {p0_base, p0_base ^ Zmask}) {
                    uint64_t p1 = p0 ^ u, p2 = p0 ^ v, p3 = p0 ^ u ^ v ^ Fmask;
                    // Check all 4 disjoint on F_6 (should be automatic since p0 = u&v on F!)
                    if ((p0 & p1 & Fmask) || (p0 & p2 & Fmask) || (p0 & p3 & Fmask) ||
                        (p1 & p2 & Fmask) || (p1 & p3 & Fmask) || (p2 & p3 & Fmask)) continue;
                    if (row_exists_b0(make_opts(p0, d2m)) && row_exists_b0(make_opts(p1, d2m)) &&
                        row_exists_b0(make_opts(p2, d2m)) && row_exists_b0(make_opts(p3, d2m))) {
                        total_4ok++;
                        std::cout << "  4-ROW SURVIVOR! wa=" << wa << " wb=" << wb << " wab=" << wab
                                  << " m2=" << m2 << " wF=("
                                  << __builtin_popcountll(p0&Fmask) << "," << __builtin_popcountll(p1&Fmask) << ","
                                  << __builtin_popcountll(p2&Fmask) << "," << __builtin_popcountll(p3&Fmask) << ")\n" << std::flush;
                    }
                }
            }
        }
    }
    std::cout << "DONE beta=0, n_8=0, dim(U)=2: total_orbs=" << total_orbs << " total_4ok=" << total_4ok << "\n";
    return 0;
}
