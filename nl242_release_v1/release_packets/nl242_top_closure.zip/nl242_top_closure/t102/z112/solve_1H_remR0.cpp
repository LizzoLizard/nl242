// Exact 8-thread solver for ALL remR == 0 orbits of beta = 1_H at t = 102:
//   - Case II  (H_0): ALL 750 Stab(H_0)-orbits with m2Z + oddF = 6!
//   - Case III (H_1): ALL 950 Stab(H_1)-orbits with m2Z + oddF = 8!
// At remR == 0: H is 100% CLEAN (d_c=1 on H cap Z, k_c=0 on H cap F),
//               H^c has d_c=2 on U_Z (0 elsewhere, m_4=0) and k_c=1 on oddF (0 elsewhere)!
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <iostream>
#include <map>
#include <mutex>
#include <set>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
    }
}

static inline void fwht16(std::array<int, 16>& a) {
    for (int step = 1; step < 16; step *= 2)
        for (int i = 0; i < 16; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}

static uint8_t rad5_of(uint32_t p) {
    uint8_t B[5] = {};
    int p0 = p & 1;
    for (int i = 0; i < 5; ++i) {
        int pi = (p >> (1 << i)) & 1;
        for (int j = 0; j < 5; ++j) {
            int pj = (p >> (1 << j)) & 1;
            int pij = (p >> ((1 << i) ^ (1 << j))) & 1;
            if (p0 ^ pi ^ pj ^ pij) B[i] |= (1u << j);
        }
    }
    int kcnt = 0, last = 0;
    for (int x = 0; x < 32; ++x) {
        bool ok = true;
        for (int i = 0; i < 5; ++i)
            if (__builtin_parity(B[i] & x)) { ok = false; break; }
        if (ok) { kcnt++; last = x; }
    }
    return (kcnt == 2) ? (uint8_t)last : 0;
}

static inline int xor5_mask(uint32_t m) {
    int r = 0;
    while (m) { int i = __builtin_ctz(m); r ^= i; m &= m - 1; }
    return r;
}

using Perm32 = std::array<uint8_t, 32>;
static inline uint32_t app32(uint32_t m, const Perm32& g) {
    uint32_t out = 0;
    while (m) { int i = __builtin_ctz(m); out |= (1u << g[i]); m &= m - 1; }
    return out;
}
struct PermHash {
    size_t operator()(const Perm32& p) const {
        uint64_t h = 1469598103934665603ULL;
        for (int i = 0; i < 32; ++i) { h ^= p[i]; h *= 1099511628211ULL; }
        return (size_t)h;
    }
};
static std::vector<Perm32> build_stabH(int is_H1) {
    int Hc[32];
    for (int i = 0; i < 32; ++i) Hc[i] = 2 * i + (1 - is_H1);
    std::vector<Perm32> gens;
    for (int v = 2; v < 64; v += 2) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        Perm32 g{};
        for (int i = 0; i < 32; ++i) {
            int x = Hc[i];
            int y = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
            g[i] = (uint8_t)(y >> 1);
        }
        gens.push_back(g);
    }
    Perm32 id{}; for (int i = 0; i < 32; ++i) id[i] = (uint8_t)i;
    std::unordered_set<Perm32, PermHash> vis; vis.reserve(40000);
    std::vector<Perm32> grp{id}; vis.insert(id);
    for (size_t qi = 0; qi < grp.size(); ++qi) {
        const auto cur = grp[qi];
        for (const auto& g : gens) {
            Perm32 nx{};
            for (int i = 0; i < 32; ++i) nx[i] = g[cur[i]];
            if (vis.insert(nx).second) grp.push_back(nx);
        }
    }
    return grp;
}

struct PhaseReducer {
    uint64_t pivs[64]{};
    uint64_t mask = 0;
    void init(uint64_t m) {
        mask = m;
        for (int b = 0; b < 64; ++b) pivs[b] = 0;
        for (int k = 0; k < 7; ++k) {
            uint64_t w = 0;
            for (int c = 0; c < 64; ++c)
                if (k == 6 || ((c >> k) & 1)) w |= (1ULL << c);
            w &= mask;
            while (w) {
                int b = 63 - __builtin_clzll(w);
                if (!pivs[b]) { pivs[b] = w; break; }
                w ^= pivs[b];
            }
        }
    }
    uint64_t reduce(uint64_t w) const {
        w &= mask;
        for (int b = 63; b >= 0; --b)
            if (pivs[b] && ((w >> b) & 1)) w ^= pivs[b];
        return w;
    }
};

using Opts32 = std::array<std::vector<int>, 32>;
using HalfMap = std::unordered_map<uint32_t, std::map<uint32_t, int>>;

static void enum_slice16(int start, int j, std::array<int, 16>& z, const Opts32& opts,
                         std::map<uint16_t, std::vector<std::array<int, 16>>>& out) {
    if (j < 16) {
        for (int v : opts[start + j]) { z[j] = v; enum_slice16(start, j + 1, z, opts, out); }
        return;
    }
    auto u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 15) return;
        int q = u[y] >> 4;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back(u);
}

static void collect_half_minE(const Opts32& opts, HalfMap& by_par, long long& count) {
    by_par.clear(); count = 0;
    std::map<uint16_t, std::vector<std::array<int, 16>>> g0, g1;
    std::array<int, 16> tmp{};
    enum_slice16(0, 0, tmp, opts, g0);
    if (g0.empty()) return;
    enum_slice16(16, 0, tmp, opts, g1);
    if (g1.empty()) return;
    for (auto& [par, v0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a[y]) + std::abs(b[y]) > 4) { ok = false; break; }
                int x0 = (a[y] + b[y]) >> 1, x1 = (a[y] - b[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (uint32_t(1) << y);
                if (x1 & 1) p32 |= (uint32_t(1) << (16 + y));
                if (std::abs(x0) == 2) tw |= (uint32_t(1) << y);
                if (std::abs(x1) == 2) tw |= (uint32_t(1) << (16 + y));
            }
            if (ok) {
                auto& mp = by_par[p32];
                auto it2 = mp.find(tw);
                if (it2 == mp.end() || e2 < it2->second) mp[tw] = e2;
                count++;
            }
        }
    }
}

struct Slice16S { std::array<int, 16> u; uint16_t m68, sgn; };
static void enum_slice16_S(int start, int j, std::array<int, 16>& z, uint16_t m68, uint16_t sg,
                           const Opts32& opts, uint32_t track_mask,
                           std::map<uint16_t, std::vector<Slice16S>>& out) {
    if (j < 16) {
        int idx = start + j; bool tr = (track_mask >> idx) & 1;
        for (int v : opts[idx]) {
            z[j] = v;
            uint16_t nm = m68 | ((tr && (std::abs(v) == 6 || std::abs(v) == 8)) ? (uint16_t(1) << j) : 0);
            uint16_t ns = sg | ((v < 0) ? (uint16_t(1) << j) : 0);
            enum_slice16_S(start, j + 1, z, nm, ns, opts, track_mask, out);
        }
        return;
    }
    auto u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 15) return;
        int q = u[y] >> 4;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back({u, m68, sg});
}

struct HalfEntryS { uint32_t tw, m68, sgn; int e2; };
static void collect_half_S(const Opts32& opts, uint32_t track_mask,
                           std::unordered_map<uint32_t, std::vector<HalfEntryS>>& out) {
    out.clear();
    std::map<uint16_t, std::vector<Slice16S>> g0, g1;
    std::array<int, 16> tmp{};
    enum_slice16_S(0, 0, tmp, 0, 0, opts, track_mask, g0);
    if (g0.empty()) return;
    enum_slice16_S(16, 0, tmp, 0, 0, opts, track_mask, g1);
    if (g1.empty()) return;
    for (auto& [par, v0] : g0) {
        auto it = g1.find(par); if (it == g1.end()) continue;
        for (const auto& a : v0) for (const auto& b : it->second) {
            uint32_t p32 = 0, tw = 0; int e2 = 0; bool ok = true;
            for (int y = 0; y < 16; ++y) {
                if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                e2 += x0*x0 + x1*x1;
                if (x0 & 1) p32 |= (uint32_t(1) << y);
                if (x1 & 1) p32 |= (uint32_t(1) << (16 + y));
                if (std::abs(x0) == 2) tw |= (uint32_t(1) << y);
                if (std::abs(x1) == 2) tw |= (uint32_t(1) << (16 + y));
            }
            if (ok) {
                uint32_t m68 = uint32_t(a.m68) | (uint32_t(b.m68) << 16);
                uint32_t sg = uint32_t(a.sgn) | (uint32_t(b.sgn) << 16);
                out[p32].push_back({tw, m68, sg, e2});
            }
        }
    }
}

static inline uint64_t interleave_H(uint32_t h_bits, uint32_t hc_bits, int is_H1) {
    uint64_t out = 0;
    for (int i = 0; i < 32; ++i) {
        if ((h_bits >> i) & 1) out |= (1ULL << (2 * i + is_H1));
        if ((hc_bits >> i) & 1) out |= (1ULL << (2 * i + (1 - is_H1)));
    }
    return out;
}

static void solve_case(const std::string& name, int is_H1, int R_max,
                       const std::vector<uint32_t>& all_q,
                       const std::unordered_map<uint32_t, uint8_t>& rad_map) {
    int H_pts[32], Hc_pts[32];
    uint32_t mHZ = 0, mHF = 0, mHcZ = 0, mHcF = 0;
    for (int i = 0; i < 32; ++i) {
        H_pts[i] = 2 * i + is_H1;
        Hc_pts[i] = 2 * i + (1 - is_H1);
        if (Q64[H_pts[i]] == 0) mHZ |= (1u << i); else mHF |= (1u << i);
        if (Q64[Hc_pts[i]] == 0) mHcZ |= (1u << i); else mHcF |= (1u << i);
    }
    auto grp = build_stabH(is_H1);
    std::unordered_map<uint32_t, std::vector<uint32_t>> byZ, byF;
    for (uint32_t q : all_q) {
        byZ[q & mHcZ].push_back(q);
        byF[q & mHcF].push_back(q);
    }
    std::vector<uint32_t> all_smallZ, z1_reps;
    for (const auto& [z, _] : byZ)
        if (z != 0 && __builtin_popcount(z) <= R_max) all_smallZ.push_back(z);
    std::sort(all_smallZ.begin(), all_smallZ.end());
    {
        std::unordered_set<uint32_t> visZ;
        for (uint32_t z : all_smallZ) {
            if (visZ.count(z)) continue;
            z1_reps.push_back(z);
            for (const auto& g : grp) visZ.insert(app32(z, g));
        }
    }
    std::vector<std::vector<uint32_t>> U_reps;
    U_reps.push_back({});
    for (uint32_t z1 : z1_reps) U_reps.push_back({z1});
    {
        std::set<std::vector<uint32_t>> seenU2;
        int max_min_w = (2 * R_max) / 3;
        for (uint32_t z1 : z1_reps) {
            int w1 = __builtin_popcount(z1);
            if (w1 > max_min_w) continue;
            std::vector<Perm32> stab1;
            for (const auto& g : grp) if (app32(z1, g) == z1) stab1.push_back(g);
            std::unordered_set<uint32_t> vis2;
            for (uint32_t z2 : all_smallZ) {
                if (z2 == z1 || vis2.count(z2)) continue;
                if (__builtin_popcount(z2) < w1) continue;
                uint32_t z3 = z1 ^ z2;
                if (__builtin_popcount(z3) < w1 || __builtin_popcount(z1 | z2) > R_max) continue;
                for (const auto& g : stab1) { vis2.insert(app32(z2, g)); vis2.insert(app32(z3, g)); }
                std::vector<uint32_t> U{z1, z2, z3}; std::sort(U.begin(), U.end());
                if (seenU2.count(U)) continue;
                U_reps.push_back(U);
                for (const auto& g : grp) {
                    std::vector<uint32_t> nx{app32(U[0], g), app32(U[1], g), app32(U[2], g)};
                    std::sort(nx.begin(), nx.end()); seenU2.insert(nx);
                }
            }
        }
    }
    std::vector<uint32_t> f_errs[9];
    {
        std::vector<int> fbits;
        for (int i = 0; i < 32; ++i) if ((mHcF >> i) & 1) fbits.push_back(i);
        int nf = (int)fbits.size();
        auto dfs = [&](auto& self, int idx, int w, uint32_t mask) -> void {
            f_errs[w].push_back(mask);
            if (w == R_max) return;
            for (int i = idx; i < nf; ++i) self(self, i + 1, w + 1, mask | (1u << fbits[i]));
        };
        dfs(dfs, 0, 0, 0);
    }

    // Collect ALL remR == 0 Stab(H)-orbit reps!
    struct Task {
        std::array<uint32_t, 4> t;
        uint32_t u_union, oddF_mask;
    };
    std::vector<Task> tasks;
    for (const auto& U : U_reps) {
        int dim = (U.size() == 0) ? 0 : (U.size() == 1 ? 1 : 2);
        uint32_t u_union = 0;
        for (uint32_t z : U) u_union |= z;
        int m2Z = __builtin_popcount(u_union);
        int xZ = xor5_mask(u_union);
        int need_oddF = R_max - m2Z; // remR == 0!

        std::vector<Perm32> stabU;
        for (const auto& g : grp) {
            bool ok = true;
            if (dim == 1) ok = (app32(U[0], g) == U[0]);
            else if (dim == 2) {
                uint32_t a0 = app32(U[0], g), a1 = app32(U[1], g);
                ok = ((a0 == U[0] || a0 == U[1] || a0 == U[2]) &&
                      (a1 == U[0] || a1 == U[1] || a1 == U[2]));
            }
            if (ok) stabU.push_back(g);
        }

        uint32_t z1 = (dim >= 1) ? U[0] : 0;
        uint32_t z2 = (dim >= 2) ? U[1] : 0;
        const auto& L1 = byZ[z1];
        const auto& L2 = byZ[z2];

        std::set<std::array<uint32_t, 4>> local_tuples;
        for (uint32_t a : L1) for (uint32_t b : L2) {
            uint32_t prodF = (a & b) & mHcF;
            for (uint32_t e : f_errs[need_oddF]) {
                if ((xZ ^ xor5_mask(e)) != 1) continue; // remR==0 => rad_xor==0 => xHc == 1!
                auto it = byF.find(prodF ^ e);
                if (it == byF.end()) continue;
                for (uint32_t p0 : it->second) {
                    uint32_t p1 = p0 ^ a, p2 = p0 ^ b, p3 = p0 ^ a ^ b ^ mHcF;
                    if ((rad_map.at(p0) ^ rad_map.at(p1) ^ rad_map.at(p2) ^ rad_map.at(p3)) != 0) continue;
                    std::array<uint32_t, 4> t{p0, p1, p2, p3};
                    std::sort(t.begin(), t.end());
                    local_tuples.insert(t);
                }
            }
        }
        std::set<std::array<uint32_t, 4>> visT;
        for (const auto& t : local_tuples) {
            if (visT.count(t)) continue;
            for (const auto& g : stabU) {
                std::array<uint32_t, 4> nx{app32(t[0], g), app32(t[1], g), app32(t[2], g), app32(t[3], g)};
                std::sort(nx.begin(), nx.end());
                visT.insert(nx);
            }
            uint32_t a = t[1] ^ t[0], b = t[2] ^ t[0];
            uint32_t oddF_mask = (t[0] ^ (a & b)) & mHcF;
            tasks.push_back({t, u_union, oddF_mask});
        }
    }

    std::cout << "\n=== " << name << " remR == 0: solving ALL " << tasks.size() << " orbits ===\n" << std::flush;

    // Solve all tasks on 8 threads!
    std::atomic<size_t> next_i{0};
    std::atomic<long long> n_dead_empty{0}, n_dead_minm{0}, n_need_join{0}, n_joins_102{0}, n_joins_any{0};
    std::mutex mu;

    auto worker = [&]() {
        while (true) {
            size_t ti = next_i.fetch_add(1);
            if (ti >= tasks.size()) break;
            const auto& tk = tasks[ti];

            // Phase 1: fast min_m per slice!
            int min_m[4];
            bool ok = true;
            int sum_min = 0;
            for (int k = 0; k < 4; ++k) {
                uint32_t p = tk.t[k];
                Opts32 opt_t, opt_s;
                for (int i = 0; i < 32; ++i) {
                    int pi = (p >> i) & 1;
                    if (Q64[H_pts[i]] == 1) opt_t[i] = pi ? std::vector<int>{6} : std::vector<int>{-6};
                    else opt_t[i] = pi ? std::vector<int>{-2, 6} : std::vector<int>{-6, 2};

                    if (Q64[Hc_pts[i]] == 1) {
                        if ((tk.oddF_mask >> i) & 1) opt_s[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 8};
                        else opt_s[i] = pi ? std::vector<int>{-12, 12} : std::vector<int>{0};
                    } else {
                        if (pi) opt_s[i] = {-4, 4};
                        else if ((tk.u_union >> i) & 1) opt_s[i] = {0}; // d_c = 2 forces 0!
                        else opt_s[i] = {-8, 0, 8}; // d_c = 0: (0,0,0,8)
                    }
                }
                HalfMap mt, ms; long long ct = 0, cs = 0;
                collect_half_minE(opt_t, mt, ct);
                if (ct == 0) { ok = false; break; }
                collect_half_minE(opt_s, ms, cs);
                if (cs == 0) { ok = false; break; }
                int best = 999;
                for (const auto& [p32, tm] : mt) {
                    auto it = ms.find(p32); if (it == ms.end()) continue;
                    for (const auto& [tw_t, et] : tm)
                        for (const auto& [tw_s, es] : it->second)
                            if ((tw_t & tw_s) == 0) {
                                int m = (et + es) / 2;
                                if (m < best) best = m;
                            }
                }
                if (best >= 999) { ok = false; break; }
                min_m[k] = best;
                sum_min += best;
                if (sum_min > 102) break;
            }
            if (!ok) { n_dead_empty.fetch_add(1); continue; }
            if (sum_min > 102) { n_dead_minm.fetch_add(1); continue; }

            // Phase 2: EXACT 4-cell join (e6 on H cap Z, e8 on H^c cap (Z \ U_Z), sum m <= 102, phase64)!
            n_need_join.fetch_add(1);
            // Everywhere-nonzero frequencies: ALL 32 of H, ALL of H^c cap Z where p0=p1=p2=p3=1 (d_c=0 -> (4,4,4,4)),
            // and ALL of oddF_mask (k_c=1 -> (4,4,4,8))!
            uint32_t Z1 = mHcZ & tk.t[0] & tk.t[1] & tk.t[2] & tk.t[3];
            uint32_t Z0 = mHcZ & ~(tk.t[0] | tk.t[1] | tk.t[2] | tk.t[3]); // need exactly one +-8 on each bit of Z0!
            uint64_t phase64 = interleave_H(0xFFFFFFFFu, Z1 | tk.oddF_mask, is_H1);
            PhaseReducer red; red.init(phase64);
            uint64_t tgt_sgn = red.reduce(phase64); // ALL of these have sgn_xor == 1!

            struct Sig {
                uint32_t e6, e8; int m; uint64_t sgn;
                bool operator<(const Sig& o) const {
                    if (e6 != o.e6) return e6 < o.e6;
                    if (e8 != o.e8) return e8 < o.e8;
                    if (m != o.m) return m < o.m;
                    return sgn < o.sgn;
                }
                bool operator==(const Sig& o) const {
                    return e6 == o.e6 && e8 == o.e8 && m == o.m && sgn == o.sgn;
                }
            };
            std::array<std::vector<Sig>, 4> sigs;
            bool empty_s = false;
            for (int k = 0; k < 4; ++k) {
                uint32_t p = tk.t[k];
                int max_mk = 102 - (sum_min - min_m[k]);
                Opts32 opt_t, opt_s;
                for (int i = 0; i < 32; ++i) {
                    int pi = (p >> i) & 1;
                    if (Q64[H_pts[i]] == 1) opt_t[i] = pi ? std::vector<int>{6} : std::vector<int>{-6};
                    else opt_t[i] = pi ? std::vector<int>{-2, 6} : std::vector<int>{-6, 2};
                    if (Q64[Hc_pts[i]] == 1) {
                        if ((tk.oddF_mask >> i) & 1) opt_s[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 8};
                        else opt_s[i] = pi ? std::vector<int>{-12, 12} : std::vector<int>{0};
                    } else {
                        if (pi) opt_s[i] = {-4, 4};
                        else if ((tk.u_union >> i) & 1) opt_s[i] = {0};
                        else opt_s[i] = {-8, 0, 8};
                    }
                }
                std::unordered_map<uint32_t, std::vector<HalfEntryS>> mt, ms;
                collect_half_S(opt_t, mHZ, mt);
                collect_half_S(opt_s, Z0, ms);
                for (const auto& [p32, vt] : mt) {
                    auto its = ms.find(p32); if (its == ms.end()) continue;
                    for (const auto& et : vt) for (const auto& es : its->second) {
                        if (et.tw & es.tw) continue;
                        int m = (et.e2 + es.e2) / 2;
                        if (m > max_mk) continue;
                        uint64_t sg = red.reduce(interleave_H(et.sgn, es.sgn, is_H1));
                        sigs[k].push_back({et.m68, es.m68, m, sg});
                    }
                }
                std::sort(sigs[k].begin(), sigs[k].end());
                sigs[k].erase(std::unique(sigs[k].begin(), sigs[k].end()), sigs[k].end());
                if (sigs[k].empty()) { empty_s = true; break; }
            }
            if (empty_s) continue;

            // Sort by size for balanced 2+2 join!
            std::array<int, 4> ord{0, 1, 2, 3};
            std::sort(ord.begin(), ord.end(), [&](int a, int b){ return sigs[a].size() < sigs[b].size(); });
            struct Key {
                uint32_t e6, e8; uint64_t sgn;
                bool operator<(const Key& o) const {
                    if (e6 != o.e6) return e6 < o.e6;
                    if (e8 != o.e8) return e8 < o.e8;
                    return sgn < o.sgn;
                }
            };
            std::map<Key, std::array<uint64_t, 2>> lmap;
            for (const auto& a : sigs[ord[0]]) for (const auto& b : sigs[ord[3]]) {
                if ((a.e6 & b.e6) || (a.e8 & b.e8)) continue;
                int m = a.m + b.m; if (m > 102) continue;
                auto& bm = lmap[{a.e6 | b.e6, a.e8 | b.e8, a.sgn ^ b.sgn}];
                bm[m >> 6] |= (1ULL << (m & 63));
            }
            for (const auto& c : sigs[ord[1]]) for (const auto& d : sigs[ord[2]]) {
                if ((c.e6 & d.e6) || (c.e8 & d.e8)) continue;
                int m = c.m + d.m; if (m > 102) continue;
                auto it = lmap.find({mHZ ^ (c.e6 | d.e6), Z0 ^ (c.e8 | d.e8), tgt_sgn ^ (c.sgn ^ d.sgn)});
                if (it != lmap.end()) {
                    n_joins_any.fetch_add(1);
                    int rem = 102 - m;
                    if (it->second[rem >> 6] & (1ULL << (rem & 63))) {
                        n_joins_102.fetch_add(1);
                        std::lock_guard<std::mutex> lk(mu);
                        std::cout << "  [HIT!] task=" << ti << " m2Z=" << __builtin_popcount(tk.u_union)
                                  << " oddF=" << __builtin_popcount(tk.oddF_mask) << "\n" << std::flush;
                    }
                }
            }
        }
    };

    std::vector<std::thread> ths;
    for (int i = 0; i < 8; ++i) ths.emplace_back(worker);
    for (auto& th : ths) th.join();

    std::cout << "  RESULT " << name << " remR==0: total=" << tasks.size()
              << " dead_empty=" << n_dead_empty.load()
              << " dead_minm(>102)=" << n_dead_minm.load()
              << " needed_join=" << n_need_join.load()
              << " joins_any=" << n_joins_any.load()
              << " JOINS_102=" << n_joins_102.load() << "\n" << std::flush;
}

int main() {
    init_Q();
    uint32_t mons[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0;
        for (int i = 0; i < 32; ++i) if ((i & m) == m) mask |= (1u << i);
        mons[mk++] = mask;
    }
    std::vector<uint32_t> all_q(65536, 0);
    for (int s = 1; s < 65536; ++s) all_q[s] = all_q[s - 1] ^ mons[__builtin_ctz(s)];
    std::unordered_map<uint32_t, uint8_t> rad_map;
    rad_map.reserve(100000);
    for (uint32_t p : all_q) rad_map[p] = rad5_of(p);

    solve_case("Case II (H_0)", 0, 6, all_q, rad_map);
    solve_case("Case III (H_1)", 1, 8, all_q, rad_map);
    return 0;
}
