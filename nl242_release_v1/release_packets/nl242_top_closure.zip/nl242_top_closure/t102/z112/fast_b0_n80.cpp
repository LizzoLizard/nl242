// Instant check of beta = 0, n_8 = 0, dim(U) = 1 at t = 102 (|Z| = 112, |D| = 28)!
// Uses the exact 4-way meet-in-the-middle engine from verify_t104_closed.cpp (with 7 affine sign pivots!).
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static uint64_t Zmask = 0, Fmask = 0;
static int perm64[63][64];

static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
        if (Q64[x] == 0) Zmask |= (1ULL << x);
        else Fmask |= (1ULL << x);
    }
    for (int v = 1; v < 64; ++v) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        for (int x = 0; x < 64; ++x)
            perm64[v - 1][x] = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
    }
}

static inline uint64_t apply_p64(uint64_t w, const int* p) {
    uint64_t out = 0;
    while (w) { int i = __builtin_ctzll(w); out |= (1ULL << p[i]); w &= w - 1; }
    return out;
}

static inline void fwht16(std::array<int, 16>& a) {
    for (int step = 1; step < 16; step *= 2)
        for (int i = 0; i < 16; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}

using Slice = std::array<int, 16>;
using Opts64 = std::array<std::vector<int>, 64>;
using Groups = std::map<uint16_t, std::vector<Slice>>;

static void enum_slice_b0(const int idx[16], int j, Slice& z, const Opts64& opts, Groups& out) {
    if (j < 16) {
        for (int v : opts[idx[j]]) { z[j] = v; enum_slice_b0(idx, j + 1, z, opts, out); }
        return;
    }
    Slice u = z; fwht16(u);
    uint16_t par = 0;
    for (int y = 0; y < 16; ++y) {
        if (u[y] & 3) return;
        int q = u[y] >> 2;
        if (std::abs(q) > 4) return;
        u[y] = q;
        if (q & 1) par |= (uint16_t(1) << y);
    }
    out[par].push_back(u);
}

struct Pair { uint16_t par = 0, s2 = 0, d2 = 0; };
static inline bool make_pair(const Slice& a, const Slice& b, Pair& p) {
    p.par = p.s2 = p.d2 = 0;
    for (int y = 0; y < 16; ++y) {
        int s = (a[y] + b[y]) >> 1, d = (a[y] - b[y]) >> 1;
        if (std::abs(s) > 2 || std::abs(d) > 2) return false;
        if (s & 1) p.par |= (uint16_t(1) << y);
        if (std::abs(s) == 2) p.s2 |= (uint16_t(1) << y);
        if (std::abs(d) == 2) p.d2 |= (uint16_t(1) << y);
    }
    return true;
}

static int min_row_energy(const Opts64& o) {
    int s = 0;
    for (int c = 0; c < 64; ++c) { int m = 99; for (int v : o[c]) m = std::min(m, v * v); s += m; }
    return s;
}

static bool row_exists_b0(Opts64 opts) {
    if (min_row_energy(opts) > 256) return false;
    std::array<int, 7> pivots{};
    for (int c = 0; c < 64; ++c) {
        auto& ent = opts[c];
        if (std::find(ent.begin(), ent.end(), 0) != ent.end() || ent.size() <= 1) continue;
        int col = 64 | c;
        for (int i = 6; i >= 0; --i) if ((col >> i) & 1) {
            if (pivots[i]) col ^= pivots[i];
            else {
                pivots[i] = col;
                ent.erase(std::remove_if(ent.begin(), ent.end(), [](int v){ return v < 0; }), ent.end());
                break;
            }
        }
    }
    long long best_cost = (1LL << 60); int b0 = 5, b1 = 4;
    for (int i = 0; i < 6; ++i) for (int j = i + 1; j < 6; ++j) {
        long long prod[4] = {1, 1, 1, 1};
        for (int c = 0; c < 64; ++c) prod[(((c>>i)&1)<<1)|((c>>j)&1)] *= (long long)opts[c].size();
        if (prod[0]+prod[1]+prod[2]+prod[3] < best_cost) { best_cost = prod[0]+prod[1]+prod[2]+prod[3]; b0 = i; b1 = j; }
    }
    int rem[4], rk = 0;
    for (int b = 0; b < 6; ++b) if (b != b0 && b != b1) rem[rk++] = b;
    int sl[4][16];
    for (int q = 0; q < 4; ++q)
        for (int r = 0; r < 16; ++r) {
            int c = (((q >> 1) & 1) << b0) | ((q & 1) << b1);
            for (int j = 0; j < 4; ++j) if ((r >> j) & 1) c |= (1 << rem[j]);
            sl[q][r] = c;
        }
    std::array<Groups, 4> grp;
    for (int q = 0; q < 4; ++q) {
        Slice f{}; enum_slice_b0(sl[q], 0, f, opts, grp[q]);
        if (grp[q].empty()) return false;
    }
    int min_q = 0;
    for (int q = 1; q < 4; ++q) if (grp[q].size() < grp[min_q].size()) min_q = q;
    for (const auto& [k, _] : grp[min_q]) {
        std::array<const std::vector<Slice>*, 4> g{};
        bool ok = true;
        for (int q = 0; q < 4; ++q) {
            auto it = grp[q].find(k);
            if (it == grp[q].end()) { ok = false; break; }
            g[q] = &it->second;
        }
        if (!ok) continue;
        std::array<int, 4> ord{0, 1, 2, 3};
        std::sort(ord.begin(), ord.end(), [&](int a, int b){ return g[a]->size() < g[b]->size(); });
        std::unordered_map<uint16_t, std::vector<Pair>> idx;
        for (const auto& a : *g[ord[0]]) for (const auto& b : *g[ord[3]]) {
            Pair p; if (make_pair(a, b, p)) idx[p.par].push_back(p);
        }
        if (idx.empty()) continue;
        for (const auto& c : *g[ord[1]]) for (const auto& d : *g[ord[2]]) {
            Pair q; if (!make_pair(c, d, q)) continue;
            auto it = idx.find(q.par); if (it == idx.end()) continue;
            for (const auto& p : it->second)
                if (!(p.s2 & q.s2) && !(p.d2 & q.d2)) return true;
        }
    }
    return false;
}

static Opts64 make_opts(uint64_t p, uint64_t uZ) {
    Opts64 o;
    for (int c = 0; c < 64; ++c) {
        int pc = (p >> c) & 1;
        if (Q64[c] == 1) o[c] = pc ? std::vector<int>{-3, 3} : std::vector<int>{0};
        else if ((uZ >> c) & 1) o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{0};
        else o[c] = pc ? std::vector<int>{-1, 1} : std::vector<int>{-2, 0, 2};
    }
    return o;
}

int main() {
    init_Q();
    uint64_t mons[22]; int mk = 0;
    for (int m = 0; m < 64; ++m) if (__builtin_popcount(m) <= 2) {
        uint64_t mask = 0;
        for (int c = 0; c < 64; ++c) if ((c & m) == m) mask |= (1ULL << c);
        mons[mk++] = mask;
    }
    std::unordered_set<uint64_t> seenZ;
    std::vector<uint64_t> reps;
    uint64_t cur = 0;
    for (uint32_t s = 1; s < (1u << 22); ++s) {
        cur ^= mons[__builtin_ctz(s)];
        uint64_t uZ = cur & Zmask;
        int wZ = __builtin_popcountll(uZ);
        if (wZ < 4 || wZ > 14) continue;
        int xr = 0; uint64_t tmp = uZ;
        while (tmp) { xr ^= __builtin_ctzll(tmp); tmp &= tmp - 1; }
        if (xr != 0) continue;
        if (seenZ.count(uZ)) continue;
        std::vector<uint64_t> bfs{uZ}; seenZ.insert(uZ);
        for (size_t qi = 0; qi < bfs.size(); ++qi)
            for (int g = 0; g < 63; ++g) {
                uint64_t nxt = apply_p64(bfs[qi], perm64[g]);
                if (seenZ.insert(nxt).second) bfs.push_back(nxt);
            }
        reps.push_back(cur);
    }
    std::cout << "Found " << reps.size() << " Aut(Q)-orbits (wt in [4..14], XOR=0)!\n";
    int surv = 0;
    for (size_t i = 0; i < reps.size(); ++i) {
        uint64_t u = reps[i], uZ = u & Zmask;
        int wZ = __builtin_popcountll(uZ), wF = __builtin_popcountll(u & Fmask);
        for (int p2_is_Z = 0; p2_is_Z < 2; ++p2_is_Z) {
            uint64_t p2 = p2_is_Z ? Zmask : 0ULL;
            uint64_t p0 = p2 ^ u;
            uint64_t p1 = p0 ^ Fmask;
            bool ok0 = row_exists_b0(make_opts(p0, uZ));
            bool ok1 = ok0 && row_exists_b0(make_opts(p1, uZ));
            if (ok0 && ok1) {
                surv++;
                std::cout << "  BOTH p0,p1 EXIST! orb=" << i << " wZ=" << wZ << " wF=" << wF
                          << " p2_Z=" << p2_is_Z << "\n" << std::flush;
            }
        }
    }
    std::cout << "TOTAL surviving (p0,p1) pairs (out of " << reps.size()*2 << "): " << surv << "\n";
    return 0;
}
