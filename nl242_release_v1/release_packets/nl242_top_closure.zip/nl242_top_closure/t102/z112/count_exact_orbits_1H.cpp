#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
    }
}

static uint8_t rad5_of(uint32_t p) {
    uint8_t B[5] = {};
    int p0 = p & 1;
    for (int i = 0; i < 5; ++i) {
        int pi = (p >> (1 << i)) & 1;
        for (int j = 0; j < 5; ++j) {
            int pj = (p >> (1 << j)) & 1;
            int pij = (p >> ((1 << i) ^ (1 << j))) & 1;
            if (p0 ^ pi ^ pj ^ pij) B[i] |= (1u << j);
        }
    }
    int kcnt = 0, last = 0;
    for (int x = 0; x < 32; ++x) {
        bool ok = true;
        for (int i = 0; i < 5; ++i)
            if (__builtin_parity(B[i] & x)) { ok = false; break; }
        if (ok) { kcnt++; last = x; }
    }
    return (kcnt == 2) ? (uint8_t)last : 0;
}

static inline int xor5_mask(uint32_t m) {
    int r = 0;
    while (m) { int i = __builtin_ctz(m); r ^= i; m &= m - 1; }
    return r;
}

using Perm32 = std::array<uint8_t, 32>;
static inline uint32_t app32(uint32_t m, const Perm32& g) {
    uint32_t out = 0;
    while (m) { int i = __builtin_ctz(m); out |= (1u << g[i]); m &= m - 1; }
    return out;
}

struct PermHash {
    size_t operator()(const Perm32& p) const {
        uint64_t h = 1469598103934665603ULL;
        for (int i = 0; i < 32; ++i) { h ^= p[i]; h *= 1099511628211ULL; }
        return (size_t)h;
    }
};

// Build full Stab(H) group on 32 pts of H^c!
static std::vector<Perm32> build_stabH(int is_H1) {
    int Hc[32];
    for (int i = 0; i < 32; ++i) Hc[i] = 2 * i + (1 - is_H1);
    std::vector<Perm32> gens;
    for (int v = 2; v < 64; v += 2) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        Perm32 g{};
        for (int i = 0; i < 32; ++i) {
            int x = Hc[i];
            int y = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
            g[i] = (uint8_t)(y >> 1);
        }
        gens.push_back(g);
    }
    Perm32 id{}; for (int i = 0; i < 32; ++i) id[i] = (uint8_t)i;
    std::unordered_set<Perm32, PermHash> vis; vis.reserve(40000);
    std::vector<Perm32> grp{id}; vis.insert(id);
    for (size_t qi = 0; qi < grp.size(); ++qi) {
        const auto cur = grp[qi];
        for (const auto& g : gens) {
            Perm32 nx{};
            for (int i = 0; i < 32; ++i) nx[i] = g[cur[i]];
            if (vis.insert(nx).second) grp.push_back(nx);
        }
    }
    return grp;
}

static void analyze(const std::string& name, int is_H1, int R_max,
                    const std::vector<uint32_t>& all_q,
                    const std::unordered_map<uint32_t, uint8_t>& rad_map) {
    int Hc[32];
    uint32_t mZ = 0, mF = 0;
    for (int i = 0; i < 32; ++i) {
        Hc[i] = 2 * i + (1 - is_H1);
        if (Q64[Hc[i]] == 0) mZ |= (1u << i);
        else mF |= (1u << i);
    }
    auto grp = build_stabH(is_H1);
    std::cout << "\n=== " << name << " (|Z|=" << __builtin_popcount(mZ)
              << ", |F|=" << __builtin_popcount(mF) << ", R_max=" << R_max
              << ", |Stab(H)|=" << grp.size() << ") ===\n" << std::flush;

    std::unordered_map<uint32_t, std::vector<uint32_t>> byZ, byF;
    for (uint32_t q : all_q) {
        byZ[q & mZ].push_back(q);
        byF[q & mF].push_back(q);
    }

    // 1. Find Stab(H)-orbits of single nonzero Z-words z with wt(z) <= R_max!
    std::unordered_set<uint32_t> visZ;
    std::vector<uint32_t> z1_reps;
    std::vector<uint32_t> all_smallZ;
    for (const auto& [z, _] : byZ)
        if (z != 0 && __builtin_popcount(z) <= R_max) all_smallZ.push_back(z);
    std::sort(all_smallZ.begin(), all_smallZ.end());
    for (uint32_t z : all_smallZ) {
        if (visZ.count(z)) continue;
        z1_reps.push_back(z);
        for (const auto& g : grp) visZ.insert(app32(z, g));
    }
    std::cout << "  Small nonzero Z-words (wt<=" << R_max << "): " << all_smallZ.size()
              << " -> " << z1_reps.size() << " Stab(H)-orbits\n" << std::flush;

    // 2. Build ALL Stab(H)-orbits of U_Z (dim 0, 1, 2) with m2Z <= R_max!
    // For dim 2, the minimum-weight nonzero element z1 has 3*wt(z1) <= wt(z1)+wt(z2)+wt(z3) = 2*m2Z <= 2*R_max,
    // so wt(z1) <= (2*R_max)/3 (<= 4 in Case II, <= 5 -> <= 4 in Case III!!).
    std::vector<std::vector<uint32_t>> U_reps;
    U_reps.push_back({}); // dim 0
    for (uint32_t z1 : z1_reps) U_reps.push_back({z1}); // dim 1

    std::set<std::vector<uint32_t>> seenU2;
    int max_min_w = (2 * R_max) / 3;
    for (uint32_t z1 : z1_reps) {
        int w1 = __builtin_popcount(z1);
        if (w1 > max_min_w) continue;
        // Compute Stab(z1)
        std::vector<Perm32> stab1;
        for (const auto& g : grp) if (app32(z1, g) == z1) stab1.push_back(g);
        // Find all z2 in all_smallZ with wt(z2) >= w1, wt(z1^z2) >= w1, |z1|z2| <= R_max
        std::unordered_set<uint32_t> vis2;
        for (uint32_t z2 : all_smallZ) {
            if (z2 == z1 || vis2.count(z2)) continue;
            int w2 = __builtin_popcount(z2);
            if (w2 < w1) continue;
            uint32_t z3 = z1 ^ z2;
            if (__builtin_popcount(z3) < w1) continue;
            if (__builtin_popcount(z1 | z2) > R_max) continue;
            // Mark Stab(z1)-orbit of {z2, z3}
            for (const auto& g : stab1) {
                vis2.insert(app32(z2, g));
                vis2.insert(app32(z3, g));
            }
            std::vector<uint32_t> U{z1, z2, z3};
            std::sort(U.begin(), U.end());
            // Check global Stab(H) dedup (in case wt(z2) == w1 or wt(z3) == w1!)
            if (seenU2.count(U)) continue;
            U_reps.push_back(U);
            for (const auto& g : grp) {
                std::vector<uint32_t> nx{app32(U[0], g), app32(U[1], g), app32(U[2], g)};
                std::sort(nx.begin(), nx.end());
                seenU2.insert(nx);
            }
        }
    }
    std::cout << "  Total exact Stab(H)-orbits of U_Z (m2Z <= " << R_max << "): " << U_reps.size() << "\n" << std::flush;

    // Precompute F-error masks by weight <= R_max
    std::vector<uint32_t> f_errs[9];
    {
        std::vector<int> fbits;
        for (int i = 0; i < 32; ++i) if ((mF >> i) & 1) fbits.push_back(i);
        int nf = (int)fbits.size();
        auto dfs = [&](auto& self, int idx, int w, uint32_t mask) -> void {
            f_errs[w].push_back(mask);
            if (w == R_max) return;
            for (int i = idx; i < nf; ++i) self(self, i + 1, w + 1, mask | (1u << fbits[i]));
        };
        dfs(dfs, 0, 0, 0);
    }

    // For each U_Z rep, compute Stab(U_Z), find ALL valid 4-tuples (including remR==0 => rad_xor==0!),
    // and orbit-reduce by Stab(U_Z)!
    std::map<std::tuple<int, int, int, int>, long long> orb_cnt;
    long long total_orbs = 0;
    for (const auto& U : U_reps) {
        int dim = (U.size() == 0) ? 0 : (U.size() == 1 ? 1 : 2);
        uint32_t u_union = 0;
        for (uint32_t z : U) u_union |= z;
        int m2Z = __builtin_popcount(u_union);
        int xZ = xor5_mask(u_union);
        int max_oddF = R_max - m2Z;

        // Compute Stab(U_Z)
        std::vector<Perm32> stabU;
        for (const auto& g : grp) {
            bool ok = true;
            if (dim == 1) ok = (app32(U[0], g) == U[0]);
            else if (dim == 2) {
                uint32_t a0 = app32(U[0], g), a1 = app32(U[1], g);
                ok = ((a0 == U[0] || a0 == U[1] || a0 == U[2]) &&
                      (a1 == U[0] || a1 == U[1] || a1 == U[2]));
            }
            if (ok) stabU.push_back(g);
        }

        uint32_t z1 = (dim >= 1) ? U[0] : 0;
        uint32_t z2 = (dim >= 2) ? U[1] : 0;
        const auto& L1 = byZ[z1];
        const auto& L2 = byZ[z2];

        // Orbit-reduce (a, b) first? Even simpler: collect valid 4-tuples, orbit-reduce with stabU!
        std::set<std::array<uint32_t, 4>> local_tuples;
        for (uint32_t a : L1) {
            for (uint32_t b : L2) {
                uint32_t prodF = (a & b) & mF;
                for (int w = (m2Z & 1); w <= max_oddF; w += 2) {
                    int remR = R_max - m2Z - w;
                    for (uint32_t e : f_errs[w]) {
                        auto it = byF.find(prodF ^ e);
                        if (it == byF.end()) continue;
                        int xHc = xZ ^ xor5_mask(e);
                        for (uint32_t p0 : it->second) {
                            uint32_t p1 = p0 ^ a;
                            uint32_t p2 = p0 ^ b;
                            uint32_t p3 = p0 ^ a ^ b ^ mF;
                            int rad_xor = rad_map.at(p0) ^ rad_map.at(p1) ^ rad_map.at(p2) ^ rad_map.at(p3);
                            if (xHc != (1 ^ rad_xor)) continue;
                            if (remR == 0 && rad_xor != 0) continue; // R|_H = 0 => XOR_5(R|_H) = 0!
                            std::array<uint32_t, 4> t{p0, p1, p2, p3};
                            std::sort(t.begin(), t.end());
                            local_tuples.insert(t);
                        }
                    }
                }
            }
        }
        // Orbit-reduce local_tuples under stabU!
        std::set<std::array<uint32_t, 4>> visT;
        for (const auto& t : local_tuples) {
            if (visT.count(t)) continue;
            for (const auto& g : stabU) {
                std::array<uint32_t, 4> nx{app32(t[0], g), app32(t[1], g), app32(t[2], g), app32(t[3], g)};
                std::sort(nx.begin(), nx.end());
                visT.insert(nx);
            }
            int rad_xor = rad_map.at(t[0]) ^ rad_map.at(t[1]) ^ rad_map.at(t[2]) ^ rad_map.at(t[3]);
            uint32_t a = t[1] ^ t[0], b = t[2] ^ t[0];
            int oddF = __builtin_popcount((t[0] ^ (a & b)) & mF);
            orb_cnt[{dim, m2Z, oddF, rad_xor != 0}]++;
            total_orbs++;
        }
    }
    std::cout << "  >>> EXACT TOTAL Stab(H)-orbits of 4-tuples: " << total_orbs << " <<<\n";
    for (const auto& [k, v] : orb_cnt) {
        auto [dim, m2Z, oddF, rnz] = k;
        std::cout << "    dim=" << dim << " m2Z=" << m2Z << " oddF=" << oddF
                  << " remR=" << (R_max - m2Z - oddF) << " rad_nz=" << rnz << ": " << v << " orbits\n";
    }
    std::cout << std::flush;
}

int main() {
    init_Q();
    uint32_t mons[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0;
        for (int i = 0; i < 32; ++i) if ((i & m) == m) mask |= (1u << i);
        mons[mk++] = mask;
    }
    std::vector<uint32_t> all_q(65536, 0);
    for (int s = 1; s < 65536; ++s) all_q[s] = all_q[s - 1] ^ mons[__builtin_ctz(s)];
    std::unordered_map<uint32_t, uint8_t> rad_map;
    rad_map.reserve(100000);
    for (uint32_t p : all_q) rad_map[p] = rad5_of(p);

    analyze("Case II (H_0)", 0, 6, all_q, rad_map);
    analyze("Case III (H_1)", 1, 8, all_q, rad_map);
    return 0;
}
