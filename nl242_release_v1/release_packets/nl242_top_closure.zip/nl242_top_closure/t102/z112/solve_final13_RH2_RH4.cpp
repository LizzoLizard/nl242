// Exact Stab(T)-orbit-reduced solver for R_H == 2 AND R_H == 4 across ALL 13 final orbits:
//   - 7 Case II (H_0) remR == 6 orbits: (RH=2, 2eHc=4) and (RH=4, 2eHc=2)
//   - 4 Case III (H_1) remR == 6 orbits: (RH=2, 2eHc=4) and (RH=4, 2eHc=2)
//   - 2 Case III (H_1) remR == 8 orbits: (RH=2, 2eHc=6) and (RH=4, 2eHc=4)
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <mutex>
#include <set>
#include <stdexcept>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

static int Q64[64];
static void init_Q() {
    for (int x = 0; x < 64; ++x) {
        int s = ((x & 3) == 3) ^ (((x >> 2) & 3) == 3) ^ (((x >> 4) & 3) == 3);
        Q64[x] = s ^ (x & 1) ^ ((x >> 1) & 1);
    }
}
static inline void fwht8(std::array<int, 8>& a) {
    for (int step = 1; step < 8; step *= 2)
        for (int i = 0; i < 8; i += 2 * step)
            for (int j = i; j < i + step; ++j) {
                int x = a[j], y = a[j + step];
                a[j] = x + y; a[j + step] = x - y;
            }
}
static uint8_t rad5_of(uint32_t p) {
    uint8_t B[5] = {};
    int p0 = p & 1;
    for (int i = 0; i < 5; ++i) {
        int pi = (p >> (1 << i)) & 1;
        for (int j = 0; j < 5; ++j) {
            int pj = (p >> (1 << j)) & 1;
            int pij = (p >> ((1 << i) ^ (1 << j))) & 1;
            if (p0 ^ pi ^ pj ^ pij) B[i] |= (1u << j);
        }
    }
    int kcnt = 0, last = 0;
    for (int x = 0; x < 32; ++x) {
        bool ok = true;
        for (int i = 0; i < 5; ++i)
            if (__builtin_parity(B[i] & x)) { ok = false; break; }
        if (ok) { kcnt++; last = x; }
    }
    return (kcnt == 2) ? (uint8_t)last : 0;
}
static inline int xor5_mask(uint32_t m) {
    int r = 0;
    while (m) { int i = __builtin_ctz(m); r ^= i; m &= m - 1; }
    return r;
}

using Perm32 = std::array<uint8_t, 32>;
static inline uint32_t app32(uint32_t m, const Perm32& g) {
    uint32_t out = 0;
    while (m) { int i = __builtin_ctz(m); out |= (1u << g[i]); m &= m - 1; }
    return out;
}
struct PermHash {
    size_t operator()(const Perm32& p) const {
        uint64_t h = 1469598103934665603ULL;
        for (int i = 0; i < 32; ++i) { h ^= p[i]; h *= 1099511628211ULL; }
        return (size_t)h;
    }
};
static std::vector<Perm32> build_stabH(int is_H1) {
    std::vector<Perm32> gens;
    for (int v = 2; v < 64; v += 2) {
        int dual = ((v & 21) << 1) | ((v & 42) >> 1);
        Perm32 g{};
        for (int i = 0; i < 32; ++i) {
            int x = 2 * i + (1 - is_H1);
            int y = x ^ ((1 ^ Q64[v] ^ (__builtin_parity(x & dual) & 1)) ? v : 0);
            g[i] = (uint8_t)(y >> 1);
        }
        gens.push_back(g);
    }
    Perm32 id{}; for (int i = 0; i < 32; ++i) id[i] = (uint8_t)i;
    std::unordered_set<Perm32, PermHash> vis; vis.reserve(40000);
    std::vector<Perm32> grp{id}; vis.insert(id);
    for (size_t qi = 0; qi < grp.size(); ++qi) {
        const auto cur = grp[qi];
        for (const auto& g : gens) {
            Perm32 nx{};
            for (int i = 0; i < 32; ++i) nx[i] = g[cur[i]];
            if (vis.insert(nx).second) grp.push_back(nx);
        }
    }
    return grp;
}

struct PhaseReducer {
    uint64_t pivs[64]{};
    uint64_t mask = 0;
    void init(uint64_t m) {
        mask = m;
        for (int b = 0; b < 64; ++b) pivs[b] = 0;
        for (int k = 0; k < 7; ++k) {
            uint64_t w = 0;
            for (int c = 0; c < 64; ++c)
                if (k == 6 || ((c >> k) & 1)) w |= (1ULL << c);
            w &= mask;
            while (w) {
                int b = 63 - __builtin_clzll(w);
                if (!pivs[b]) { pivs[b] = w; break; }
                w ^= pivs[b];
            }
        }
    }
    uint64_t reduce(uint64_t w) const {
        w &= mask;
        for (int b = 63; b >= 0; --b)
            if (pivs[b] && ((w >> b) & 1)) w ^= pivs[b];
        return w;
    }
};

using Opts32 = std::array<std::vector<int>, 32>;
using HalfMap = std::unordered_map<uint32_t, std::map<uint32_t, int>>;

static inline uint64_t interleave_H(uint32_t h_bits, uint32_t hc_bits, int is_H1) {
    uint64_t out = 0;
    for (int i = 0; i < 32; ++i) {
        if ((h_bits >> i) & 1) out |= (1ULL << (2 * i + is_H1));
        if ((hc_bits >> i) & 1) out |= (1ULL << (2 * i + (1 - is_H1)));
    }
    return out;
}
static inline uint16_t compute_q16(const std::array<int8_t, 16>& u) {
    uint16_t q = 0;
    for (int y = 0; y < 16; ++y)
        if ((u[y] >> 1) & 1) q |= (uint16_t(1) << y);
    return q;
}
static long long opt_cost(const Opts32& o) {
    long long p0 = 1, p1 = 1;
    for (int i = 0; i < 16; ++i) p0 *= (long long)o[i].size();
    for (int i = 16; i < 32; ++i) p1 *= (long long)o[i].size();
    return p0 + p1;
}

// ---------- Core 8x8 S + minE + q16 helpers ----------
struct Slice8S { std::array<int8_t, 8> b; uint8_t m68, sgn; };
static void enum_slice8_S(int start, int j, std::array<int, 8>& z, uint8_t m68, uint8_t sg,
                          const Opts32& opts, uint32_t track_mask,
                          std::array<std::vector<Slice8S>, 256>& out) {
    if (j < 8) {
        int idx = start + j; bool tr = (track_mask >> idx) & 1;
        for (int v : opts[idx]) {
            z[j] = v;
            uint8_t nm = m68 | ((tr && (std::abs(v) == 6 || std::abs(v) == 8)) ? (uint8_t(1) << j) : 0);
            uint8_t ns = sg | ((v < 0) ? (uint8_t(1) << j) : 0);
            enum_slice8_S(start, j + 1, z, nm, ns, opts, track_mask, out);
        }
        return;
    }
    auto u = z; fwht8(u);
    uint8_t par = 0; std::array<int8_t, 8> b;
    for (int y = 0; y < 8; ++y) {
        if (u[y] & 7) return;
        int q = u[y] >> 3; if (std::abs(q) > 8) return;
        b[y] = (int8_t)q; if (q & 1) par |= (uint8_t(1) << y);
    }
    out[par].push_back({b, m68, sg});
}

struct Slice16S { std::array<int8_t, 16> u; uint16_t m68, sgn, q16; };
struct HalfByQS {
    std::vector<Slice16S> all;
    std::unordered_map<uint16_t, std::vector<uint32_t>> by_q;
};
static void enum_slice16_S_by_par(int start, const Opts32& opts, uint32_t track_mask,
                                  const std::unordered_map<uint16_t, std::vector<uint16_t>>* allowed_par,
                                  std::unordered_map<uint16_t, HalfByQS>& out) {
    std::array<std::vector<Slice8S>, 256> q0, q1;
    std::array<int, 8> tmp{};
    enum_slice8_S(start, 0, tmp, 0, 0, opts, track_mask, q0);
    enum_slice8_S(start + 8, 0, tmp, 0, 0, opts, track_mask, q1);
    for (int par8 = 0; par8 < 256; ++par8) {
        if (q0[par8].empty() || q1[par8].empty()) continue;
        for (const auto& a : q0[par8]) for (const auto& b : q1[par8]) {
            std::array<int8_t, 16> u; uint16_t par16 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                u[y] = (int8_t)s; u[8 + y] = (int8_t)d;
                if (s & 1) par16 |= (uint16_t(1) << y);
                if (d & 1) par16 |= (uint16_t(1) << (8 + y));
            }
            if (!ok) continue;
            if (allowed_par && !allowed_par->count(par16)) continue;
            uint16_t q16 = compute_q16(u);
            auto& hb = out[par16];
            uint32_t id = (uint32_t)hb.all.size();
            hb.all.push_back({u, uint16_t(a.m68 | (b.m68 << 8)), uint16_t(a.sgn | (b.sgn << 8)), q16});
            hb.by_q[q16].push_back(id);
        }
    }
}

struct HalfEntryS { uint32_t tw, m68, sgn; int e2; };
struct HcData {
    std::unordered_map<uint32_t, std::vector<HalfEntryS>> by_p32;
    std::unordered_map<uint16_t, std::vector<uint16_t>> p32low_by_par;
    HalfMap minE;
};

static void collect_Hc_S(const Opts32& opts, uint32_t track_mask, HcData& out,
                         const std::unordered_map<uint16_t, std::vector<uint16_t>>* filter_par = nullptr,
                         const HalfMap* filter_p32 = nullptr) {
    out.by_p32.clear(); out.p32low_by_par.clear(); out.minE.clear();
    std::unordered_map<uint16_t, HalfByQS> g0, g1;
    enum_slice16_S_by_par(0, opts, track_mask, filter_par, g0);
    if (g0.empty()) return;
    enum_slice16_S_by_par(16, opts, track_mask, filter_par, g1);
    if (g1.empty()) return;

    auto rec = [&](const Slice16S& a, const Slice16S& b, uint32_t p32) {
        uint32_t tw = 0; int e2 = 0;
        for (int y = 0; y < 16; ++y) {
            if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) return;
            int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
            e2 += x0*x0 + x1*x1;
            if (std::abs(x0) == 2) tw |= (1u << y);
            if (std::abs(x1) == 2) tw |= (1u << (16 + y));
        }
        uint32_t m68 = uint32_t(a.m68) | (uint32_t(b.m68) << 16);
        uint32_t sg = uint32_t(a.sgn) | (uint32_t(b.sgn) << 16);
        out.by_p32[p32].push_back({tw, m68, sg, e2});
        auto& mp = out.minE[p32];
        auto it2 = mp.find(tw);
        if (it2 == mp.end() || e2 < it2->second) mp[tw] = e2;
    };

    if (filter_par && filter_p32) {
        for (const auto& [par16, p32_lows] : *filter_par) {
            auto it0 = g0.find(par16); if (it0 == g0.end()) continue;
            auto it1 = g1.find(par16); if (it1 == g1.end()) continue;
            const auto& H0 = it0->second; const auto& H1 = it1->second;
            size_t n0 = H0.all.size(), n1 = H1.all.size(), np = p32_lows.size();
            if (n0 * n1 <= std::min(n0, n1) * np * 2) {
                for (const auto& a : H0.all) for (const auto& b : H1.all) {
                    uint16_t lo = a.q16 ^ b.q16 ^ par16;
                    uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                    if (!filter_p32->count(p32)) continue;
                    rec(a, b, p32);
                }
            } else if (n0 <= n1) {
                for (const auto& a : H0.all) {
                    uint16_t base = a.q16 ^ par16;
                    for (uint16_t lo : p32_lows) {
                        auto itq = H1.by_q.find(base ^ lo); if (itq == H1.by_q.end()) continue;
                        uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                        for (uint32_t id1 : itq->second) rec(a, H1.all[id1], p32);
                    }
                }
            } else {
                for (const auto& b : H1.all) {
                    uint16_t base = b.q16 ^ par16;
                    for (uint16_t lo : p32_lows) {
                        auto itq = H0.by_q.find(base ^ lo); if (itq == H0.by_q.end()) continue;
                        uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                        for (uint32_t id0 : itq->second) rec(H0.all[id0], b, p32);
                    }
                }
            }
        }
    } else {
        for (const auto& [par16, H0] : g0) {
            auto it1 = g1.find(par16); if (it1 == g1.end()) continue;
            for (const auto& a : H0.all) for (const auto& b : it1->second.all) {
                uint16_t lo = a.q16 ^ b.q16 ^ par16;
                uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                rec(a, b, p32);
            }
        }
    }
    for (const auto& [p32, _] : out.minE) {
        uint16_t lo = (uint16_t)(p32 & 0xFFFFu), hi = (uint16_t)(p32 >> 16);
        out.p32low_by_par[lo ^ hi].push_back(lo);
    }
}

static int min_join_m(const HalfMap& mt, const HalfMap& ms) {
    int best = 999;
    const HalfMap* sm = &mt; const HalfMap* bg = &ms;
    if (ms.size() < mt.size()) std::swap(sm, bg);
    for (const auto& [p32, tm] : *sm) {
        auto it = bg->find(p32); if (it == bg->end()) continue;
        for (const auto& [tw1, e1] : tm)
            for (const auto& [tw2, e2] : it->second)
                if ((tw1 & tw2) == 0) {
                    int m = (e1 + e2) / 2;
                    if (m < best) best = m;
                }
    }
    return best;
}

// ---------- H u<=4 min_m_by_Fmask + exact_join_fixed_F ----------
struct HQ8 { std::array<int8_t, 8> b; uint8_t m2F, m10F, u; };
static void enum_H_q8(int start, int j, int cur_u, int max_u,
                      std::array<int, 8>& z, uint8_t m2, uint8_t m10,
                      uint32_t p, const int H_pts[32],
                      std::array<std::vector<HQ8>, 256>& out) {
    if (j == 8) {
        auto u = z; fwht8(u);
        uint8_t par = 0; std::array<int8_t, 8> b;
        for (int y = 0; y < 8; ++y) {
            if (u[y] & 7) return;
            int q = u[y] >> 3; if (std::abs(q) > 8) return;
            b[y] = (int8_t)q; if (q & 1) par |= (uint8_t(1) << y);
        }
        out[par].push_back({b, m2, m10, (uint8_t)cur_u});
        return;
    }
    int idx = start + j, pi = (p >> idx) & 1;
    uint8_t bit = uint8_t(1) << j;
    if (Q64[H_pts[idx]] == 0) {
        if (pi == 0) {
            z[j] = -6; enum_H_q8(start, j+1, cur_u, max_u, z, m2, m10, p, H_pts, out);
            z[j] = 2;  enum_H_q8(start, j+1, cur_u, max_u, z, m2, m10, p, H_pts, out);
        } else {
            z[j] = -2; enum_H_q8(start, j+1, cur_u, max_u, z, m2, m10, p, H_pts, out);
            z[j] = 6;  enum_H_q8(start, j+1, cur_u, max_u, z, m2, m10, p, H_pts, out);
        }
    } else {
        if (pi == 0) {
            z[j] = -6; enum_H_q8(start, j+1, cur_u, max_u, z, m2, m10, p, H_pts, out);
            if (cur_u < max_u) {
                z[j] = 2;  enum_H_q8(start, j+1, cur_u+1, max_u, z, m2|bit, m10,     p, H_pts, out);
                z[j] = 10; enum_H_q8(start, j+1, cur_u+1, max_u, z, m2,     m10|bit, p, H_pts, out);
            }
        } else {
            z[j] = 6;  enum_H_q8(start, j+1, cur_u, max_u, z, m2, m10, p, H_pts, out);
            if (cur_u < max_u) {
                z[j] = -2;  enum_H_q8(start, j+1, cur_u+1, max_u, z, m2|bit, m10,     p, H_pts, out);
                z[j] = -10; enum_H_q8(start, j+1, cur_u+1, max_u, z, m2,     m10|bit, p, H_pts, out);
            }
        }
    }
}

struct HH16 { std::array<int8_t, 16> u; uint16_t m2F, m10F, q16; };
struct HHalfByU {
    std::vector<HH16> all[5];
    std::unordered_map<uint16_t, std::vector<uint32_t>> idx_by_q[5];
};
static void enum_H_h16_filtered(int start, int max_u, uint32_t p, const int H_pts[32],
                                const std::unordered_map<uint16_t, std::vector<uint16_t>>& allowed_par,
                                std::unordered_map<uint16_t, HHalfByU>& out) {
    std::array<std::vector<HQ8>, 256> q0, q1;
    std::array<int, 8> tmp{};
    enum_H_q8(start, 0, 0, max_u, tmp, 0, 0, p, H_pts, q0);
    enum_H_q8(start + 8, 0, 0, max_u, tmp, 0, 0, p, H_pts, q1);
    for (int par8 = 0; par8 < 256; ++par8) {
        if (q0[par8].empty() || q1[par8].empty()) continue;
        for (const auto& a : q0[par8]) for (const auto& b : q1[par8]) {
            int uc = a.u + b.u; if (uc > max_u) continue;
            std::array<int8_t, 16> u; uint16_t par16 = 0; bool ok = true;
            for (int y = 0; y < 8; ++y) {
                if (std::abs(a.b[y]) + std::abs(b.b[y]) > 8) { ok = false; break; }
                int s = (a.b[y] + b.b[y]) >> 1, d = (a.b[y] - b.b[y]) >> 1;
                u[y] = (int8_t)s; u[8 + y] = (int8_t)d;
                if (s & 1) par16 |= (uint16_t(1) << y);
                if (d & 1) par16 |= (uint16_t(1) << (8 + y));
            }
            if (!ok || !allowed_par.count(par16)) continue;
            uint16_t q16 = compute_q16(u);
            auto& hb = out[par16];
            uint32_t id = (uint32_t)hb.all[uc].size();
            hb.all[uc].push_back({u, uint16_t(a.m2F | (b.m2F << 8)), uint16_t(a.m10F | (b.m10F << 8)), q16});
            hb.idx_by_q[uc][q16].push_back(id);
        }
    }
}

static void build_min_m_by_Fmask(const std::unordered_map<uint16_t, HHalfByU>& hg0,
                                 const std::unordered_map<uint16_t, HHalfByU>& hg1,
                                 const HcData& hc, int max_u,
                                 std::unordered_map<uint64_t, int>& out_minm) {
    auto record = [&](const HH16& a, const HH16& b, uint32_t tw, int e2, const std::map<uint32_t, int>& mp) {
        int best_es = 999999;
        for (const auto& [tw_s, es] : mp)
            if ((tw & tw_s) == 0 && es < best_es) best_es = es;
        if (best_es < 999999) {
            int m = (e2 + best_es) / 2; if (m > 64) return;
            uint32_t m2F = uint32_t(a.m2F) | (uint32_t(b.m2F) << 16);
            uint32_t m10F = uint32_t(a.m10F) | (uint32_t(b.m10F) << 16);
            uint64_t key = (uint64_t(m2F) << 32) | uint64_t(m10F);
            auto it = out_minm.find(key);
            if (it == out_minm.end() || m < it->second) out_minm[key] = m;
        }
    };
    for (const auto& [par16, p32_lows] : hc.p32low_by_par) {
        auto it0 = hg0.find(par16); if (it0 == hg0.end()) continue;
        auto it1 = hg1.find(par16); if (it1 == hg1.end()) continue;
        const auto& H0 = it0->second; const auto& H1 = it1->second;
        for (int u0 = 0; u0 <= max_u; ++u0) {
            if (H0.all[u0].empty()) continue;
            for (int u1 = 0; u1 <= max_u - u0; ++u1) {
                if (H1.all[u1].empty()) continue;
                size_t n0 = H0.all[u0].size(), n1 = H1.all[u1].size(), np = p32_lows.size();
                if (n0 * n1 <= std::min(n0, n1) * np * 2) {
                    for (const auto& a : H0.all[u0]) for (const auto& b : H1.all[u1]) {
                        uint16_t lo = a.q16 ^ b.q16 ^ par16;
                        uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                        auto itm = hc.minE.find(p32); if (itm == hc.minE.end()) continue;
                        uint32_t tw = 0; int e2 = 0; bool ok = true;
                        for (int y = 0; y < 16; ++y) {
                            if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                            int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                            e2 += x0*x0 + x1*x1;
                            if (std::abs(x0) == 2) tw |= (1u << y);
                            if (std::abs(x1) == 2) tw |= (1u << (16 + y));
                        }
                        if (ok) record(a, b, tw, e2, itm->second);
                    }
                } else if (n0 <= n1) {
                    const auto& qmap1 = H1.idx_by_q[u1];
                    for (const auto& a : H0.all[u0]) {
                        uint16_t base = a.q16 ^ par16;
                        for (uint16_t lo : p32_lows) {
                            auto itq = qmap1.find(base ^ lo); if (itq == qmap1.end()) continue;
                            uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                            const auto& mp = hc.minE.at(p32);
                            for (uint32_t id1 : itq->second) {
                                const auto& b = H1.all[u1][id1];
                                uint32_t tw = 0; int e2 = 0; bool ok = true;
                                for (int y = 0; y < 16; ++y) {
                                    if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                                    int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                                    e2 += x0*x0 + x1*x1;
                                    if (std::abs(x0) == 2) tw |= (1u << y);
                                    if (std::abs(x1) == 2) tw |= (1u << (16 + y));
                                }
                                if (ok) record(a, b, tw, e2, mp);
                            }
                        }
                    }
                } else {
                    const auto& qmap0 = H0.idx_by_q[u0];
                    for (const auto& b : H1.all[u1]) {
                        uint16_t base = b.q16 ^ par16;
                        for (uint16_t lo : p32_lows) {
                            auto itq = qmap0.find(base ^ lo); if (itq == qmap0.end()) continue;
                            uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par16) << 16);
                            const auto& mp = hc.minE.at(p32);
                            for (uint32_t id0 : itq->second) {
                                const auto& a = H0.all[u0][id0];
                                uint32_t tw = 0; int e2 = 0; bool ok = true;
                                for (int y = 0; y < 16; ++y) {
                                    if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                                    int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                                    e2 += x0*x0 + x1*x1;
                                    if (std::abs(x0) == 2) tw |= (1u << y);
                                    if (std::abs(x1) == 2) tw |= (1u << (16 + y));
                                }
                                if (ok) record(a, b, tw, e2, mp);
                            }
                        }
                    }
                }
            }
        }
    }
}

static long long exact_join_fixed_F(int is_H1, const int H_pts[32], uint32_t mHZ,
                                    const std::array<uint32_t, 4>& t,
                                    const std::array<uint32_t, 4>& m2F,
                                    const std::array<uint32_t, 4>& m10F,
                                    int d3_cnt, uint8_t need_d3_xor, uint32_t k3_H,
                                    uint32_t Z1, uint32_t track_s, uint32_t k1_act,
                                    const HcData hc[4]) {
    int need_e6_cnt = __builtin_popcount(mHZ) - d3_cnt;
    uint64_t phase64 = interleave_H(0xFFFFFFFFu, Z1 | k1_act, is_H1);
    PhaseReducer red; red.init(phase64);

    struct Sig {
        uint32_t e6, e8; int m; uint64_t sgn;
        bool operator<(const Sig& o) const {
            if (e6 != o.e6) return e6 < o.e6;
            if (e8 != o.e8) return e8 < o.e8;
            if (m != o.m) return m < o.m;
            return sgn < o.sgn;
        }
        bool operator==(const Sig& o) const {
            return e6 == o.e6 && e8 == o.e8 && m == o.m && sgn == o.sgn;
        }
    };
    std::array<std::vector<Sig>, 4> sigs;
    for (int k = 0; k < 4; ++k) {
        Opts32 ot;
        for (int i = 0; i < 32; ++i) {
            int pi = (t[k] >> i) & 1;
            if (Q64[H_pts[i]] == 0) ot[i] = pi ? std::vector<int>{-2, 6} : std::vector<int>{-6, 2};
            else {
                if ((m2F[k] >> i) & 1) ot[i] = pi ? std::vector<int>{-2} : std::vector<int>{2};
                else if ((m10F[k] >> i) & 1) ot[i] = pi ? std::vector<int>{-10} : std::vector<int>{10};
                else ot[i] = pi ? std::vector<int>{6} : std::vector<int>{-6};
            }
        }
        std::unordered_map<uint16_t, HalfByQS> g0, g1;
        enum_slice16_S_by_par(0, ot, mHZ, &hc[k].p32low_by_par, g0);
        if (g0.empty()) return 0;
        enum_slice16_S_by_par(16, ot, mHZ, &hc[k].p32low_by_par, g1);
        if (g1.empty()) return 0;
        for (const auto& [par, h0] : g0) {
            auto it1 = g1.find(par); if (it1 == g1.end()) continue;
            for (const auto& a : h0.all) for (const auto& b : it1->second.all) {
                uint16_t lo = a.q16 ^ b.q16 ^ par;
                uint32_t p32 = uint32_t(lo) | (uint32_t(lo ^ par) << 16);
                auto its = hc[k].by_p32.find(p32); if (its == hc[k].by_p32.end()) continue;
                uint32_t tw = 0; int e2 = 0; bool ok = true;
                for (int y = 0; y < 16; ++y) {
                    if (std::abs(a.u[y]) + std::abs(b.u[y]) > 4) { ok = false; break; }
                    int x0 = (a.u[y] + b.u[y]) >> 1, x1 = (a.u[y] - b.u[y]) >> 1;
                    e2 += x0*x0 + x1*x1;
                    if (std::abs(x0) == 2) tw |= (1u << y);
                    if (std::abs(x1) == 2) tw |= (1u << (16 + y));
                }
                if (!ok) continue;
                uint32_t e6 = uint32_t(a.m68) | (uint32_t(b.m68) << 16);
                uint32_t sgH = uint32_t(a.sgn) | (uint32_t(b.sgn) << 16);
                for (const auto& es : its->second) {
                    if (tw & es.tw) continue;
                    int m = (e2 + es.e2) / 2; if (m > 64) continue;
                    sigs[k].push_back({e6, es.m68, m, red.reduce(interleave_H(sgH, es.sgn, is_H1))});
                }
            }
        }
        std::sort(sigs[k].begin(), sigs[k].end());
        sigs[k].erase(std::unique(sigs[k].begin(), sigs[k].end()), sigs[k].end());
        if (sigs[k].empty()) return 0;
    }
    std::array<int, 4> ord{0, 1, 2, 3};
    std::sort(ord.begin(), ord.end(), [&](int a, int b){ return sigs[a].size() < sigs[b].size(); });

    struct LE { uint32_t e6; uint64_t sgn; };
    std::unordered_map<uint64_t, std::vector<LE>> lmap;
    for (const auto& a : sigs[ord[0]]) for (const auto& b : sigs[ord[3]]) {
        if ((a.e6 & b.e6) || (a.e8 & b.e8)) continue;
        int m = a.m + b.m; if (m > 102) continue;
        lmap[(uint64_t(a.e8 | b.e8) << 8) | uint64_t(m)].push_back({a.e6 | b.e6, a.sgn ^ b.sgn});
    }
    long long hits = 0;
    for (const auto& c : sigs[ord[1]]) for (const auto& d : sigs[ord[2]]) {
        if ((c.e6 & d.e6) || (c.e8 & d.e8)) continue;
        int m = c.m + d.m; if (m > 102) continue;
        uint32_t e8r = c.e8 | d.e8;
        if ((e8r & track_s) != e8r) continue;
        auto it = lmap.find((uint64_t(track_s ^ e8r) << 8) | uint64_t(102 - m));
        if (it == lmap.end()) continue;
        uint32_t re6 = c.e6 | d.e6;
        uint64_t rsgn = c.sgn ^ d.sgn;
        for (const auto& L : it->second) {
            if (L.e6 & re6) continue;
            uint32_t u6 = L.e6 | re6;
            if (__builtin_popcount(u6) != need_e6_cnt) continue;
            uint32_t d3_H = mHZ ^ u6;
            if (xor5_mask(d3_H) != need_d3_xor) continue;
            uint64_t tgt_sgn = red.reduce(phase64 ^ interleave_H(d3_H | k3_H, 0, is_H1));
            if ((L.sgn ^ rsgn) == tgt_sgn) hits++;
        }
    }
    return hits;
}

// Solve R_H == 4 for ONE fixed H^c config (hc[0..3])!
static long long solve_RH4_one_Hc(int is_H1, const int H_pts[32], uint32_t mHZ, uint32_t mHF,
                                  const std::vector<int>& HF_pts,
                                  const std::array<uint32_t, 4>& t, uint8_t rad_xor,
                                  uint32_t Z1, uint32_t track_s, uint32_t k1_act,
                                  const HcData hc[4]) {
    int nHF = (int)HF_pts.size();
    std::unordered_map<uint64_t, int> minm[4];
    for (int k = 0; k < 4; ++k) {
        std::unordered_map<uint16_t, HHalfByU> hg0, hg1;
        enum_H_h16_filtered(0, 4, t[k], H_pts, hc[k].p32low_by_par, hg0);
        enum_H_h16_filtered(16, 4, t[k], H_pts, hc[k].p32low_by_par, hg1);
        build_min_m_by_Fmask(hg0, hg1, hc[k], 4, minm[k]);
    }
    auto get_m = [&](int k, uint32_t m2, uint32_t m10) -> int {
        auto it = minm[k].find((uint64_t(m2) << 32) | uint64_t(m10));
        return (it == minm[k].end()) ? 999 : it->second;
    };
    long long hits = 0;
    auto check_assign = [&](const std::array<uint32_t, 4>& m2, const std::array<uint32_t, 4>& m10,
                            int d3_cnt, uint8_t need_d3_xor, uint32_t k3_H) {
        int s = get_m(0, m2[0], m10[0]); if (s >= 999) return;
        s += get_m(1, m2[1], m10[1]); if (s >= 999) return;
        s += get_m(2, m2[2], m10[2]); if (s >= 999) return;
        s += get_m(3, m2[3], m10[3]); if (s > 102) return;
        hits += exact_join_fixed_F(is_H1, H_pts, mHZ, t, m2, m10, d3_cnt, need_d3_xor, k3_H, Z1, track_s, k1_act, hc);
    };
    auto test_pattern = [&](const std::vector<std::pair<int, int>>& pts) {
        int sumk = 0; uint8_t odd_xor = 0; uint32_t k3_H = 0;
        for (auto [pt, kv] : pts) { sumk += kv; if (kv & 1) odd_xor ^= (uint8_t)pt; if (kv == 3) k3_H |= (1u << pt); }
        int d3_cnt = 4 - sumk;
        uint8_t need_d3_xor = rad_xor ^ odd_xor;
        if (d3_cnt == 0 && need_d3_xor != 0) return;
        if (d3_cnt == 1 && !((mHZ >> need_d3_xor) & 1)) return;
        if (d3_cnt == 2 && need_d3_xor == 0) return;
        std::array<uint32_t, 4> m2{0,0,0,0}, m10{0,0,0,0};
        auto rec = [&](auto& self, size_t idx) -> void {
            if (idx == pts.size()) { check_assign(m2, m10, d3_cnt, need_d3_xor, k3_H); return; }
            int pt = pts[idx].first, kv = pts[idx].second; uint32_t bit = 1u << pt;
            if (kv == 4) {
                for (int k = 0; k < 4; ++k) m2[k] |= bit;
                self(self, idx + 1);
                for (int k = 0; k < 4; ++k) m2[k] ^= bit;
            } else if (kv == 3) {
                for (int j = 0; j < 4; ++j) {
                    for (int k = 0; k < 4; ++k) if (k != j) m2[k] |= bit;
                    self(self, idx + 1);
                    for (int k = 0; k < 4; ++k) if (k != j) m2[k] ^= bit;
                }
            } else if (kv == 1) {
                for (int j = 0; j < 4; ++j) {
                    m10[j] |= bit; for (int k = 0; k < 4; ++k) if (k != j) m2[k] |= bit;
                    self(self, idx + 1);
                    m10[j] ^= bit; for (int k = 0; k < 4; ++k) if (k != j) m2[k] ^= bit;
                }
            } else {
                for (int a = 0; a < 4; ++a) for (int b = a + 1; b < 4; ++b) {
                    m2[a] |= bit; m2[b] |= bit; self(self, idx + 1); m2[a] ^= bit; m2[b] ^= bit;
                }
            }
        };
        rec(rec, 0);
    };
    test_pattern({});
    for (int ia = 0; ia < nHF; ++ia) for (int ka = 1; ka <= 4; ++ka) test_pattern({{HF_pts[ia], ka}});
    for (int ia = 0; ia < nHF; ++ia) for (int ib = ia + 1; ib < nHF; ++ib) {
        int a = HF_pts[ia], b = HF_pts[ib];
        test_pattern({{a,1},{b,1}}); test_pattern({{a,2},{b,1}}); test_pattern({{a,1},{b,2}});
        test_pattern({{a,3},{b,1}}); test_pattern({{a,1},{b,3}}); test_pattern({{a,2},{b,2}});
    }
    if (rad_xor != 0) {
        for (int ib = 0; ib < nHF; ++ib) {
            int b = HF_pts[ib], c = b ^ rad_xor;
            if (c <= b || !((mHF >> c) & 1)) continue;
            for (int ia = 0; ia < nHF; ++ia) {
                int a = HF_pts[ia]; if (a == b || a == c) continue;
                test_pattern({{a, 2}, {b, 1}, {c, 1}});
            }
        }
    }
    for (int ia = 0; ia < nHF; ++ia) for (int ib = ia + 1; ib < nHF; ++ib) for (int ic = ib + 1; ic < nHF; ++ic) {
        int a = HF_pts[ia], b = HF_pts[ib], c = HF_pts[ic];
        int z = a ^ b ^ c ^ rad_xor;
        if ((mHZ >> z) & 1) test_pattern({{a, 1}, {b, 1}, {c, 1}});
        if (z > c && ((mHF >> z) & 1)) test_pattern({{a, 1}, {b, 1}, {c, 1}, {z, 1}});
    }
    return hits;
}

// Solve R_H == 2 (rad_xor != 0!) for ONE fixed H^c config (hc[0..3])!
static long long solve_RH2_one_Hc(int is_H1, const int H_pts[32], uint32_t mHZ,
                                  const std::array<uint32_t, 4>& t, uint8_t rad_xor,
                                  uint32_t Z1, uint32_t track_s, uint32_t k1_act,
                                  const HcData hc[4]) {
    // Only 16 pairs {a, b} with a ^ b == rad_xor!
    // Build minm[k][(m2, m10)] with max_u = 2 (instantaneous: < 0.005s!)
    std::unordered_map<uint64_t, int> minm[4];
    for (int k = 0; k < 4; ++k) {
        std::unordered_map<uint16_t, HHalfByU> hg0, hg1;
        enum_H_h16_filtered(0, 2, t[k], H_pts, hc[k].p32low_by_par, hg0);
        enum_H_h16_filtered(16, 2, t[k], H_pts, hc[k].p32low_by_par, hg1);
        build_min_m_by_Fmask(hg0, hg1, hc[k], 2, minm[k]);
    }
    auto get_m = [&](int k, uint32_t m2, uint32_t m10) -> int {
        auto it = minm[k].find((uint64_t(m2) << 32) | uint64_t(m10));
        return (it == minm[k].end()) ? 999 : it->second;
    };
    long long hits = 0;
    for (int a = 0; a < 32; ++a) {
        int b = a ^ rad_xor; if (b < a) continue;
        bool aF = (Q64[H_pts[a]] == 1), bF = (Q64[H_pts[b]] == 1);
        if (!aF && !bF) {
            int s = get_m(0,0,0) + get_m(1,0,0) + get_m(2,0,0) + get_m(3,0,0);
            if (s <= 102) hits += exact_join_fixed_F(is_H1, H_pts, mHZ, t, {0,0,0,0}, {0,0,0,0}, 2, rad_xor, 0, Z1, track_s, k1_act, hc);
        } else if (aF != bF) {
            int iz = aF ? b : a, iF = aF ? a : b;
            uint32_t bit = 1u << iF;
            for (int j = 0; j < 4; ++j) {
                std::array<uint32_t, 4> m2{bit,bit,bit,bit}, m10{0,0,0,0};
                m2[j] = 0; m10[j] = bit;
                int s = get_m(0,m2[0],m10[0]) + get_m(1,m2[1],m10[1]) + get_m(2,m2[2],m10[2]) + get_m(3,m2[3],m10[3]);
                if (s <= 102) hits += exact_join_fixed_F(is_H1, H_pts, mHZ, t, m2, m10, 1, (uint8_t)iz, 0, Z1, track_s, k1_act, hc);
            }
        } else {
            uint32_t ba = 1u << a, bb = 1u << b;
            for (int ja = 0; ja < 4; ++ja) for (int jb = 0; jb < 4; ++jb) {
                std::array<uint32_t, 4> m2{ba|bb,ba|bb,ba|bb,ba|bb}, m10{0,0,0,0};
                m2[ja] ^= ba; m10[ja] |= ba;
                m2[jb] ^= bb; m10[jb] |= bb;
                int s = get_m(0,m2[0],m10[0]) + get_m(1,m2[1],m10[1]) + get_m(2,m2[2],m10[2]) + get_m(3,m2[3],m10[3]);
                if (s <= 102) hits += exact_join_fixed_F(is_H1, H_pts, mHZ, t, m2, m10, 0, 0, 0, Z1, track_s, k1_act, hc);
            }
        }
    }
    return hits;
}

static Opts32 make_opt_s(int is_H1, uint32_t p, uint32_t u_union, uint32_t oddF,
                         uint32_t m4, uint32_t k3, uint32_t k2, uint32_t k4) {
    Opts32 os;
    for (int i = 0; i < 32; ++i) {
        int pi = (p >> i) & 1;
        if (Q64[2 * i + (1 - is_H1)] == 1) {
            if ((oddF >> i) & 1) {
                if ((k3 >> i) & 1) os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{0};
                else os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 8};
            } else {
                if ((k4 >> i) & 1) os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{0};
                else if ((k2 >> i) & 1) os[i] = pi ? std::vector<int>{-4, 4} : std::vector<int>{-8, 0, 8};
                else os[i] = pi ? std::vector<int>{-12, 12} : std::vector<int>{0};
            }
        } else {
            if (pi) os[i] = {-4, 4};
            else if (((u_union | m4) >> i) & 1) os[i] = {0};
            else os[i] = {-8, 0, 8};
        }
    }
    return os;
}

struct HcCfg { uint32_t m4, k3, k2, k4; };

static std::vector<HcCfg> enum_Hc_orbits(int two_eHc, uint32_t Z0, uint32_t oddF, uint32_t evenF,
                                         const std::vector<Perm32>& stabT) {
    std::vector<int> pos2, posF;
    for (int i = 0; i < 32; ++i) {
        if (((Z0 | oddF | evenF) >> i) & 1) pos2.push_back(i);
        if ((evenF >> i) & 1) posF.push_back(i);
    }
    std::vector<HcCfg> raw;
    if (two_eHc == 2) {
        for (int i : pos2) { uint32_t b = 1u << i; raw.push_back({b & Z0, b & oddF, b & evenF, 0}); }
    } else if (two_eHc == 4) {
        for (int i : posF) raw.push_back({0, 0, 0, 1u << i});
        for (size_t a = 0; a < pos2.size(); ++a)
            for (size_t b = a + 1; b < pos2.size(); ++b) {
                uint32_t m = (1u << pos2[a]) | (1u << pos2[b]);
                raw.push_back({m & Z0, m & oddF, m & evenF, 0});
            }
    } else if (two_eHc == 6) {
        // k4 + one +2 (disjoint)
        for (int i : posF) for (int j : pos2) {
            if (i == j) continue;
            uint32_t b = 1u << j;
            raw.push_back({b & Z0, b & oddF, b & evenF, 1u << i});
        }
        // three +2
        for (size_t a = 0; a < pos2.size(); ++a)
            for (size_t b = a + 1; b < pos2.size(); ++b)
                for (size_t c = b + 1; c < pos2.size(); ++c) {
                    uint32_t m = (1u << pos2[a]) | (1u << pos2[b]) | (1u << pos2[c]);
                    raw.push_back({m & Z0, m & oddF, m & evenF, 0});
                }
    }
    // Orbit-reduce raw under stabT!
    std::set<std::array<uint32_t, 4>> vis;
    std::vector<HcCfg> reps;
    for (const auto& c : raw) {
        std::array<uint32_t, 4> key{c.m4, c.k3, c.k2, c.k4};
        if (vis.count(key)) continue;
        reps.push_back(c);
        for (const auto& g : stabT)
            vis.insert({app32(c.m4, g), app32(c.k3, g), app32(c.k2, g), app32(c.k4, g)});
    }
    return reps;
}

static void solve_case(const std::string& name, int is_H1, int R_max,
                       const std::vector<uint32_t>& all_q,
                       const std::unordered_map<uint32_t, uint8_t>& rad_map) {
    int H_pts[32], Hc_pts[32];
    uint32_t mHZ = 0, mHF = 0, mHcZ = 0, mHcF = 0;
    std::vector<int> HF_pts;
    for (int i = 0; i < 32; ++i) {
        H_pts[i] = 2 * i + is_H1; Hc_pts[i] = 2 * i + (1 - is_H1);
        if (Q64[H_pts[i]] == 0) mHZ |= (1u << i); else { mHF |= (1u << i); HF_pts.push_back(i); }
        if (Q64[Hc_pts[i]] == 0) mHcZ |= (1u << i); else mHcF |= (1u << i);
    }
    auto grp = build_stabH(is_H1);
    std::unordered_map<uint32_t, std::vector<uint32_t>> byZ, byF;
    for (uint32_t q : all_q) { byZ[q & mHcZ].push_back(q); byF[q & mHcF].push_back(q); }

    std::vector<std::vector<uint32_t>> U_reps;
    U_reps.push_back({});
    if (R_max == 8) {
        std::unordered_set<uint32_t> visZ;
        for (const auto& [z, _] : byZ)
            if (z != 0 && __builtin_popcount(z) == 2 && !visZ.count(z)) {
                U_reps.push_back({z});
                for (const auto& g : grp) visZ.insert(app32(z, g));
            }
    }
    std::vector<uint32_t> f_errs[3];
    std::vector<int> fbits;
    for (int i = 0; i < 32; ++i) if ((mHcF >> i) & 1) fbits.push_back(i);
    f_errs[0].push_back(0);
    for (size_t i = 0; i < fbits.size(); ++i)
        for (size_t j = i + 1; j < fbits.size(); ++j)
            f_errs[2].push_back((1u << fbits[i]) | (1u << fbits[j]));

    struct Job {
        int orb_id, remR, RH, two_eHc;
        std::array<uint32_t, 4> t;
        uint32_t u_union, oddF, Z1, Z0;
        uint8_t rad_xor;
        HcCfg cfg;
    };
    std::vector<Job> jobs;
    int orb_id = 0;
    for (const auto& U : U_reps) {
        int dim = (int)U.size();
        uint32_t u_union = dim ? U[0] : 0;
        int m2Z = __builtin_popcount(u_union), xZ = xor5_mask(u_union);
        std::vector<Perm32> stabU;
        for (const auto& g : grp) if (dim == 0 || app32(U[0], g) == U[0]) stabU.push_back(g);
        const auto& L1 = byZ[u_union]; const auto& L2 = byZ[0];
        std::set<std::array<uint32_t, 4>> local_tuples;
        for (uint32_t a : L1) for (uint32_t b : L2) {
            uint32_t prodF = (a & b) & mHcF;
            for (int w = 0; w <= (R_max - 6 - m2Z); w += 2) {
                for (uint32_t e : f_errs[w]) {
                    int need_rad = 1 ^ xZ ^ xor5_mask(e);
                    auto it = byF.find(prodF ^ e); if (it == byF.end()) continue;
                    for (uint32_t p0 : it->second) {
                        uint32_t p1 = p0 ^ a, p2 = p0 ^ b, p3 = p0 ^ a ^ b ^ mHcF;
                        int rx = rad_map.at(p0) ^ rad_map.at(p1) ^ rad_map.at(p2) ^ rad_map.at(p3);
                        if (rx != need_rad) continue;
                        std::array<uint32_t, 4> t{p0, p1, p2, p3};
                        std::sort(t.begin(), t.end());
                        local_tuples.insert(t);
                    }
                }
            }
        }
        std::set<std::array<uint32_t, 4>> visT;
        for (const auto& t : local_tuples) {
            if (visT.count(t)) continue;
            std::vector<Perm32> stabT;
            for (const auto& g : stabU) {
                std::array<uint32_t, 4> nx{app32(t[0], g), app32(t[1], g), app32(t[2], g), app32(t[3], g)};
                std::sort(nx.begin(), nx.end());
                visT.insert(nx);
                if (nx == t) stabT.push_back(g);
            }
            uint32_t a = t[1] ^ t[0], b = t[2] ^ t[0];
            uint32_t oddF = (t[0] ^ (a & b)) & mHcF;
            uint32_t Z1 = mHcZ & t[0] & t[1] & t[2] & t[3];
            uint32_t Z0 = mHcZ & ~(t[0] | t[1] | t[2] | t[3]);
            uint32_t evenF = mHcF & ~oddF;
            int remR = R_max - m2Z - __builtin_popcount(oddF);
            uint8_t rx = rad_map.at(t[0]) ^ rad_map.at(t[1]) ^ rad_map.at(t[2]) ^ rad_map.at(t[3]);

            auto cfgs_rh2 = enum_Hc_orbits(remR - 2, Z0, oddF, evenF, stabT);
            auto cfgs_rh4 = enum_Hc_orbits(remR - 4, Z0, oddF, evenF, stabT);
            std::cout << "  " << name << " orb#" << orb_id << " (remR=" << remR << ", |StabT|=" << stabT.size()
                      << "): RH=2 has " << cfgs_rh2.size() << " Hc-orbits; RH=4 has " << cfgs_rh4.size() << " Hc-orbits\n";
            for (const auto& c : cfgs_rh2) jobs.push_back({orb_id, remR, 2, remR - 2, t, u_union, oddF, Z1, Z0, rx, c});
            for (const auto& c : cfgs_rh4) jobs.push_back({orb_id, remR, 4, remR - 4, t, u_union, oddF, Z1, Z0, rx, c});
            orb_id++;
        }
    }
    std::cout << "=== " << name << ": running ALL " << jobs.size() << " (RH=2 & RH=4) Stab(T)-orbit jobs ===\n" << std::flush;

    auto t0 = std::chrono::steady_clock::now();
    std::atomic<size_t> ni{0};
    std::atomic<long long> h_rh2{0}, h_rh4{0}, n_empty{0};
    std::mutex mu;

    std::vector<std::thread> ths;
    for (int ti = 0; ti < 8; ++ti) ths.emplace_back([&]() {
        while (true) {
            size_t idx = ni.fetch_add(1); if (idx >= jobs.size()) break;
            const auto& jb = jobs[idx];
            uint32_t Z0_act = jb.Z0 ^ jb.cfg.m4;
            uint32_t k1_act = jb.oddF ^ jb.cfg.k3;
            uint32_t track_s = Z0_act | jb.cfg.k2;
            std::array<Opts32, 4> os4;
            std::array<int, 4> ko{0, 1, 2, 3};
            for (int k = 0; k < 4; ++k)
                os4[k] = make_opt_s(is_H1, jb.t[k], jb.u_union, jb.oddF, jb.cfg.m4, jb.cfg.k3, jb.cfg.k2, jb.cfg.k4);
            std::sort(ko.begin(), ko.end(), [&](int a, int b){ return opt_cost(os4[a]) < opt_cost(os4[b]); });

            HcData hc[4];
            bool ok = true;
            for (int k : ko) {
                collect_Hc_S(os4[k], track_s, hc[k]);
                if (hc[k].minE.empty()) { ok = false; break; }
            }
            if (!ok) { n_empty.fetch_add(1); continue; }
            if (jb.RH == 2) {
                long long h = solve_RH2_one_Hc(is_H1, H_pts, mHZ, jb.t, jb.rad_xor, jb.Z1, track_s, k1_act, hc);
                if (h) { h_rh2.fetch_add(h); std::lock_guard<std::mutex> lk(mu); std::cout << "  [HIT RH2!] orb=" << jb.orb_id << " h=" << h << "\n" << std::flush; }
            } else {
                long long h = solve_RH4_one_Hc(is_H1, H_pts, mHZ, mHF, HF_pts, jb.t, jb.rad_xor, jb.Z1, track_s, k1_act, hc);
                if (h) { h_rh4.fetch_add(h); std::lock_guard<std::mutex> lk(mu); std::cout << "  [HIT RH4!] orb=" << jb.orb_id << " h=" << h << "\n" << std::flush; }
            }
        }
    });
    for (auto& th : ths) th.join();
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::cout << "  RESULT " << name << " (remR>=6, RH in {2,4}) in " << dt << "s: jobs=" << jobs.size()
              << " hc_empty=" << n_empty.load() << " HITS_RH2=" << h_rh2.load() << " HITS_RH4=" << h_rh4.load() << "\n" << std::flush;
}

int main() {
    init_Q();
    uint32_t mons[16]; int mk = 0;
    for (int m = 0; m < 32; ++m) if (__builtin_popcount(m) <= 2) {
        uint32_t mask = 0;
        for (int i = 0; i < 32; ++i) if ((i & m) == m) mask |= (1u << i);
        mons[mk++] = mask;
    }
    std::vector<uint32_t> all_q(65536, 0);
    for (int s = 1; s < 65536; ++s) all_q[s] = all_q[s - 1] ^ mons[__builtin_ctz(s)];
    std::unordered_map<uint32_t, uint8_t> rad_map;
    for (uint32_t p : all_q) rad_map[p] = rad5_of(p);

    solve_case("Case II (H_0)", 0, 6, all_q, rad_map);
    solve_case("Case III (H_1)", 1, 8, all_q, rad_map);
    return 0;
}
