# Universal Proof That $t = 118$ Is Impossible for Balanced $N = 9, \mathrm{nl} = 242$

**New Universal Range (extending `Balanced242Endpoint.lean`):**
$$64 \le t \le 116,\qquad t \equiv 0 \pmod 2,\qquad N_{28} \ge 108.$$

*(At $t = 116$, the high-block identity $8t + 3N_{28} = 1248 + 2N_{12} + 3N_4$ gives $3N_{28} = 320 + 2N_{12} + 3N_4$. $N_{28} = 106$ gives $318 < 320$, and $N_{28} = 107$ forces $2N_{12} + 3N_4 = 1$, impossible in $\mathbb{N}$; hence $N_{28} \ge 108$.)*

---

## Proof Outline (Ready for Lean 4.15.0 Formalization)

Assume a balanced 9-variable Boolean function with nonlinearity $242$ has $t = 118$ agreement sites in support-XOR coordinates ($\mathrm{suppXor}(A) = 0$, $\sum V = 0$, $|\mathrm{lo}| \le 24$, $|\mathrm{hi}| \le 28$).

### Step 1: Canonicalize the Forced $m = 4$ Half-Space
By `Balanced242Endpoint.lean` (`large_support_counts`, `four_mask_at_118`):
- $Z = \{a : 16 \mid \mathrm{lo}(a)\}$ is a linear 6-flat $\{a : a \cdot d_1 = 0,\, a \cdot d_2 = 0\}$,
- $n_0 + 2n_8 = 24$ with $n_0 \ge 8$ and $n_8 \le 8$,
- One nonzero annihilator $d_1$ has $m(d_1) = 4$ masks of $|\mathrm{lo}| = 8$ and $124$ masks of $|\mathrm{lo}| = 24$ on $a \cdot d_1 = 1$,
- The other two nonzero annihilators $d_2, d_1 \oplus d_2$ satisfy $m \in \{4, 6, 7, 8\}$.

Apply $L \in \mathrm{GL}(8, 2)$ so $d_1 = 128$ (top bit). Let $m_0, m_1, m_2, m_3$ be the 4 small masks in $\{128,\dots,255\}$ with signs $s_k = \mathrm{sgn}(\mathrm{lo}(m_k)) \in \{\pm 1\}$, and $D(x) = V(0,x) - V(1,x)$ for $x \in \mathbb{F}_2^7$, so $\sum_{x} D(x)^2 = 144 - 4 = 140$ and $D(x) + T(x) \equiv 0 \pmod 3$.

- **Affinely dependent ($m_0 \oplus m_1 \oplus m_2 \oplus m_3 = 0$):**
  - If $\prod s_k = +1$: $|T| = 4$ on $32$ inputs and $T = 0$ on $96$, so $\sum D^2 \le 32 \cdot 4 = 128 < 140$.
  - If $\prod s_k = -1$: $|T| = 2$ on all $128$ inputs, so $|D| \in \{1,2\}$ everywhere; $128 + 3k_2 = 140 \Rightarrow k_2 = 4, k_1 = 124 \Rightarrow t \ge k_1 + 2k_2 = 132 > 118$.
- **Affinely independent:** $\{m_0, m_1, m_2, m_3\}$ are 4 linearly independent vectors in $\mathbb{F}_2^8$ with top bit 1. By $\mathrm{GL}(7, 2)$ on the low 7 bits, put them at $128 + \{0, 16, 32, 64\}$. Since $t = 118$ is even, input translation $u \mapsto u \oplus c$ preserves $\mathrm{suppXor}(A) = 0$ and sets all four signs to $+1$.

### Step 2: Complete Classification of $D(y, z)$ on $\mathbb{F}_2^3 \times \mathbb{F}_2^4$
Write $x = (y, z) \in \mathbb{F}_2^3 \times \mathbb{F}_2^4$. From $D + T \equiv 0 \pmod 3$:
- $D(y, z) = 0$ for $y \in \{3, 5, 6\}$ (all 48 zero-difference sites `pos0`),
- $D(y, z) = \eta_y (1 - 3 f_y(z))$ for $y \in \{0, 1, 2, 4, 7\}$ with $\eta = (-, +, +, +, -)$ and $f_y : \mathbb{F}_2^4 \to \{0, 1\}$.

1. **Row weights ($b = 0$):** Inverting the 3-bit transform $(4, 4, 4, \pm 12, 4, \pm 12, \pm 12, \pm 12)$ subject to vanishing on $\{3, 5, 6\}$ and $\sum w_y = 20$ (from $80 + 3\sum w_y = 140$) gives the **unique** solution $w_0 = w_1 = w_2 = w_4 = w_7 = 4$.
2. **Nonzero inner frequencies ($b \in \mathbb{F}_2^4 \setminus \{0\}$):** $|\widehat{2D}(a, b)| = 24$ for all $a \in \mathbb{F}_2^3$ forces $|\mathrm{FWHT}_3(\eta_y \widehat{f_y}(b))[a]| = 4$ for all $a$. By Parseval, $\sum_y \widehat{f_y}(b)^2 = 16$. Since each $\widehat{f_y}(b)$ is even ($w_y = 4$), the vector $(\eta_y \widehat{f_y}(b))$ on $\{0, 1, 2, 4, 7\}$ has either one entry $\pm 4$ and four $0$s, or four entries $\pm 2$ on the unique 2-flat $\{1, 2, 4, 7\}$ with $\widehat{f_0}(b) = 0$.
3. **Three universal consequences:**
   - **(i) $f_0$ is ALWAYS an affine 2-plane** ($\widehat{f_0}(b) \in \{0, \pm 4\}$ on all $b \neq 0$, $w_0 = 4$).
   - **(ii) Universal autocorrelation identity:** For every $d_2 \in \{1,\dots,15\}$,
     $$2 p_{22}(d_2) = \sum_y |f_y \cap (f_y \oplus d_2)| = \frac{1}{16}\Bigl(5\cdot 16 + \sum_{b\ne 0} 16(-1)^{b\cdot d_2}\Bigr) = 4 \implies p_{22}(d_2) = 2.$$
   - **(iii) Exact Family A / Family B dichotomy:** Either all four $\{f_1, f_2, f_4, f_7\}$ are affine 2-planes completing an affine 5-plane spread (**Family A**, 256 shifts, $|f_y \cap (f_{y'} \oplus z_0)| \le 1$), or all four are dim-3 weight-4 sets sharing the 8 frequencies outside a hyperplane $H \supset P_0^\perp$ at $\pm 2$ and taking the 4 distinct frequencies $n_1, n_2, n_4, n_7 \in H \setminus P_0^\perp$ at $\pm 4$ (**Family B**, 4,096 instances, $|f_y \cap (f_{y'} \oplus z_0)| \le 2$).

### Step 3: Simultaneous Elimination of All Four Orbits of $d_2 = (y_d, z_0) \in \mathbb{F}_2^7 \setminus \{0\}$
Let $c_{01} = \#\{a < 128 : a \cdot d_2 = 1,\, |\mathrm{lo}(a)| = 8\} = n_8 - 4 \le 4$, $T_{\mathrm{out}}$ be the signed sum of those $c_{01}$ characters, and $Z_T = \{p \in \mathbb{F}_2^6 : T_{\mathrm{out}}(p) \equiv 0 \pmod 3\}$. The number of occupied `pos0` sites must be exactly $\mathrm{occ}_0 = 9$.

1. **Orbit 1 ($y_d = 0$, $15$ dirs, $c_{01} = 4$, $m(d_2) = 4$):**
   - Since $p_{22} = 2$ universally, $n_{12} = 16$.
   - Dependent $T_{\mathrm{out}}$: either $|Z_T| = 0$ (contradicts $p_{22} = 2$) or $|Z_T^c| = 16$ (forces $Z_T^c$ = the 16 $(1,2)$ pairs, giving $\sum T^2 = 16 \neq 136$).
   - Independent $T_{\mathrm{out}}$: $|Z_T| = 24$ (3 cosets of a 3-subspace $K \subset \mathbb{F}_2^6$, $|Z_T^c| = 40$). Then $\sum T^2 = 112 + 12 k_2 = 136 \Rightarrow k_2 = 2$, and $\mathrm{occ}_0 = k_{00} + k_2 + 2z_2 = 9 \Rightarrow k_{00} = 7 - 2z_2 \in \{1, 3, 5, 7\}$ (odd and $\le 7$).
   - Exhaustively over every 3-subspace $K \subset \mathbb{F}_2^6$ and every 2-flat-minus-1-point coset union, $k_{00} = 24 - |Z_T \cap (\{3,5,6\}\times\mathbb{F}_2^3)| \in \{0, 4, 6, 8, 12, 14, 15, 16, 18, 20, 24\}$ — **never in $\{1, 3, 5, 7\}$**. Contradiction.

2. **Orbits 2 & 3 ($y_d \in \{1, 2, 4\}$ or $y_d = 7$, $64$ dirs, $c_{01} = 3$):**
   - $Z_T = \{|T_{\mathrm{out}}| = 3\}$ is an affine 4-flat of size 16 in $\mathbb{F}_2^6$.
   - Across the three rows pairing `pos0` with $\{f_a, f_b, f_c\}$ ($\{2,4,7\}$ for $y_d=1$, $\{1,2,4\}$ for $y_d=7$), the simultaneous mod-3 equations on $e_1 = d_2$ and $e_2 = 128 \oplus d_2$ force $\mathrm{occ}_0 \ge |(Z_T \cap \text{3 rows}) \triangle (f_a \cup f_b \cup f_c)|$.
   - Row split $(16,0,0,0)$ gives $\ge 12$; $(8,8,0,0)$ gives $\ge 4+4+4 = 12$; $(4,4,4,4)$ gives parallel 2-planes $P + c_y$ in each row, yielding $\ge 0 + 6 + 6 = 12$ in Family A (disjoint planes) and $\ge 2 + 4 + 4 = 10$ in Family B (since $\dim(P^\perp \cap H) \ge 1$ hits at most one of the three disjoint $n_y$, leaving $\ge 4$ symmetric difference on the other two and $\ge 2$ on the third). Always $\mathrm{occ}_0 \ge 10 > 9$. Contradiction.

3. **Orbit 4 ($y_d \in \{3, 5, 6\}$, $48$ dirs, $c_{01} = 2$, $m = (4,4)$):**
   - $Z_T$ is an affine 5-flat of size 32. Neither non-`pos0` row can have $|Z_T| = 16$ because $|f_y \cap (f_{y'} \oplus z_0)| \le 2 < 4$ leaves $(2,1)$ pairs requiring $T_{\mathrm{out}} \not\equiv 0 \pmod 3$.
   - Split $(16, 0, 0, 16)$ forces $\mathrm{occ}_0 \ge 16 - 4 = 12 > 9$ on the $(0, y_d)$ row; split $(8, 8, 8, 8)$ forces $\mathrm{occ}_0 \ge (16 - 8) + (8 - 4) = 12 > 9$. Contradiction.

4. **Orbit 5 ($y_d \in \{3, 5, 6\}$, $48$ dirs, $c_{01} = 4$, $m = (6,6)$):**
   - Dependent $\prod s = -1$: $|Z_T| = 0 \Rightarrow \mathrm{occ}_0 \ge 16 > 9$.
   - Dependent $\prod s = +1$: $|Z_T^c| = 16$ (4-flat) hits both non-`pos0` rows in $\ge 4$ points each, forcing split $(0, 8, 8, 0)$ ($\mathrm{occ}_0 \ge 12 > 9$) or $(4, 4, 4, 4)$ ($\mathrm{occ}_0 \ge 4 + 8 = 12 > 9$).
   - Independent ($|Z_T| = 24$, 29 possible row splits $(z_{03}, z_{12}, z_{47}, z_{56})$): exact energy $\sum (D_{e_1}^2 + D_{e_2}^2) = 276$ combined with $\mathrm{occ}_0 \le 9$ and $p_{22} \le 4$ leaves **only one** arithmetic solution across all 29 splits: $(z_{03}, z_{12}, z_{47}, z_{56}) = (8, 0, 0, 16)$ with $a = |Z_T(0, y_d) \cap f_0| = 3$. However, for split $(8, 0, 0, 16)$, $Z_T(0, y_d)$ is a single affine 3-flat (size 8), whose intersection with the affine 2-plane $f_0$ (size 4) can only have size $0, 2,$ or $4$ — **never $3$**. Contradiction. $\blacksquare$

---

## Machine Cross-Checks
- `verify_spread_t118_all127.c`: Exhaustively verified **0 survivors across all 175 $(d_2, c_{01})$ cases covering all 127 directions** on `Balanced242Spread.lean` in 2.89s.
- `scan_affine_spreads.c`: Verified **0 survivors** across all 256 affine shifts for $c_{01}=2$ and across 5 diverse shifted Family A spreads over all 127 directions.
- `scan_family_b.c`: Verified **0 survivors** across 4 diverse Family B instances over all 127 directions.
