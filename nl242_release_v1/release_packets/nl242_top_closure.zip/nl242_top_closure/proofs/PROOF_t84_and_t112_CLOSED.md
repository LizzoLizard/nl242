# Closing `t = 84` and `t = 112` in the Balanced 9-Variable `nl = 242` Problem

Two more agreement counts are excluded — one from each end of the remaining window — reducing the open problem from **15** even agreement counts (`84 ≤ t ≤ 112`) to **13** even agreement counts:

$$
\boxed{86 \le t \le 110, \qquad t \equiv 0 \pmod 2, \qquad 126 \le N_{28} \le 211.}
$$

All proofs below are independently verified offline by zero-dependency pure-integer Python scripts (`verify_t84_closed.py`, `verify_t112_closed.py`) and exact C++ enumeration (`check_d80_sections.cpp`).

---

## 1. Closing `t = 84` (High Block: `MIN_HALF_MASS = 88`)

Building directly on `nl242-lab/check_high_sections.cpp` (which proved no 7-variable high Walsh section exists with deficit $M \le 72$ or $e \le 18$ exceptions) and $8 \mid M$, it suffices to exclude all 20 integer profiles $(a, b, c)$ satisfying
$$
6a + 3b + 5c = 80, \qquad e = a + b + c \ge 19.
$$
For all 20 profiles, $T_7 = -896 + 8a + 12b + 4c \le -592 < -512$, so the quadratic high phase $q$ cannot have polar rank $\le 4$ (which forces $|T_7| \le 512$); hence $q$ has **polar rank 6**, with $\widehat{q} = 16\sigma$ on a 64-point affine flat $R$ ($\sigma$ a 6-variable bent function).

### 1.1 Exact Symplectic-Parity Phase Bound (extends `excluded_by_phase` to all $k \ge 4$)
On $R$, $D(x)\sigma(x) \ge -1 + [J(x)]_3$ where $J = \sum_{i=1}^k c_i \eta_i$, $k = a+c$, $c_i = -1$ for weight 1 ($a$ terms) and $+1$ for weight 3 ($c$ terms), and $\eta_i = q(a_i)\chi_{a_i}\sigma$.

Because $f(x_1,\dots,x_k) = [x_1 + \dots + x_k]_3$ is an **odd** symmetric function on $\{-1,+1\}^k$, its Fourier expansion contains **only odd-degree terms**:
$$
[J]_3 = \sum_{\substack{1 \le d \le k \\ d\text{ odd}}} \widehat{f}(d) \sum_{|S|=d} \prod_{i \in S} (c_i \eta_i).
$$
Since $\widehat{q} = 16\sigma$ on $R$, Walsh inversion on $\mathbb{F}_2^7$ gives $\sum_{x \in R} \chi_u(x)\sigma(x) = +8q(u)$. For any odd subset $S$, $\sigma^{|S|} = \sigma$, so
$$
\sum_{x \in R} \prod_{i \in S} \eta_i(x) = 8 \left(\prod_{i \in S} q(a_i)\right) q\!\left(\bigoplus_{i \in S} a_i\right) = +8 \cdot (-1)^{\sum_{i < j \in S} B(a_i, a_j)},
$$
where $B(u,v) = Q(u \oplus v) + Q(u) + Q(v) + Q(0) \in \mathbb{F}_2$ is the symplectic bilinear form of $q = (-1)^Q$ (the constant term $Q(0)$ cancels because $|S|+1$ is even, and the identity holds identically even if two frequencies satisfy $a_i = a_j \oplus r^*$).

Minimizing over all $2^{\binom{k}{2}}$ symmetric zero-diagonal binary matrices $B$ in exact scaled integer arithmetic (`verify_t84_closed.py`) strictly excludes **8 of the 20 profiles**:
- `e=26 (0,25,1) k=1`: $T_7/8 = -74 < -56$
- `e=25 (1,23,1) k=2`: $T_7/8 = -76 < -64$
- `e=24 (2,21,1) k=3`: $T_7/8 = -78 < -72$
- `e=23 (3,19,1) k=4`: $T_7/8 = -80 < -68$
- `e=23 (1,18,4) k=5`: $T_7/8 = -82 < -76$
- `e=22 (4,17,1) k=5`: $T_7/8 = -82 < -76$
- `e=22 (0,15,7) k=7`: $T_7/8 = -86 < -80$
- `e=21 (5,15,1) k=6`: $T_7/8 = -84 < -78$

### 1.2 Exact `W_6(D|_R)` Walsh-Peak Bound at Boundary Equality (2 profiles)
Two further profiles hit exact equality $T_7/8 = \mathrm{exactLB}$:
- **`e=24 (0,20,4) k=4`** ($T_7/8 = -80$), and
- **`e=22 (2,16,4) k=6`** ($T_7/8 = -84$, attained by 128 matrices $B$ of ranks 4 and 6).

At equality, $D(x) = \sigma(x)(-1 + [J(x)]_3)$ identically on all 64 points of $R$. Multiplying the odd-degree expansion by $\sigma$ cancels $\sigma^2 = 1$ and turns every term $S$ into a pure delta spike of height $64\widehat{f}(|S|)\prod_{i\in S} c_i (-1)^{\mathrm{par}(B,S)} q(a_S)$ at frequency $a_S = \bigoplus_{i\in S} a_i$. Since $W_6(D|_R)(a) = H(a) \pm H(a \oplus r^*)$ and $|H| \le 7$, we must have $|W_6(D|_R)(a)| \le 14$ everywhere.

Checking every tight $B$ and every even-weight linear dependency subspace $L \subseteq \ker(B)$ in exact integer arithmetic (`verify_t84_closed.py`) gives:
- `(0,20,4)`: $\min \max |W_6(D|_R)| = 32 > 14$ — **excluded**.
- `(2,16,4)`: $\min \max |W_6(D|_R)| = 26 > 14$ — **excluded**.

### 1.3 Exhaustive C++ Verification of the 10 Remaining `e ≤ 21` Profiles
Running the exact `SectionSearch` engine from `check_high_sections.cpp` on all 10 remaining profiles (`check_d80_sections.cpp`):
- `e=19`: `(1,8,10)` (12 lifts), `(3,9,7)` (0), `(5,10,4)` (0), `(7,11,1)` (0)
- `e=20`: `(0,10,10)` (580 lifts), `(2,11,7)` (0), `(4,12,4)` (130), `(6,13,1)` (2,715)
- `e=21`: `(1,13,7)` (4,365 lifts), `(3,14,4)` (0)

**Total: 7,802 bounded lifts, 0 survivors.**

### 1.4 Parseval Contradiction at `t = 84`
Hence every affine frequency hyperplane has mass $M \ge 88$. At $t = 84$, total mass is $T = 8(84)-480 = 192$, so every non-DC coefficient satisfies $|\widehat{A}(d)| \le 192 - 2(88) = 16$. Since $A^2 \ge 3A$, Parseval gives
$$
110{,}592 = 256(3 \cdot 192) - 192^2 \le \sum_{d \ne 0} \widehat{A}(d)^2 \le 255 \cdot 16^2 = 65{,}280,
$$
contradiction! Thus **`t = 84` is impossible**.

---

## 2. Closing `t = 112` (Low Block Alone: `|Z| = 96, n_8 ≤ 3`)

From `AGREEMENT_RANGE.md` and `Balanced242HighSections.plane_switch`, any balanced 242 table at $t = 112$ has $|Z| = 96$ with polar rank 4, and low Parseval slack
$$
n_0 + 2n_8 = 8 \implies n_8 \in \{0, 1, 2, 3\}, \qquad n_0 = 8 - 2n_8 \in \{8, 6, 4, 2\}.
$$
Up to $\mathrm{GL}(8,2)$ fixing $0 \in Z$, the rank-4 quadratic set $Z$ is unique: it is a union of 6 cosets $S_Z$ (containing $0$) of a 4-dimensional radical $W \subset \mathbb{F}_2^8$, with complement $Z^c$ a union of 10 cosets $S_{Z^c}$. Let $K = W^\perp$ ($|K| = 16$), partitioning input space into 16 cells $x + K$ ($x \in \mathbb{F}_2^4$). On each cell $x$, let $v_x \in \{-1, 0, 1\}^{16}$ be the restriction of $V$, $m(x) = \sum_{y \in K} v_x(y)^2$, and $z_c(x) = \sum_{y \in K} (-1)^{c \cdot y} v_x(y)$.

By 16-point Walsh inversion modulo 3, $z_c(x) \equiv j_c(x) \pmod 3$ on all 10 cosets $c \in S_{Z^c}$, where $j_c(x)$ is the signed sum of the small-mask ($|\widehat{V}| = 4$) characters in $c + W$. Because $H_{16}^2 = 16I \equiv I \pmod 3$, each cell has exactly $3^6 = 729$ possible ternary patterns $v_x$ for fixed $(j_c(x) \bmod 3)_{c \in S_{Z^c}}$, satisfying:
- $\sum_x m(x) = 112$,
- $\sum_x z_c(x)^2 = 144 - 8 c_s$ for each $c \in S_{Z^c}$ with $c_s$ small masks,
- $\sum_x z_c(x) j_c(x) = +4 c_s$,
- $\sum_x z_0(x)^2 \le 60$ (since $\widehat{V}(0) = 0$) and $\sum_x z_s(x)^2 \le 64$ for $s \in S_Z \setminus \{0\}$.

### 2.1 Constant Cell-Parity Lemma (for `n_8 = 2` and `n_8 = 3`)
When $n_8 \in \{2, 3\}$, the total number of zeros across the 6 cosets of $S_Z$ is $n_0 \in \{4, 2\} < 6$. By pigeonhole, some coset $s \in S_Z$ has **no zeros** ($|\widehat{V}(s+w)| = 8$ for all $16$ $w \in W$, i.e. $\widehat{V}(s+w) = 8\varepsilon(w)$). Then
$$
z_s(x) = \frac{1}{2}\sum_{w \in W} \varepsilon(w)(-1)^{w \cdot x} = 8 - \mathrm{wt}(\varepsilon \oplus \ell_x) \equiv \mathrm{wt}(\varepsilon) \pmod 2
$$
is **constant across all 16 cells $x$** (since $\mathrm{wt}(\ell_x) \in \{0,8\}$ is even). Because $m(x) \equiv z_s(x) \pmod 2$, **all 16 cells must have the same parity of $m(x)$** (all even or all odd).

### 2.2 Exhaustive Exclusion of All Four Values `n_8 ∈ {0, 1, 2, 3}` (`verify_t112_closed.py`)
1. **`n_8 = 0` (combinatorial + exact 729-cell table):**
   - Every odd cell has $m \ge 11$ and $z_c^2 = 9$ on all 10 cosets of $S_{Z^c}$; every even cell has $z_c^2 \in \{0, 36, 144\}$. Thus $9r \equiv 144 \pmod{36} \implies 4 \mid r$. $r \ge 12$ gives $m \ge 132 > 112$; $r = 8$ forces 5 cells of $m=10$ ($m \ge 138 > 112$); $r = 4$ forces $30/4 = 7.5$ cells of $m=10$. Hence $r = 0$ (all even cells).
   - With $k$ cells of $m=12$ and $10-k$ of $m=10$, remaining weight $12-2k \in \{0, 6, 8, 12\}$ forces $k \in \{6, 3, 2, 0\}$.
   - **$k = 6$:** The 4 cells of $m=10$ share one 4-subset $P \subset S_{Z^c}$ and must form an affine 2-plane $A_4 \subset \mathbb{F}_2^4$ (by vanishing autocorrelation). All 15 $z_{S_Z}$-admissible mask choices produce a coset $s \in S_Z$ with $\pm 2$ on $A_4$ and $\pm 4$ on a disjoint 3-subset $T$, which never satisfies $|W_4(z_s)| = 8$ everywhere (`0 / 28,160` checked).
   - **$k = 3$:** `0` multisets of 7 supports cover any 7-coset subset $C_7 \subset S_{Z^c}$ 4 times each.
   - **$k = 2$:** `0` valid `(8 x m10, 2 x m12, 1 x m8)` combinations satisfy $z_{S_Z}^2 \le (60, 64, 64, 64, 64, 64)$.
   - **$k = 0$:** 10 cells of $m=10$ + 2 cells of $m=6$ (at $y_1, y_2$, $d = y_1 \oplus y_2 \ne 0$) + 4 cells of $m=0$. On every $s \in S_Z$, orthogonality $\sum_{w \in H_s} W_4(f_{\pm 4})(w) W_4(g_s)(w) = 0$ with every term $\le 0$ forces $W_4(g_s) \equiv 0$ on $H_s$, so $X_{10}$ splits into 5 $d$-pairs. Only one 5-plane double-cover of $S_{Z^c}$ satisfies $k_0 \le 6, k_{1..5} \le 8$, giving $k_s = (0, 8, 8, 8, 8, 8)$. That requires all five 4-subsets of 5 distinct points in $\mathbb{F}_2^3$ to have XOR sum 0, forcing $p_1 = p_2$, contradiction.
2. **`n_8 = 1` (all 10 cosets):** One universal 5-integer Farkas inequality `[-256, 36, 5, -1, 8]` on `(1, m, z_{c_1}^2, sum_{clean} z_c^2, z_{c_1} j_{c_1})` holds $\ge 0$ on all 729 cells and sums to `-648 < 0`.
3. **`n_8 = 2` (Constant Cell-Parity Lemma):**
   - **Subcase 2A (same coset, 10 cosets):** Odd gives $8\cdot 7 + 8\cdot 11 = 144 > 112$. Even is killed by one universal 6-integer Farkas vector `[-128, 0, 72, -5, -5, -8]` (RHS `-144 < 0`).
   - **Subcase 2B (distinct cosets, all 45 pairs × 3 histograms via union):** Odd killed universally by `[-102, 36, -3, -2, 0]`; even certified across all 45 pairs by exact integer Farkas vectors (`t112_farkas_certs.json`).
4. **`n_8 = 3` (Constant Cell-Parity Lemma):**
   - **Partition `(3)` (10 cosets):** Odd gives $4\cdot 11 + 12\cdot 7 = 128 > 112$; even killed universally by `[0, -64, 18, -1, -1, 2]` (RHS `-144 < 0`).
   - **Partition `(2,1)` (all 90 ordered pairs × 3 histograms via union):** Even killed universally by `[-64, -32, 18, -1, -1, 2]`; odd killed universally by `[-254, -190, 36, 1, -1, -8]`.
   - **Partition `(1,1,1)` (all 120 triples × 11 histograms via union):** Even killed universally by `[-48, 18, -1, -1, 2]` or `[-96, 24, -1, -1, 0]`; odd certified across all 120 triples by exact integer Farkas vectors (`t112_farkas_certs.json`).

Hence **`t = 112` is impossible**. Because $t = 112$ was the only remaining agreement count admitting $122 \le N_{28} \le 125$, the universal lower bound on $N_{28}$ also tightens from **122** to **126**.

---

## 3. Reproducible Verification Files
- `t104_plus/verify_t84_closed.py`
- `t104_plus/check_d80_sections.cpp`
- `t104_plus/verify_t112_closed.py`
- `t104_plus/t112_farkas_certs.json`
- `mid_window_exact_cap_packet.json` (repository root, not in this packet) (verified balanced 512-bit exact-cap tables at `t = 84` and `t = 86`)
