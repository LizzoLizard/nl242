# Complete Proof That `t = 102` Is Impossible for Balanced 9-Variable `NL = 242` Boolean Functions

## Theorem
No balanced 9-variable Boolean function $F : \mathbb{F}_2^9 \to \mathbb{F}_2$ with nonlinearity $\mathrm{NL}(F) = 242$ ($\max_a |W_F(a)| = 28$) has agreement count $t = 102$.

Together with prior closures of $t \le 92$ and $t \ge 104$, this reduces the remaining open agreement counts of the balanced 9-variable $\mathrm{NL} = 242$ problem to $t \in \{94, 96, 98, 100\}$.

---

## Complete Case Decomposition at `t = 102`

Let $V, U : \mathbb{F}_2^8 \to \{-1, 0, +1\}$ be the disjoint low and high blocks in adapted coordinates ($\mathrm{wt}(V) = t = 102$, $\mathrm{wt}(U) = 256 - t = 154$, $\mathrm{lo} = 2\widehat V$, $\mathrm{hi} = 2\widehat U = 4H$, $|\mathrm{lo}| \in \{0, 8, 16, 24\}$, $|\mathrm{hi}| \in \{4, 12, 20, 28\}$). Let $q(a) = (-1)^{(\mathrm{hi}(a) - 4)/8} = \pm\chi_b(a)(-1)^{\mathrm{lo}(a)/8}$ be the coupled quadratic phase of polar rank $r \in \{0, 2, 4, 6, 8\}$, and $Z = \{a : 16 \mid \mathrm{lo}(a)\}$.

By Parseval on $\widehat V / 4$, the low-block defect budget is
$$|D| := n_0 + 2 n_8 = \frac{2304 - 5|Z| - 16t}{4} = \frac{672 - 5|Z|}{4},$$
where $n_0 = \#\{a : \mathrm{lo}(a) = 0\}$ and $n_8 = \#\{a : |\mathrm{lo}(a)| = 8\}$.

| Phase rank $r$ | Allowed $\|Z\|$ | $\|D\| = n_0 + 2 n_8$ | Status & Exact Verifier |
|---|---|---|---|
| $r = 0, 2, 4$ | $64, 96, 128, 160, 192, 256$ | — | **CLOSED** (`verify_k2_sections.py`; 0 open $r \le 4$ systems in `nl242-lab/t94/open2_t102.json`) |
| $r = 8$ | $136$ | $-2 < 0$ | **CLOSED** (negative defect budget) |
| $r = 8$ | $120$ | $18$ | **CLOSED** ([verify_t102_r8_closed.cpp](../t102/verify_t102_r8_closed.cpp), `22.86s`, 0 warnings, exit `0`) |
| $r = 6$ | $144$ | $-12 < 0$ | **CLOSED** (negative defect budget) |
| $r = 6$ | $128$ | $8$ | **CLOSED** ([verify_t102_z128_closed.py](../t102/verify_t102_z128_closed.py), pure algebraic + exact integer check) |
| $r = 6$ | $112$ | $28$ | **CLOSED** (4-slice decomposition + Mod-16 Radical Separation + Mod-3 Coupled Cell Bound, detailed below) |

---

## Proof of `(t = 102, r = 6, |Z| = 112)`

In adapted rank-6 coordinates on $\mathbb{F}_2^2 \times \mathbb{F}_2^6$, $Q(a, c) = Q_6(c)$ where $|Z_6| = |\{Q_6 = 0\}| = 28$ and $|F_6| = |\{Q_6 = 1\}| = 36$, so $|Z| = 4 \cdot 28 = 112$ and $|D| = 28$. Let $v_x : \mathbb{F}_2^6 \to \{-1, 0, +1\}$ ($x \in \mathbb{F}_2^2$) be the four 64-point cells of $V$ and $z_x(c) = \widehat{v_x}(c)$, so $\widehat V(a, c) = \sum_{x} (-1)^{a \cdot x} z_x(c)$.

Since $4 z_x(c) = \sum_a (-1)^{a \cdot x} \widehat V(a, c)$ and $\widehat V(a, c) \equiv 4 Q_6(c) \pmod 8$, every $z_x(c)$ is even and satisfies
$$z_x(c) \equiv 2\beta(c) \pmod 4 \quad \text{for all } x \in \mathbb{F}_2^2,$$
with a single common affine linear function $\beta \in \mathrm{RM}(1, 6)$ (since $(z_x(c) - z_x(0))/2 \equiv c \cdot \bigoplus \mathrm{supp}(v_x) \pmod 2$). Under $\mathrm{Aut}(Q_6)$, the 128 affine functions in $\mathrm{RM}(1, 6)$ split into exactly four orbits: $\beta \equiv 1$, $\beta \equiv 0$, $\beta = \mathbf{1}_{H_0}$ ($|H_0 \cap Z_6| = 16$, $|H_0 \cap F_6| = 16$, 63 hyperplanes), and $\beta = \mathbf{1}_{H_1}$ ($|H_1 \cap Z_6| = 12$, $|H_1 \cap F_6| = 20$, 63 hyperplanes).

### 1. Case $\beta \equiv 1$: CLOSED
Every $c \in Z_6$ has $d_c \in \{1, 3\}$, so $\sum_{Z_6} d_c \ge 28$ saturates the budget $|D| = 28$, forcing $d_c = 1$ on all of $Z_6$ and $k_c = 0$ on all of $F_6$. Thus $z_x(c) = 6(-1)^{1 \oplus p_x(c)}$ on $F_6$ and $z_x(c) \in \{2(-1)^{p_x(c)}, 6(-1)^{1 \oplus p_x(c)}\}$ on $Z_6$, with $s_0 + s_1 + s_2 + s_3 = 28$ where $s_x = \#\{c \in Z_6 : |z_x(c)| = 6\}$. Exhaustive exact 32+32 half-join over **all $32,768$ quadratic forms** $p \in \mathrm{RM}(2,6)/\mathrm{RM}(1,6)$ ([verify_t102_z112_beta1.cpp](../t102/z112/verify_t102_z112_beta1.cpp), `0.70s`) proves $\max s_x = 4$, so $\sum s_x \le 16 < 28$.

### 2. Case $\beta \equiv 0$: CLOSED
Every $z_x(c) \equiv 0 \pmod 4$, so $p_x(c) = (z_x(c)/4) \bmod 2 \in \mathrm{RM}(2, 6)$ satisfies $p_0 \oplus p_1 \oplus p_2 \oplus p_3 = Q_6$. Exhaustive exact 4-slice joins across all $\dim(U) \in \{0, 1, 2\}$ and all $(n_0, n_8)$ in `t102/z112/` (`fast_b0_n80.cpp`, `check_orb24.cpp`, `probe_b0_dim2_n80.cpp`, `join_b0_dim1_w6810.cpp`, `check_b0_dim1_1abc_fast.cpp`, `check_b0_dim1_1d.cpp`, `resolve_1d_alerts.cpp`, `resolve_1d_alerts2.cpp`, `join_b0_dim2_t102.cpp`, `join_b0_dim2_extra.cpp`) return **0 solutions**.

### 3. Case $\beta = \mathbf{1}_H$ ($H \in \{H_0, H_1\}$): CLOSED (Low-Block Exhaustion + Mod-3 Coupled Cell Bound)

On $H$, $z_x(c) \equiv 2 \pmod 4$ and $p_x(c) = ((z_x(c)-2)/4) \bmod 2 \in \mathrm{RM}(2,5)$. Subtracting the mandatory $|H \cap Z_6|$ zeros from $|D| = 28$ leaves residual half-budget $R_{\max} = 6$ on $H_0$ (Case II) and $R_{\max} = 8$ on $H_1$ (Case III).

**Mod-16 Radical Separation Law** (verified on all $65,536$ words of $\mathrm{RM}(2,5)$ in [count_beta1H_rad.cpp](../t102/z112/count_beta1H_rad.cpp)):
For any $t : \mathbb{F}_2^5 \to \mathbb{Z}$ with $z(c) = \widehat t(c) \equiv 2 + 4p(c) + 8q(c) \pmod{16}$, setting $S_2 = \{c : |z(c)| = 2\}$ gives $p + 2q \equiv 2 - 2\mathbf{1}_{S_2} - p \pmod 4$, which forces $|S_2|$ even and $\bigoplus S_2 = \mathrm{rad}(p)$. Consequently:
$$\bigoplus R|_H = \mathrm{rad}_\oplus := \bigoplus_{x=0}^3 \mathrm{rad}(p_x), \qquad \bigoplus R|_{H^c} = 1 \oplus \mathrm{rad}_\oplus,$$
with both $|R|_H|$ and $|R|_{H^c}|$ even.

Under $\mathrm{Stab}_{\mathrm{Aut}(Q_6)}(H)$, all admissible 4-tuples $(p_0, p_1, p_2, p_3)$ on $H^c$ classify into exactly **$1,016$ Case II ($H_0$) orbits** and **$1,968$ Case III ($H_1$) orbits** (`2,984` total, [count_exact_orbits_1H.cpp](../t102/z112/count_exact_orbits_1H.cpp)):

| Subcase | Case II ($H_0$) orbits | Case III ($H_1$) orbits | Exact Solver | Result |
|---|---:|---:|---|---|
| $\mathrm{rem}R = 0$ ($R_H = 0$) | $750$ | $950$ | `solve_1H_remR0.cpp` | **0 hits** |
| $\mathrm{rem}R = 2$, $\mathrm{rad}_\oplus \ne 0$ ($R_H = 2$) | $224$ | $894$ | `solve_1H_remR2_radnz.cpp` | **0 hits** |
| $\mathrm{rem}R = 2$, $\mathrm{rad}_\oplus = 0$ ($R_H \in \{0, 2\}$) | $9$ | $60$ | `solve_1H_r2z0_r4_RH02_q16.cpp` | **0 hits** |
| $\mathrm{rem}R = 4$, $R_H \in \{0, 2\}$ | $26$ | $58$ | `solve_1H_r2z0_r4_RH02_q16.cpp` | **0 hits** |
| $\mathrm{rem}R = 4$, $R_H = 4$ ($e_{H^c} = 0$) | $26$ | $58$ | `solve_1H_RH4_exact_SF.cpp` | **0 hits** |
| $\mathrm{rem}R \in \{6, 8\}$, $R_H = 0$ | $7$ | $6$ | `check_final13_RH0.cpp` | **Impossible** ($\mathrm{rad}_\oplus \ne 0$ on all 13!) |
| $\mathrm{rem}R \in \{6, 8\}$, $R_H \in \{2, 4\}$ | $7$ | $6$ | `solve_final13_RH2_RH4.cpp` | **0 hits** except `H0_orb#1` ($R_H = 4, m_4 = \mathrm{0x40}$): **512 real $V$'s** |
| $\mathrm{rem}R \in \{6, 8\}$, $R_H \in \{6, 8\}$ | $7$ | $6$ | `solve_final13_RH68_fast.cpp` | **0 hits** (with positive control finding all 64 hits on `H0_orb#1` in `0.40s`!) |

### 4. Exact Coupled High-Block Elimination of the 512 Real Low Blocks in `H0_orb#1`

The sole surviving low-block family across all $2,984$ orbits (`H0_orb#1`, $R_H = 4$, $m_4 = \mathrm{0x40}$, $n_0 = 20, n_8 = 4$) yields exactly **512 genuine `t = 102` low blocks $V$** with cell weights $(14, 10, 30, 48)$ (sample in [real_V_t102_orb1.txt](../t102/z112/real_V_t102_orb1.txt)). None extends to a coupled high block $U$:

1. **Global Lower Bound $B = N_4 + N_{12} \ge 12$ at $(t = 102, r = 6)$:**
   - **$B \le 8$ impossible (5-line proof):** If the $B$ small masks lie in an affine hyperplane $W = \{a \cdot v_0 = c_0\}$, then the complementary hyperplane $W^c$ is a $(0, b, 0)$ section. By `Balanced242Plateau.section_0_b_0`, $b = 80$ and $\sum D^2 = (784 - 240)/4 = 136$, where $D(x) = U(x) - (-1)^{c_0} U(x \oplus v_0)$ vanishes off pairs intersecting the 64-point dual flat $R$. If $v_0 \in \mathrm{dir}(R)$, at most 32 pairs meet $R$, giving $\sum D^2 \le 128 < 136$. If $v_0 \notin \mathrm{dir}(R)$, $R$ meets 64 pairs with $|D| = 1$ at $64 - p$ pairs and $|D| = 2$ at $p$ pairs (where $p = \#\{y \in R : U_0(y) s\sigma(y) = -1\}$), giving $64 + 3p = 136 \implies p = 24$, contradicting $2p \le 2t - 168 - B = 36 - B \implies B \le -12$. Hence the $B$ small masks affinely span $\mathbb{F}_2^8$, forcing $B \ge 9$, and $B$ is even at rank 6, so $B \ge 10$.
   - **$B = 10$ impossible:** Exhaustive small-mask geometry check ([check_small_masks_t102.cpp](../t102/z112/check_small_masks_t102.cpp)) gives **0 survivors** at $k = 10$ (4 geometries, 1 zero-count match, 0 survivors). Thus **$B \ge 12$**.

2. **Mod-3 Coupled Cell Bound kills ALL 512 real $V$'s on all 4 cells for $B \ge 12$:**
   On the dual flat cell $R = \{(b_a, y) : y \in \mathbb{F}_2^6\}$ with high-block support $S_{b_a} = \mathbb{F}_2^6 \setminus \mathrm{supp}(v_{b_a})$, the phase identity $\sum_{y \in S_{b_a}} U(b_a, y) s \sigma_0(y \oplus b_c) = -28 - B$ forces $B = |S_{b_a}| - 28 - 2f$, where $f = \#\{y \in S_{b_a} : U(b_a, y) = +s\sigma_0(y \oplus b_c)\}$. Pointwise mod-3 reduction gives
   $$\mathrm{wt}_3\bigl(\widehat{g} \bmod 3\bigr) \le B = |S_{b_a}| - 28 - 2f,$$
   where $g = u_{b_a} + s\sigma_0(\cdot \oplus b_c) \pmod 3$, and $\mathrm{wt}_3(\widehat{g} \bmod 3)$ is strictly invariant under all 64 shifts $b_c$ and both signs $s = \pm 1$. Exhaustive bit-sliced mod-3 checks across all 80 unique shift-canonical cell supports ([check_all512_orb1.cpp](../t102/z112/check_all512_orb1.cpp) and [check_cell1_f7.cpp](../t102/z112/check_cell1_f7.cpp)):
   - Cell 3 ($|S| = 16$): impossible for all $B \ge 0$ ($16 < 28$).
   - Cell 2 ($|S| = 34$): **0 survivors** for all $B \ge 0$ ($f \le 3$).
   - Cell 0 ($|S| = 50$): **0 survivors** for all $B \ge 12$ ($f \le 5$).
   - Cell 1 ($|S| = 54$): **0 survivors** for all $B \ge 12$ ($f \le 6$ in `check_all512_orb1.cpp`, $f = 7$ in `check_cell1_f7.cpp`, `0.57s`, 8/8 killed).

Therefore, **no balanced 9-variable $\mathrm{NL} = 242$ function exists at $t = 102$.** $\square$
