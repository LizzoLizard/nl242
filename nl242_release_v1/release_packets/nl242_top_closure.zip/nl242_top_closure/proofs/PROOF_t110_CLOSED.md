# Closure of Agreement Count `t = 110` for Balanced 9-Variable Boolean Functions of Nonlinearity 242

## Main Theorem

**Theorem.** *No balanced 9-variable Boolean function $f : \mathbb{F}_2^9 \to \mathbb{F}_2$ with nonlinearity $\mathrm{NL}(f) = 242$ (equivalently $\max_a |W_f(a)| \le 28$ in the support-XOR coordinates of `AGREEMENT_RANGE.md`) has agreement count $t = 110$.*

Combined with the previously verified exclusions $t \le 86$ and $t \ge 112$, this narrows the open agreement-count window to the **11 even counts**
$$
88 \le t \le 108, \qquad t \equiv 0 \pmod 2.
$$

**Independence from the covering-radius theorem:** Unlike $t \in \{114, 116\}$, the elimination of $|Z| = 64$ at $t = 110$ does **not** use the Wang–Lou–Wang covering-radius theorem $\rho(1,9) \le 244$. The entire proof rests solely on the low Walsh block `lo` and the elementary 8-dimensional affine-span bound $B \ge 9$ (`AGREEMENT_RANGE.md`), and is machine-verified in **100% pure Python exact integer arithmetic with zero third-party libraries** by [`verify_t110_closed.py`](../t104_plus/verify_t110_closed.py) using [`t110_farkas_certs.json`](../t104_plus/t110_farkas_certs.json).

---

## 1. Reduction to Polar Rank 4 (`|Z| = 96`) and Parseval Slack `n_0 + 2 n_8 = 16`

Let $V \in \{-1, 0, 1\}^{\mathbb{F}_2^8}$ be the signed agreement table ($\operatorname{wt}(V) = t = 110$) and $\mathrm{lo} = 2\widehat{V}$, with quadratic residue set $Z = \{a \in \mathbb{F}_2^8 : 16 \mid \mathrm{lo}(a)\}$. Since $f$ is balanced, $\mathrm{lo}(0) = 0$, so $0 \in Z$ and $n_0 := |\{a \in Z : \mathrm{lo}(a) = 0\}| \ge 1$. On $Z$, $\mathrm{lo}(a) \in \{0, \pm 16\}$; on $Z^c$, $\mathrm{lo}(a) \in \{\pm 8, \pm 24\}$, with $n_8 := |\{a \in Z^c : |\mathrm{lo}(a)| = 8\}|$.

Parseval on $\mathbb{F}_2^8$ gives
$$
256(|Z| - n_0) + 576(256 - |Z|) - 512 n_8 = 1024 \cdot 110
\iff
\tfrac{5}{4}|Z| + (n_0 + 2 n_8) = 136.
$$
Since $n_0 \ge 1$, $|Z| \le \lfloor \frac{4}{5}\cdot 135 \rfloor = 108$. The quadratic support sizes $|Z| = 128 \pm 128/\sqrt{2^r}$ (or $128$) containing $0$ and satisfying $|Z| \le 108$ are only $|Z| = 64$ (polar rank $2$) and $|Z| = 96$ (polar rank $4$).

- **Exclusion of $|Z| = 64$:** By the coupled-phase identity (`AGREEMENT_RANGE.md`),
  $$
  16(2 \cdot 110 - 232 - B) = 64 \sum_{x \in P} U(x)\sigma(x) \implies \sum_{x \in P} U(x)\sigma(x) = -\frac{12 + B}{4}.
  $$
  Since $|P| = 4$, $\left|\sum_{x \in P} U(x)\sigma(x)\right| \le 4$, forcing $B \le 4$, which contradicts $B \ge 9$ (`AGREEMENT_RANGE.md`).

Therefore $|Z| = 96$ and
$$
n_0 + 2 n_8 = 16.
$$
Up to $\mathrm{GL}(8, 2)$ fixing $0$, $Z$ splits uniquely as $Z = S_Z \times \mathbb{F}_2^4$ where
$$
S_Z = \{0, 4, 8, 13, 14, 15\}, \qquad S_Z^c = \{1, 2, 3, 5, 6, 7, 9, 10, 11, 12\}.
$$
For each cell $x \in \mathbb{F}_2^4$, let $v_x(y) = V(x, y) \in \{-1, 0, 1\}$, $m(x) = \sum_{y \in \mathbb{F}_2^4} v_x(y)^2$ (so $\sum_x m(x) = 110$), and $z_a(x) = \sum_{y \in \mathbb{F}_2^4} (-1)^{a \cdot y} v_x(y)$ for each coset $a \in \mathbb{F}_2^4$. Then $\widehat{z_a}(w) = \widehat{V}(a, w) = \mathrm{lo}(a, w)/2$:
- For $s \in S_Z$: $\widehat{z_s}(w) \in \{0, \pm 8\}$ with $n_0(s)$ zeros and $E(s) := \sum_x z_s(x)^2 = 64 - 4 n_0(s)$.
- For $c \in S_Z^c$: $\widehat{z_c}(w) \in \{\pm 4, \pm 12\}$ with $k_c$ entries of $\pm 4$ ($\sum_{c \in S_Z^c} k_c = n_8$) and $E(c) := \sum_x z_c(x)^2 = 144 - 8 k_c$.

Writing $S_c = \{w : |\widehat{z_c}(w)| = 4\}$, $\varepsilon_c(w) = \operatorname{sgn}(\widehat{z_c}(w))$, and $J_c(x) = \sum_{w \in S_c} \varepsilon_c(w)(-1)^{w \cdot x}$, inversion on $\mathbb{F}_2^4$ gives $z_c(x) \equiv J_c(x) \pmod 3$ for all $c \in S_Z^c$ and $\sum_x z_c(x) J_c(x) = 4 k_c$. Hence on every cell $x$, the $3^6 = 729$ choices of $(z_s(x) \bmod 3)_{s \in S_Z}$ determine $v_x \in \{-1, 0, 1\}^{16}$ uniquely.

---

## 2. Structural Theorems

### Lemma 1 (Even-Zeros, Constant Cell-Parity, and No-Pair-of-Zeros)
1. For every $s \in S_Z$, $2 z_s(x) = \sum_{w \notin Z_s} (\pm 1)(-1)^{w \cdot x} \equiv 16 - n_0(s) \pmod 2$, so **$2 \mid n_0(s)$**. In particular $2 \mid n_0$, $n_0 \ge 2$, and $n_8 \in \{0, 1, 2, 3, 4, 5, 6, 7\}$.
2. If $n_0(s) = 0$ for some $s \in S_Z$, writing $\widehat{z_s} = 8(1 - 2 f_s)$ gives $z_s(x) = 8 \delta_{x,0} - \sum_w f_s(w)(-1)^{w \cdot x} \equiv \operatorname{wt}(f_s) \pmod 2$, independent of $x$. Since $m(x) \equiv z_a(x) \pmod 2$ for every $a \in \mathbb{F}_2^4$, **all 16 cells share a single parity** $m(x) \equiv p_f \pmod 2$ ($p_f \in \{0, 1\}$).
3. If $n_0(s) = 2$ with $Z_s = \{u, v\}$ ($u \ne v$), extending the sign function arbitrarily to $u, v$ gives
   $$
   z_s(x) = \tfrac{1}{2}\widehat{s_s}(x) - \tfrac{1}{2}\bigl((-1)^{u \cdot x} + (-1)^{v \cdot x}\bigr).
   $$
   The first term has constant parity in $x$, whereas the second is odd on the affine hyperplane $(u \oplus v)\cdot x = 0$ (8 cells) and even on its complement (8 cells). Thus **$n_0(s) = 2$ forces an exact 8-even / 8-odd affine hyperplane split $(H_p, H_p^c)$**.

**Corollary.** Whenever Constant Cell-Parity holds (automatic for $n_8 \ge 3$ since $n_0 < 12$, and also proved for $n_8 = 0$), **$n_0(s) \ne 2$ for all $s \in S_Z$**; in particular $n_0(0) \ge 4$ and $E(0) \le 48$. At $n_8 = 2$ ($n_0 = 12$), either Constant Cell-Parity holds ($E(0) \le 48$), or **Mixed Parity** holds with $n_0(s) = 2$ ($E(s) = 56$) for all six $s \in S_Z$ and an affine hyperplane parity split $(H_p, H_p^c)$.

### Theorem 2 (The Mod-16 Affine-Parity Theorem)
There is an exact bijection between $S_Z^c$ and the $\binom{5}{3} = 10$ triples of $S_Z \setminus \{0\}$ given by $c = s_1 \oplus s_2 \oplus s_3$. Suppose $s_1, s_2, s_3 \in S_Z \setminus \{0\}$ are all zero-free ($n_0(s_i) = 0$), so Constant Cell-Parity $p_f \in \{0, 1\}$ holds. Then for $c = s_1 \oplus s_2 \oplus s_3$:
1. For each zero-free $s \in S_Z$, $\widehat{z_s} = 8(1 - 2 f_s)$ implies
   $$
   2 z_s(x) = 16 \delta_{x,0} - 2 \sum_{f_s(w)=1} \bigl(1 - 2(w \cdot x)\bigr) \equiv -2 \operatorname{wt}(f_s) + 4 \Bigl(\bigoplus_{f_s(w)=1} w\Bigr) \cdot x \pmod 8,
   $$
   so $b_s(x) := (z_s(x) - p_f)/2 \pmod 2$ is **affine** ($\deg b_s \le 1$).
2. Pointwise on $y \in \mathbb{F}_2^4$, setting $a_i = (-1)^{s_i \cdot y} \in \{\pm 1\}$ gives $a_1 + a_2 + a_3 + a_1 a_2 a_3 = (a_1 + a_2)(1 + a_2 a_3) \equiv 0 \pmod 4$. Summing against $v_x(y)$ yields $4 \mid (z_c + z_{s_1} + z_{s_2} + z_{s_3})$, hence
   $$
   b_c(x) := \frac{z_c(x) - p_f}{2} \bmod 2 = b_{s_1}(x) \oplus b_{s_2}(x) \oplus b_{s_3}(x)
   $$
   is **affine** ($\deg b_c \le 1$). Write $z_c(x) = p_f + 2 A_c(x) + 4 r_c(x)$ with $A_c : \mathbb{F}_2^4 \to \{0, 1\}$ affine and $r_c(x) \in \mathbb{Z}$.
3. Since $\sum_x z_c(x) = \widehat{z_c}(0) \in \{\pm 4, \pm 12\} \equiv 4 \pmod 8$ while $16 p_f \equiv 0 \pmod 8$ and $2 \sum_x A_c(x) \in \{0, 16, 32\} \equiv 0 \pmod 8$, we obtain **$\sum_x r_c(x) \equiv 1 \pmod 2$**.
4. Squaring $z_c(x)$ modulo $16$ and summing over $\mathbb{F}_2^4$:
   - **$p_f = 0$ (EVEN):** $144 - 8 k_c = \sum_x z_c(x)^2 \equiv 4 \sum_x A_c(x) \in \{0, 32, 64\} \equiv 0 \pmod{16} \implies$ **$k_c$ is EVEN**.
     - If $k_c = 0$ (clean), $6 \mid z_c$ and $\sum z_c^2 = 144$ allow at most four values $|z_c| = 6 \equiv 2 \pmod 4$; intersecting with $\operatorname{wt}(A_c) \in \{0, 8, 16\}$ forces **$|z_c| \in \{0, 12\}$ everywhere** (a unique cell with $|z_c| = 12$).
     - If $k_c = 2$, exhaustive check over all $2^{14}$ signings shows only three EVEN patterns exist: `P1 = (0^8; -10, 2^7)`, `P2 = (0^8; -4^3, 2^4, 8)`, and `P3 = (0^6, 6^2; -4^2, 2^6)` (normalizing $J_c = +2$ on $H_1$). Since $\operatorname{wt}(A_c) \in \{0, 8, 16\}$ eliminates `P2` (weight $4$) and $\operatorname{wt}(A_c|_{H_0}) \in \{0, 4, 8\}$ eliminates `P3` (weight $2$), **$k_c = 2$ affine forces `P1`**, in particular a cell with $z_c = -10$ when $J_c = +2$.
   - **$p_f = 1$ (ODD):** $144 - 8 k_c \equiv 16 + 8 \sum_x A_c(x) + 8 \sum_x r_c(x) \equiv 8 \pmod{16} \implies$ **$k_c$ is ODD ($k_c \ge 1$)**.

### Lemma 3 (Affine 2-Plane Hyperplane-Restriction Lemma)
If $s \in S_Z$ has $n_0(s) = 0$ ($|\widehat{z_s}(w)| = 8$ for all $w$) and $|z_s(x)| \in \{0, 4\}$ for all $x \in \mathbb{F}_2^4$, then $T = \operatorname{supp}(z_s)$ has size $4$ and $\sum_{x \in T} \operatorname{sgn}(z_s(x))(-1)^{w \cdot x} = \pm 2$ for every $w \in \mathbb{F}_2^4$. Thus an odd number of the four terms equal $-1$, so $(\prod_{x \in T} \operatorname{sgn}(z_s(x)))(-1)^{w \cdot \bigoplus_{x \in T} x} = -1$ for all $w$. Evaluating at $w = 0$ yields $\bigoplus_{x \in T} x = 0$, so $T$ is an affine 2-plane in $\mathbb{F}_2^4$. Every affine hyperplane $H_0$ intersects $T$ in $0, 2,$ or $4$ points, hence
$$
E_{H_0}(s) := \sum_{x \in H_0} z_s(x)^2 \in \{0, 32, 64\}.
$$

---

## 3. Case-by-Case Closure of All `n_8 ∈ {0, 1, 2, 3, 4, 5, 6, 7}`

All symmetries (`|Aut(SZ)| = 120`, transitive on `SZ\{0}` and `SZc`; `|Stab(4)| = 24`, preserving `A_4 = {9, 10, 11, 12}`), all `J`-histograms for `k ∈ {1,2,3,4}`, all 65,536 zero-free Boolean functions, all `k_c = 2` EVEN/M1 coset patterns, all combinatorial checks, and all 279 pure-integer Farkas certificates are independently verified from scratch in [`verify_t110_closed.py`](../t104_plus/verify_t110_closed.py).

| `n_8` | `n_0` | Proof Method | Exact Outcome |
|---:|---:|---|---|
| **0** | 16 | Pure combinatorics + Mod-16 Affine-Parity (0 LP) | $r = 0$ (all 16 cells even, $n_0(s) \ne 2$). Remaining weight leaves $k \in \{1, 2, 5\}$ cells of $m = 12$: $k = 5$ and $k = 1$ have 0 survivors; all 30 $k = 2$ survivors have 4 zero-free $s \in S_Z \setminus \{0\}$, forcing $\ge 4$ clean $1 \times 12$ cosets ($> 2$). |
| **1** | 14 | 1 universal aggregate Farkas cert | `[-256, 36, 5, -1, 8]` certifies all 10 cosets with $\mathrm{RHS} = -720 < 0$. |
| **2** | 12 | Pure-integer Farkas certs (const & mixed parity) | Constant parity (`E(0) <= 48`): `2A` (2 certs) & `2B` (4 certs) dead. Mixed parity (`E(s)=56`, affine split 8E+8O): `2B` (2 certs), `2A M2/M3` (2 certs) dead; `2A M1` Pattern 3 has 0 cells, Patterns 1 & 2 certified across all `(c_6, k_0)` (50 certs). |
| **3** | 10 | Mod-16 Affine-Parity (ODD) + 7 Farkas certs (EVEN) | $n_0 = 10 < 12$ forces $\ge 4$ zero-free $s \in S_Z \setminus \{0\}$ ($\ge 4$ affine cosets). ODD needs $n_8 \ge 4 > 3$. EVEN `(3)`, `(2,1)`, `(1,1,1)` certified across all `Aut(SZ)` orbits (7 certs). |
| **4** | 8 | Mod-16 Affine-Parity (`4-I`) + Farkas certs (`4-II`) | **`4-I` (`n_0(0)=8`, 5 zero-free, 0 LP):** ODD needs $n_8 \ge 10$; EVEN `(4,)` requires 9 distinct $m = 12$ cells ($108$) with no $m = 2$ cell; EVEN `(2,2)` has 0 cells with $z_{c_1} = -10$ and 8 clean in $\{0, 12\}$. **`4-II` (`n_0(0)=n_0(4)=4`, `A_4={9,10,11,12}` affine):** ODD forced `(1,1,1,1)` on `A_4` (1 cert); EVEN `(4,)`, `(3,1)`, `(2,1,1)`, `(1,1,1,1)` and 3/5 orbits of `(2,2)` (21 certs); remaining `(2,2)` on `(1,2)` & `(1,5)`: `8/8-comp` & `4/4/4/4` (4 certs), `8/8-same` 8 non-`(P2,P2)` pairs (16 certs), `(P2,P2)` sequential `s* ∈ {8,15,13,14}` (8 certs), and `s* = None` where every cell satisfies $|z_s| \in \{0, 4\}$ on $\{8,13,14,15\}$, forcing $E_{H_0}(s) \in \{0, 32, 64\}$ by Lemma 3 (162 certs). |
| **5** | 6 | 1-line Mod-16 Affine-Parity (0 LP) | $n_0(0) = 6$, all 5 $s \in S_Z \setminus \{0\}$ zero-free $\implies$ all 10 cosets affine. ODD needs $n_8 \ge 10 > 5$; EVEN requires $2 \mid n_8$, impossible for $5$. |
| **6** | 4 | Pure Mod-16 Affine-Parity (0 LP) | $n_0(0) = 4$, all 5 $s \in S_Z \setminus \{0\}$ zero-free $\implies$ all 10 cosets affine. ODD needs $n_8 \ge 10 > 6$; EVEN forces `(6,)`, `(4,2)`, `(2,2,2)`. `(6,)` leaves $110 - 108 = 2$ with no $m = 2$ cell; `(4,2)` (all 90 ordered pairs) and `(2,2,2)` (all 120 triples) have 0 cells with $z_c = -10$ and clean cosets in $\{0, 12\}$. |
| **7** | 2 | 1-line No-Pair-of-Zeros (0 LP) | $n_0 = 2 < 12 \implies$ Constant Cell-Parity, contradicting $n_0(0) = 2$. |

---

## 4. Independent Verification

Run with zero third-party dependencies:
```bash
PYTHONDONTWRITEBYTECODE=1 python3 verify_t110_closed.py
```
- Certificate store: [`t110_farkas_certs.json`](../t104_plus/t110_farkas_certs.json) (279 exact integer Farkas certificates, 33.6 KB, $\max |y_i| = 3{,}960{,}495$).
- Generator script: ``gen_t110_farkas_certs.py``.
