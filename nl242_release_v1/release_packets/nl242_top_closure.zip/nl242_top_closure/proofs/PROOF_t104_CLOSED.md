# Proof that Agreement Count $t = 104$ is Impossible (Balanced 9-Variable $\mathrm{NL} = 242$)

**Theorem.** *In the balanced $9$-variable Boolean function problem with $\mathrm{NL} = 242$ (adapted coordinates with low Walsh cap $24$ and high Walsh cap $28$), there is **no** balanced table with agreement count $t = 104$.*

Together with the previously closed ranges ($t \le 92$ and $t \ge 106$), this reduces the entire remaining open window of the 20-year-old problem to just **five even agreement counts**:
$$t \in \{94, 96, 98, 100, 102\}.$$

---

## 1. Reduction to Polar Rank $6$, $|Z| = 112$, $|D| = 20$

Let $V : \mathbb{F}_2^8 \to \{-1, 0, +1\}$ be the low block ($|\mathrm{supp}\,V| = t = 104$, $\widehat{V}(0) = 0$, $|2\widehat{V}(u)| \le 24$), and let $Q(u) = (\widehat{V}(u)/4) \bmod 2$ be its quadratic phase with polar rank $r \in \{0, 2, 4, 6, 8\}$ and zero set $Z = \{u : Q(u) = 0\}$, $z = |Z|$.

By Parseval on the low block, letting $n_0 = \#\{u \in Z : \widehat{V}(u) = 0\} \ge 1$ and $n_8 = \#\{u \notin Z : |2\widehat{V}(u)| = 8\}$, the total defect weight is
$$|D| = n_0 + 2 n_8 = 576 - \frac{5z}{4} - 4t = 160 - \frac{5z}{4}.$$

- **$r = 0$** ($z \in \{128, 256\}$): $|D| \le 0 < 1$, impossible.
- **$r = 2$** ($z \in \{64, 128, 192\}$): the high-block quadratic phase bound on the 4-point dual flat $R$ requires $2a + 3b + c \ge 448 - 16 \cdot 4 = 384$, contradicting $6a + 3b + 5c = 8t - 480 = 352$.
- **$r = 4$** ($z \in \{96, 128, 160\}$): the high-block rank-4 bound gives $k = a + c \le 2(t - 100) = 8 < 10$, contradicting the affine hyperplane lemma ($k \ge 10$).
- **$r = 8$** ($z \in \{120, 136\}$): $z = 136$ gives $|D| = -10 < 0$. For $z = 120$, $|D| = 10$; by the low autocorrelation congruence, the augmented incidence rows of the low zeros have rank $9$ orthogonal to $\mathbf{1}$, forcing $n_0 \ge 10$, and equality $n_0 = 10$ uniquely forces $Q(x) \cong \binom{\mathrm{wt}(x)}{2} \bmod 2$ with $z = 136 \ne 120$.
- **$r = 6$** ($z \in \{112, 128, 144\}$): $z = 128$ gives $|D| = 0 < 1$, and $z = 144$ gives $|D| = -20 < 0$.

Thus **only polar rank $6$ with $|Z| = 112$ and $|D| = n_0 + 2 n_8 = 20$** remains.

---

## 2. Quotient Structure, Mod-8 Congruence, and Hyperplane Dichotomy

Modulo the 2D radical $W$ of $Q$, the frequency space factors as $\mathbb{F}_2^8 = \mathbb{F}_2^6 \times W$ with elliptic quadratic $Q(c) = c_0 c_1 + c_2 c_3 + c_4 c_5 + c_0 + c_1$ on $\mathbb{F}_2^6$, having $|Z_6| = 28$ zeros and $|F_6| = 36$ ones. Decomposing $V$ into four 64-point input cells $v_x : \mathbb{F}_2^6 \to \{-1, 0, +1\}$ ($x \in \mathbb{F}_2^2$) with $\sum_x m(v_x) = 104$ and Walsh transforms $z_x(c) = \widehat{v_x}(c)$:

1. **Common mod-4 residue $\beta(c)$:** For every $c \in \mathbb{F}_2^6$, all four $z_x(c)$ are even and share the same residue modulo $4$, defining $\beta(c) = (z_x(c)/2) \bmod 2$. Since $64 v_x(y) \equiv 2 \widehat{\beta}(y) \pmod 4$ and $v_x \in \{-1,0,1\}$, we have $32 \mid \widehat{\beta}(y)$ for all $y \in \mathbb{F}_2^6$, forcing $\beta \in \{0, 1, \mathbf{1}_H\}$ for an affine hyperplane $H \subset \mathbb{F}_2^6$.
   - $\beta \equiv 1$ requires odd defect count $d_c \in \{1, 3\}$ at every $c \in Z_6$, so $n_0 \ge 28 > 20$, impossible.
   - Under the 63 transvections generating $\mathrm{Aut}(Q) \subset \mathrm{AGL}(6, 2)$ (verified to preserve $Q$ and $v_x \in \{-1, 0, +1\}^{64}$), all $126$ affine hyperplanes split into **exactly two orbits of size $63$**:
     - **Case II:** $(|H \cap Z_6|, |H \cap F_6|) = (16, 16)$, representative $H_0 = \{c_0 = 0\}$.
     - **Case III:** $(|H \cap Z_6|, |H \cap F_6|) = (12, 20)$, representative $H_1 = \{c_0 = 1\}$.

2. **Quadratic Mod-8 Theorem (for both $\beta = 0$ and $\beta = \mathbf{1}_H$):** Define $p_x(c) = ((z_x(c) - 2 \beta(c))/4) \bmod 2$. For every affine 3-flat $A = a + U \subset \mathbb{F}_2^6$ ($|A| = 8$), Poisson summation gives
   $$\sum_{c \in A} z_x(c) = 8 \sum_{y \in U^\perp} (-1)^{a \cdot y} v_x(y) \equiv 0 \pmod 8.$$
   Since $|A \cap H| \in \{0, 4, 8\}$ is always divisible by $4$, $2 \sum_{c \in A} \beta(c) \equiv 0 \pmod 8$, hence $\sum_{c \in A} p_x(c) \equiv 0 \pmod 2$ for every 3-flat $A$. Thus $\deg(p_x) \le 2$ ($p_x \in \mathrm{RM}(2, 6)$) for every $x \in \mathbb{F}_2^2$, and summing over $x$ modulo $8$ gives
   $$p_0 \oplus p_1 \oplus p_2 \oplus p_3 = Q \quad \text{everywhere on } \mathbb{F}_2^6.$$

3. **Autocorrelation Mod-8 Defect Law:** Pointwise on $\mathbb{F}_2^6$,
   $$\sum_{x \in \mathbb{F}_2^2} z_x(c)^2 = 64 + 80 Q(c) - 16 D(c), \qquad \sum_{c \in \mathbb{F}_2^6} D(c) = 20,$$
   where $D(c) = d_c$ on $Z_6$ and $D(c) = 2 k_c$ on $F_6$. Since $\sum_u v_x(u) v_x(u \oplus y)$ is even for every $y \ne 0$, taking the 6-bit Walsh transform gives $80 \widehat{Q}(y) - 16 \widehat{D}(y) \equiv 0 \pmod{128}$, hence
   $$\widehat{D}(y) \equiv 5 \widehat{Q}(y) \equiv 4 \pmod 8 \qquad \forall y \ne 0.$$
   Writing $D = \mathbf{1}_{H \cap Z_6} + 2 R$ (with $\sum R = 2$ in Case II and $\sum R = 4$ in Case III), exact Walsh evaluation proves:
   - **Case II ($H_0 = \{c_0 = 0\}$):** the two defect units $a, b$ satisfy $a \oplus b = d = 2$ (unique!).
   - **Case III ($H_1 = \{c_0 = 1\}$):** the four defect units $a_1, a_2, a_3, a_4$ satisfy $a_1 \oplus a_2 \oplus a_3 \oplus a_4 = d = 2$ (unique!).

4. **Independent Affine Normalization for $\beta = \mathbf{1}_H$:** Replacing $v_x(u_0, u') \mapsto (-1)^s v_x(u_0, u' \oplus a')$ leaves $p_x|_{H^c}$, $|z_x(c)|$, and $m(v_x)$ invariant while shifting $p_x|_H$ by any affine function $s \oplus (a' \cdot c')$. Thus every single-row problem for $\beta = \mathbf{1}_H$ reduces to $p_x(0, c') = p_x(1, c')$ determined solely by the 5-variable quadratic $p_x|_{H^c}$, and on $H \cap F_6$ clean values are pinned to a single signed integer ($+6$ if $p_x = 1$, $-6$ if $p_x = 0$).

---

## 3. Exhaustive Elimination Summary (All Verified in `verify_t104_closed.cpp`)

### Pass 2: $\beta = \mathbf{1}_{H_0}$, Case II ($|H_0 \cap Z_6| = 16$, $a \oplus b = 2$)
Under the 31 transvections in $\mathrm{Stab}(H_0)$, all $65{,}536$ 5-variable quadratics on $H_0^c$ collapse into **74 exact orbits**. Because $a \oplus b = 2$ fixes $c_0$, flips $Q$ on $H_0$, and preserves $Q$ on $H_0^c$, only three subcases exist:
- **II-D** ($n_8 = 0, n_0 = 20$, $\{a, b\} \subset H_0^c \cap Z_6$, all $36$ $F_6$-cosets clean): exact 32+32 half-join across all 74 orbits yields $\min \sum_{x=0}^3 m(v_x) = 108 > 104$.
- **II-B** ($n_8 = 1, n_0 = 18$, $a \in H_0 \cap Z_6$, $b = a \oplus 2 \in H_0 \cap F_6$): across all 74 orbits and all 16 choices of $b \in H_0 \cap F_6$, $\min \sum_{x=0}^3 m(v_x) = 114 > 104$.
- **II-C** ($n_8 = 2, n_0 = 16$, $\{a, b\} \subset H_0^c \cap F_6$): all 10 pairs $\{a, a \oplus 2\} \subset H_0^c \cap F_6$ form a single $\mathrm{Stab}(H_0)$ orbit. Fixing $\{1, 3\}$, all valid $(p_0, p_1, p_2, p_3)$ on $H_0^c$ with identical restriction to $H_0^c \cap Z_6$ form **102 unordered 4-tuples**. Testing all 102 tuples directly with exact $(E_6, E_8, \sum m = 104)$ partitioning and affine sign-phase consistency across all $32 + \mathrm{wt}_{Z} + 2$ everywhere-nonzero frequencies yields **0 joins**.

### Pass 3: $\beta = \mathbf{1}_{H_1}$, Case III ($|H_1 \cap Z_6| = 12$, $a_1 \oplus a_2 \oplus a_3 \oplus a_4 = 2$)
Under $\mathrm{Stab}(H_1)$, all $65{,}536$ quadratics on $H_1^c$ collapse into **74 orbits**, $\ker(\mathrm{RM}(2, 5)|_{H_1^c \cap Z_6}) = \{0, Q|_{H_1^c}\}$ has dimension $1$, all weights on $H_1^c \cap Z_6$ are even, and both the 120 pairs in $H_1^c \cap Z_6$ and 120 pairs in $H_1^c \cap F_6$ form single orbits.
- **III-0** ($n_8 = 0, n_0 = 20$): across all 74 orbits, $\min \sum_{x=0}^3 m(v_x) = 120 > 104$.
- **$1 \le n_8 \le 4$**, exhaustively partitioned by $(m_{2, Z}, \mathrm{odd}_F)$ on $H_1^c$ ($m_{2, Z} + \mathrm{odd}_F \le 4$, $m_{2, Z} \ne 1$):
  - **III-A** ($m_{2, Z} = 3, \mathrm{odd}_F = 1, n_8 = 1$): all 12 cases have $\min \sum m > 104$ (and $\mathrm{odd}_F = 0$ is verified impossible across all 56 lifts).
  - **III-B** ($m_{2, Z} = 0, \mathrm{odd}_F = 4, n_8 = 4$): 160 quadratics with $\mathrm{XOR} = 2$ collapse into 2 orbits, $\min \sum m = 106 > 104$.
  - **III-C** ($m_{2, Z} = 2, \mathrm{odd}_F = 2, n_8 = 2$): all 16 cases have $\min \sum m > 104$.
  - **III-D** ($m_{2, Z} = 2, \mathrm{odd}_F = 0$): $p_0 = \mathbf{1}_Z$ has 0 rows; $p_0 = 0$ has $\min m(p_0) = 30$, while $m(v_1) + m(v_3) \ge 58$ by Parseval, giving $60 + 58 = 118 > 104$.
  - **III-E2** ($m_{2, Z} = 0, \mathrm{odd}_F = 2$): all cases have $\min \sum m > 104$.
  - **III-E0** ($m_{2, Z} = 0, \mathrm{odd}_F = 0$, $p_0 \in \{0, \mathbf{1}_Z\}$, $p_3 = p_0 \oplus \mathbf{1}_F$): Parseval gives $m(v_3) \ge 46$ (when $k_{H^c} = 0$) and $m(v_3) \ge 45$ (when $k_{H^c} = 2$). For $p_0 = \mathbf{1}_Z$, every defect orbit gives $\sum m \ge 105 > 104$. For $p_0 = 0$, every orbit fails except two defect masks on $H_1 \cap F_6$ (`0x3` and `0x7`), for both of which $p_3 = \mathbf{1}_F$ has **0** valid 64-point rows.

### Pass 4: $\beta = 0$, All $(n_0, n_8)$ with $n_0 + 2 n_8 = 20$
Let $U = \mathrm{span}(p_1 \oplus p_0, p_2 \oplus p_0, p_3 \oplus p_0)|_{Z_6} \subset \mathrm{RM}(2, 6)|_{Z_6}$ ($\dim U \in \{0, 1, 2\}$), $m_2 = |\bigcup U|$, $n_0 = 2 m_2 + 4 m_4$. Verified $\mathrm{RM}(2, 6)|_{Z_6}$ has minimum nonzero weight $4$ ($315$ words) and $\mathrm{RM}(2, 6)|_{F_6}$ has minimum nonzero weight $6$ ($336$ words).
- **$n_0 \in \{2, 6, 10\}$**: forces odd $m_2 \le 5$, impossible ($4 + 4 + 4 = 12 > 10$).
- **$\dim U = 0$ ($m_2 = 0$, covering $(4, 8)$ and $m_2 = 0$ everywhere)**: one cell has clean $F_6$-energy $36 \cdot 144 - 80 n_8 \ge 4384 > 4096 = 64^2$ for all $n_8 \le 10$.
- **$(n_0, n_8) = (8, 6)$ ($m_2 = 4$, $\dim U = 1$)**: $\mathrm{odd}_F \in \{0, 6\}$; exact 4-cell $(E_8, \text{phase})$ join over all Schreier stabilizer orbits of $w_6(F_6)$, $(2,2,2)$, and $(4,2)$ yields **0 joins**.
- **$n_0 \ge 12$, $\dim U = 1$**: $\mathrm{odd}_F \le 4 < 6 \implies p_0 \in \{0, \mathbf{1}_Z\}$ and $n_8 \in \{0, 2, 4\}$. Across all $12$ orbits for $(20, 0)$, $6$ orbits for $(16, 2)$, and $3$ orbits for $(12, 4)$ (both $p_0 = 0$ and $p_0 = \mathbf{1}_Z$), exact 4-cell $(E_8, v_0, v_2)$ join yields **0 joins**.
- **$n_0 \ge 12$, $\dim U = 2$ ($6 \le m_2 \le 10$)**: the smallest nonzero word $a \in U$ has $\mathrm{wt}(a) \in \{4, 6\}$ (3 $\mathrm{Aut}(Q)$ orbits). Exact $[36, 21, 6]$ 15-bit syndrome decoding of $(u \mathbin{\&} v)|_{F_6}$ across all pairs $(a, b)$ with $m_2 \le 10$ reduces the entire $\dim U = 2$ universe to **27 $\mathrm{Stab}(a)$-orbits** (322 total cases covering every weight $\le 10 - m_2$ error pattern, both $Z$-lifts, and $k = (3,1)$ / $(1,1,2)$ for $m_2 = 6$). Exact 4-cell $(E_8, \text{phase})$ join yields **0 joins**.

---

## 4. Independent Replay

```bash
python3 t104_plus/verify_t104_closed.py
```

Both positive controls (`beta = 1_H`, `beta = 0`, `PhaseReducer`), all rank-0/2/4/8 checks, and Passes 1–4 compile cleanly with `-Wall -Wextra -Wpedantic` (zero third-party libraries) and pass with exit code `0`.
