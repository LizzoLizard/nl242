# Three-Line Proof That $|E| \ge 22$ and $t \ge 70$ for Balanced $N = 9, \mathrm{nl} = 242$

**New Universal Range (combining with `t <= 116`):**
$$70 \le t \le 116,\qquad t \equiv 0 \pmod 2,\qquad 108 \le N_{28} \le 234.$$
*(Only **24** even values of $t$ remain!)*

---

## Proof (15 Lines in Lean 4.15.0)

Let $E = \{a \in \mathbb{F}_2^8 : |\mathrm{hi}(a)| < 28\}$ (`|E| = m = 256 - N_{28}`).

### Step 1: Every Affine 6-Flat Meets $E$ (Hence Every Hyperplane Has $8 \le |E \cap H| \le m - 8$)
Take any affine 6-flat $F = \{a \in \mathbb{F}_2^8 : a \cdot d = b_1,\, a \cdot c = b_2\}$ ($d, c$ linearly independent, $b_1, b_2 \in \{0, 1\}$), with annihilator 2-subspace $K = \{0, d, c, d \oplus c\}$.
If $E \cap F = \emptyset$, then $7 \mid 28 = |\mathrm{hi}(a)|$ for all $a \in F$. By Fourier inversion on $K$, for every $x \in \mathbb{F}_2^8$:
$$128 \sum_{k \in K} (-1)^{\beta(k)} H_{\mathrm{dis}}(x \oplus k) = \sum_{a \in F} \mathrm{hi}(a)(-1)^{a \cdot x} \equiv 0 \pmod 7.$$
Since $H_{\mathrm{dis}}(u) \in \{-1, 0, +1\}$, the 4-term sum lies in $[-4, 4]$ and is divisible by $7$, hence equals $0$ identically for all $x$. Therefore $\mathrm{hi}(a) = 0$ for all $a \in F$, contradicting $\mathrm{hi}(a) \equiv 4 \pmod 8$.

Thus every affine 6-flat meets $E$. Consequently, for **every** affine hyperplane $H \subset \mathbb{F}_2^8$ (both $a \cdot d = 0$ and $a \cdot d = 1$), $E \cap H$ cannot lie inside any 6-flat of $H$, so $E \cap H$ affinely spans $H$ ($\dim_{\mathrm{aff}} H = 7$), forcing:
$$|E \cap H| \ge 8 \quad \text{and} \quad |E \cap H^c| \ge 8.$$

### Step 2: Parseval Kills $m \le 20$ (Already Kills $t = 64, 66, 68$!)
Let $s_d = \widehat{1_E}(d) = |E \cap \{a \cdot d = 0\}| - |E \cap \{a \cdot d = 1\}|$ for $d \in \mathbb{F}_2^8 \setminus \{0\}$.
From Step 1, $|s_d| \le m - 16$ for all $255$ nonzero $d$. By Parseval:
$$256 m - m^2 = \sum_{d \neq 0} s_d^2 \le 255 (m - 16)^2.$$
For $m \le 20$, $256 m - m^2 > 255(m - 16)^2$ (at $m = 20$: $4720 > 4080$). Contradiction! Thus $m \ge 21$.

### Step 3: Fourth Moment Kills $m = 21$ (Hence $|E| \ge 22$ and $N_{28} \le 234$)
Suppose $m = 21$. Since $s_d \equiv m = 21 \equiv 1 \pmod 2$ and $|s_d| \le 21 - 16 = 5$, every $d \neq 0$ has $s_d^2 \in \{1, 9, 25\}$. Hence $(s_d^2 - 1)(s_d^2 - 25) \le 0$, i.e., $s_d^4 \le 26 s_d^2 - 25$. Summing over all $255$ nonzero $d$:
$$\sum_{d \neq 0} s_d^4 \le 26 (256 \cdot 21 - 21^2) - 25 \cdot 255 = 26 \cdot 4935 - 6375 = 121{,}935.$$
On the other hand, by Fourier inversion on 4-tuples,
$$\sum_{d \in \mathbb{F}_2^8} s_d^4 = 256 \cdot \#\{(a,b,c,e) \in E^4 : a \oplus b \oplus c \oplus e = 0\}.$$
Counting only the trivial zero-sum 4-tuples ($a=b, c=e$; $a=c, b=e$; $a=e, b=c$; minus $2m$ overcounts of $a=b=c=e$) gives at least $3m^2 - 2m = 1281$ solutions. Subtracting $s_0^4 = 21^4 = 194{,}481$:
$$\sum_{d \neq 0} s_d^4 \ge 256 \cdot 1281 - 194{,}481 = 133{,}455 > 121{,}935.$$
Contradiction! Therefore $|E| \ge 22$ and $N_{28} \le 234$.

### Step 4: Consequence for $t$
From `Balanced242Blocks` ($8t + 3N_{28} = 1248 + 2N_{12} + 3N_4$):
- $t = 64 \implies N_{28} \ge 246 \implies |E| \le 10 < 22$,
- $t = 66 \implies N_{28} \ge 240 \implies |E| \le 16 < 22$,
- $t = 68 \implies N_{28} \ge 236 \implies |E| \le 20 < 22$.

Hence **$t \ge 70$** (and combined with our $t = 118$ elimination, **$70 \le t \le 116$, $108 \le N_{28} \le 234$**). $\blacksquare$
