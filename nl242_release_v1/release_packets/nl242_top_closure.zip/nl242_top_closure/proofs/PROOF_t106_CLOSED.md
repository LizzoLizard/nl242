# Closure of Agreement Count `t = 106` for Balanced 9-Variable Boolean Functions of Nonlinearity 242

## Main Theorem

**Theorem.** *No balanced 9-variable Boolean function $f : \mathbb{F}_2^9 \to \mathbb{F}_2$ with nonlinearity $\mathrm{NL}(f) = 242$ has agreement count $t = 106$.*

In ``nl242-lab/middle/MIDDLE_PROOF.md`` (in `nl242_middle_closure.zip`) and ``nl242-lab/middle/check_middle.py`` (in `nl242_middle_closure.zip`), polar ranks $0, 2, 4,$ and $8$ are already excluded at $t = 106$, leaving **only polar rank $6$ ($|Z| = 112$, low Parseval slack $|D| = n_0 + 2 n_8 = 12$)**. Here we exclude polar rank $6$ at $t = 106$ using **only the low Walsh block**, with **zero LP/MILP, zero third-party libraries, and zero covering-radius dependence**, verified end-to-end in pure Python integer arithmetic by [`verify_t106_closed.py`](../t104_plus/verify_t106_closed.py).

Combined with $t \le 92$ (`verify_t84_closed.py`, `verify_t86_92.py`) and $t \ge 108$ (`MIDDLE_PROOF.md`, `verify_t110_closed.py`, `verify_t112_closed.py`, `AGREEMENT_RANGE.md`), the open window shrinks to **6 even counts**:
$$
94 \le t \le 104, \qquad t \equiv 0 \pmod 2.
$$

---

## 1. Quotient Structure and Defect Congruence for Rank 6 (`|Z| = 112`, `|D| = 12`)

Let $V \in \{-1, 0, 1\}^{\mathbb{F}_2^8}$ be the signed agreement table ($\operatorname{wt}(V) = 106$), $\widehat{V} = \mathrm{lo}/2$, and $Q(a) = (\widehat{V}(a)/4) \bmod 2$ of polar rank $6$ with $|Z| = |\{Q = 0\}| = 112$. Factor $\mathbb{F}_2^8 = \mathbb{F}_2^6 \times W$ where $W \cong \mathbb{F}_2^2$ is the 2-dimensional radical, so $Z = S_{28} \times W$ with $|S_{28}| = 28$ ($0 \in S_{28}$) and $|S_{36}| = |S_{28}^c| = 36$.

In dual input coordinates $\mathbb{F}_2^8 = \mathbb{F}_2^2 \times \mathbb{F}_2^6$, there are four 64-point cells $v_x \in \{-1, 0, 1\}^{\mathbb{F}_2^6}$ ($x \in \mathbb{F}_2^2$) with weights $m(x) = \operatorname{wt}(v_x)$, $\sum_{x \in \mathbb{F}_2^2} m(x) = 106$, and 6-bit Walsh transforms
$$
z_x(c) = \widehat{v_x}(c) = \frac{1}{4}\sum_{w \in W} (-1)^{w \cdot x} \widehat{V}(c, w), \qquad \sum_{c \in \mathbb{F}_2^6} z_x(c)^2 = 64 \, m(x) \le 4096.
$$
Let $D(c, w) \in \{0, 1, 2\}$ be the low defect weight ($1$ at zeros on $Z$, $2$ at $|\widehat{V}| = 4$ on $Z^c$), so $|D| = n_0 + 2 n_8 = 576 - \frac{5}{4}\cdot 112 - 4\cdot 106 = 12$. As in `MIDDLE_PROOF.md`, transforming $\widehat{V}^2 = 144 - 80 \cdot \mathbf{1}_Z - 64 D$ gives the exact congruence
$$
5 \cdot \widehat{\mathbf{1}_Z}(u) + 4 \cdot \widehat{D}(u) \equiv 0 \pmod{32} \qquad \forall u \in \mathbb{F}_2^8.
$$

### Step 1: On $W^\perp$ — Forcing $4 \mid z_x(c)$ Everywhere ($\beta \equiv 0$)
Define the quotient defect $D_{\mathrm{bar}}(c) = \sum_{w \in W} D(c, w)$ ($\sum_c D_{\mathrm{bar}}(c) = 12$). For every $u \in W^\perp \setminus \{0\}$, $\widehat{\mathbf{1}_Z}(u) = \pm 16$, so $\widehat{D_{\mathrm{bar}}}(u) \equiv 4 \pmod 8$. With $|\widehat{D_{\mathrm{bar}}}(u)| \le 12$, every nonzero $u \in W^\perp$ satisfies $\widehat{D_{\mathrm{bar}}}(u) \in \{\pm 4, \pm 12\}$. Letting $m_{12} = |\{u \in W^\perp \setminus \{0\} : |\widehat{D_{\mathrm{bar}}}(u)| = 12\}|$ (so $1 + m_{12} = 2^d$), Parseval on $\mathbb{F}_2^6$ gives
$$
64 \sum_{c \in \mathbb{F}_2^6} D_{\mathrm{bar}}(c)^2 = 144 + 63 \cdot 16 + 128 m_{12} = 1152 + 128 m_{12}
\implies
\sum_{c \in \mathbb{F}_2^6} D_{\mathrm{bar}}(c)^2 = 18 + 2 m_{12} \ge 18.
$$

For every $s \in S_{28}$, $z_x(s) = 2 \sum_{w \notin Z_s} \varepsilon_s(w)(-1)^{w \cdot x}$ is even, so $m(x) \equiv z_x(s) \equiv 0 \pmod 2$ for all $x \in \mathbb{F}_2^2$. Writing $v_x = g_x - 2 h_x$, the binary function $\beta_x(c) := (z_x(c)/2) \bmod 2$ is **affine** in $c \in \mathbb{F}_2^6$ ($\deg \beta_x \le 1$), and on $S_{28}$ it satisfies $\beta_x(s) = n_0(s) \bmod 2$, independent of $x$. Because degree-$\le 1$ monomials on $S_{28}$ have full binary rank $7/7$, $\beta_0 = \beta_1 = \beta_2 = \beta_3 =: \beta$ on all of $\mathbb{F}_2^6$.

If $\beta \not\equiv 0$, then $|\{s \in S_{28} : \beta(s) = 1\}| \in \{12, 16, 28\}$ (hyperplane intersection with the elliptic quadric $S_{28}$). Since $n_0 \le 12$, this forces $n_0 = 12$, $n_8 = 0$, and $D_{\mathrm{bar}} \in \{0, 1\}$ supported on $12$ points, giving $\sum_c D_{\mathrm{bar}}(c)^2 = 12 < 18$, a contradiction.

Hence **$\beta \equiv 0$**, i.e., **$4 \mid z_x(c)$ on all 64 cosets and all 4 cells**, every $n_0(s) \in \{0, 2, 4\}$ is even, and every clean coset $c \in S_{36}$ ($k_c = 0$) has magnitude pattern $(0, 0, 0, 12)$.

### Step 2: Quadratic Parity Functions $p_x(c) = (z_x(c)/4) \bmod 2$ and Forcing $m_2 \ge 4$
Writing $d(c) = D_{\mathrm{bar}}(c)/2$ ($\sum_c d(c) = 6$), Parseval yields
$$
\sum_{c \in \mathbb{F}_2^6} d(c)^2 = \frac{9 + m_{12}}{2} = 4 + 2^{d-1} \in \{6, 8, 12, 20, 36\}.
$$
Since $d(0) \le 2$ ($n_0(0) \le 4$), the only integer partitions of $6$ achieving this sum of squares are `(4,2)`, `(2,2,2)`, `(3,1,1,1)`, `(2,1,1,1,1)`, and `(1,1,1,1,1,1)`.

Because $4 \mid z_x(c)$, each $p_x(c) := (z_x(c)/4) \bmod 2$ is a **quadratic polynomial** ($\deg p_x \le 2$) on $\mathbb{F}_2^6$. For any pair $(x, x')$, $q_{x, x'} := p_x \oplus p_{x'}$ vanishes on every $s \in S_{28}$ with $n_0(s) \in \{0, 4\}$, and takes value $1$ on a subset of the $m_2 := |\{s \in S_{28} : n_0(s) = 2\}|$ cosets. Exhaustive enumeration of all $2^{21}$ codewords of $\mathrm{RM}(2, 6)|_{S_{28}}$ verifies that the minimum nonzero weight on $S_{28}$ is **$4$**:
- Weight $0$: $1$ codeword ($\mathrm{wt}_{36} \in \{0, 36\}$).
- Weight $4$: $315$ codewords ($\mathrm{wt}_{36} \in \{12, 24\}$; every support on $S_{28}$ is a totally singular affine 2-plane).
- Weight $6$: $1008$ codewords ($\mathrm{wt}_{36} \in \{10, 26\}$; 4-flat hyperovals) and $5040$ codewords ($\mathrm{wt}_{36} \in \{18, 18\}$; rank-4 radical $K$ of size $4$).

If $m_2 \le 3$, then every $q_{x, x'}$ vanishes on $S_{28}$, so $q_{x, x'} \in \{0, Q\}$ for all $(x, x')$. Thus all $36 - n_8 \ge 31$ clean $(0, 0, 0, 12)$ cosets in $S_{36}$ peak on the **same** cell $x^*$, giving $64 m(x^*) \ge 31 \cdot 144 = 4464 > 4096$, impossible. This immediately eliminates `(4,2)`, `(2,2,2)`, and `(3,1,1,1)`, leaving only:
- **`A1`:** $d = (2,1,1,1,1)$, $m_2 = 4$, one $n_0(s) = 4$, $n_8 = 0$.
- **`A2`:** $d = (2,1,1,1,1)$, $m_2 = 4$, one $k_{c^*} = 2$ in $S_{36}$, $n_8 = 2$.
- **`B1`:** $d = (1^6)$, $m_2 = 6$, $n_8 = 0$.
- **`B2`:** $d = (1^6)$, $m_2 = 5$, one $k_c = 1$ in $S_{36}$, $n_8 = 1$.
- **`B3`:** $d = (1^6)$, $m_2 = 4$, two $k_c = 1$ in $S_{36}$, $n_8 = 2$.

### Step 3: Off $W^\perp$ — Killing `B2`, `B3` and Forcing $p_{01} = p_{11} \equiv 0$
For each nonzero $u_2 \in W \setminus \{0\}$ (`3` directions), let $g_{u_2}(c) = \frac{1}{2} \sum_{w \in W} (-1)^{u_2 \cdot w} D(c, w)$. Off $W^\perp$, $\widehat{\mathbf{1}_Z} = 0$, so $8 \mid \widehat{D}(u_6, u_2)$ and $|\widehat{D}| \le 12$ force $\widehat{g_{u_2}}(u_6) \in \{-4, 0, +4\}$ for all $u_6 \in \mathbb{F}_2^6$.
- In $\dim 3$ (`A1, A2`): exhaustive check shows valid $|g|$ multisets with $\sum |g| \le 6$ are only `(), (2,2), (1,1,1,1), (1,1,1,1,2)`.
- In $\dim 4$ (`B1, B2, B3`): valid support sizes for $g \in \{-1, 0, 1\}$ with $|g| \le 6$ are only $0, 4, 6$.

Each $k_c = 1$ coset contributes $\pm 1$ to **all three** $g_1, g_2, g_3$, while each $n_0(s) = 2$ coset contributes $\pm 1$ to **one** of them. Hence `B2` requires $\sum |g_i| = 5 + 3 = 8 \ge 3 \cdot 4 = 12$ (dead!) and `B3` requires $\sum |g_i| = 4 + 6 = 10 \ge 12$ (dead!). In all three survivors **`A1, A2, B1`**, two of the three projections must vanish ($g_2 = g_3 = 0$), so all $m_2$ cosets share a **single pair direction** $w^* \in W \setminus \{0\}$.

Relabeling $W$, all $m_2$ cosets equalize $(p_{00}, p_{10})$ and $(p_{01}, p_{11})$ on $S_{28}$, so $q_{00, 10}, q_{01, 11} \in \{0, Q\}$. Since $q_{00, 10} \oplus q_{01, 11} = Q$ on all clean cosets of $S_{36}$ (where $\mathrm{RM}(2,6)$ has rank $21/22$ even after deleting $c^*$), WLOG $q_{00, 10} = Q$ and $q_{01, 11} = 0$. Hence **all clean cosets in $S_{36}$ vanish on cells `01` and `11`**, so $p_{01} = p_{11} \in \{0, 1 + Q\}$ by rank $21/22$ on $S_{36}$ and $S_{35}$. Setting $p_{01} = 1 + Q$ forces $|z_s(01)| = 4$ on all $28$ cosets of $S_{28}$, which is impossible in `A1` ($n_0(s) = 4$ gives $z_s = 0$) and gives odd cell weight $m(01) = 28 \cdot 16 / 64 = 7$ in `B1` (and at least one of $m(01), m(11) = 7$ in `A2`). Therefore **$p_{01} = p_{11} \equiv 0$ everywhere**, and $p_{00}, p_{10}$ are a complementary weight-$(m_2, \mathrm{wt}_{36})$ pair of $\mathrm{RM}(2, 6)$ codewords!

---

## 2. Exact Cell-00 Elimination of All Three Remaining Subcases

1. **`B1-{10, 26}` ($\mathrm{wt}_{28} = 6, \mathrm{wt}_{36} = 10$, 1008 hyperoval 4-flats):**
   Every codeword defines an affine 4-flat $F_4 \subset \mathbb{F}_2^6$ whose intersection with $S_{28}$ is a 6-point hyperoval $H_6$ ($|\widehat{\mathbf{1}_{H_6}}(u)| = 2$ for $u \ne 0$). On Cell `00` ($26$ peaks of $\pm 12$ and $6$ entries of $\pm 4$), $m(00) \ge (26 \cdot 144 + 6 \cdot 16)/64 = 60$. Yet the 4-flat Poisson projection $S_0(y) = \sum_{u \in F_4^\perp} v_{00}(y + u)$ has $\widehat{S_0}$ supported on $H_6$ with entries $\pm 4$; across all $2^6 = 64$ signings, every integer $S_0$ has magnitude multiset $(0^{10}, 1^6)$ ($6$ odd 4-point cosets $\implies$ at least $6$ zeros of $v_{00}$), forcing $m(00) \le 64 - 6 = 58 < 60$. **Contradiction!**

2. **`A1` ($\mathrm{wt}_{28} = 4, \mathrm{wt}_{36} = 12$, $n_8 = 0$) & `A2` (one $k_{c^*} = 2$ in $S_{36}$):**
   All 315 weight-4 codewords are $(4, 8, 8, 8)$ 4-flat pencils $L_4 = P^{\perp_B}$ of totally singular 2-spaces $P$ of $Q^-(5,2)$ (all equivalent up to frequency translation and Witt's theorem on $Q^-(5,2)$).
   - In **`A1`**, $S_0$ on $F_4$ has unique pattern $(0^{12}, 1^4)$ ($8$ translates/negations), forcing $m(00) \le 60$ and hence $k_{00} = m(00) - 55 \in \{1, 3, 5\}$. Exhaustive 4-coset reconstruction over $(S_0, S_1, S_2, S_3)$ finds $0$ solutions for $k_t = 0$ and **$0$ valid $v_{00} \in \{-1, 0, 1\}^{64}$** across all $(k_1, k_2, k_3)$ summing to $3$ or $5$.
   - In **`A2`**, $p_{00} \oplus p_{10} = Q$ forces $|z_{c^*}| = (0, 0, 4, 8)$ with the $4$ on either Cell `00` (`A2-I`, $c^* \notin F_4$) or Cell `10` (`A2-II`, $c^* \in F_4$).
     - **`A2-II`:** If $z_{c^*}(00) = 0$, Cell `00` reduces to `A1` ($0$ solutions). If $|z_{c^*}(00)| = 8$, all $12$ choices of $c^* \in F_4 \cap S_{36}$ force $S_0$ to have $8$ odd entries $\implies m(00) \le 56 = 56 \implies k_{00} = 0$, yielding **$0$ valid $v_{00}$**.
     - **`A2-I`:** For all $8$ choices of $c^* \in (F_4 + t_1) \cap S_{36}$, $m(00) \le 60 \implies k_{00} \in \{3, 5, 7\}$, yielding **$0$ valid $v_{00}$**.

3. **`B1-{18, 18}` ($\mathrm{wt}_{28} = 6, \mathrm{wt}_{36} = 18$, 5040 radical pairs):**
   Across all $5040/5040$ pairs $(p_{00}, p_{10})$, exactly one cell has a 2-dimensional radical $K = \operatorname{rad}(p)$ on which the polar form $B$ is **nondegenerate**. Taking $L_4 = K^{\perp_B}$ decomposes $\mathbb{F}_2^6 = L_4 \oplus K$ into $6$ cosets `SZ4` ($p=1$, $1 \times S_{28} + 3 \times S_{36}$), $4$ cosets `C4` ($p=0$, $1 \times S_{28} + 3 \times S_{36}$, forming an affine 2-plane), and $6$ cosets `C6` ($p=0$, $3 \times S_{28} + 1 \times S_{36}$, forming a bent 6-point elliptic quadric), with a single shared exceptional element $w^* \in K$. Because $\operatorname{Aut}(S_{Z,\mathrm{ref}})$ (order $120$) acts transitively on all $15$ affine 2-planes in $S_{Z,\mathrm{ref}}^c$, all $5040$ pairs yield a **single canonical cell problem**.
   Splitting this 64-point cell into its four 16-point sub-cells on $K^\perp$, the mod-4 parity $a(c) = (u_c/2) \bmod 2$ is an affine function on $\mathbb{F}_2^4$ shared across all four sub-cells. Exhaustive pure-integer enumeration of all valid 16-point sub-cells across all $32$ affine functions $a(c)$ yields **$0$ four-subcell covers** for $31/32$ affine functions, and a single integer cover (`m = 54`, $16+16+16+6$) for $a \equiv 0$ which has **$0$ exact $K$-sign-consistent realizations** across all $24$ sub-cell permutations.

---

## 3. Independent Verification

Run with zero third-party dependencies:
```bash
PYTHONDONTWRITEBYTECODE=1 python3 verify_t106_closed.py
```
Verified exit code `0` in `56.63s` (100% pure Python integer arithmetic, zero LP/MILP).
