# Complete Proof That `t = 100` Is Impossible for Balanced 9-Variable `NL = 242` Boolean Functions

## Theorem
No balanced 9-variable Boolean function $F : \mathbb{F}_2^9 \to \mathbb{F}_2$ with nonlinearity $\mathrm{NL}(F) = 242$ ($\max_a |W_F(a)| = 28$) has agreement count $t = 100$.

Together with prior closures of $t \le 92$ and $t \ge 102$ (see [PROOF_t102_CLOSED.md](PROOF_t102_CLOSED.md)), this closes the upper range through $t = 100$, leaving only $t \in \{94, 96, 98\}$ open from the top.

---

## Complete Case Decomposition at `t = 100`

Let $V, U : \mathbb{F}_2^8 \to \{-1, 0, +1\}$ be the disjoint low and high blocks in adapted coordinates ($\mathrm{wt}(V) = t = 100$, $\mathrm{wt}(U) = 256 - t = 156$, $\mathrm{lo} = 2\widehat V = 8f$, $\mathrm{hi} = 2\widehat U = 4H$, $|\mathrm{lo}| \in \{0, 8, 16, 24\}$, $|\mathrm{hi}| \in \{4, 12, 20, 28\}$). Let $q(a)$ be the coupled quadratic phase of polar rank $r \in \{0, 2, 4, 6, 8\}$ and $Z = \{a : 16 \mid \mathrm{lo}(a)\}$.

By Parseval on $f = \widehat V / 4$, the low-block defect budget is
$$|D| := n_0 + 2 n_8 = \frac{2304 - 5|Z| - 16t}{4} = \frac{704 - 5|Z|}{4},$$
where $n_0 = \#\{a \in Z : f(a) = 0\}$ ($0 \in Z_0$) and $n_8 = \#\{a \in F : |f(a)| = 1\}$.

| Phase rank $r$ | Allowed $\|Z\|$ | $\|D\| = n_0 + 2 n_8$ | Status & Exact Verifier Archive |
|---|---|---|---|
| $r = 0, 2, 4$ | $64, 96, 128, 160, 192, 256$ | — | **CLOSED** (`0` open $r \le 4$ systems in `nl242-lab/t94/open2_t100.json`) |
| $r = 6$ | $144$ | $-4 < 0$ | **CLOSED** (negative defect budget) |
| $r = 6$ | $128$ | $16$ | **CLOSED** (10 exact C++ verifiers in `t100/z128/`) |
| $r = 6$ | $112$ | $36$ | **CLOSED** (13 exact C++ verifiers in `t100/z112/`) |
| $r = 8$ | $136$ | $6$ | **CLOSED** ($n_0 \le 6 < 10$, contradicting $\mathrm{rank}(U) = 8$ and $U\mathbf{1} = 0$) |
| $r = 8$ | $120$ | $26$ | **CLOSED** (20 exact C++/Python verifiers in `t100/r8/`, detailed below) |

---

## Proof of `(t = 100, r = 6)`

Case structure, per-verifier claims, replay results and the derivations still to be written: [PROOF_t100_RANK6.md](PROOF_t100_RANK6.md).

### 1. `(t = 100, r = 6, |Z| = 128)` (`|D| = 16`): CLOSED
Archived in `t100/z128/` (10 standalone exact C++ verifiers):
- [check_z128_branchI.cpp](../t100/z128/check_z128_branchI.cpp), [test_z128_branchI_half.cpp](../t100/z128/test_z128_branchI_half.cpp), [solve_branchI_wt12_m02.cpp](../t100/z128/solve_branchI_wt12_m02.cpp), [solve_branchI_wt16_fast.cpp](../t100/z128/solve_branchI_wt16_fast.cpp), [solve_branchI_rest.cpp](../t100/z128/solve_branchI_rest.cpp), [solve_branchIIA.cpp](../t100/z128/solve_branchIIA.cpp), [solve_IIB1_02b4_exact.cpp](../t100/z128/solve_IIB1_02b4_exact.cpp), [solve_IIB12_r4_exact.cpp](../t100/z128/solve_IIB12_r4_exact.cpp), [solve_IIB2_r4_exact.cpp](../t100/z128/solve_IIB2_r4_exact.cpp), [solve_IIB4_exact.cpp](../t100/z128/solve_IIB4_exact.cpp).

### 2. `(t = 100, r = 6, |Z| = 112)` (`|D| = 36`): CLOSED
Archived in `t100/z112/` (13 standalone exact C++ verifiers):
- [gen_shapes_mt.cpp](../t100/z112/gen_shapes_mt.cpp), [scan_all_11_13.cpp](../t100/z112/scan_all_11_13.cpp), [scan_h14_p0_exact.cpp](../t100/z112/scan_h14_p0_exact.cpp), [scan_h16_p0_exact.cpp](../t100/z112/scan_h16_p0_exact.cpp), [scan_h16_p2.cpp](../t100/z112/scan_h16_p2.cpp), [kill_h16_p6_even.cpp](../t100/z112/kill_h16_p6_even.cpp), [kill_h16_p8.cpp](../t100/z112/kill_h16_p8.cpp), [kill_h8_p0.cpp](../t100/z112/kill_h8_p0.cpp), [kill_betaU1_fast.cpp](../t100/z112/kill_betaU1_fast.cpp), [kill_betaU_1H_exact_join.cpp](../t100/z112/kill_betaU_1H_exact_join.cpp), [solve_v0_6_minD36_exact.cpp](../t100/z112/solve_v0_6_minD36_exact.cpp), [fix_lv5_cases.cpp](../t100/z112/fix_lv5_cases.cpp), [test_H5_m2_fast.cpp](../t100/z112/test_H5_m2_fast.cpp).

---

## Proof of `(t = 100, r = 8, |Z| = 120)` (`n_0 + 2 n_8 = 26`)

In adapted rank-8 coordinates, $Q_8^-(u) = u_0 + u_1 + u_0 u_1 + u_2 u_3 + u_4 u_5 + u_6 u_7$ satisfies $|Z| = |\{Q_8^- = 0\}| = 120$, $|F| = |\{Q_8^- = 1\}| = 136$, and is self-dual ($Q^* = Q_8^-$). Here $Z_0 = \{0, u_1, \dots, u_m\} \subset Z$ ($m = n_0 - 1$) and $S_8 = \{u \in F : |f(u)| = 1\}$ ($|S_8| = n_8$) with $v := \bigoplus_{u \in S_8} u \in \mathbb{F}_2^8$.

### Core Exact Theorems (Zero Floating-Point Trust)

1. **Mod-4 Hyperplane Weight Law:**
   For every $y \in \mathbb{F}_2^8 \setminus \{0\}$, $w(y) := |\{u \in Z_0 : \langle y, u \rangle = 1\}|$ satisfies
   $$w(y) \equiv 2\bigl(Q^*(y) \oplus \langle y, v \rangle\bigr) \pmod 4,$$
   derived from $\sum_{\langle y, u\rangle=1} f(u)^2 \equiv 8t \equiv 0 \pmod{16}$. Translating $f(u) \mapsto f(u \oplus u_0)$ ($V(x) \mapsto (-1)^{u_0 \cdot x} V(x)$) for any $u_0 \in Z_0$ preserves $0 \in Z_0$, $|Z| = 120$, $n_0$, $n_8$, $t$, and the parity class of $(v = 0 / v \ne 0 / Q(v) = 1)$, so the minimum affine hyperplane intersection $d_{\mathrm{aff}}(Z_0) := \min_{y \ne 0} \min(w(y), n_0 - w(y))$ is WLOG attained on a linear hyperplane $H_y$ ($0 \notin H_y$).

2. **Exact Rational Proof of $H_{64}\ w \ge 6$** ([verify_h64_w_ge_6_exact.py](../t100/r8/verify_h64_w_ge_6_exact.py)):
   - $\mathrm{rank}(\mathrm{RM}(3, 7)|_{Z_{64}}) = 56 \implies \ker = 8 = \dim(Q_7 \cdot \mathrm{RM}(1, 7))$, so the phase $g|_{F_{64}}$ is **unique** up to spatial shift and global sign (zero quotient ambiguity; note $H_{56}$ has $\mathrm{quotient\_dim} = 8$, so **no** $H_{56}$ orbit is ever excluded by single-$g$ LPs).
   - Exhaustive check of all $\binom{64}{2} = 2,016$ pairs in $Z_{64}$: **$0$** valid 2-subsets.
   - Exhaustive check of all $\binom{64}{4} = 635,376$ 4-subsets of $Z_{64}$: exactly **$5,376$** valid 4-subsets, forming **2** $\mathrm{Stab}_{O^-(8,2)}(e_7)$-orbits of sizes $3,456$ and $1,920$.
   - Exact `fractions.Fraction` LP dual certificates (denominators $\le 128$) prove $\min n_8^{(1)} \ge 8$ on **both** orbits, ruling out $H_{64}\ w = 4$ for all $n_8 \le 7$ (hence every $n_0 \ge 12$ at $t = 100$).

3. **Exact Rational Signed $(Q^*, v)$-Weighted Delsarte Farkas Certificates** ([verify_delsarte_farkas_exact.py](../t100/r8/verify_delsarte_farkas_exact.py)):
   Using only $H_{64}\ w \ge 6$, standard Delsarte Krawtchouk identities, $Q^*$-weighted ($j = 1, 2$), $v$-weighted ($j = 1, \dots, 14$), and $(Q^*\cdot v)$-weighted ($j = 1$) identities (all verified on real valid codes; `QR(17)` feasibility positive control passes), **11/11** exact arbitrary-precision `fractions.Fraction` Farkas dual rays ($y_{\mathrm{ub}} \ge 0$, $y^T A \ge 0$, $y^T b < 0$) prove:
   - $n_0 = 18$ ($Q(v) = 0, 1$): $d_{\mathrm{aff}} \ge 6$ infeasible ($d_{\mathrm{aff}} \in \{2, 4\}$).
   - $n_0 = 20$ ($v = 0, Q(v) = 0, 1$): $d_{\mathrm{aff}} \ge 8$ infeasible ($d_{\mathrm{aff}} \in \{2, 4, 6\}$).
   - $n_0 = 22$ ($Q(v) = 0, 1$): $d_{\mathrm{aff}} \ge 8$ infeasible ($d_{\mathrm{aff}} \in \{2, 4, 6\}$).
   - $n_0 = 24$ ($Q(v) = 1$): $d_{\mathrm{aff}} \ge 10$ infeasible, AND $d_{\mathrm{aff}} = 8$ without an affine $H_{64}$ slice of size 8 infeasible.
   - $n_0 = 26$ ($v = 0$): $d_{\mathrm{aff}} \ge 10$ infeasible, AND $d_{\mathrm{aff}} = 8$ without an affine $H_{64}$ slice of size 8 infeasible ($w = 4$ impossible for $v = 0$).

4. **Exact $\mathrm{RM}(3, 8)$ Mod-8 $y_Z$ Enumeration Theorem (Zero LP, Zero Histogram Grouping):**
   Since $\mathrm{rank}(\mathrm{RM}(3, 8)|_Z) = 84$ ($\ker = 9 = \dim(Q_8^- \cdot \mathrm{RM}(1, 8))$), $g|_F$ is uniquely determined by $Z_0$ up to spatial shift and sign. For any fixed $S_8 \subset F$ of size $n_8$:
   - Exact orthogonality Parseval bound: $\mathrm{top}_{100}(|w_{F,\mathrm{true}}|) \ge 4(1224 - 8 n_8) = 4896 - 32 n_8$.
   - Writing $f(u) = 2 - 4 y_Z(u)$ on $Z \setminus Z_0$ ($m_Z = 120 - n_0$), Poisson summation on all 93 monomials $m \in \mathrm{RM}(3, 8)$ forces $M_3[:, Z \setminus Z_0]\, y_Z \equiv (M_3 f_{\mathrm{base}} / 4) \pmod 2$, leaving only $2^{m_Z - \mathrm{rk}}$ exact candidates ($2^{10} = 1,024$ for $n_0 = 26$, $\le 2^{13}$ for $n_0 = 24$, $\le 2^{15}$ for $n_0 = 22$), every one checked directly by `fwht256`.

5. **Exact Hyperplane & $v$-Orbit Tables** (computed and verified in [exact_H_orbits.cpp](../t100/r8/exact_H_orbits.cpp), [compute_v_orbits.cpp](../t100/r8/compute_v_orbits.cpp), [compute_v_orbits_H64_w6.cpp](../t100/r8/compute_v_orbits_H64_w6.cpp), [exact_H64_w8_and_n26_d8.cpp](../t100/r8/exact_H64_w8_and_n26_d8.cpp)):
   - $H_{56}\ w = 2$: 1 orbit (`28` sets, `{13, 15}`), 6 $v$-orbits (`Q=1: {2,6,18}`, `Q=0: {0,4,16}`), with $O^+(4,2) \times \mathbb{Z}_2$ (`144x`), $O^+(4,2)$ (`72x`), and $\mathrm{Stab}_{O^+(4,2)}(e_0) \times \mathbb{Z}_2$ (`16x`) symmetry modes all non-empty verified `sym=0` vs `sym>0` in [test_sym_nonempty.cpp](../t100/r8/test_sym_nonempty.cpp).
   - $H_{56}\ w = 4$: 1 orbit (`2,520` sets, [exact_orbs_H56_w4.txt](../t100/r8/exact_orbs_H56_w4.txt)), 10 $v$-orbits (`Q=1: 4`, `Q=0: 6`).
   - $H_{56}\ w = 6$: 10 exact orbits (`257,292` sets, [exact_orbs_H56_w6.txt](../t100/r8/exact_orbs_H56_w6.txt), $v$-orbits in [exact_v_orbits.txt](../t100/r8/exact_v_orbits.txt)).
   - $H_{64}\ w = 6$: 5 exact orbits (`580,608` sets, [exact_orbs_H64_w6.txt](../t100/r8/exact_orbs_H64_w6.txt), 120 $v$-orbits in [exact_v_orbits_H64_w6.txt](../t100/r8/exact_v_orbits_H64_w6.txt)).
   - $H_{64}\ w = 8$: 62 exact orbits (`46,644` sets, [exact_orbs_H64_w8.txt](../t100/r8/exact_orbs_H64_w8.txt)).

---

### Exhaustive Closure of Every $n_0$ at `(t = 100, r = 8, |Z| = 120)`

| $n_0$ ($n_8$) | Allowed $v$ / $d_{\mathrm{aff}}$ | Exhaustive Enumeration & Exact Verification | Verifier | Result |
|---|---|---|---|---|
| $\le 8$ | — | $\mathrm{rank}(U) = 8$, $U\mathbf{1} = 0 \implies n_0 \ge 10$ | Algebraic | **CLOSED** |
| $10$ ($8$) | — | Unique $[9, 1, \ge 3]$ LCD code gives $\|Z\| = 136 \ne 120$ | [verify_t102_r8_closed.cpp](../t102/verify_t102_r8_closed.cpp) | **CLOSED** |
| $12$ ($7$) | — | Unique $\|Z\| = 120$ geometry $S_{12}$ forces $n_8 \ge 51 > 7$ | [verify_t102_r8_closed.cpp](../t102/verify_t102_r8_closed.cpp) | **CLOSED** |
| $14$ ($6$) | All $v$ | `472` LCD codes $\to$ `30` ($v=0$) + `2` ($v \ne 0$); **all 32/32 individually killed** by exact integer dual witnesses ($\min\text{margin} = +320$) | [audit_n14_n16_exact.cpp](../t100/r8/audit_n14_n16_exact.cpp) | **CLOSED** |
| $16$ ($5$) | All $v$ | `5,185,911` LCD codes $\to$ `4,124` unique RREF reps (`1,236` $v=0$, `1,412` $Q(v)=0$, `1,476` $Q(v)=1$); **all 4,124/4,124 individually killed** by exact integer dual witnesses ($\min\text{margin} = +160$) | [audit_n14_n16_exact.cpp](../t100/r8/audit_n14_n16_exact.cpp) | **CLOSED** |
| $18$ ($4$) | $v = 0$ | Unique code `QR(17)` (`verify_t102_r8_closed.cpp`); all `53,550` XOR-0 4-subsets $S_8 \subset F$ checked (`53,142` killed by $\mathrm{top}_{100} < 4768$; `408` tight $= 4768$ uniquely force $V$, all `408/408` invalid; $t=102$ pos-ctrl recovers real $V$) | [verify_qr17_t100_standalone.cpp](../t100/r8/verify_qr17_t100_standalone.cpp) | **CLOSED** |
| $18$ ($4$) | $v \ne 0$, $d_{\mathrm{aff}} \in \{2, 4\}$ | `0` at $d=2$; `912` valid across 10 $v$-orbs at $d=4$ $\to$ explicit 256-pt verified $O^-(8,2)$ iso reduces to **5 exact $O^-(8,2)$ orbits**; **5/5 killed** by exact `Fraction` $L_1$ LP duals ($\min L_1 \ge 6,560 > 6,400$) | [audit_n18_n20_exact_orbits.cpp](../t100/r8/audit_n18_n20_exact_orbits.cpp), [certify_exact_o8_orbs_L1.py](../t100/r8/certify_exact_o8_orbs_L1.py) | **CLOSED** |
| $20$ ($3$) | All $v$, $d_{\mathrm{aff}} \in \{2, 4, 6\}$ | `109,846` valid codes across $H_{64}\ w=6$, $H_{56}\ w\in\{2,4,6\}$ $\to$ explicit 256-pt verified $O^-(8,2)$ iso reduces to **342 exact $O^-(8,2)$ orbits**; **342/342 killed** in exact `Fraction` arithmetic (`224` plain-infeasible Farkas + `118` $L_1$ duals, $\min L_1 \ge 6,569.89 > 6,400$; `QR(17)` pos-ctrl passes) | [audit_n18_n20_exact_orbits.cpp](../t100/r8/audit_n18_n20_exact_orbits.cpp), [certify_exact_o8_orbs_L1.py](../t100/r8/certify_exact_o8_orbs_L1.py) | **CLOSED** |
| $22$ ($2$) | $v \ne 0$, $d_{\mathrm{aff}} \in \{2, 4, 6\}$ | `1,267,047` valid codes across $H_{64}\ w=6$ (`5` orbs, `120` $v$-orbs), $H_{56}\ w\in\{2,4,6\}$ $\to$ explicit 256-pt verified $O^-(8,2)$ iso reduces to **8,655 exact $O^-(8,2)$ orbits**; **ZERO-LP exact check** across all `36` $S_8 = \{f_1, f_1\oplus v\} \subset F$ pairs (`311,580` pairs: `939` orbs killed by $\mathrm{top}_{100} < 4832$, `7,716` orbs / `253,362` pairs killed by exact $2^{\le 15}$ $y_Z$ enumeration, `101.76s`) | [solve_n22_o8_exact.cpp](../t100/r8/solve_n22_o8_exact.cpp) | **CLOSED (`REAL_V = 0`)** |
| $24$ ($1$) | $Q(v)=1$, $d_{\mathrm{aff}} \in \{2,4,6,8\}$ | `12,318,368` valid codes across $H_{64}\ w=8$ (`62` orbs: `0` valid), $H_{64}\ w=6$ (`5` orbs: `6,891,128`), $H_{56}\ w=6$ (`10` orbs, `91` $v$-orbs: `3,363,973`), $H_{56}\ w=4$ (`4` $v$-orbs: `1,409,160`), $H_{56}\ w=2$ (`3` $v$-orbs: `654,107`); **ZERO-LP code-by-code check** (`2,688,263` killed by $\mathrm{top}_{100} < 4864$, `9,630,105` killed by exact $2^{\le 13}$ $y_Z$ enumeration, `1112.37s`) | [solve_n24_exact.cpp](../t100/r8/solve_n24_exact.cpp) | **CLOSED (`REAL_V = 0`)** |
| $26$ ($0$) | $v = 0$, $d_{\mathrm{aff}} \in \{2, 6, 8\}$ | `1,413,762` valid codes across $H_{64}\ w=8$ (`62` orbs: `2,940`, `4.02s`), $H_{56}\ w=6$ (`10` orbs: `1,020,732`, `38s`), $H_{56}\ w=2$ (`144x` sym: `390,090`, `9.85s`); **ZERO-LP code-by-code check** ($\mathrm{top}_{100} < 4896$ + exact $2^{10} = 1,024$ $y_Z$ enumeration; `QR(17)` $t=102$ pos-ctrl recovers `12/12` on $H_{56}\ w=6$ and `4/4` on $H_{64}\ w=8$) | [solve_n26_v0_turbo.cpp](../t100/r8/solve_n26_v0_turbo.cpp), [exact_H64_w8_and_n26_d8.cpp](../t100/r8/exact_H64_w8_and_n26_d8.cpp) | **CLOSED (`REAL_V = 0`)** |

---

## Summary of Mandatory Positive Controls

Every engine in `t100/r8/` passed live positive controls before producing its closure verdict:
1. **`QR(17)` at `t = 102` (`n_0 = 18, n_8 = 0`)**:
   - `solve_n26_v0_turbo.cpp` recovered all **`12/12`** real $V$'s on $H_{56}\ w = 6$ (Orbit 7).
   - `exact_H64_w8_and_n26_d8.cpp` recovered all **`4/4`** real $V$'s on $H_{64}\ w = 8$.
   - `verify_qr17_t100_standalone.cpp` recovered the unique real $V$ ($\mathrm{top}_{102} = 4,896$, `ge = 102`).
   - `certify_exact_o8_orbs_L1.py` gave exact $\min L_1 = 6,528.00 = 64 \cdot 102$ at $n_8 = 0$, and $6,272.00 \le 6,400$ at $n_8 = 4$ (not falsely killed).
   - `verify_delsarte_farkas_exact.py` confirmed $(n_0 = 18, v = 0, d_{\mathrm{aff}} \ge 6)$ is **FEASIBLE**.
2. **Exact $v$-Orbit Completeness & Fixed-$v$ Turbo DFS**:
   - `solve_n24_exact.cpp` `[PC2]`: weighted sum $\sum_{v\text{-orb}} |\mathrm{orb}(v)| \cdot \mathrm{valid}(v)$ across the 10 $H_{56}\ w = 4$ $v$-orbits at $n_0 = 18$ matched **`16,128 == 16,128`** exactly.
   - `solve_n22_o8_exact.cpp` `[PC1]`: fixed-$v$ $H_{64}\ w = 6$ (Orbit 1, 24 $v$-orbs) at $m = 19$ recovered the exact `n_0 = 20` $132:1$ $O^-(8,2)$ orbit (`valid = 16, exact_O8_orbs = 1`).
3. **Non-Empty Exact Symmetry Breaking (`sym=0` vs `sym ∈ {1, 2, 3}`)**:
   - `test_sym_nonempty.cpp`: exact non-empty match on all 5 nonzero $v$-orbit reps of $H_{56}\ w = 2$:
     `v=2` (`m=19, d64=6`: `58,320` vs `19,602` $\to$ `4/4` hists),
     `v=4` (`510` vs `82` $\to$ `2/2`), `v=6` (`300` vs `40` $\to$ `1/1`),
     `v=16` (`880` vs `272` $\to$ `2/2`), `v=18` (`720` vs `416` $\to$ `1/1`).
4. **Mod-4 Sign-Flip & Parseval Checks**:
   - `solve_n24_exact.cpp` `[PC1]` ($n_8 = 1$: right sign `mod4_bad = 0`, wrong sign `mod4_bad = 15`, $L_2^2 = 311,296 = 256 \cdot 1216$).
   - `solve_n22_o8_exact.cpp` / `solve_n22_exact.cpp` ($n_8 = 2$: `36` pairs for both $Q(v)=0$ and $Q(v)=1$, `mod4_bad = 0`, $L_2^2 = 309,248 = 256 \cdot 1208$).

Therefore, **no balanced 9-variable $\mathrm{NL} = 242$ Boolean function exists at $t = 100$.** $\square$
