# t = 100, rank 6: case structure, verifiers and replay record

This document covers the rank-6 part of `t = 100`, which `PROOF_t100_CLOSED.md` only lists
as file names. For each case it records what the verifier checks and what it printed on an
independent replay (Colab, 8 cores, 2026-11-22; every verifier exited with code 0).

**Status (updated after full reduction & completeness audit, 2026-11-22).**
- Every reduction listed previously as unwritten is now **proved in full** in Section 5 of `t100.tex` and verified independently by three standalone C++17 programs included directly in this packet (and run automatically by `verify_quick.sh`):
  1. `t100/z128/verify_z128_reductions.cpp` (`0.21s`, exit 0): checks all 288 local group identities, regenerates all 11 Branch I orbits under `G_lit` (`|G_lit| = 23,040`), checks all 2,604 affine 4-flats of Branch II-A, proves the Branch II-B Gram identity and `Sp(6,2)` orbit coverage (`0x0025`, `0x0028`, `0x02b4`) across all 32,768 quadratic forms, confirms 0 arithmetic solutions for II-B2 and II-B3 under the Zero-Set Rank Bound (`wt(v) <= 62 - rank(p)`), and regenerates all 10 Branch II-B4 isotropic-plane orbits (`5,040/5,040`).
  2. `t100/z112/check_small_masks.cpp` (`8s`, exit 0): exhaustively excludes `9 <= k <= 15` for `t ∈ {94, 96, 98, 100}` (`0` survivors); combined with the hand proof of `k >= 9` from `Balanced242Plateau.section_0_b_0`, this proves `k >= 16` (`h = 32 - k <= 16`, 45 pairs `(h, p)`).
  3. `t100/z112/verify_z112_all45_exact.cpp` (`24.9s`, exit 0): passes 7 mandatory positive controls (`PC1`–`PC7`), scans all 45 `(h, p)` pairs (`302` level hits `-> 175` killed by exact `2*` `check_v0` `+ 16` killed by `H_5 m_2 >= 2` `-> 111` live), and kills all `111/111` live cases (`0` survivors).
- **Three genuine bugs/omissions caught and closed in the legacy `t100/z112/` scripts:**
  1. `scan_all_11_13.cpp` and `scan_h16_p2.cpp` charged `4` instead of `2` defects per `F_6`-group with `|z_0| ∈ {4, 8}` (falsified by `f = (1, 3, 3, -3)` with `z_0 = 4, 2n_8 = 2`), plus an unproven `+8` offset at `β_V = 0` (the true offset is `+2`).
  2. `(h, p) = (16, 1)` (`x_0 ∈ E'` on size 15) was never scanned and has a genuine survivor (`E = 0x50500330537, F = 0x1, rem = 1, minD = 32`).
  3. `(h, p) = (0, 0)` (now closed by hand via Parseval `m_2 >= 16 > 10`) and two `(16, 0)` orbits (`0xff00ff` and `0xcc003300ff`) were omitted from `kill_betaU1_fast.cpp`.
  `t100/z112/verify_z112_all45_exact.cpp` supersedes those legacy `t100/z112/` scripts (which are retained for archival replay traceability).

## Setup

Notation follows `PROOF_t102_CLOSED.md`:
- V and U are the low and high blocks, with `wt(V) = t = 100`.
- `lo = 2·V̂`, and `Z = {a : 16 | lo(a)}`.
- `n_0 = #{lo = 0}` and `n_8 = #{|lo| = 8}`.
- Parseval on `V̂/4` gives the defect budget

  `|D| = n_0 + 2·n_8 = (2304 − 5|Z| − 16t)/4 = (704 − 5|Z|)/4`.

At rank 6, `|Z| ∈ {112, 128, 144}`:

| `|Z|` | `|D|` | status |
|---|---|---|
| 144 | −4 | impossible (negative budget) |
| 128 | 16 | complete reductions in `t100.tex` + 11 exact C++ verifiers in `t100/z128/` (incl. `verify_z128_reductions.cpp`) |
| 112 | 36 | complete reductions in `t100.tex` + master `verify_z112_all45_exact.cpp` & `check_small_masks.cpp` (+ 13 legacy scripts) in `t100/z112/` |

In adapted rank-6 coordinates `F_2^2 × F_2^6`, V splits into four 64-point cells, and
`z_x = WHT_6(v_x)` is the transform of cell `x`.

## `|Z| = 128`, `|D| = 16`

The cells are written `v00, v01, v10, v11`, with transforms `z00, z01, z10, z11`.
- `q6` is the rank-6 phase form on `F_2^6`.
- `L00` and `L01` are the affine parts of the cell residues.
- The defect `|D| = 16` is spread over points c via counters `d_c ∈ {0,1,2}` and `k_c ∈ {0,1}`.
- Wherever a verifier needs the allowed `(z, z′)` value pairs at a point, it computes them
  by brute force over all `(V00, V01, V10, V11)` for the given `(q6(c), d_c, k_c)`. Nothing
  is hand-tabulated.

The case tree used by the verifiers:

| Branch | Condition | Sub-cases | Verifier | Replay result |
|---|---|---|---|---|
| I | `L00 = 1_H` (H a hyperplane) | 11 orbits: 9 of weight 12, 2 of weight 16 | see the four rows below | |
| I, half test | each orbit, both 32-point halves | 11 orbits | `test_z128_branchI_half.cpp` | survivor counts per orbit and half (e.g. weight-16: 16,384/65,536 per half) |
| I, mod-512 autocorrelation | all 416 words of weight ≤ 16 in `1_H·q6 + RM(2,6)` | n/a | `check_z128_branchI.cpp` | RC 0 |
| I, weight 12, `m0 = 2` | 4 orbits (0, 3, 5, 7) | 32 `p_self` classes each | `solve_branchI_wt12_m02.cpp` | 0 full pair joins |
| I, weight 12, `m0 = 1, k1 = 1` | 5 orbits (1, 2, 4, 6, 8) | 128 classes each | `solve_branchI_rest.cpp` | 0 full pair joins |
| I, weight 16 | 2 orbits (`6Z,10F` and `10Z,6F`) | all 65,536 normalised `p00` (`16,384` pass `L0` on `H^c`) and all 65,536 `p01|_H` (`16,384` pass `has_L0_any`) | `solve_branchI_wt16_fast.cpp` | 0 full pair joins (`1.4s`/orbit) |
| II-A | `L00 = 0`, `L01 = 1`, `u = 1_W` (W the bent 4-flat), `k ≡ 0` | 8,192 of 4,194,304 `p00` survive the C mod-16 filter | `solve_branchIIA.cpp` | 0 joins (pair00 and pair01) |
| II-B1, `p01` of rank 6 | `|M| = 8`, `k2 = 0`, `p01 = 0x02b4` | 288 cliques → 25 `Stab_{O+(6,2)}` orbits (`|Stab| = 14`), generated in the verifier | `solve_IIB1_02b4_exact.cpp` | 0 hits |
| II-B1, `p01` of rank 4 | `p01 ∈ {0x0025, 0x0028}`, B = 24 | n/a | `solve_IIB12_r4_exact.cpp` | 0 hits each |
| II-B2, `p01` of rank 4 | `|M| = 6`, `k2 = 1`, `p01 = 0x0025`, tight cases A (B = 22) and B (B = 23) | n/a | `solve_IIB2_r4_exact.cpp` | 0 hits each |
| II-B4 | `k1 = 4`, `|M| = 4`, `|K2| = 0` | 10 `Stab(P)`-orbits of isotropic 2-planes `K1` | `solve_IIB4_exact.cpp` | 0 full hits in all 10 |

- Note on the weight-16 Branch I orbits:
  - `solve_branchI_rest.cpp` also runs these two orbits without coupling `s_A` to `p01|_H` or filtering `has_L0_any`, reporting 589,824 uncoupled 32×32 pair joins for each.
  - They close to `0` joins in `solve_branchI_wt16_fast.cpp` using:
    1. the exact global 64× normalization `v'_{ab}(y) = (-1)^s v_{ab}(y + (0, y'))` giving WLOG `p'_{00}|_H = p'_{00}|_{H^c}` and the companion `has_L0_any` filter on `p'_{01}|_H`;
    2. the exact 22-bit degree-4/5/6 subcube syndrome on `A(c) = z00(c) + z10(c)` mod 16 with `s_A(c) = [(A(c) − 4) mod 16 == 8]` over the 8 sites `H^c ∩ U`.
  - **Resolved:** Both steps are proved in full in **Lemma 5.2 (`lem:wt16`)** of `t100.tex` and verified bit-for-bit against `solve_branchI_wt16_fast.cpp` by `[PASS 5]` of `t100/z128/verify_z128_reductions.cpp` (64/64 local tuples, `opts_L0` `H <-> H^c` symmetry, `|H^c ∩ U| = |H ∩ U| = 8`, and 22-bit subcube positive control).

## `|Z| = 112`, `|D| = 36`

Here `Q(a, c) = Q6(c)` with `|{Q6 = 0}| = 28`, as at `t = 102`. The low-block defect set
in `F_2^6` is classified by a pair `(h, p)` using orbit tables of point sets under
`Sp(6,2) ⋉ F_2^6`.

| Step | Verifier | Replay result |
|---|---|---|
| Orbit tables `shapes9..15` | `gen_shapes_mt.cpp` | shapes10 = 2,965 (positive control); shapes11–14 = 11,356 / 43,902 / 161,196 / 560,256 (checksum matches) |
| `(h, p)` scan on sizes 11–13 | `scan_all_11_13.cpp` | survivors: h12p0 (1), h14p1 (1), h14p2 (14), h16p4 (3); all other listed `(h, p)` give 0 |
| `h = 14, p = 0` | `scan_h14_p0_exact.cpp` | 1 orbit (`0x220011001100ff`) |
| `h = 16, p = 0` | `scan_h16_p0_exact.cpp` | 6 orbits (positive control on 9,800 extensions passes) |
| `h = 16, p = 2` | `scan_h16_p2.cpp` | 1 orbit; cross-check `h14p0` count = 1 |
| `β_U ≡ 1` cases (h16p0 b/c, h16p2, h16p4, h12p0) | `kill_betaU1_fast.cpp` | 0 hits each (weight-4 positive control finds 9,458) |
| `β_U = 1_H` cases (h16p0a, h10p0a, h14p2 a/e, h14p1) | `kill_betaU_1H_exact_join.cpp` | 0 alive triples in every case (positive control re-finds a real u) |
| `h = 16, p = 8` | `kill_h16_p8.cpp` | 0 hits over all 32,768 forms (min `|S_2|` = 99 > 12) |
| `h = 16, p = 6` (even levels) | `kill_h16_p6_even.cpp` | 0 hits |
| `h = 8, p = 0` | `kill_h8_p0.cpp` | 0 hits for cost 0–5 over all 32,768 forms |
| level-5 cases (h16p6 odd #1–4, h16p0a) | `fix_lv5_cases.cpp` | 0 hits / 0 alive triples |
| `|V0| = 6`, `β = 1_H`, `min_D = 36` | `solve_v0_6_minD36_exact.cpp` | 0 joins |
| auxiliary lemma on `F_2^5` | `test_H5_m2_fast.cpp` | no d with `|WHT_5(d)| ∈ {2,6}` and `m_2 ∈ {0,1,3}`; 13,888 with `m_2 = 2`; 555,520 with `m_2 = 4` |

## Resolution of all five derivations (written in full in `t100.tex`, Section 5)

1. **`|Z| = 128` case tree completeness & hand closure of II-B2 / II-B3:**
   - Proved in `t100.tex` Lemmas 5.1, 5.3, 5.4 and Proposition 5.5: autocorrelation forces `|K_1|` even (`≠ 2`) and `⊕_{K_1} = 0`; mod-16 Gram identity forces `⊕_{M Δ K_1} = 0`, hence `⊕_M = 0` (`|M| ≠ 2`), and `G = J(B + (1 + τ)J)J` has `r_G = 6` on all 315 isotropic rank-2 forms (`τ = ω(u, v) = 0`), so `r_G = 2` occurs only on the 336 hyperbolic rank-2 forms (`{r_0, r_1} = {2, 4}`); for `K_1 = ∅`, a 6-line proof forces `p00 ≡ 0`; and the Zero-Set Rank Bound (`wt(v) <= 62 - rank(p)`) kills **both II-B3** (`N <= 26 < 58`) **and II-B2** (`wt(v11) >= 58 > 56`) completely by hand and pins II-B1 `(4, 6)` to `B = 24`.
2. **`|Z| = 128` orbit generation (`t100/z128/verify_z128_reductions.cpp`):**
   - Regenerates all 11 Branch I orbits (`2` wt-16 + `9` wt-12) under `G_lit` (`|G_lit| = 23,040`), all `32,768` quadratic forms `p01` with exact `Sp(6,2)` orbit coverage by `0x0025` (`4,032`), `0x0028` (`3,780`), and `0x02b4` (`2,880 + 2,880 = 5,760`, where the exact `GL(8, 2)` shear `(x_0, x_1, y) ↦ (x_0 + x_1, x_1, y)` / `(w_0, w_1, c) ↦ (w_0, w_0 + w_1, c)` fixes `Q = w_0 + q_6` pointwise and exchanges `v01 ↔ v11`, `p01 ↔ p11 = p01 + 1 + q_6`, mapping the two `2,880`-element orbits bijectively), and all `10` Branch II-B4 orbits covering all `5,040` affine isotropic 2-planes.
3. **Branch I weight-16 normalisation & syndrome (`t100.tex` Lemma 5.2):**
   - Translating `(v00, v10)` by `(0, y')` and global sign `(-1)^s` (`64` symmetries) fixes `p00|_{H^c}` and shifts `p00|_H` by an arbitrary affine function; since `p00 ∈ RM(2,6)`, a unique shift makes `p00|_H = p00|_{H^c}` (`589,824 = 64 × 9,216`). Requiring `p01|_H` to admit a valid `(v01, v11)` half-pair (and matching the 22-bit degree-4..6 syndrome `s_A`) eliminates all `9,216` pairs.
4. **`|Z| = 112` `(h, p)` scheme, range `0 <= h <= 16`, and 1-WHT mod-3 identity (`t100.tex` Prop. 5.6 & Lemma 5.7):**
   - `h = |V_0| + 2|F| = 32 - k` (even), `lv(c) = 3 + Q_6(c)s(c)/2 ∈ [0, 12]`.
   - `k >= 9` proved by hand from `Balanced242Plateau.section_0_b_0` (`b' = 80, m = 16 => p_1 = 24 => h >= 48 > 32`); `k ∈ {10, 12, 14}` closed by `t100/z112/check_small_masks.cpp` (`0` survivors).
   - 1-WHT mod-3 extension identity `#{3 | lv(c)} = (wt(f) - Q_6(x_0) f_hat(x_0))/2` proved and brute-force verified on `12,800` extensions (`PC3`).
5. **Exact `β_U` classification & audited all-45 `(h, p)` closure (`t100.tex` Lemma 5.8, Remark 5.9, `verify_z112_all45_exact.cpp`):**
   - `β_U(c) = lv(c) mod 2 = (1 + p + (1/2) Σ_{V_0} Q_6) + c · ⊕_{V_0} ∈ RM(1, 6)`. All **three** affine types occur (`β_U ≡ 1`, `β_U = 1_H`, and `β_U ≡ 0` at `h = 16, p = 6`); on the low side, `β_V ≡ 1` forces `|V_0| >= 20 > 16`.
   - `(h, p) = (0, 0)` is closed by hand (`m_2 >= 16 > 10` across all 4 ranks); all `111/111` live cases across all 45 `(h, p)` pairs are closed in `t100/z112/verify_z112_all45_exact.cpp` (`0` survivors, `7/7` positive controls passing).

## Replay

Run `bash verify_quick.sh` from the packet root (which runs `verify_z128_reductions.cpp`, `check_small_masks.cpp`, and `verify_z112_all45_exact.cpp` automatically), or compile any individual verifier inside its directory:

```sh
g++ -O3 -std=c++17 -pthread <file>.cpp -o /tmp/x && /tmp/x
```

- `t100/z112/verify_z112_all45_exact.cpp` regenerates `shapes0..10` from scratch and reads `shapes/shapes11..15.bin` (cross-checking `shapes10.bin`).
- `gen_shapes_mt.cpp` regenerates all shape tables and checks them against the stored ones.
