"""Independent Stage A + Stage B for the k=16 branch (own code, own conventions).

Stage A: all balanced f in RM(3,5) with |W_f(h)| in {0,8,16} for h != 0, then their AGL(5,2) orbits.
Stage B: for every orbit rep Y = supp(f) (16 points), D' = span{1, coordinates on Y} (6-dim),
C' = D'^perp (10-dim), and every index-2 subcode C of C' containing 1 (511 of them).
Necessary conditions: nonzero weights of C >= 4; b + C (b in C' \\ C) has weight
distribution {4:40,6:96,8:240,10:96,12:40}.  K = columns of a basis (1, g1..g8) of C,
T(x) = sum_j (-1)^{b_j + a_j.x}, u = T mod 3 (ternary).  Keep u with wt 136 and |W_u| in {4,12}.
Writes every surviving u (no reduction by Aut(Y)) to the output file.
"""
import sys, itertools
import numpy as np
from collections import Counter

def fwht(a):
    a = np.array(a, dtype=np.int64)
    n = a.shape[-1]; h = 1
    while h < n:
        a = a.reshape(a.shape[:-1] + (n // (2 * h), 2, h))
        x = a[..., 0, :].copy(); y = a[..., 1, :].copy()
        a[..., 0, :] = x + y; a[..., 1, :] = x - y
        a = a.reshape(a.shape[:-3] + (n,)); h *= 2
    return a

pts5 = np.arange(32)
bit = lambda x, i: (x >> i) & 1
# monomial truth tables on F_2^5
def mono(S):
    t = np.ones(32, dtype=np.int64)
    for i in S: t &= bit(pts5, i)
    return t
low = [mono(S) for d in range(3) for S in itertools.combinations(range(5), d)]   # 16 of degree <= 2
cub = [mono(S) for S in itertools.combinations(range(5), 3)]                      # 10 cubic
assert len(low) == 16 and len(cub) == 10
lowmat = np.array(low)                       # 16 x 32
masks16 = ((np.arange(1 << 16)[:, None] >> np.arange(16)) & 1)   # 65536 x 16
lowtabs = (masks16 @ lowmat) & 1                                    # all RM(2,5) tables
S = set()
for cm in range(1024):
    c = np.zeros(32, dtype=np.int64)
    for i in range(10):
        if (cm >> i) & 1: c ^= cub[i]
    tabs = lowtabs ^ c
    wt = tabs.sum(axis=1)
    sel = tabs[wt == 16]
    W = np.abs(fwht(1 - 2 * sel))
    ok = np.all((W[:, 1:] == 0) | (W[:, 1:] == 8) | (W[:, 1:] == 16), axis=1)
    for t in sel[ok]:
        S.add(int((t << np.arange(32)).sum()))
print("Stage A: balanced RM(3,5) functions with |W| in {0,8,16}:", len(S))

# AGL(5,2) generators as point maps on F_2^5: swap(0,1), 5-cycle, transvection x0 += x1, translation by e0
def perm_of(phi): return [phi(x) for x in range(32)]
def swap01(x): return (x & ~3) | (bit(x, 0) << 1) | bit(x, 1)
def cyc(x): return ((x << 1) & 31) | (x >> 4)
def transv(x): return x ^ bit(x, 1)
def transl(x): return x ^ 1
gens = [perm_of(g) for g in (swap01, cyc, transv, transl)]
def act(t, p):   # f'(x) = f(p(x))
    r = 0
    for x in range(32):
        if (t >> p[x]) & 1: r |= 1 << x
    return r
seen = set(); orbits = []
for s in sorted(S):
    if s in seen: continue
    orb = [s]; seen.add(s); q = [s]
    while q:
        cur = q.pop()
        for p in gens:
            n = act(cur, p)
            if n not in seen:
                assert n in S, "set not AGL-invariant?!"
                seen.add(n); orb.append(n); q.append(n)
    orbits.append((s, len(orb)))
print("Stage A: AGL(5,2) orbits:", len(orbits), "sizes", sorted(o[1] for o in orbits), "sum", sum(o[1] for o in orbits))

# ---- GF(2) helpers on python ints (bit j = coordinate j) ----
def rref(rows):
    """Row-reduced basis (by leading bit) of the span of rows."""
    piv = {}
    for r in rows:
        x = r
        while x:
            hb = x.bit_length() - 1
            if hb in piv: x ^= piv[hb]
            else: piv[hb] = x; break
    return list(piv.values())
def span(basis):
    out = [0]
    for b in basis: out += [x ^ b for x in out]
    return out
def dual(basis, n):
    # brute force: all vectors orthogonal to basis (n = 16 -> 65536)
    return [v for v in range(1 << n) if all(bin(v & b).count('1') % 2 == 0 for b in basis)]
pc = lambda x: bin(x).count('1')
PAR = np.array([[pc(a & x) & 1 for x in range(256)] for a in range(256)], dtype=np.int64)   # a.x mod 2
target = Counter({4: 40, 6: 96, 8: 240, 10: 96, 12: 40})
out = open(sys.argv[1], 'w'); summary = []
for rep, size in orbits:
    Y = [x for x in range(32) if (rep >> x) & 1]
    one = (1 << 16) - 1
    Dp = [one] + [sum(bit(Y[j], i) << j for j in range(16)) for i in range(5)]
    assert len(rref(Dp)) == 6
    Cp = dual(Dp, 16); assert len(Cp) == 1024 and one in Cp
    Cp_basis = rref(Cp); assert len(Cp_basis) == 10
    # basis of C' with 1 first
    bas = [one]
    for v in Cp_basis:
        if len(rref(bas + [v])) > len(bas): bas.append(v)
    assert len(bas) == 10
    nvalid = 0; npass = Counter()
    for phi in range(1, 512):             # functional: 0 on 1, phi_i on bas[1+i]
        C_basis = [one]; bvec = None
        # kernel of phi restricted to bas[1:]
        vals = [(phi >> i) & 1 for i in range(9)]
        piv = vals.index(1)
        for i in range(9):
            if i == piv: continue
            C_basis.append(bas[1 + i] ^ (bas[1 + piv] if vals[i] else 0))
        bvec = bas[1 + piv]
        C = span(C_basis); assert len(set(C)) == 512
        if min(pc(c) for c in C if c) < 4: continue
        npass['mindist'] += 1
        if Counter(pc(bvec ^ c) for c in C) != target: continue
        npass['coset'] += 1
        # K: column j -> a_j = (g1[j],...,g8[j])
        g = C_basis[1:]
        a = [sum(((g[i] >> j) & 1) << i for i in range(8)) for j in range(16)]
        assert len(set(a)) == 16
        T = np.zeros(256, dtype=np.int64)
        for j in range(16):
            T += 1 - 2 * (((bvec >> j) & 1) ^ PAR[a[j]])
        u = np.where(T % 3 == 0, 0, np.where(T % 3 == 1, 1, -1))
        if int(np.abs(u).sum()) != 136: continue
        npass['wt136'] += 1
        Wu = fwht(u)
        if not set(np.abs(Wu).tolist()) <= {4, 12}: continue
        small = sorted(int(i) for i in np.where(np.abs(Wu) == 4)[0])
        npass['spectrum'] += 1
        assert small == sorted(a), "small frequencies differ from K"
        nvalid += 1
        out.write(' '.join(str(int(t)) for t in u) + '\n')
    summary.append((size, dict(npass), nvalid))
    print(f"orbit size {size:6d}: passes {dict(npass)} -> valid lifts {nvalid}")
out.close()
print("TOTAL valid (Y-rep, C) lifts:", sum(s[2] for s in summary))
