#!/bin/sh
# Cross-check of the direct t = 114/116 endpoint exclusion.
# Needs Python 3 with numpy and a C++17 compiler.  PYTHON may name the interpreter command
# (word-split, e.g. PYTHON="uv run --no-project --with numpy python"); THREADS sets threads.
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
out=$(mktemp -d "${TMPDIR:-/tmp}/endpoint-crosscheck.XXXXXX")
PY=${PYTHON:-python3}
th=${THREADS:-2}
echo "outputs in $out"
$PY -I "$here/verify_t114_t116_unconditional.py" > "$out/antigravity.txt"
$PY -I "$here/indep_k16.py" "$out/lifts_all.txt" > "$out/stage_ab.txt"
"${CXX:-c++}" -O3 -std=c++17 -pthread "$here/bf_quad.cpp" -o "$out/bf_quad"
n=0
while IFS= read -r line; do
  n=$((n + 1)); printf '%s\n' "$line" > "$out/u.txt"
  printf 'lift %d: ' "$n"
  "$out/bf_quad" "$out/u.txt" "$th" 28 --reduce | grep -E 'reduce|max score|score>=|peak|RESULT' | tr '\n' ' '
  echo
done < "$out/lifts_all.txt" > "$out/lifts_reduced.txt"
last=$(wc -l < "$out/lifts_all.txt" | tr -d ' ')
for n in 1 "$last"; do
  sed -n "${n}p" "$out/lifts_all.txt" > "$out/u$n.txt"
  "$out/bf_quad" "$out/u$n.txt" "$th" 28 > "$out/full_lift$n.txt"
  "$out/bf_quad" "$out/u$n.txt" "$th" 12 --positive-control > "$out/positive_control_lift$n.txt"
done
echo "== Antigravity checker"; tail -1 "$out/antigravity.txt"
echo "== independent Stage A/B"; cat "$out/stage_ab.txt"
echo "== all lifts, reduced sweep (counts are per translation class; multiply by 2^r)"
sed 's/^lift [0-9]*: //' "$out/lifts_reduced.txt" | sort | uniq -c
for n in 1 "$last"; do
  echo "== lift $n, full 2^28 sweep"; grep -E 'max score|score>=|forced|RESULT' "$out/full_lift$n.txt"
  echo "== lift $n, positive control on supp(u)"; grep -E 'RESULT' "$out/positive_control_lift$n.txt"
done
