// Independent brute force for the k=16 low-complement step at t=116.
// For a high block u (ternary table on F_2^8), gamma_u(a) = ((W_u(a)-4)/8) mod 2.
// Every candidate low block v has gamma_v = gamma_u + Q with deg Q <= 2, and needs
// score(Q) = sum_{x : u(x)=0} |W_{gamma_v}(x)| >= 2304.  We enumerate ALL 2^28 quadratic
// parts; the 2^8 linear parts are translations of W (all scored at once by XOR
// convolution); the constant only negates W.  No coordinate split, no rank cases.
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <vector>
#include <thread>
#include <mutex>
#include <algorithm>
static inline void fwht(int32_t *a) {
  for (int h = 1; h < 256; h <<= 1)
    for (int i = 0; i < 256; i += 2 * h)
      for (int j = i; j < i + h; ++j) { int32_t x = a[j], y = a[j + h]; a[j] = x + y; a[j + h] = x - y; }
}
int u[256], Wu[256], gu[256], Zm[256]; int32_t FZ[256]; int THR = 2304, N4 = 48;
int monos[28][64]; int sub[28]; int nsub = 28;
struct Res { long long ge = 0, eq = 0, gt = 0, wzero = 0, valid = 0; int mx = 0, minpk = 1 << 30, maxpk = 0; long long hist[8] = {0}; };
std::mutex mtx;
void work(uint64_t lo, uint64_t hi, Res *R) {
  int32_t s[256], W[256], A[256];
  uint64_t g0 = lo ^ (lo >> 1);
  for (int a = 0; a < 256; ++a) s[a] = gu[a] ? -1 : 1;
  for (int k = 0; k < nsub; ++k) if ((g0 >> k) & 1) for (int t = 0; t < 64; ++t) s[monos[sub[k]][t]] = -s[monos[sub[k]][t]];
  for (uint64_t c = lo; c < hi; ++c) {
    if (c != lo) { int k = sub[__builtin_ctzll(c)]; for (int t = 0; t < 64; ++t) s[monos[k][t]] = -s[monos[k][t]]; }
    memcpy(W, s, sizeof W); fwht(W);
    for (int i = 0; i < 256; ++i) A[i] = W[i] < 0 ? -W[i] : W[i];
    fwht(A);
    for (int i = 0; i < 256; ++i) A[i] *= FZ[i];
    fwht(A);  // A[l] = 256 * sum_{x in Z} |W(x ^ l)|
    for (int l = 0; l < 256; ++l) {
      int sc = A[l] >> 8;
      if (sc > R->mx) R->mx = sc;
      int b = (THR - sc + 31) / 32; if (b >= 0 && b < 8) R->hist[b]++;  // scores in (2304-32(b+1), 2304-32b]
      if (sc < THR) continue;
      R->ge++; if (sc == THR) R->eq++; else R->gt++;
      // forced v(x) = -sign W(x^l) on Z (exact at equality); check the low cap |W_v| <= 12
      int32_t v[256]; bool zero = false;
      for (int x = 0; x < 256; ++x) {
        if (!Zm[x]) { v[x] = 0; continue; }
        int w = W[x ^ l]; if (w == 0) zero = true; v[x] = w > 0 ? -1 : 1;
      }
      if (zero) R->wzero++;
      // direct recheck of the score
      int dsum = 0; for (int x = 0; x < 256; ++x) if (Zm[x]) dsum += std::abs(W[x ^ l]);
      if (dsum != sc) { fprintf(stderr, "score mismatch\n"); exit(2); }
      fwht(v); int pk = 0, n4 = 0; bool ok = true;
      for (int i = 0; i < 256; ++i) { int t = std::abs(v[i]); pk = std::max(pk, t); if (t == 4) n4++; else if (t != 12) ok = false; }
      if (ok && n4 == N4) R->valid++;
      R->minpk = std::min(R->minpk, pk); R->maxpk = std::max(R->maxpk, pk);
    }
  }
}
int main(int argc, char **argv) {
  if (argc < 2) { fprintf(stderr, "usage: bf_quad u.txt [nthreads] [log2count]\n"); return 1; }
  FILE *f = fopen(argv[1], "r"); for (int i = 0; i < 256; ++i) if (fscanf(f, "%d", &u[i]) != 1) return 1; fclose(f);
  int nt = argc > 2 ? atoi(argv[2]) : (int)std::thread::hardware_concurrency();
  int lg = argc > 3 ? atoi(argv[3]) : 28;
  bool pcmode = argc > 4 && !strcmp(argv[4], "--positive-control");
  int32_t t[256]; int wt = 0;
  for (int i = 0; i < 256; ++i) { t[i] = u[i]; wt += u[i] != 0; Zm[i] = pcmode ? u[i] != 0 : u[i] == 0; }
  fwht(t); int n4 = 0;
  for (int i = 0; i < 256; ++i) { Wu[i] = t[i]; int m = std::abs(t[i]); if (m == 4) n4++; else if (m != 12) { printf("bad |W_u|\n"); return 1; } gu[i] = ((t[i] - 4) / 8) & 1; if ((t[i] - 4) % 8) return 1; }
  if (pcmode) { THR = 12 * (256 - n4) - 4 * n4; N4 = n4; printf("POSITIVE CONTROL: target set supp(u), threshold %d; u itself must be found\n", THR); }
  printf("wt(u)=%d  #|W_u|=4: %d  |Z|=%d\n", wt, n4, 256 - wt);
  // PC: sum_x u(x) W_{gamma_u}(x) = sum_a (-1)^{gamma_u(a)} W_u(a) = 4*16 - 12*240
  int32_t g[256]; for (int a = 0; a < 256; ++a) g[a] = gu[a] ? -1 : 1; fwht(g);
  long long pc = 0; for (int x = 0; x < 256; ++x) pc += (long long)u[x] * g[x];
  printf("PC sum u*W_gamma_u = %lld (expect %d)\n", pc, 4 * n4 - 12 * (256 - n4));
  for (int i = 0; i < 256; ++i) FZ[i] = Zm[i]; fwht(FZ);
  int k = 0;
  for (int i = 0; i < 8; ++i) for (int j = i + 1; j < 8; ++j) { int c = 0; for (int a = 0; a < 256; ++a) if (((a >> i) & 1) && ((a >> j) & 1)) monos[k][c++] = a; ++k; }
  for (int i = 0; i < 28; ++i) sub[i] = i;
  int r = 0;
  if (argc > 4 && !strcmp(argv[4], "--reduce")) {
    // quadratic part of D_e gamma_u for e = unit vectors; score is invariant under Q2 -> Q2 + span
    auto anf = [](int *t) { for (int h = 1; h < 256; h <<= 1) for (int i = 0; i < 256; i += 2 * h) for (int j = i; j < i + h; ++j) t[j + h] ^= t[j]; };
    std::vector<uint32_t> M;
    for (int e = 0; e < 8; ++e) {
      int d[256]; for (int a = 0; a < 256; ++a) d[a] = gu[a] ^ gu[a ^ (1 << e)];
      anf(d); uint32_t m = 0; int kk = 0;
      for (int i = 0; i < 8; ++i) for (int j = i + 1; j < 8; ++j) { if (d[(1 << i) | (1 << j)]) m |= 1u << kk; ++kk; }
      for (int a = 0; a < 256; ++a) if (__builtin_popcount(a) >= 3 && d[a]) { printf("contraction has degree>2?!\n"); return 1; }
      M.push_back(m);
    }
    // row-reduce, then greedily pick unit monomials outside the span
    std::vector<uint32_t> piv(32, 0);
    auto ins = [&](uint32_t v) { for (int b = 31; b >= 0; --b) if ((v >> b) & 1) { if (!piv[b]) { piv[b] = v; return true; } v ^= piv[b]; } return false; };
    for (auto m : M) if (ins(m)) ++r;
    nsub = 0; for (int k = 0; k < 28; ++k) if (ins(1u << k)) sub[nsub++] = k;
    if (r + nsub != 28) { printf("rank bookkeeping failed\n"); return 1; }
    lg = nsub;
    printf("reduce: contraction rank r=%d, enumerating 2^%d quadratic parts (multiply counts by 2^%d)\n", r, nsub, r);
  }
  uint64_t N = 1ULL << lg; std::vector<Res> R(nt); std::vector<std::thread> th;
  for (int i = 0; i < nt; ++i) th.emplace_back(work, N * i / nt, N * (i + 1) / nt, &R[i]);
  for (auto &x : th) x.join();
  Res T; for (auto &r : R) { T.ge += r.ge; T.eq += r.eq; T.gt += r.gt; T.wzero += r.wzero; T.valid += r.valid; T.mx = std::max(T.mx, r.mx); T.minpk = std::min(T.minpk, r.minpk); T.maxpk = std::max(T.maxpk, r.maxpk); for (int b = 0; b < 8; ++b) T.hist[b] += r.hist[b]; }
  printf("quadratic parts: 2^%d, (Q2,linear) pairs: %llu\n", lg, (unsigned long long)(N * 256));
  printf("max score = %d\n", T.mx);
  printf("score>=%d: %lld  (==: %lld, >: %lld, with a zero W on target: %lld)\n", THR, T.ge, T.eq, T.gt, T.wzero);
  if (T.ge) printf("forced v: peak |W_v| min %d max %d; v with |W_v| in {4,12} and %d fours: %lld\n", T.minpk, T.maxpk, N4, T.valid);
  printf("score histogram, bins of 32 below %d: ", THR); for (int b = 0; b < 8; ++b) printf("%lld ", T.hist[b]); printf("\n");
  if (pcmode) printf("RESULT %s\n", T.valid >= 1 ? "POSITIVE_CONTROL_FOUND" : "POSITIVE_CONTROL_FAILED");
  else printf("RESULT %s\n", T.valid == 0 && T.gt == 0 && T.wzero == 0 ? "NO_LOW_COMPLEMENT" : "CHECK");
}
