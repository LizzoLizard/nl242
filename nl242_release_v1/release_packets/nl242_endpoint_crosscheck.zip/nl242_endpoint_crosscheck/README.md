# Cross-check of the direct t = 114/116 endpoint exclusion

The direct route in `nl242_endpoint_closure.zip` (paper, "Direct exclusion of the switched
endpoints") closes t = 114 and 116 from the plane switch, without the covering-radius
theorem. This packet re-derives its finite part twice more, with separate code:

1. `verify_t114_t116_unconditional.py`: an earlier implementation of the same route, written
   with Antigravity. It parametrises the geometry differently and splits the low-block search
   by the rank of a quadratic form.
2. `indep_k16.py` and `bf_quad.cpp`: written for this audit. They rebuild every high block
   from scratch without merging equivalent ones, and score every quadratic Q directly, with
   no coordinate split.

All three agree.

## Setting

The plane switch (checked in Lean; see the endpoint packet) gives ternary tables u, v on
F_2^8 with complementary supports and |W_u|, |W_v| in {4, 12}. Put E = {a : |W_u(a)| = 4}
and k = |E|. Then k = 12 at t = 114, and k is 12 or 16 at t = 116.

## Hand steps (re-checked for this audit)

- **Hyperplane counts.**
  - For d ≠ 0 let m = |{a in E : a·d = 1}|.
  - Inverting W_u^2 = 144 − 128·1_E gives Σ_x u(x)u(x+d) = m − k/2. The left side is even,
    so m is even.
  - m ≥ 4 holds by the halfspace count (Lean `halfspace_small_counts`, or the short identity
    argument in the endpoint packet). It applies to u·χ_e too, which covers the other side
    of each hyperplane.
  - So restricting affine functions to E gives an even [k, 9, ≥4] code C containing 1.
- **k = 12.** 2^9 disjoint radius-1 balls need 512·13 = 6656 > 4096 points.
- **k = 16.**
  - Write T(x) = Σ_{a in E} s_a(−1)^{a·x} = 16 − 2·wt(b + Φ(x)), where s_a = W_u(a)/4 and
    b is the sign word. Then u = T mod 3, wt(u) = 136, Σ T² = 4096 and Σ uT = 64.
  - **Odd wt(b):** T ≡ 2 (mod 4). The 120 zeros of u need |T| = 6, so Σ T² ≥ 4320, a
    contradiction.
  - **Even wt(b):** the three moment equations give 18·n16 + 9·z12 = 0. So b + C has weight
    distribution {4:40, 6:96, 8:240, 10:96, 12:40}.
  - Then C' = C ∪ (b + C) is an even [16, 10, 4] code containing 1.
  - Its dual D' (dimension 6, containing 1) has a generator (1, g1..g5). Its columns give
    16 distinct points Y in F_2^5.
  - The weights of D' make 1_Y balanced with |W| in {0, 8, 16}. Restriction weights then give
    degree ≤ 3.
  - D' fixes Y up to AGL(5,2). Conversely, Y gives C', then C (one of 511 index-2 subcodes
    containing 1), then E up to AGL(8,2), with b taken from C' \ C.
- **Low block.**
  - For h = u, v let p_h = ((W_h − 4)/8) mod 2.
  - Expanding W_h(a) = Σ_x h(x)Π(1 − 2a_i x_i) shows two things. First, deg p_h ≤ 3. Second,
    the cubic coefficient at I is Σ_x h(x)x^I mod 2.
  - Complementary supports give equal cubic coefficients, because Σ_x x^I = 32. So
    p_v = p_u + Q with deg Q ≤ 2.
  - Walsh duality gives Σ_{x: u(x)=0} v(x)W_b(x) = 4·48 − 12·208 = −2304, where b = (−1)^{p_v}.
  - So the score Σ_{u=0}|W_b| must be at least 2304, and equality forces v = −sign(W_b).

## Computations

| Check | Code | Result |
|---|---|---|
| Balanced RM(3,5) functions with \|W\| in {0,8,16} | `indep_k16.py` | 18,736,648 functions in 8 AGL(5,2) orbits |
| Index-2 subcodes C passing all high-block tests | `indep_k16.py` | 64 on the orbit of size 8,680; 6 on the orbit of size 27,776; 0 elsewhere (70 lifts) |
| Low block for each of the 70 lifts | `bf_quad.cpp --reduce` | 64 lifts: maximum score 2272. 6 lifts: maximum 2304, with 320 equality cases per translation class, each forcing v with peak \|W_v\| = 28 |
| Full sweep of all 2^28 quadratic parts, no reduction, on lifts 1 and 70 | `bf_quad.cpp` | maximum 2272; maximum 2304 with 81,920 = 320·256 equality cases, all with peak 28 |
| Positive control: target supp(u), threshold 2816 | `bf_quad.cpp --positive-control` | finds u itself |
| Earlier implementation | `verify_t114_t116_unconditional.py` | the same 2 classes, maxima and equality count |

`--reduce` uses the translations of the frequency space:
- They send p_u + Q to p_u + Q', where Q' − Q is the contraction of the cubic part. Scores
  are unchanged, and the forced v is only multiplied by a character.
- For every lift, the eight contractions have rank 8. So 2^20 coset representatives cover
  all 2^28 quadratic parts, and every count is multiplied by 2^8.
- The full sweep confirms this on lifts 1 and 70.

These numbers match the endpoint packet:
- the same two geometries: one contains eight affine planes, the other is the Gold graph;
- maxima 2272 and 2304;
- 320 equality cases per sign coset;
- peak 28.

## Notes on `verify_t114_t116_unconditional.py`

The program is correct. Its text has these slips:

1. The docstring swaps the orbit labels. In the actual output, orbit 0 has 64 lifts and
   B4 = 8 (maximum 2272), and orbit 1 has 6 lifts and B4 = 0 (maximum 2304).
2. "All 72,904 balanced f_Y" is the number of functions whose cubic part *equals* one of the
   three orbit representatives. The full set has 18,736,648 functions. Each orbit size here
   is the program's orbit size times the cubic-orbit size (1, 155 or 868).
3. Step 1 prints the Hamming bound but does not compute m ≥ 4. That comes from the
   halfspace count above.
4. Stage C splits Q by the rank of the common y-part A0 of p_u. That split needs A0 to be
   quadratic, but the program only asserts that A0 is the same for all z. For both blocks
   the cubic terms of p_u have the types y·z·z and z³ only (checked in this audit), so the
   split is valid. The brute force here does not use the split.
5. The docstring obtains deg(p_v − p_u) ≤ 2 from the nine-variable condition W ≡ 8 (mod 16).
   The eight-variable argument above gives it directly.
6. Step 0 (the switch and the possible k) rests on Lean modules still in development, as
   does the covering-radius route.

## Replay

```sh
sh run_crosscheck.sh        # Python 3 + numpy, C++17; about 10 minutes on 2 threads
```

`PYTHON` may name the interpreter command, and `THREADS` sets the thread count. `results/`
holds the output of one run of this script.
