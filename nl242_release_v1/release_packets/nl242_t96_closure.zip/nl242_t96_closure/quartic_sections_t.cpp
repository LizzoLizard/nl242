#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <vector>
using U = uint64_t;
int pop(U x) { return __builtin_popcountll(x); }
int parity(int x) { return __builtin_parity((unsigned)x); }
int qbit(int x) { return parity(x & (x >> 1) & 21); }
using P3 = std::array<int, 3>;
using V64 = std::array<int, 64>;
using V256 = std::array<int, 256>;
template <size_t N> void walsh(std::array<int, N> &a) {
  for (unsigned s = 1; s < N; s *= 2)
    for (unsigned i = 0; i < N; i += 2 * s)
      for (unsigned j = i; j < i + s; j++) {
        int u = a[j], v = a[j + s];
        a[j] = u + v;
        a[j + s] = u - v;
      }
}
std::array<U, 32768> quadratic{};
std::array<U, 128> affine{};
int jpolar = 0;
void setup() {
  std::array<U, 15> monos{};
  int d = 0;
  for (int i = 0; i < 6; i++)
    for (int j = 0; j < i; j++, d++) {
      if ((i ^ j) == 1)
        jpolar |= 1 << d;
      for (int x = 0; x < 64; x++)
        if ((x >> i & 1) && (x >> j & 1))
          monos[d] |= U(1) << x;
    }
  for (int b = 1; b < 32768; b++)
    quadratic[b] = quadratic[b & (b - 1)] ^ monos[__builtin_ctz(b)];
  for (int l = 0; l < 128; l++)
    for (int x = 0; x < 64; x++)
      if (parity(x & l) ^ (l >> 6))
        affine[l] |= U(1) << x;
}
bool gram_ok(U p) {
  int gram[6] = {}, sum = 0;
  for (U s = p; s; s &= s - 1) {
    int x = __builtin_ctzll(s);
    sum ^= x;
    for (int i = 0; i < 6; i++)
      if (x >> i & 1)
        gram[i] ^= x;
  }
  if (pop(p) % 2 || sum)
    return false;
  for (int i = 0; i < 6; i++)
    if (gram[i] != (1 << (i ^ 1)))
      return false;
  return true;
}

struct Bins {
  std::array<unsigned char, 128> weights;
  std::array<unsigned char, 128> indices;
  std::array<unsigned short, 66> start{};
};
struct Tables {
  std::vector<Bins> bins;
  Tables(U p) : bins(32768) {
    for (int b = 0; b < 32768; b++) {
      auto &group = bins[b];
      for (int l = 0; l < 128; l++) {
        int w = pop(p ^ quadratic[b] ^ affine[l]);
        group.weights[l] = w;
        ++group.start[w + 1];
      }
      for (int j = 1; j < 66; j++)
        group.start[j] += group.start[j - 1];
      auto pos = group.start;
      for (int l = 0; l < 128; l++)
        group.indices[pos[group.weights[l]]++] = l;
    }
  }
};
// Point transvections and their affine translates preserve the symplectic
// form. Only retain ones that fix the distinguished six-flat set P.
int recover(U m) {
  int coeff = 0;
  for (int j = 0; j < 7; j++) {
    int x = j == 6 ? 0 : 1 << j;
    if ((m >> x & 1) ^ (j == 6 ? 0 : m & 1))
      coeff |= 1 << j;
  }
  U pure = m ^ affine[coeff];
  int bit = 0;
  for (int i = 0; i < 6; i++)
    for (int j = 0; j < i; j++, bit++)
      if (pure >> ((1 << i) | (1 << j)) & 1)
        coeff |= 1 << (7 + bit);
  return coeff;
}
struct Generator {
  std::array<std::array<int, 256>, 3> index{};
  int reindex(int c) const {
    return index[0][c & 255] ^ index[1][(c >> 8) & 255] ^ index[2][c >> 16];
  }
  std::array<std::array<U, 256>, 8> bytes{};
  U map(U x) const {
    U v = 0;
    for (int j = 0; j < 8; j++) {
      v |= bytes[j][x & 255];
      x >>= 8;
    }
    return v;
  }
};
std::vector<Generator> generators(U p) {
  std::vector<Generator> res;
  for (int w = 1; w < 64; w++)
    for (int l = 0; l < 2; l++) {
      int dual = ((w & 21) << 1) | ((w & 42) >> 1);
      std::array<int, 64> perm{};
      U dest = 0;
      for (int x = 0; x < 64; x++) {
        perm[x] = x ^ ((parity(x & dual) ^ l) ? w : 0);
        if (p >> x & 1)
          dest |= U(1) << perm[x];
      }
      if (dest != p)
        continue;
      res.emplace_back();
      auto &tab = res.back().bytes;
      for (int j = 0; j < 8; j++)
        for (int v = 1; v < 256; v++)
          tab[j][v] =
              tab[j][v & (v - 1)] | U(1) << perm[8 * j + __builtin_ctz(v)];
    }
  for (auto &g : res) {
    for (int j = 0; j < 3; j++)
      for (int b = 0; b < 8 && 8 * j + b < 22; b++) {
        int c = 1 << (8 * j + b);
        g.index[j][1 << b] =
            recover(g.map(quadratic[c >> 7] ^ affine[c & 127]));
      }
    for (auto &tab : g.index)
      for (int v = 1; v < 256; v++)
        if (v & (v - 1))
          tab[v] = tab[v & (v - 1)] ^ tab[v & -v];
  }
  return res;
}
using Cutoffs = std::vector<P3>;
long long tested = 0;
std::map<P3, long long> passed;
bool count_only = false;
int minimum_side = 0;
std::array<U, 64> far{};
using Template = std::array<int, 129>;
std::vector<Template> library;
std::set<std::pair<std::vector<int>, int>> sampled;
std::ofstream sample;
long long skip_min = 0;
std::set<std::array<U, 4>> survivors;
V256 qq;
int G_NP_BASE = 43;
int G_SUPP = 158;
void test(const std::array<U, 4> &f, const Cutoffs &profiles) {
  ++tested;
  if (count_only)
    return;
  int n = 0;
  int w[4];
  for (int j = 0; j < 4; j++) {
    w[j] = pop(f[j]);
    n += w[j];
  }
  for (int i = 1; i < 64; i++) {
    int z[4];
    for (int j = 0; j < 4; j++)
      z[j] = w[j] - 2 * pop(f[j] & far[i]);
    int a = z[0] + z[1], b = z[0] - z[1], c = z[2] + z[3], d = z[2] - z[3];
    if (std::max(std::abs(a) + std::abs(c), std::abs(b) + std::abs(d)) >
        n - 2 * minimum_side) {
      ++skip_min;
      return;
    }
  }

  V256 v{};
  for (int y = 0; y < 4; y++)
    for (int x = 0; x < 64; x++)
      if (f[y] >> x & 1)
        v[64 * y + x] = qq[64 * y + x];
  walsh(v);
  for (int x = 0; x < 256; x++)
    v[x] *= qq[x];
  std::array<bool, 100> live{};
  for (unsigned i = 0; i < profiles.size(); i++)
    live[i] = true;

  // Dual weights are a sum of one or more nested lower-level indicators.
  // The true signed ternary input has exactly p positives and 158-p negatives.
  auto apply = [&](const Template &lut) {
    V256 weights{};
    long long rhs = 0;
    std::array<int, 256> yvals{};
    for (int x = 0; x < 256; x++) {
      int y = lut[(v[x] + 256) / 4];
      yvals[x] = y;
      weights[x] = qq[x] * y;
      rhs += (28 - 3 * v[x]) * y;
    }
    walsh(weights);
    std::array<int, 256> ins{}, outs{};
    int ni = 0, no = 0;
    for (int i = 0; i < 256; i++) {
      int score = qq[i] * weights[i];
      if (f[i >> 6] >> (i & 63) & 1)
        ins[ni++] = -score;
      else
        outs[no++] = score;
    }
    std::sort(ins.begin(), ins.begin() + ni, std::greater<int>());
    std::sort(outs.begin(), outs.begin() + no, std::greater<int>());
    std::sort(yvals.begin(), yvals.end());
    std::array<long long, 257> si{}, so{}, uy{};
    for (int j = 0; j < ni; j++)
      si[j + 1] = si[j] + ins[j];
    for (int j = 0; j < no; j++)
      so[j + 1] = so[j] + outs[j];
    for (int j = 0; j < 256; j++)
      uy[j + 1] = uy[j] + yvals[j];
    bool any = false;
    for (unsigned i = 0; i < profiles.size(); i++)
      if (live[i]) {
        auto k = profiles[i];
        int np = G_NP_BASE - k[0] - k[2], nn = G_SUPP - np;
        long long umin = uy[np] - (uy[256] - uy[256 - nn]);
        if (2 * (so[k[0]] + si[k[2]]) < rhs + 32 * umin)
          live[i] = false;
        else
          any = true;
      }
    return any;
  };
  auto cut = [&](int a, int b, int c, bool) {
    Template lut{};
    for (int i = 0; i < 129; i++) {
      int x = 4 * i - 254;
      lut[i] = (x <= a) + (x <= b) + (x <= c);
    }
    return apply(lut);
  };
  int mn = *std::min_element(v.begin(), v.end());
  for (int t = mn; t <= -2; t += 4)
    if (!cut(t, -1000, -1000, true))
      return;
  for (auto xy : {std::pair<int, int>{-6, -2},
                  {-10, -2},
                  {-6, 10},
                  {-10, 6},
                  {-6, 6},
                  {-6, 2},
                  {-14, -6},
                  {-2, 10}})
    if (!cut(xy.first, xy.second, -1000, false))
      return;
  for (const auto &lut : library)
    if (!apply(lut))
      return;
  for (int a = mn; a <= 2; a += 4)
    for (int b = a; b <= 18; b += 4)
      if (!cut(a, b, -1000, false))
        return;
  for (int a = mn; a <= -6; a += 4)
    for (int b = a; b <= 6; b += 4)
      for (int c = b; c <= 18; c += 4)
        if (!cut(a, b, c, false))
          return;
  std::vector<int> hist(129, 0);
  for (auto x : v)
    hist[(x + 256) / 4]++;
  for (unsigned i = 0; i < profiles.size(); i++)
    if (live[i]) {
      passed[profiles[i]]++;
      if (sampled.insert({hist, int(i)}).second && sampled.size() <= 4000) {
        for (U e : f)
          sample << std::hex << e << " ";
        sample << std::dec << profiles[i][0] << " " << profiles[i][1] << " "
               << profiles[i][2] << std::endl;
      }
    }
  if (std::find(live.begin(), live.end(), true) != live.end() &&
      survivors.size() < 2000)
    survivors.insert(f);
}
int main(int argc, char **argv) {
  if (argc < 5)
    return 2;
  std::string dir = argv[1];
  int t_agree = std::stoi(argv[2]);
  if (t_agree % 2 != 0 || t_agree < 70 || t_agree > 256)
    throw std::runtime_error("invalid t");
  G_NP_BASE = (3 * t_agree - 208) / 2;
  G_SUPP = 256 - t_agree;
  int n = std::stoi(argv[3]);
  count_only = std::stoi(argv[4]);
  Cutoffs profiles;
  int a, b, c;
  while (std::cin >> a >> b >> c)
    if (b + c == n)
      profiles.push_back({a, b, c});
  if (profiles.empty() || profiles.size() > 100)
    throw std::runtime_error("wrong profile count");
  for (auto p : profiles)
    if (p[0] < 0 || p[1] < 0 || p[2] < 0 || p[0] + p[2] > G_NP_BASE)
      throw std::runtime_error("invalid profile");
  for (int i = 0; i < 256; i++)
    qq[i] = 1 - 2 * (qbit(i & 63) ^ ((i >> 6) == 3));
  for (int d = 0; d < 64; d++)
    for (int x = 0; x < 64; x++)
      if (parity(x & d))
        far[d] |= U(1) << x;
  sample.open("sample" + std::to_string(n) + ".txt");
  if (argc > 5) {
    std::ifstream cuts(argv[5]);
    if (!cuts)
      throw std::runtime_error("missing cuts");
    Template v;
    while (cuts >> v[0]) {
      if (v[0] < -100000 || v[0] > 100000)
        throw std::runtime_error("bad cut");
      for (int i = 1; i < 129; i++)
        if (!(cuts >> v[i]) || v[i] < -100000 || v[i] > 100000)
          throw std::runtime_error("bad cut");
      library.push_back(v);
    }
  }
  setup();
  // Pick a minimum half size using Parseval. Then take a globally minimum
  // nondegenerate six-flat inside the chosen half over its transverse slices.
  int maxs = (n / 2) & ~1;
  while (255 * (n - 2 * maxs) * (n - 2 * maxs) < n * (256 - n))
    maxs -= 2;
  for (int m = 8; 2 * m <= maxs; m += 2) {
    std::ifstream in(dir + "/shapes" + std::to_string(m) + ".bin",
                     std::ios::binary);
    if (!in)
      throw std::runtime_error("missing orbit file");
    U p;
    int cores = 0;
    while (in.read((char *)&p, 8)) {
      if (pop(p) != m)
        throw std::runtime_error("wrong orbit size");
      if (!gram_ok(p))
        continue;
      ++cores;
      Tables tw(p);
      auto gens = generators(p);
      for (int size = 2 * m; size <= maxs; size += 2) {
        if (size == 18)
          continue;
        minimum_side = size;
        long long pairs = 0, before = tested;
        std::unordered_set<U> covered;
        for (int bt = 0; bt < 32768; bt++)
          for (int lt = 0; lt < 128; lt++) {
            U T = quadratic[bt] ^ affine[lt];
            if (tw.bins[bt].weights[lt] != size - m)
              continue;
            // Normalise by the affine shears of the radical (all transverse
            // slices).
            if (pop(T) > (size - 2 * m) * (size - 2 * m))
              continue;
            bool min = true;
            for (U l : affine)
              if (pop(p ^ (l & T)) < m) {
                min = false;
                break;
              }
            if (!min)
              continue;
            if (covered.count(T))
              continue;
            std::vector<U> orbit{T};
            covered.insert(T);
            for (size_t k = 0; k < orbit.size(); k++)
              for (auto &g : gens) {
                U next = g.map(orbit[k]);
                if (covered.insert(next).second)
                  orbit.push_back(next);
              }
            ++pairs;
            std::vector<const Generator *> stab;
            for (const auto &g : gens)
              if (g.map(T) == T)
                stab.push_back(&g);
            std::vector<bool> already(1 << 22, false);

            for (int bh = 0; bh < 32768; bh++) {
              int br = bh ^ bt ^ jpolar;
              // The two opposite cells are ordered by weight below.

              const auto &L = tw.bins[bh];
              const auto &R = tw.bins[br];
              for (int wl = 8; wl <= 56; wl += 2) {
                int need = n - size - wl;
                if (need < wl || need > 56 || L.start[wl] == L.start[wl + 1] ||
                    R.start[need] == R.start[need + 1])
                  continue;
                // By choice of a minimum hyperplane, the other pairings have
                // both side sizes >= size as well.
                if (m + wl < size || m + need < size || size - m + wl < size ||
                    size - m + need < size)
                  continue;
                for (int il = L.start[wl]; il < L.start[wl + 1]; il++) {
                  int i = L.indices[il];
                  int code = (bh << 7) | i;
                  if (already[code])
                    continue;
                  std::vector<int> horbit{code};
                  already[code] = true;
                  for (size_t oi = 0; oi < horbit.size(); oi++)
                    for (const auto *g : stab) {
                      int h2 = g->reindex(horbit[oi]);
                      if (!already[h2]) {
                        already[h2] = true;
                        horbit.push_back(h2);
                      }
                    }
                  if (count_only) {
                    tested += R.start[need + 1] - R.start[need];
                    continue;
                  }
                  for (int jr = R.start[need]; jr < R.start[need + 1]; jr++) {
                    int j = R.indices[jr];
                    test({p, p ^ T, p ^ quadratic[bh] ^ affine[i],
                          p ^ quadratic[br] ^ affine[j]},
                         profiles);
                  }
                }
              }
            }
          }
        std::cout << n << " p " << std::hex << p << std::dec << " size " << size
                  << " pairs " << pairs << " configurations " << tested - before
                  << " total " << tested << std::endl;
      }
    }
    if (!cores || !in.eof() || in.gcount())
      throw std::runtime_error("incomplete core file");
  }
  for (const auto &[p, z] : passed)
    std::cout << "survivor " << p[0] << "," << p[1] << "," << p[2] << " " << z
              << std::endl;
  std::cout << "finished " << n << " profiles " << profiles.size()
            << " configurations " << tested << " survivors " << passed.size()
            << std::endl;
  if (!count_only) {
    std::ofstream out("dsurv" + std::to_string(n) + ".txt");
    for (auto f : survivors)
      out << std::hex << f[0] << " " << f[1] << " " << f[2] << " " << f[3]
          << "\n";
  }
}
