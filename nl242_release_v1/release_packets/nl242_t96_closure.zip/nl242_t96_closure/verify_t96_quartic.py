"""Self-contained replay closing all 55 rank-eight t=96 profiles via quartic enumeration."""
import argparse
from collections import Counter
import hashlib
import os
from pathlib import Path
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent

DIGESTS = {
    8: "0c504784d9dc3cbe386b71dafb9555288ae46999e3bb207ce86723f3699a1e00",
    10: "62e0aee4dfe0dd447f1e6514877c6d406388f0bbaf0f79041f8649557dab714a",
    12: "9ffac4ee5979d0402f23037f016e713723b9b0acea898b8dfadec552cfcddd38",
    14: "0c5f976f58c129b46fd172a4822292ec73658e671731757569918a060daedeb2",
    16: "66d02a405c4f1828c397f298370a47c5641d8f2393dd9af56c2e16ad0d70c786",
}
CUTS_DIGEST = "9747ad36ea58222db269cf9dd13d88d55669b48a54ab633a54a53a4492b34733"
ALL_WEIGHTS = (46, 50, 54, 58, 62, 66, 70, 74, 78)


def check_hash(path, expected):
    got = hashlib.sha256(path.read_bytes()).hexdigest()
    if got != expected:
        raise ValueError(f"SHA-256 mismatch for {path}: got {got}, expected {expected}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--shapes",
        type=Path,
        required=True,
        help="directory containing shapes{8,10,12,14,16}.bin "
        "(input/nl242_t98_v3/quartic/shapes after running the t98 packet's setup)",
    )
    parser.add_argument(
        "--cuts",
        type=Path,
        required=True,
        help="radial_cuts.txt (input/nl242_t98_v3/quartic/radial_cuts.txt in the t98 packet)",
    )
    parser.add_argument(
        "--checker",
        choices=("hinge_t", "quartic_sections_t"),
        default="hinge_t",
    )
    parser.add_argument("--weights", type=int, nargs="+", default=list(ALL_WEIGHTS))
    args = parser.parse_args()

    for m, digest in DIGESTS.items():
        check_hash(args.shapes / f"shapes{m}.bin", digest)
    check_hash(args.cuts, CUTS_DIGEST)

    profiles = [
        tuple(map(int, line.split()))
        for line in (HERE / "inventory96.txt").read_text().splitlines()
        if line.strip()
    ]
    if len(profiles) != 55:
        raise ValueError(f"expected 55 t=96 profiles, got {len(profiles)}")
    counts = Counter(b + c for a, b, c in profiles)
    weights = sorted(set(args.weights))
    if any(n not in counts for n in weights):
        parser.error("requested weight absent from t=96 inventory")

    if args.checker == "hinge_t":
        src = HERE / "hinge_t.cpp"
    else:
        src = HERE / "quartic_sections_t.cpp"
        if not src.exists():
            src = HERE.parent / "quartic_sections_t.cpp"
    cxx = os.environ.get("CXX", "c++")

    remaining = set(profiles)
    with tempfile.TemporaryDirectory(prefix="t96-quartic-") as td:
        work = Path(td)
        binary = work / args.checker
        subprocess.run([cxx, "-std=c++17", "-O3", str(src), "-o", str(binary)], check=True)

        for n in weights:
            group = {p for p in profiles if p[1] + p[2] == n}
            res = subprocess.run(
                [str(binary), str(args.shapes), "96", str(n), "0", str(args.cuts)],
                cwd=work,
                input="".join(f"{a} {b} {c}\n" for a, b, c in sorted(group)),
                text=True,
                stdout=subprocess.PIPE,
                check=True,
            )
            lines = res.stdout.splitlines()
            survivors = {
                tuple(map(int, l.split()[1].split(",")))
                for l in lines
                if l.startswith("survivor ")
            }
            last = lines[-1].split()
            if (
                last[:5] != ["finished", str(n), "profiles", str(len(group)), "configurations"]
                or last[6:] != ["survivors", str(len(survivors))]
                or not survivors <= group
            ):
                raise ValueError(f"incomplete search at n={n}: {lines[-3:]}")
            remaining -= group - survivors
            print(
                f"t=96 n={n} [{args.checker}] checked {last[5]} configs, "
                f"{len(group) - len(survivors)}/{len(group)} profiles excluded",
                flush=True,
            )

    print(f"Remaining t=96 rank-8 profiles: {len(remaining)} / 55")


if __name__ == "__main__":
    main()
