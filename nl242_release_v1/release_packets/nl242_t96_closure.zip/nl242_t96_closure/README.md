# t = 96 closure packet (rank 8, all 55 profiles)

This packet excludes agreement count `t = 96` for the balanced 9-variable NL-242 problem.
- **Rank 8.** All 55 remaining profiles are excluded by the four-cell quartic enumerator
  with exact integer high-block hinge bounds and dual cuts.
- **Rank 6.** No profiles remain after the profile replay (see `NOTES.md`).
- **Rank ≤ 4.** No open systems.

The derivation (degree-4 support of `1_F`, `2KD = 28 − 3S + 32u`, the ternary counts and
the first-moment identity) is in `NOTES.md` and in the t98 packet's `quartic/NOTES.md`.

## Inputs (from the t98 packet)

The shape tables and the cut file are the ones shipped with `nl242_t98_closure.zip`.
1. Unpack that zip and run its setup.
2. The setup creates `input/nl242_t98_v3/quartic/shapes/shapes{8,10,12,14,16}.bin`.
3. The cut file is `input/nl242_t98_v3/quartic/radial_cuts.txt`.

`verify_t96_quartic.py` checks the SHA-256 of all six input files before running.

## Replay

```sh
T98=/path/to/nl242_t98_closure/input/nl242_t98_v3/quartic
python3 verify_t96_quartic.py --shapes $T98/shapes --cuts $T98/radial_cuts.txt
# baseline checker, weights 46..74:
python3 verify_t96_quartic.py --shapes $T98/shapes --cuts $T98/radial_cuts.txt \
        --checker quartic_sections_t --weights 46 50 54 58 62 66 70 74
```

The full run takes about 15 minutes on 8 cores. The last weight, `b + c = 78`, alone
checks 106,366,593 configurations. Expected final line:
`Remaining t=96 rank-8 profiles: 0 / 55`.

## Files

| File | Role |
|---|---|
| `verify_t96_quartic.py` | driver: hash checks, compile, run each weight, account for every profile |
| `hinge_t.cpp` | four-cell enumerator with the three hinge bounds and dual cuts (closes all 55) |
| `quartic_sections_t.cpp` | audited baseline enumerator (closes weights 46–74) |
| `inventory96.txt` | the 55 rank-8 profiles (matches `remaining_profiles.tsv`) |
| `logs/original_run/` | logs of the original run |
| `logs/audit_replay_20261122_hinge.txt` | independent replay (0 / 55 remaining) |

## Computer-assisted

This exclusion is an exhaustive computer enumeration. Its correctness includes the
correctness of `hinge_t.cpp`, `quartic_sections_t.cpp` and the driver, which is why they
ship as source. The two enumerators agree on every weight both of them cover.
