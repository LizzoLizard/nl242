# Agreement count t = 96 — Uniform Quartic Closure

## Result

Starting from the 55 remaining rank-eight profiles for `t = 96` in `remaining_profiles.tsv` (rank six already has 0 remaining profiles after `replay.py`), the global four-cell quartic section checker with integer high-block dual inequalities excludes **all 55/55 profiles**:

- **Audited baseline (`quartic_sections_t.cpp`)** closed all **53 profiles** with `b+c ∈ {46, 50, 54, 58, 62, 66, 70, 74}` (0 survivors; logs `t96_n46.log` .. `t96_n74.log`).
- **Hardened fast checker (`hinge_t.cpp`)** independently replayed `b+c = 46..74` (0 survivors; logs `hinge96_n46.log` .. `hinge96_n74.log`) and checked the final 2 profiles at `b+c = 78` (`(0,51,27)` and `(1,54,24)`, log `hinge96_n78.log`).
- Independently, `(1,54,24)` is already closed in Lean (`Balanced242T96Centered` / `../centered_certificates.json`) and both `(0,51,27)` and all four `b+c = 74` profiles were already closed in `rank8cp/fx/closures.log`.

## Generalization from t = 98 to t = 96

The quartic degree-four support structure of $1_F$ and the identity
$$2 K D = 28 - 3 S + 32 u, \qquad u = \sigma U \in \{-1, 0, +1\}^{256}$$
hold identically for every rank-eight profile at any even agreement count $t$. Only the support size and sign balance of $u$ depend on $t$:
- $|\operatorname{supp}(U)| = 256 - t = 160$ at $t = 96$.
- Parseval on $H = W(U)/2$ gives $6a + 3(b+c) + 2c = 288$, so the number of $+1$ entries in $u$ is $p = \frac{3t - 208}{2} - a - c = 40 - a - c$, with $160 - p$ entries equal to $-1$.
- The first-moment identity $\langle u, S \rangle = 10n - 16c$ is independent of $t$.

## Replay

See `README.md` for the replay commands. `--shapes` and `--cuts` are required and come from the t98 packet.
