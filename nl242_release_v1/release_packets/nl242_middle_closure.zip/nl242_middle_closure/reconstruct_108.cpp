// Exact rank-four high-block reconstruction at t=108 for k=12 and k=14.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <vector>

using Table = std::array<int, 256>;
int parity(int v) { return __builtin_parity(static_cast<unsigned>(v)); }
void walsh(Table& a) {
    for (int h = 1; h < 256; h *= 2)
        for (int b = 0; b < 256; b += 2*h)
            for (int i = b; i < b+h; ++i) {
                const int l = a[i], r = a[i+h];
                a[i] = l+r;
                a[i+h] = l-r;
            }
}

struct Search {
    const int k, j, limit;
    std::array<int, 9> cols{};
    std::uint64_t geometries = 0, signings = 0, flats = 0, hits = 0;
    explicit Search(int k) : k(k), j(k-9), limit(1<<j) {}

    void complete(const Table& u0, const std::array<int, 8>& moments,
                  int a, int b, bool add, const Table& small) {
        // The columns of the polar matrix span the direction of the dual flat.
        int pivot[8]{};
        std::vector<int> space{0};
        for (int i=0; i<8; ++i) {
            int v = moments[i] ^ ((a>>i&1) ? a : 0) ^ ((b>=0 && (b>>i&1)) ? b : 0);
            for (int bit=7; bit>=0 && v; --bit) if (v>>bit&1) {
                if (pivot[bit]) { v ^= pivot[bit]; continue; }
                if (space.size() == 16) return;
                pivot[bit] = v;
                int n = static_cast<int>(space.size());
                for (int s=0; s<n; ++s) space.push_back(space[s]^v);
                break;
            }
        }
        if (space.size()!=16 || (b>=0 && std::find(space.begin(),space.end(),b^a)==space.end()))
            return;
        ++flats;
        Table u = u0;
        for (int s : space) {
            int x = s^a;
            if (!u[x] && x!=a) return;
            u[x] = -u[x];
        }
        if (b>=0) u[b]=0;
        for (int s : {-1,1}) {
            if (!add && s>0) break;
            u[a] = add ? s : 0;
            Table spectrum = u;
            walsh(spectrum);
            bool good = true;
            for (int f=0; f<256; ++f) {
                int absw = std::abs(spectrum[f]);
                if (absw>14 || absw%4!=2 || ((absw<=6) != bool(small[f]))) {
                    good=false;
                    break;
                }
            }
            if (good) ++hits;
        }
    }

    void lift(const std::vector<int>& freq, int sign, int zeros) {
        ++signings;
        Table u{}, small{};
        for (int i=0; i<k; ++i) u[freq[i]] = small[freq[i]] =
            (i>=9 && (sign>>(i-9)&1)) ? -1 : 1;
        walsh(u);
        std::array<int,8> moments{};
        int support_xor=0, seen_zeros=0;
        for (int x=0;x<256;++x) {
            u[x] = ((u[x]%3+4)%3)-1;
            if (!u[x]) { ++seen_zeros; continue; }
            support_xor ^= x;
            for (int i=0;i<8;++i) if (x>>i&1) moments[i]^=x;
        }
        if (seen_zeros!=zeros) throw std::logic_error("character zero count");
        if (zeros==106) {
            for (int a=0;a<256;++a) {
                int b=a^support_xor;
                if (a<b && u[a] && u[b]) complete(u,moments,a,b,false,small);
            }
        } else {
            bool add = zeros==109;
            if ((u[support_xor]==0)==add)
                complete(u,moments,support_xor,-1,add,small);
        }
    }

    void inspect() {
        // The dependency matrix consists of nine columns followed by an identity.
        // Its even minimum distance of at least four encodes distinct affine points.
        int coeff[32]{};
        coeff[0]=1;
        for (int y=1; y<limit; ++y) {
            int w=__builtin_popcount(static_cast<unsigned>(y));
            for (int c : cols) w += parity(c&y);
            if (w<4 || (w&1)) return;
            int power=1;
            for (int i=0; i<w/2;++i) power *= -3;
            coeff[y]=power;
        }
        ++geometries;
        std::vector<int> freq{0,1,2,4,8,16,32,64,128};
        for (int l=0;l<j;++l) {
            int f=0;
            for (int i=0;i<9;++i) if (cols[i]>>l&1) f ^= freq[i];
            freq.push_back(f);
        }
        for (int h=1;h<limit;h*=2)
            for (int b=0;b<limit;b+=2*h) for (int i=b;i<b+h;++i) {
                int u=coeff[i], v=coeff[i+h];
                coeff[i]=u+v; coeff[i+h]=u-v;
            }
        const int scale=1<<(k-1);
        for (int sign=0;sign<limit;++sign) {
            int num=256*(scale+coeff[sign]), den=3*scale;
            if (num%den) throw std::logic_error("nonintegral weight");
            int zeros=num/den;
            if ((k==12 && (zeros==106 || zeros==109)) || (k==14 && zeros==107))
                lift(freq,sign,zeros);
        }
    }

    void generate(int depth, int lower, int pending, std::array<int,5> history) {
        for (int c=lower; c<limit; ++c) {
            if (depth==8 && c!=pending) continue;
            bool minimal=true;
            for (int i=0;i<j;++i) for (int b=i+1;b<j;++b)
                if (history[i]==history[b] && !(c>>i&1) && (c>>b&1)) minimal=false;
            if (!minimal) continue;
            cols[depth]=c;
            if (depth==8) { inspect(); continue; }
            auto next=history;
            for (int i=0;i<j;++i) next[i]=2*history[i]+(c>>i&1);
            generate(depth+1,c,pending^c,next);
        }
    }
};

int main() {
    for (int k : {12,14}) {
        Search s(k);
        s.generate(0,1,s.limit-1,{});
        std::cout<<"k="<<k<<" geometry representatives="<<s.geometries
                 <<" eligible signings="<<s.signings<<" candidate flats="<<s.flats
                 <<" high completions="<<s.hits<<std::endl;
        if (s.signings==0 || s.flats==0 || s.hits!=0) return 1;
    }
}
