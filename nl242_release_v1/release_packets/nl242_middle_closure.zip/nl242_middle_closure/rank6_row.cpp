// Complete a six-bit Walsh row from allowed values of its spectrum divided by four.
// Each input line consists of 64 bitmasks; bit j permits the integer j-3.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <stdexcept>
#include <set>
#include <string>
#include <vector>

using Slice = std::array<int,16>;
using Options = std::array<std::vector<int>,64>;
using Groups = std::map<unsigned,std::vector<Slice>>;

static void walsh(Slice& x) {
    for (int step=1; step<16; step*=2)
        for (int start=0; start<16; start+=2*step)
            for (int i=start; i<start+step; ++i) {
                int left=x[i], right=x[i+step];
                x[i]=left+right; x[i+step]=left-right;
            }
}

static void slices(int start, int j, Slice& freq, const Options& opts, Groups& result) {
    if (j<16) {
        for (int v : opts[start+j]) {
            freq[j]=v; slices(start,j+1,freq,opts,result);
        }
        return;
    }
    Slice time=freq;
    walsh(time);
    unsigned parity=0;
    for (unsigned i=0; i<16; ++i) {
        if (time[i]%4 || std::abs(time[i])>16) return;
        time[i]/=4;
        parity|=unsigned(time[i]&1)<<i;
    }
    result[parity].push_back(time);
}

struct Pair { unsigned parity=0, sumTwo=0, diffTwo=0; };
static bool describe(const Slice& a, const Slice& b, Pair& p) {
    for (unsigned i=0; i<16; ++i) {
        int s=(a[i]+b[i])/2, d=(a[i]-b[i])/2;
        if (std::abs(s)>2 || std::abs(d)>2) return false;
        p.parity|=unsigned(s&1)<<i;
        p.sumTwo|=unsigned(std::abs(s)==2)<<i;
        p.diffTwo|=unsigned(std::abs(d)==2)<<i;
    }
    return true;
}

static void local_check() {
    for (int a=-4; a<=4; ++a) for (int b=-4; b<=4; ++b)
    for (int c=-4; c<=4; ++c) for (int d=-4; d<=4; ++d) {
        bool direct=true;
        for (int n : {a+b+c+d,a-b+c-d,a+b-c-d,a-b-c+d})
            direct &= n%4==0 && std::abs(n)<=4;
        bool grouped=false;
        if ((a&1)==(b&1) && (a&1)==(c&1) && (a&1)==(d&1)) {
            Slice A{a},B{b},C{c},D{d}; Pair p,q;
            grouped=describe(A,B,p) && describe(C,D,q) && p.parity==q.parity
                && !(p.sumTwo&q.sumTwo) && !(p.diffTwo&q.diffTwo);
        }
        if (direct!=grouped) throw std::logic_error("four-site inversion");
    }
}

using Signatures = std::set<std::pair<uint64_t,uint64_t>>;

static std::pair<uint64_t,uint64_t> signature(const std::array<const Slice*,4>& slices,
                                                uint64_t phase) {
    uint64_t two=0,negative=0;
    for (int b=0; b<4; ++b) {
        auto row=*slices[b];
        walsh(row);  // Four times the original frequency slice.
        for (int i=0; i<16; ++i) {
            uint64_t bit=uint64_t(1)<<(16*b+i);
            if (std::abs(row[i])==8) two|=bit;
            if (row[i]<0) negative|=bit;
        }
    }
    return {two,negative&phase};
}

static bool complete(Options opts, uint64_t phase, Signatures* signatures) {
    // Translation and overall sign independently fix signs on an affine basis.
    std::array<int,7> pivots{};
    for (int j=0; j<64; ++j) {
        auto& entries=opts[j];
        if (std::find(entries.begin(),entries.end(),0)!=entries.end()) continue;
        int column=64|j;
        for (int i=6; i>=0; --i) if ((column>>i)&1) {
            if (pivots[i]) column^=pivots[i];
            else {
                pivots[i]=column;
                entries.erase(std::remove_if(entries.begin(),entries.end(),
                    [](int v){return v<0;}),entries.end());
                break;
            }
        }
    }
    std::array<Groups,4> groups;
    for (int b=0; b<4; ++b) {
        Slice f{}; slices(16*b,0,f,opts,groups[b]);
    }
    for (auto& entry : groups[0]) {
        auto k=entry.first;
        std::array<const std::vector<Slice>*,4> g{};
        bool missing=false;
        for (int b=0; b<4; ++b) {
            auto it=groups[b].find(k);
            if (it==groups[b].end()) {missing=true; break;}
            g[b]=&it->second;
        }
        if (missing) continue;
        // Any permutation of four two-bit frequencies is affine, preserving
        // ternarity of their four-point inverse. Pair the lists by size.
        std::array<int,4> order{0,1,2,3};
        std::sort(order.begin(),order.end(),[&](int a,int b){return g[a]->size()<g[b]->size();});
        struct Entry { Pair pair; const Slice *a, *b; };
        std::map<unsigned,std::vector<Entry>> indexed;
        for (auto& a:*g[order[0]]) for (auto& b:*g[order[3]]) {
            Pair p;
            if (describe(a,b,p)) indexed[p.parity].push_back({p,&a,&b});
        }
        for (auto& c:*g[order[1]]) for (auto& d:*g[order[2]]) {
            Pair q;
            if (!describe(c,d,q)) continue;
            auto it=indexed.find(q.parity);
            if (it==indexed.end()) continue;
            for (const auto& item:it->second) {
                if ((item.pair.sumTwo&q.sumTwo) || (item.pair.diffTwo&q.diffTwo)) continue;
                if (!signatures) return true;
                std::array<const Slice*,4> original{};
                original[order[0]]=item.a; original[order[3]]=item.b;
                original[order[1]]=&c; original[order[2]]=&d;
                signatures->insert(signature(original,phase));
            }
        }
    }
    return false;
}

int main(int argc, char** argv) {
    bool list=argc==2 && std::string(argv[1])=="--signatures";
    if (argc!=1 && !list) return 2;
    local_check();
    for (;;) {
        uint64_t phase=0;
        if (list && !(std::cin>>phase)) return std::cin.eof() ? 0 : 1;
        Options opts; int mask;
        for (int j=0; j<64; ++j) {
            if (!(std::cin>>mask)) return !list && j==0 && std::cin.eof() ? 0 : 1;
            if (mask<=0 || mask>=128) return 2;
            for (int v=-3; v<=3; ++v) if ((mask>>(v+3))&1) {
                if (!((mask>>(3-v))&1)) return 2;
                opts[j].push_back(v);
            }
        }
        if (list) {
            Signatures found;
            complete(opts,phase,&found);
            std::cout<<found.size()<<"\n";
            for (auto [two,sign]:found) std::cout<<two<<" "<<sign<<"\n";
            std::cout<<std::flush;
        } else {
            std::cout<<(complete(opts,0,nullptr) ? "possible" : "excluded")<<std::endl;
        }
    }
}
