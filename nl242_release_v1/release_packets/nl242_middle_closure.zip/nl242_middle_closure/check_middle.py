"""Integer checks for the middle agreement counts. Run with Python 3.9 or newer."""

from functools import lru_cache
from itertools import combinations, product
from math import comb


def weight(x):
    return bin(x).count("1")


def walsh(values):
    out = list(values)
    step = 1
    while step < len(out):
        for start in range(0, len(out), 2 * step):
            for i in range(start, start + step):
                a, b = out[i], out[i + step]
                out[i], out[i + step] = a + b, a - b
        step *= 2
    return out


def binary_rank(vectors):
    basis = {}
    for v in vectors:
        while v and v.bit_length() in basis:
            v ^= basis[v.bit_length()]
        if v:
            basis[v.bit_length()] = v
    return len(basis)


def monomials(n, degree):
    return [m for m in range(1 << n) if weight(m) <= degree]


def standard_quad(x, pairs):
    return sum((x >> (2 * i)) & 3 == 3 for i in range(pairs)) % 2


def low_zero_checks():
    # The off-diagonal matrix of the normalized ten-point zero set is its own inverse.
    n = 8
    points = [0] + [1 << i for i in range(n)] + [255]
    moment = [sum((sum((x >> i & 1) * (x >> j & 1) for x in points) % 2) << j
                  for j in range(n)) for i in range(n)]
    assert moment == [255 ^ (1 << i) for i in range(n)]
    for i, row in enumerate(moment):
        assert sum((weight(row & col) % 2) << j for j, col in enumerate(moment)) == 1 << i
    q = [comb(weight(x), 2) % 2 for x in range(256)]
    assert all(q[x] == 0 for x in points) and q.count(0) == 136

    # Elliptic six-dimensional quotient, normalized by an affine change of frequency.
    zero = [x for x in range(64) if standard_quad(x, 3) == ((x & 1) ^ (x >> 1 & 1))]
    assert len(zero) == 28
    for degree, expected in ((1, 7), (2, 21)):
        rows = [sum((x & m == m) << j for j, x in enumerate(zero))
                for m in monomials(6, degree)]
        assert binary_rank(rows) == expected
    # A clean four-frequency group either has one peak or four equal magnitudes.
    for mag, expected in ((8, {(0, 0, 0, 8), (4, 4, 4, 4)}),
                          (12, {(0, 0, 0, 12), (6, 6, 6, 6)})):
        options = {tuple(sorted(abs(v) // 4 for v in walsh([mag * s for s in signs])))
                   for signs in product((-1, 1), repeat=4)}
        assert expected == options
    assert 36 * 12**2 > 64**2
    assert 32 * 12**2 > 64**2  # t=106 with four zeros and at most four dirty groups


def check_high_parity():
    # Fourth divided power of the quadratic part in symplectic coordinates.
    for rank in (0, 2, 4, 6, 8):
        h = [sum((x >> (2*i) & 3) == 3 for i in range(rank // 2))
             for x in range(256)]
        parity = sum(1 ^ ((v >> 1) & 1) ^ ((v >> 2) & 1) for v in h) % 2
        assert parity == (rank == 8)


def possible_zero_count(k, zeros):
    """Rank-four small masks span the affine cube and have no coloop."""
    if not 0 <= zeros <= 256 or k % 2:
        raise ValueError((k, zeros))
    if k < 10:
        return False
    if k == 10:
        # The only dependency contains all ten terms. Each of the 512 patterns
        # of a fixed sign parity occurs equally often after adjoining overall sign.
        choices = {sum(comb(10, w) for w in range(parity, 11, 2)
                       if (10-2*w) % 3 == 0) // 2 for parity in (0,1)}
        assert choices == {45, 126}
        return zeros in choices
    return True


SIGMA = tuple(1 - 2 * standard_quad(x, 2) for x in range(16))
assert walsh(SIGMA) == [4 * s for s in SIGMA]


@lru_cache(None)
def section_totals(h, positive):
    """Unordered frequency-coset sums forced by a signed input on the dual flat."""
    histograms = set()
    for plus in combinations(range(16), positive):
        remaining = [x for x in range(16) if x not in plus]
        for zeros in combinations(remaining, h - 2 * positive):
            defect = [0] * 16
            for x in plus:
                defect[x] = 2 * SIGMA[x]
            for x in zeros:
                defect[x] = SIGMA[x]
            histograms.add(tuple(sorted(20 + 2 * q * u for q, u in zip(SIGMA, walsh(defect)))))
    return histograms


@lru_cache(None)
def local_counts(total):
    return [(a, c) for a in range(17) for c in range(17 - a)
            if total >= 2 * a + c and (total - 2 * a - c) % 3 == 0
            and a + c + (total - 2 * a - c) // 3 <= 16]


@lru_cache(None)
def possible_small_counts(totals, k):
    counts = {(0, 0)}
    for total in totals:
        counts = {(a + i, c + j) for a, c in counts for i, j in local_counts(total)
                  if a + c + i + j <= k}
        if not counts:
            break
    return {a for a, c in counts if a + c == k}


def rank_four(t):
    surviving = []
    for k in range(0, 2 * (t - 100) + 1, 2):
        h = t - 100 - k // 2
        allowed_a = set()
        for p in range(h // 2 + 1):
            if possible_zero_count(k, t - h + 3 * p):
                for totals in section_totals(h, p):
                    allowed_a.update(possible_small_counts(totals, k))
        for a in sorted(allowed_a):
            c = k - a
            rest = 8 * t - 480 - 6 * a - 5 * c
            if rest >= 0 and rest % 3 == 0:
                surviving.append((a, rest // 3, c))
    return surviving


def main():
    low_zero_checks()
    check_high_parity()
    print("Rank 8, ten zeros force |Z| = 136. Rank 6, t = 108 fails the 64-site energy bound.")
    for t in (102, 104, 106, 108, 110):
        survivors = rank_four(t)
        if t <= 106:
            assert not survivors
        print(f"t={t}, rank 4: {len(survivors)} profiles pass the two high-block tests: {survivors}")


if __name__ == "__main__":
    main()
