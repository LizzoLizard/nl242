// Independent 256-point high spectrum check. Covers kernel dimensions 2, 3, 4
// and all ranks of the quadratic coefficient map on that kernel.
#include <algorithm>
#include <array>
#include <iostream>
#include <vector>

using Row = std::array<int,16>;
int pc(int v) { return __builtin_popcount(static_cast<unsigned>(v)); }
void transform(Row& a) {
    for (int h : {1,2,4,8}) for (int i=0;i<16;++i) if (!(i&h)) {
        int u=a[i], v=a[i+h]; a[i]=u+v; a[i+h]=u-v;
    }
}

struct Subspace { std::vector<int> basis, elements{0}; };
void subspaces(const Subspace& s, int n, int maxdim, std::vector<Subspace>& out) {
    out.push_back(s);
    if (int(s.basis.size())==maxdim) return;
    for (int v=s.elements.back()+1;v<(1<<n);++v) {
        if (std::any_of(s.elements.begin(),s.elements.end(),[v](int x){return (v^x)<v;})) continue;
        // Require a new, higher leading bit. This puts each subspace in echelon form.
        if (!s.basis.empty() && __builtin_clz(v)==__builtin_clz(s.basis.back())) continue;
        Subspace next=s;
        next.basis.push_back(v);
        for (int x:s.elements) next.elements.push_back(x^v);
        std::sort(next.elements.begin(),next.elements.end());
        subspaces(next,n,maxdim,out);
    }
}

Row sigma;
std::array<Row,1024> inner;
std::array<int,1024> masses;
void prepare() {
    std::vector<int> monomials;
    for (int deg:{2,3}) for (int m=1;m<16;++m) if (pc(m)==deg) monomials.push_back(m);
    for (int c=0;c<16;++c) sigma[c]=((c&3)==3)^((c&12)==12) ? -1:1;
    for (int a=0;a<1024;++a) {
        Row f=sigma;
        for (int c=0;c<16;++c) for (int i=0;i<10;++i)
            if ((a>>i&1) && (c&monomials[i])==monomials[i]) f[c]=-f[c];
        transform(f);
        for (int& v:f) { v=(v%3+4)%3-1; masses[a]+=v*v; }
        transform(f); inner[a]=f;
    }
}

struct Direct {
    long long candidates=0,hits=0;
    void test(const std::vector<int>& gens) {
        Row index{};
        int sum=0;
        for (int x=1;x<16;++x) {
            int i=__builtin_ctz(static_cast<unsigned>(x));
            index[x]=index[x^(1<<i)]^gens[i];
            int m=masses[index[x]];
            if (m%2) return;
            sum+=m;
        }
        if (sum!=132) return;
        ++candidates;
        for (int c=0;c<16;++c) {
            Row spectral{};
            spectral[0]=-4*sigma[c];
            for (int x=1;x<16;++x) spectral[x]=inner[index[x]][c];
            transform(spectral);
            int a=0,b=0;
            for (int v:spectral) {
                int signed_value=sigma[c]*v;
                if (signed_value==2) ++a;
                else if (signed_value==10) ++b;
                else if (signed_value!=-14) return;
            }
            if (a!=1 || b!=6) return;
        }
        ++hits;
    }
    void lift(std::vector<int>& gens,const Subspace& image,const std::vector<int>& reps,int i) {
        if (i==int(image.basis.size())) {test(gens);return;}
        for (int r:reps) {
            gens.push_back((image.basis[i]<<6)|r);
            lift(gens,image,reps,i+1);
            gens.pop_back();
        }
    }
};

int main() {
    prepare();
    std::vector<Subspace> quadratic,cubic;
    subspaces({},6,4,quadratic); subspaces({},4,2,cubic);
    if (quadratic.size()!=2761 || cubic.size()!=51) {
        std::cerr<<"subspaces "<<quadratic.size()<<" "<<cubic.size()<<"\n"; return 1;
    }
    for (int d:{2,3,4}) {
        Direct check;
        for (const auto& kernel:quadratic) {
            if (int(kernel.basis.size())>d) continue;
            std::vector<int> generators=kernel.basis, reps;
            generators.resize(d,0);
            for (int v=0;v<64;++v)
                if (std::none_of(kernel.elements.begin(),kernel.elements.end(),[v](int s){return (s^v)<v;}))
                    reps.push_back(v);
            for (const auto& image:cubic) if (int(image.basis.size())==4-d)
                check.lift(generators,image,reps,0);
        }
        std::cout<<"kernel dimension "<<d<<": mass-qualified "<<check.candidates
                 <<", full high spectra "<<check.hits<<std::endl;
        if (check.hits) return 1;
    }
}
