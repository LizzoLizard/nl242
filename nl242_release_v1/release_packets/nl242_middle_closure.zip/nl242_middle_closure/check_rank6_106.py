"""Enumerate the rank-six residue patterns at agreement count 106 (Python 3.8+)."""
from itertools import combinations, permutations, product
from pathlib import Path
import subprocess
import tempfile


def weight(x):
    return bin(x).count("1")


def bits(indices):
    return sum(1 << j for j in indices)


def sites(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask -= bit


def quad(x):
    return (weight(x & (x >> 1) & 21) + weight(x & 3)) % 2


ALL = (1 << 64) - 1
Z = bits(x for x in range(64) if quad(x) == 0)
F = ALL ^ Z
QUADRATICS = [bits(x for x in range(64) if x & m == m) for m in range(64) if weight(m) <= 2]


def decoder(domain):
    """Lift a restriction to one quadratic, and record the kernel."""
    rows, kernel = {}, []
    for word in QUADRATICS:
        while word & domain:
            pivot = (word & domain).bit_length()
            if pivot not in rows:
                rows[pivot] = word
                break
            word ^= rows[pivot]
        else:
            kernel.append(word)

    def lift(word):
        result = 0
        while word:
            pivot = word.bit_length()
            if pivot not in rows:
                return None
            result ^= rows[pivot]
            word ^= rows[pivot] & domain
        return result
    return lift, kernel


lift_z, kernel_z = decoder(Z)
lift_f, kernel_f = decoder(F)
assert kernel_z == [F] and kernel_f == [Z]


def transvection(v, x):
    dual = ((v & 21) << 1) | ((v & 42) >> 1)
    return x ^ (v if (1 ^ quad(v) ^ (weight(x & dual) % 2)) else 0)


PERMS = [tuple(transvection(v, x) for x in range(64)) for v in range(1, 64)]
assert all(sorted(p) == list(range(64)) and all(quad(x) == quad(p[x]) for x in range(64))
           for p in PERMS)


def move(word, perm):
    return bits(perm[x] for x in sites(word))


def orbit(word, perms):
    seen, queue = {word}, [word]
    for current in queue:
        for perm in perms:
            other = move(current, perm)
            if other not in seen:
                seen.add(other)
                queue.append(other)
    return seen


def small_words():
    result = {}
    for size in range(1, 7):
        words = set()
        for indices in combinations(sites(Z), size):
            word = bits(indices)
            if lift_z(word) is not None:
                words.add(word)
        result[size] = words
    assert [len(result[i]) for i in range(1, 7)] == [0, 0, 0, 315, 0, 6048]
    return result


def differences(limit, words):
    yield 0, 0
    for size in (4, 6):
        if size > limit:
            continue
        pending = words[size].copy()
        while pending:
            a = min(pending)
            pending -= orbit(a, PERMS)
            yield a, 0
    if limit >= 6:
        # Three nonzero words have total weight twice the union size.
        # Thus if independent, all three have weight four and the union has six.
        a = min(words[4])
        assert len(orbit(a, PERMS)) == len(words[4])
        for b in words[4]:
            if weight(a | b) == 6:
                yield a, b


def cell_options():
    options = {}
    for on_z, defects in product((False, True), range(5)):
        large, small = (2, 0) if on_z else (3, 1)
        entries = (small,) * defects + (large,) * (4 - defects)
        for m in set(permutations(entries)):
            for s in product((-1, 1), repeat=4):
                z = [sum(s[w]*m[w]*(-1)**(weight(x & w) % 2) for w in range(4)) for x in range(4)]
                if any(v % 4 for v in z):
                    continue
                h = tuple(abs(v)//4 for v in z)
                label = bits(i for i,v in enumerate(h) if v % 2)
                options.setdefault((on_z, defects, label), set()).add(h)
    return options


CELLS = cell_options()


def candidates(n0, n8, words):
    for a, b in differences(n0//2, words):
        used = weight(a | b)
        if (n0 - 2*used) % 4:
            continue
        u, v = lift_z(a), lift_z(b)
        for ntriple in range(n8+1):
            for exc in combinations(sites(F), ntriple):
                p = lift_f((u & v & F) ^ bits(exc))
                if p is None:
                    continue
                for first in (p, p ^ Z):
                    ps = (first, first ^ u, first ^ v, first ^ u ^ v ^ F)
                    if weight(Z & ~(ps[0] | ps[1] | ps[2] | ps[3])) < (n0-2*used)//4:
                        continue
                    floors = [0]*4
                    for c in range(64):
                        label = bits(i for i,h in enumerate(ps) if (h >> c) & 1)
                        if (Z >> c) & 1:
                            for i in range(4):
                                floors[i] += (label >> i) & 1
                        elif weight(label) == 1:
                            floors[label.bit_length()-1] += 9
                        else:
                            opts = CELLS[False,1,label]
                            for i in range(4):
                                floors[i] += min(h[i]**2 for h in opts)
                    if max(floors) <= 256 + 8*(n8-ntriple):
                        yield ps, ntriple


def scalar_options(p, dirty):
    result = []
    for c in range(64):
        odd, outside = (p >> c) & 1, (F >> c) & 1
        if not outside:
            vals = (1,) if odd else (0,2)
        elif dirty == c:
            vals = (1,) if odd else (0,2)
        else:
            vals = (3,) if odd else (0,)
        result.append(bits(v+3 for v in {s*v for v in vals for s in (-1,1)}))
    return tuple(result)


def check_affine_cut():
    for a in range(64):
        for b in (0,1):
            if not (a or b):
                continue
            cut = [x for x in sites(Z) if (weight(a & x)+b) % 2]
            if len(cut) <= 12:
                assert len(cut) == 12
                span = {0}
                for x in cut:
                    span |= {s ^ x ^ cut[0] for s in span}
                assert len(span) > 16


def row_jobs():
    check_affine_cut()
    words = small_words()
    jobs = set()
    for n0,n8 in ((8,2),(10,1),(12,0)):
        cases = list(candidates(n0,n8,words))
        print(f"({n0},{n8}): {len(cases)} quadratic patterns before row tests", flush=True)
        for ps, ntriple in cases:
            assert ntriple == 0
            inactive = [p for p in ps if not p & F]
            assert len(inactive) == 2 and inactive[0] == inactive[1]
            if inactive[0] == Z:
                # Each of these two rows has odd mass 7 until a dirty group
                # supplies one magnitude 8. A single group can supply only one.
                continue
            assert inactive[0] == 0
            active = sorted((p for p in ps if p & F), key=lambda p:(weight(p & F),-p))
            # Either active row suffices. The smaller hexadecimal representative
            # has the cheaper failed inversion in the equal-weight case.
            p = active[-1]
            if not n8:
                jobs.add(scalar_options(p, None))
                continue
            assert n8 == 2
            stabilizer = [perm for perm in PERMS if move(p, perm) == p]
            remaining = F
            while remaining:
                c = next(sites(remaining))
                orb = orbit(1 << c, stabilizer)
                remaining &= ~sum(orb)
                jobs.add(scalar_options(p, c))
    return sorted(jobs)


def main():
    jobs = row_jobs()
    source = Path(__file__).with_name("rank6_row.cpp")
    with tempfile.TemporaryDirectory() as tmp:
        exe = Path(tmp) / "row"
        subprocess.run(["c++","-O3","-std=c++17","-Wall","-Wextra","-pedantic",str(source),"-o",str(exe)],check=True)
        # A row constant on a 4-flat with magnitude four in the divided
        # spectrum would be out of range. Use an 8-site flat instead: its
        # eight nonzero Walsh entries are all magnitude eight.
        positive = [bits((1,5)) if c & 7 == 0 else 8 for c in range(64)]
        lines = [positive] + jobs
        text = "".join(" ".join(map(str,row))+"\n" for row in lines)
        run = subprocess.run([str(exe)],input=text,text=True,capture_output=True,check=True)
        verdicts = run.stdout.splitlines()
        assert verdicts == ["possible"] + ["excluded"] * len(jobs), verdicts
    print(f"positive control accepted; {len(jobs)} representative six-bit row problems excluded")


if __name__ == "__main__":
    main()
