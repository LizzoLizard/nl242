# Excluding agreement count 108

In the support-XOR coordinates of the balanced nine-variable problem, **there is no table with agreement count 108 and Walsh caps 24 and 28**. The same argument excludes ranks four and eight at both 104 and 106. Only rank six remains at those two counts.

Write V and U for the complementary signed agreement and disagreement tables on the eight-cube. Their support sizes are t and 256−t. The low and high blocks are twice their unnormalized Walsh transforms. The inputs from the existing reduction are balance, the caps, divisibility of the low transform by four, and the high transform being two modulo four. Thus H = Ũ/2 takes odd values of magnitude at most seven. Write Q = V̂/4 mod 2 and q = (−1)^((H−1)/2). The two quadratic phases have the same polar matrix. This also follows directly from the Walsh expansion in binary coordinates. The quadratic coefficients after division by four are the two-coordinate moments of the support modulo two, and the two complementary supports have the same moments. The proof below uses integer arithmetic throughout and does not require any exhaustive seven-variable section logs.

## Low block

Put Z = {Q=0}, z = |Z|, and let D have weight one at low zeros and weight two where |V̂|=4. Its total weight is n₀+2n₈, in the convention where n₈ counts coefficients of the original doubled low block. Comparing squares point by point and using Parseval gives

    V̂² = 144 − 80 1_Z − 64 D
    |D| = 576 − 5z/4 − 4t.

For a nonzero translation, the signed autocorrelation of V is even because pairs occur twice. At the zero translation it is t, also even. Transforming the first identity therefore gives, at every direction,

    5 · Walsh(1_Z) + 4 · Walsh(D) = 0 mod 32.

**Rank eight.** The possible sizes of Z are 120 and 136. Write Walsh(1_Z) = 128 δ₀ + 8s with s a quadratic sign with the inverse polar matrix. For completeness, if B is the nondegenerate polar form of Q, shifting a quadratic Walsh sum by Bx multiplies it by its linear character and a quadratic sign in x. This identifies the dual polar form with B inverse. The congruence gives Walsh(D) = −2s mod 8. For a direction u, let w(u) be the weight of D on u·a=1. Then w(u) is even, since 2w(u) = |D|−Walsh(D)(u). The Boolean function w(u)/2 mod 2 has the same polar matrix as s: it is one precisely when s(u) differs from s(0). Polarization of the integer weight gives its matrix off the diagonal as the two-coordinate incidence moments of the low zeros. The weight-two points disappear modulo two. The first moments of the zeros vanish, since all w(u) are even, and the number of zeros is even by the slack formula.

Consequently the incidence rows of the zero coordinates have rank eight. Together with the constant row they have rank nine (the zero frequency is a zero column of the coordinate rows). All nine rows are orthogonal to the all-ones vector, so n₀ ≥ 10. At equality take the origin and eight independent zero frequencies as an affine frame. The remaining zero is their sum. In this frame the off-diagonal moment matrix is the all-ones matrix plus the identity, which is its own inverse. As Q vanishes at zero and the eight unit vectors, Q(x) = binom(wt(x),2) mod 2 and z = 136. Thus z=120 requires at least twelve zeros. At t=104 and 106 the slack for z=120 is respectively 10 and 2. The other size already exceeds the energy budget. Both rank-eight cases are excluded. At 108 even z=120 exceeds the budget.

**Rank six at 108.** The only size within budget is z=112. Its radical W has dimension two, Q is invariant along W, and Walsh(1_Z) has non-DC magnitudes 16 on W-perp and zero elsewhere. The slack is four. The congruence and |Walsh(D)| ≤ 4 force magnitude four on W-perp, including DC, and zero off it. Parseval gives sum D² = 4 = sum D. All four defects are zeros. Equality in the triangle inequality forces all four to have identical character values throughout W-perp. As DC is a zero, their set is precisely W.

Use c for the six-dimensional frequency quotient by W, and x for the four input cells of size 64. Let z_x(c) be the Walsh transform on one cell after choosing linear complements. It is one quarter of the four-point Walsh transform of V̂(c,w) over w. The zero group gives four zeros. Each of the 27 other groups on Q=0 gives either one magnitude 8 or four magnitudes 4. Each of the 36 groups on Q=1 gives either one magnitude 12 or four magnitudes 6.

Every z_x is even. The function z_x/2 mod 2 is affine in c by integer Walsh expansion, and vanishes on the 28-point quotient quadric Q=0. That quadric affinely spans, so all z_x are divisible by four. Each of the 36 groups consequently has exactly one magnitude 12. The functions p_x = z_x/4 mod 2 are quadratic. Their pairwise sums vanish on Q=0 since the four parities there coincide. The only quadratics vanishing on that elliptic quadric are 0 and Q. The checker verifies this by binary Gaussian elimination: the 22-dimensional space of quadratics restricts with rank 21. Hence all pairwise parities are constant on Q=1. A weight-one four-bit vector is determined by its pairwise differences among weight-one vectors. The same input cell therefore receives all 36 peaks. Its spectral energy is at least 36·12² = 5184, exceeding 64² = 4096.

### Restrictions on the remaining profiles

At rank six and t=106 only z=112 fits. The defect weight is twelve. For all directions u, the weight w(u) of D on u·a=1 is divisible by four on W-perp and is two modulo four off W-perp. This follows from the same autocorrelation congruence above, since Walsh(D) is four modulo eight on W-perp and zero modulo eight elsewhere. Thus w/2 mod 2 is the Boolean OR of the two linear tests defining W-perp. Its polar form has rank two and image W. Polarizing also gives precisely the incidence moment matrix of the zeros since the small masks have even multiplicity. The zero locations have XOR zero.

If there were six zeros, the constant and coordinate incidence rows on these six points would span a code with Gram rank two. For a binary code of dimension m and length n the Gram rank is at least 2m−n, since its radical lies in the orthogonal complement. Hence m ≤ 4 here and the six points lie in an affine three-flat. Their complement in that flat is a pair of distinct points and has nonzero XOR, a contradiction. Two zeros are also impossible. For four zeros, XOR zero makes them a plane. Its incidence moment matrix has image its direction plane, so the zeros are exactly W. The preceding four-cell proof now works on the same 28 zero-side groups. There are at least 32 clean groups on the other side even after allowing four small masks, and 32·12² still exceeds 4096. Consequently the surviving low counts (n₀,n₈) at 106 are (8,2), (10,1), (12,0).

At rank four with z=96, all Walsh coefficients of D are divisible by eight. The zero set has even size, zero XOR and zero second incidence moments. Its augmented incidence code is self-orthogonal and has at most n₀/2 dimensions. Since the points are distinct it contains at most 2^(n₀/2−1) distinct columns with leading coordinate one. This excludes n₀=2,4,6. If n₀=8 the zeros must form an affine three-flat. If n₀=10, they lie in a four-flat and their six-point complement has the same vanishing moments, which was just excluded. In particular the n₈=5 and 6 branches from the pasted t=110 search are both impossible, as is n₈=3.

A separate parity test applies throughout the middle window. The number k=a+c of small high coefficients is odd exactly at rank eight. To see this, set h=(Ũ−2)/4. At the permitted high values, h ranges from −4 to 3 and the small-mask indicator is 1 XOR bit₁(h) XOR bit₂(h), using bits of the residue modulo eight. In the integer multilinear expansion of h on binary coordinates, a degree-d coefficient for d≥2 is divisible by 2^(d−2). Its quadratic coefficients modulo two form the phase polar matrix. Expand (1+z)^h modulo two through degree four in z, allowing negative exponents as formal series. Its coefficients at z² and z⁴ are bit₁ and bit₂. A monomial of coordinate degree d costs at least 2^max(d−2,0) powers of z to contribute. The only way to cover all eight coordinates at total cost four is to take four disjoint quadratic terms with odd coefficients. Their parity is the Pfaffian of the polar matrix, one exactly in full rank. Summing over the cube extracts the full-degree coefficient. In particular rank-six searches may discard odd k, and rank-eight searches may discard even k.

## High block at rank four

The normalized quadratic sign q has Walsh transform 64σ on a 16-point affine input flat R. By translations, character multiplication, overall sign and symplectic coordinates, take R to be linear and q(c,w)=q(c), with c,w four bits each. On the quotient take q(c) = (−1)^(c₁c₂+c₃c₄); its four-bit transform is 4σ with the same canonical sign. These operations preserve support size and permute absolute high frequencies. This high-only argument allows them independently of a balanced low signing.

Let A,B,C be the frequency sets of high magnitudes |H| = 1,5,3 in that order, with sizes a,b,c respectively. In formulas involving the quotient use a subscript for the counts within a frequency group. Write K=A∪C and k=|K|. Pointwise,

    qH = −7 + 8·1_A + 12·1_B + 4·1_C,
    6a+3b+5c = 8t−480.

Summation gives sum_R Uσ = t−116−k/2. Relative to U=−σ everywhere on R, the number of zeros plus twice the number p of aligned sites equals h=t−100−k/2. Thus k is even. Call the exceptional set E; its size is h−p.

**Every affine frequency hyperplane contains at least two members of K.** Otherwise restrict 2H to that hyperplane and invert in seven dimensions. The result T has |T|≤2 because it is a signed sum of two U sites. The restricted q has rank at most four and dual support of size at most 16. If the section has no small coefficient, inversion modulo three makes T zero outside those 16 sites. Its energy is at most 64, whereas Parseval gives at least 100. If it has one small coefficient, T agrees modulo three with a signed character s off the 16 sites. There T²+sT=2 and elsewhere T²+sT ≥ 0. Hence sum(T²+sT) ≥ 224. Parseval bounds sum T² ≤ 196, and |sum sT| ≤ 6 because the character is at the small frequency. This proves the claim. In particular K affinely spans eight dimensions after deleting any one member.

Define U₀ as the ternary representative of the signed character sum on K, with signs given by q on A and −q on C. Walsh inversion modulo three gives U₀=U off R and U₀σ = Uσ−1 mod 3 on R. Thus its zero count is t−h+3p. On R outside E, U=−U₀. At a zero of U, U₀=−σ; at an aligned site, U₀=0.

The span property forces k ≥ 10. For k=10 there is exactly one affine dependency, involving all ten terms. Adjoining an overall sign does not change the modular zero test. All sign patterns of one specified parity occur equally often, giving 45 or 126 zeros. Neither is compatible at 104, 106 or 108. For each larger k and each possible defect on R the four-bit transform of U restricted to R fixes, in every frequency group, the sum 2a_c+3b_c+c_c. It equals 20 + 2q(c)·Walsh(σ times defect)(c), where defect is 1 at a zero and 2 at an aligned site. The integer checker enumerates the sixteen group totals and all count allocations. At 106 the only larger k is 12 with h=0: each group needs sum 20 and hence at least one small mask, more than twelve in total. At 102 and 104 the upper bound on k is already below ten.

At 108 this leaves k=12,14,16. For k=16 there are no defects and every group has a single A, six B and nine coefficients of magnitude seven. For k=12 and 14 the following reconstruction tests even the profiles which survive the group counts.

### Twelve or fourteen small masks

The (binary, augmented) affine points of K are distinct columns of rank nine. Select an affine basis and order its nine points as 0,e₁,…,e₈. A generator of the dependency space has nine free columns followed by an identity matrix of size j=k−9. Every dependency is even and has weight at least four. All generator columns are nonzero by the hyperplane lemma. Permuting the nine basis points and the j extras preserves affine equivalence. The C++ verifier sorts the nine free columns and makes each next column minimal under swaps of as-yet indistinguishable axes of the identity. A lexicographically minimal sorted representative has this property. Even row weights force the XOR of the free columns. No assumption is made about inequivalence between different retained representatives.

Time translation and overall sign normalize the first nine character signs. For each of the remaining 2^j choices the code computes the number of zeros of U₀. If C is the dependency code and ε the sign choice, the count is

    256/3 · [1 + 2^(1−k) sum_{y in C} ε(y)(−3)^(wt(y)/2)].

To obtain it, average the filter (1+2 Re exp(2πi S/3))/3 for the signed sum S. Expand each factor as −1/2 plus its signed imaginary part. Only affine dependencies survive after averaging over the input and a harmless global sign. The verifier checks each retained zero count again by actually transforming the signed frequency list and reducing modulo three.

At k=12, E consists of two removals from supp U₀ or one addition. At k=14 it is one removal. Since Ũ is constant modulo four, the XOR of supp U is zero. This fixes the single site or the XOR of the pair. For a proposed edit, construct the binary matrix sum_{x in supp U} xxᵀ. Its diagonal vanishes and its off-diagonal entries are the polar coefficients of q by the Walsh expansion. Its image is the direction of R. Since E is nonempty, R is now determined completely. Flip U₀ on R outside E and try both signs of an added site. Finally check all 256 integer high coefficients.

| k | Eligible signed representatives | Candidate flats | Full high blocks |
|---|---:|---:|---:|
| 12 | 76 | 1,248 | 0 |
| 14 | 149,586 | 9,831 | 0 |

### Sixteen small masks

Write w(c) for the unique A frequency within group c. In input cell x define f_x(c)=q(c)(−1)^(x·w(c)). In the fifteen noncentral cells, U_x is obtained by taking the ternary representative of the four-bit Walsh transform of f_x. The central cell is U=−σ. The fifteen cell masses sum to 132. Their total mixed moment sum of Walsh(f_x)·U_x is 96: the sum over all cells is 32 by the sixteen signed A coefficients, and the central contribution is −64.

Both the sign-weight parity of f_x and the mass parity are linear functions of x vanishing at zero. For the former, take the product of f_x over c. For the latter, use any fixed group c: its local coefficient is congruent to the input cell mass modulo two. Writing it as the four-bit group inversion gives, off the central cell, q(c)(2χ_A(x)+3 sum_B χ_b(x))/2. With six B points this reduces modulo two to the linear test by the XOR of their w coordinates. The correction at the central cell is an even integer. The verifier enumerates all 65,536 four-bit sign tables and sums their exact mass and mixed-moment types, allowing both possible linear parities and their intersections. Both parities must vanish. The only remaining masses are 4, 10, 16.

Every x·w has degree at most three because its sign table has even weight. Affine additions in c can be removed from each component by an affine shear of the frequency coordinates; equivalently they translate or negate its four-bit transforms. Modulo these additions each component has six quadratic and four cubic coefficients. The kernel of the map x ↦ cubic part has some dimension d. On that kernel, the noncentral cells have mass 4 or 16. Off it all have mass 10. These identifications are checked for all 1,024 coefficient choices. If b is the number of mass-16 noncentral cells, the mass equation gives b=2^(d−1)−2, forcing d ≥ 2.

The direct verifier enumerates d=2,3,4. It takes every possible image of the kernel in the six quadratic coefficients, including noninjective maps. It takes every (4−d)-dimensional image in the four cubic coefficients. For each basis element of that image it takes every quadratic lift modulo the kernel image. A choice of basis in the four-dimensional input-cell index implements the normalization. The resulting 256-site table is tested by two successive four-bit Walsh transforms. Every quotient frequency must give the signed spectrum (one 2, six 10, nine −14). None do. The d=2 search had 193,840 mass-qualified maps; d=3 and 4 had none.

A second implementation tests the equivalent column condition: multiply each local high coefficient by f_x(c). In a noncentral cell the result is −2 or 4, as the four-bit table verifies. At x=0 it is −4. The locations taking value 4 must form a six-point difference set for each c, with all non-DC Walsh magnitudes two. For this second check d>2 can also be discarded because the rank-four predicate of an alternating 4×4 matrix is a quadratic Pfaffian. On the kernel the column indicator differs from that predicate exactly at zero, which would have degree d, whereas a six-point difference set in four variables is a bent quadratic. The direct verifier enumerates d>2 as well.

Finally, the quadratic phase bound leaves no additional rank at 108. At rank zero the maximum phase sum is already too small. At rank two equality forces k=0, and inversion modulo three would support U on only four sites despite |supp U|=148. At ranks zero and two the same phase bound is strictly violated at 104 and 106.

## Replay

From this directory, using local Python 3 and a C++17 compiler:

    python3 -B check_middle.py
    c++ -O3 -std=c++17 reconstruct_108.cpp -o /tmp/reconstruct_108
    /tmp/reconstruct_108
    python3 -B transversal_108.py
    c++ -O3 -std=c++17 transversal_direct.cpp -o /tmp/transversal_direct_108
    /tmp/transversal_direct_108

The checks use the Python and C++ standard libraries. The full-count conclusion here is specific to 108. At 104 and 106 the rank-six branch remains open.
