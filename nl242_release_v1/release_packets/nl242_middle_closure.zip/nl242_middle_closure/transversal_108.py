"""Exact t=108, k=16 transversal check using four-bit Walsh tables."""
from itertools import combinations

from check_middle import SIGMA, monomials, walsh, weight


def span_pair(n):
    for a, b in combinations(range(1, 1 << n), 2):
        if b < (a ^ b):
            yield (0, a, b, a ^ b)


def possibilities():
    masks = [m for m in monomials(4, 3) if weight(m) == 2]
    masks += [m for m in monomials(4, 3) if weight(m) == 3]
    entries = []
    for index in range(1024):
        signs = [SIGMA[c] * (-1)**sum((index >> i & 1) for i, m in enumerate(masks)
                                      if c & m == m) for c in range(16)]
        spectrum = walsh(signs)
        u = [(v+1) % 3 - 1 for v in spectrum]
        mixed = [a*b for a, b in zip(signs, walsh(u))]
        mass = sum(v*v for v in u)
        if set(mixed) <= {-2, 4}:
            row = sum((v == 4) << i for i, v in enumerate(mixed))
            assert weight(row) in (0, 8, 16)
            entries.append((mass, row))
        else:
            entries.append((mass, None))
    return entries


def parity_check():
    types = set()
    for mask in range(65536):
        f = [1-2*(mask >> i & 1) for i in range(16)]
        tf = walsh(f)
        u = [(v+1) % 3-1 for v in tf]
        mass = sum(v*v for v in u)
        mixed = sum(v*w for v,w in zip(tf,u))
        types.add((mass, mixed, mass % 2, weight(mask) % 2))
    # Each of the two parity functions of the outer coordinate is linear and zero at 0.
    # If nonzero their joint one-count is 8 (equal) or 4 (distinct).
    joint = {(0,0,0), (0,8,0), (8,0,0), (8,8,8), (8,8,4)}
    states = {(0,0,0,0,0)}
    for _ in range(15):
        states = {(m+d, s+v, o+a, b+f, h+a*f) for m,s,o,b,h in states
                  for d,v,a,f in types if m+d <= 132 and o+a <= 8 and b+f <= 8}
    allowed = {row[2:] for row in states if row[:2] == (132,96) and row[2:] in joint}
    assert allowed == {(0,0,0)}
    assert {(m,s) for m,s,o,f in types if o==f==0} == {(4,-32),(10,16),(16,64)}


def scan():
    data = possibilities()
    for index, (mass, row) in enumerate(data):
        if mass in (4,10,16):
            assert row is not None
            assert (index < 64) == (mass != 10)
        if index < 64:
            assert mass in (1,4,16)
    # On the kernel the rank-four predicate is the Pfaffian of a 4 by 4
    # alternating matrix. Directly check its degree in the six quadratic coefficients.
    pf = [int(data[i][0] == 16) for i in range(64)]
    for bit in (1,2,4,8,16,32):
        for x in range(64):
            if x & bit:
                pf[x] ^= pf[x ^ bit]
    assert all(not v or weight(x) <= 2 for x,v in enumerate(pf))
    tested = hits = 0
    first = None
    for kernel in span_pair(6):
        if any(data[i][0] != 4 for i in kernel[1:]):
            continue
        reps = [v for v in range(64) if v == min(v ^ k for k in kernel)]
        for _, p, q, _ in span_pair(4):
            for a in reps:
                left = (p << 6) | a
                if any(data[left ^ i][0] != 10 for i in kernel):
                    continue
                for b in reps:
                    right = (q << 6) | b
                    if any(data[v ^ i][0] != 10 for i in kernel for v in (right,left^right)):
                        continue
                    tested += 1
                    indices = [base ^ i for base in (0,left,right,left^right) for i in kernel]
                    rows = [data[index][1] for index in indices]
                    rows[0] = 0
                    good = True
                    for c in range(16):
                        col = [row >> c & 1 for row in rows]
                        if sum(col) != 6 or any(abs(v) != 2 for v in walsh(col)[1:]):
                            good = False
                            break
                    if good:
                        hits += 1
                        if first is None:
                            first = indices
    print(f"k=16: {tested} subspaces pass row tests, {hits} pass all 16 column tests")
    return first


if __name__ == "__main__":
    parity_check()
    first = scan()
    if first is not None:
        raise AssertionError(("transversal high completion", first))
