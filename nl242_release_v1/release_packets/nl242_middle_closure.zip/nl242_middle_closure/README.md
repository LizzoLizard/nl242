# Middle-window packet: t = 108 (all ranks), plus ranks 4 and 8 at t = 104 / 106 and rank 6 at t = 106 / 104

Contents and scope:
- `MIDDLE_PROOF.md` excludes agreement count `t = 108` outright:
  - rank 8 is excluded by the low-block energy budget;
  - rank 6 by the four-cell 36-peak energy bound (also formalized as Lean `Balanced242T108R6`);
  - rank 4 by the high-block tests plus exhaustive reconstruction for 12, 14 and 16 small
    masks.
- `MIDDLE_PROOF.md` also excludes ranks 4 and 8 at `t = 104` and `t = 106`.
- `RANK6_106.md` excludes rank 6 at `t = 106`.
- `check_rank6_104.py` excludes rank 6 at `t = 104`. It is a second route; the top packet
  also closes `t = 104`.

## Replay (from this directory; Python 3 and a C++17 compiler, standard libraries only)

    python3 -B check_middle.py
    c++ -O3 -std=c++17 reconstruct_108.cpp -o /tmp/reconstruct_108 && /tmp/reconstruct_108
    python3 -B transversal_108.py          # imports check_middle.py; do not use -I
    c++ -O3 -std=c++17 transversal_direct.cpp -o /tmp/transversal_direct_108 && /tmp/transversal_direct_108
    python3 -B check_rank6_106.py
    python3 -B check_rank6_104.py

## Independent replay (Colab CPU, 2026-11-22; every step exited with code 0)

- `check_middle.py`: at `t = 108` rank 4, 9 profiles pass the two high-block tests, with
  small-mask counts `k ∈ {12, 14, 16}`. Rank 8: ten zeros force `|Z| = 136`. Rank 6 at
  `t = 108` fails the 64-site energy bound.
- `reconstruct_108`:
  - `k = 12`: 290 geometry representatives, 76 eligible signings, 1,248 candidate flats,
    **0 high completions**;
  - `k = 14`: 706,100 / 149,586 / 9,831, **0 high completions**.
- `transversal_108.py` (`k = 16`): 193,840 subspaces, 0 pass the column tests.
- `transversal_direct`: 0 full high spectra (kernel dimensions 2, 3, 4).
- `check_rank6_106.py`: the positive control is accepted, and 7 representative six-bit row
  problems are excluded.
- `check_rank6_104.py`:
  - `(8,6)`: 130 parity/location cases, 4 pass the independent rows, 0 join;
  - `(4,8)`: excluded by energy;
  - `(10,5)`: excluded by the two-zero group count.

## Computer-assisted

The rank-4 cases at `t = 108` and the rank-6 cases at `t = 104` / `106` close by
exhaustive computer checks. Their correctness includes the correctness of these programs,
which ship as source.
