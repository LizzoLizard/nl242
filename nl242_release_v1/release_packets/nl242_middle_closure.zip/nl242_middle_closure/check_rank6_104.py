"""Exact rank-six low-block checks at 104 for 4, 8, and 10 zeros."""
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import subprocess
import sys
import tempfile

# Allow a direct offline replay with python -I.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from check_rank6_106 import (ALL, CELLS, F, PERMS, Z, bits, check_affine_cut, lift_f,
                             lift_z, move, sites, small_words, weight)


def compose(g, h):
    return tuple(g[x] for x in h)


def stabilizers(word, lifted):
    """Obtain verified symmetries fixing both the restriction and its chosen lift."""
    identity = tuple(range(64))
    maps, queue = {word:identity}, [word]
    for source in queue:
        for g in PERMS:
            image = move(source,g)
            if image not in maps:
                maps[image] = compose(g,maps[source])
                queue.append(image)
    assert len(maps) == 315
    inverses = {w:tuple(sorted(range(64),key=g.__getitem__)) for w,g in maps.items()}
    keep = {identity}
    for w,h in maps.items():
        for g in PERMS:
            perm = compose(inverses[move(w,g)],compose(g,h))
            if move(lifted,perm) == lifted:
                keep.add(perm)
    return sorted(keep)


def reduce_words(words, perms):
    # Removing only actual images preserves coverage even if perms is not a group.
    todo = set(words)
    while todo:
        word = min(todo)
        yield word
        todo.difference_update(move(word,g) for g in perms)


def odd_masks_six():
    # Enumerate the 21-dimensional image on F in Gray order.
    from check_rank6_106 import QUADRATICS
    basis = {}
    for q in QUADRATICS:
        w = q & F
        while w and w.bit_length() in basis:
            w ^= basis[w.bit_length()]
        if w:
            basis[w.bit_length()] = w
    vectors = list(basis.values())
    assert len(vectors) == 21
    counts = [0]*7
    six = set()
    w = 0
    for i in range(1 << len(vectors)):
        if i:
            w ^= vectors[(i & -i).bit_length()-1]
        size = weight(w)
        if size <= 6:
            counts[size] += 1
        if size == 6:
            six.add(w)
    assert counts == [1,0,0,0,0,0,336]
    return six


def fibers(b, perms, six):
    for e in reduce_words(six,perms):
        yield {c:1 for c in sites(e)}, e
    for word in reduce_words((bits(t) for t in combinations(sites(F),3)),perms):
        yield {c:2 for c in sites(word)}, 0
    todo = {(c,d) for c in sites(F) for d in sites(F) if c!=d}
    while todo:
        c,d = min(todo)
        yield {c:4,d:2}, 0
        todo.difference_update((g[c],g[d]) for g in perms)


def restrictions(parities, defects):
    opts = [[] for _ in range(4)]
    required = phase = 0
    for c in range(64):
        at_z = bool((Z >> c) & 1)
        label = bits(i for i,p in enumerate(parities) if (p>>c)&1)
        zeros = 2 if weight(label)==2 else 0
        k = zeros if at_z else defects.get(c,0)
        patterns = CELLS[at_z,k,label]
        profiles = {tuple(int(v==2) for v in v4) for v4 in patterns}
        if all(sum(row)==1 for row in profiles):
            required |= 1<<c
        else:
            assert all(sum(row)==0 for row in profiles)
        if all(all(row) for row in patterns):
            phase |= 1<<c
        for i in range(4):
            vals = {s*row[i] for row in patterns for s in (-1,1)}
            opts[i].append(bits(v+3 for v in vals))
    return tuple(map(tuple,opts)), required, phase


def phases(phase):
    pivots = {}
    for i in range(7):
        word = phase & (ALL if i==6 else bits(c for c in range(64) if (c>>i)&1))
        for j in sorted(pivots,reverse=True):
            if (word>>j)&1:
                word ^= pivots[j]
        if word:
            pivots[word.bit_length()-1] = word

    def reduce(word):
        for j in sorted(pivots,reverse=True):
            if (word>>j)&1:
                word ^= pivots[j]
        return word
    return reduce


def scalar_cost(row):
    return sum(min((j-3)**2 for j in sites(opt)) for opt in row)


def compatible(signatures, required, phase):
    reduce = phases(phase)
    rows = sorted(({(e,reduce(s)) for e,s in sig} for sig in signatures),key=len)

    def pairs(a,b):
        return {(e|f,s^t) for e,s in a for f,t in b if not e&f}
    left, right = pairs(rows[0],rows[3]), pairs(rows[1],rows[2])
    return any((required^e,reduce(phase)^s) in right for e,s in left)


def run(exe):
    # At most ten zeros force beta=0 by the same affine dimension bound.
    check_affine_cut()
    words = small_words()
    six = odd_masks_six()
    # With 4 zeros all pairwise differences vanish on Z. With 10 zeros the
    # union of two-zero sites would have odd size <=5, while the only
    # positive permissible union <=5 is four. With 8 zeros also test size four.
    for n0 in (4,8,10):
        possible = [d for d in (0,4) if 2*d<=n0 and (n0-2*d)%4==0]
        if 0 in possible:
            n8 = (20-n0)//2
            # One designated row: clean cost 9, defect k relieves at most 5k.
            assert 36*9-5*n8>256
        if n0==10:
            assert not possible
    b = lift_z(min(words[4]))
    perms = stabilizers(b&Z,b)
    with subprocess.Popen([str(exe)],text=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE) as scalar, \
         subprocess.Popen([str(exe),"--signatures"],text=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE) as joint:

        @lru_cache(None)
        def exists(row):
            scalar.stdin.write(" ".join(map(str,row))+"\n")
            scalar.stdin.flush()
            verdict = scalar.stdout.readline().strip()
            assert verdict in ("possible","excluded")
            return verdict == "possible"

        @lru_cache(None)
        def collect(row, phase):
            joint.stdin.write(" ".join(map(str,(phase,)+row))+"\n")
            joint.stdin.flush()
            n = int(joint.stdout.readline())
            return {tuple(map(int,joint.stdout.readline().split())) for _ in range(n)}

        tested = alone = together = 0
        for defects,e in fibers(b,perms,six):
            first = lift_f(e)
            for p in (first,first^Z):
                ps = (p,p^b,p,p^b^F)
                rows,required,phase = restrictions(ps,defects)
                tested += 1
                if any(scalar_cost(row)>256 for row in rows):
                    continue
                if not all(exists(row) for row in sorted(set(rows),key=lambda r:-r.count(65))):
                    continue
                alone += 1
                if compatible([collect(row,phase) for row in rows],required,phase):
                    together += 1
        scalar.stdin.close()
        joint.stdin.close()
        assert scalar.wait()==joint.wait()==0
    assert tested >= 100 and alone == 4 and together == 0, (tested,alone,together)
    print(f"(8,6): {tested} parity and location cases; {alone} pass independent rows; {together} join")
    print("(4,8) excluded by energy; (10,5) excluded by two-zero group count")


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory() as tmp:
        exe = Path(tmp)/"row"
        subprocess.run(["c++","-O3","-std=c++17","-Wall","-Wextra","-pedantic",str(root/"rank6_row.cpp"),"-o",str(exe)],check=True)
        run(exe)
